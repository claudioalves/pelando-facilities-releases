// "Histórico Keepa" on the backoffice deal page: for Amazon deals, the
// product's price over the last 180 days, read from Keepa's chart by the
// service worker (src/keepa/worker.js), and how the deal's price compares.
// Right below "Testar Promoção" (src/priceTest/panel.js), else below the
// deal's title field.
const PELANDO_KEEPA_CLASS = 'pelando-keepa';

// "R$ 1.299,00"; without cents when `cents` is false ("R$ 330").
function keepaMoney(value, cents) {
  const rounded = cents ? Math.round(value * 100) / 100 : Math.round(value);
  const parts = Math.abs(rounded).toFixed(cents ? 2 : 0).split('.');
  const whole = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, '.');
  return 'R$ ' + whole + (cents ? ',' + parts[1] : '');
}

// A price read from the chart: "≈ R$ 330", with cents under R$ 100
// ("≈ R$ 19,92").
function keepaApprox(value) {
  return '≈ ' + keepaMoney(value, value < 100);
}

const KEEPA_ERROR_TEXTS = {
  'sem-historico': 'O Keepa não tem histórico deste produto.',
  'sem-asin': 'Não achei o código do produto (ASIN) no link.',
  rede: 'Não consegui falar com o Keepa.',
  'nao-li-eixo': 'Não consegui ler os números; confira pela imagem.',
  'leitura-incoerente': 'Não consegui ler os números; confira pela imagem.',
};

function keepaElement(doc, tag, className, text) {
  const el = doc.createElement(tag);
  if (className) el.className = PELANDO_KEEPA_CLASS + '-' + className;
  if (text !== undefined) el.textContent = text;
  return el;
}

function keepaRow(doc, label, value) {
  const row = keepaElement(doc, 'div', 'row');
  row.append(keepaElement(doc, 'span', 'label', label), keepaElement(doc, 'span', 'value', value));
  return row;
}

// The verdict's line, from stats.verdict (src/keepa/stats.js).
function keepaVerdictText(stats) {
  const verdict = stats.verdict;
  if (verdict.kind === 'ok') return 'Menor preço dos últimos 180 dias';
  if (verdict.kind === 'slight') {
    return 'Perto do menor preço: ' + keepaApprox(verdict.difference) + ' acima do mínimo de ' + stats.lowest.date;
  }
  return (
    'Já esteve ' +
    keepaMoney(verdict.difference, verdict.difference < 100) +
    ' mais barato (' +
    keepaApprox(stats.lowest.price) +
    ' em ' +
    stats.lowest.date +
    ')'
  );
}

function keepaChart(doc, image) {
  const chart = keepaElement(doc, 'img', 'chart');
  chart.src = image;
  chart.alt = 'Gráfico de preços do Keepa, últimos 180 dias';
  chart.title = 'Clique para ampliar';
  chart.addEventListener('click', function () {
    chart.classList.toggle(PELANDO_KEEPA_CLASS + '-chart--zoomed');
  });
  return chart;
}

function keepaFooter(doc, asin) {
  const footer = keepaElement(doc, 'div', 'footer', 'Valores ≈ lidos do gráfico do Keepa · ');
  const link = keepaElement(doc, 'a', 'link', 'Abrir no Keepa ↗');
  link.href = 'https://keepa.com/#!product/12-' + asin;
  link.target = '_blank';
  link.rel = 'noopener noreferrer';
  footer.appendChild(link);
  return footer;
}

// Fills the card's body with the service worker's response (or an error
// text). request: { url, price, coupon } sent for it.
function renderKeepaReport(body, response, request, retry) {
  const doc = body.ownerDocument;
  body.textContent = '';
  if (!response.ok) {
    body.appendChild(keepaElement(doc, 'div', 'message', KEEPA_ERROR_TEXTS[response.error] || KEEPA_ERROR_TEXTS.rede));
    if (response.error === 'rede') {
      const again = keepaElement(doc, 'button', 'retry', 'Tentar de novo');
      again.type = 'button';
      again.addEventListener('click', retry);
      body.appendChild(again);
    }
    if (response.image) body.appendChild(keepaChart(doc, response.image));
    if (response.image && response.asin) body.appendChild(keepaFooter(doc, response.asin));
    return;
  }
  const stats = response.stats;
  if (stats.verdict) {
    body.appendChild(keepaElement(doc, 'div', 'verdict ' + PELANDO_KEEPA_CLASS + '-verdict--' + stats.verdict.kind, keepaVerdictText(stats)));
  }
  if (stats.cheaperSince) body.appendChild(keepaElement(doc, 'div', 'since', 'Mais barato desde ' + stats.cheaperSince));
  if (typeof request.price === 'number') {
    body.appendChild(
      keepaRow(doc, 'Anunciado no Pelando', keepaMoney(request.price, true) + (request.coupon ? ' (cupom ' + request.coupon + ')' : ''))
    );
  }
  body.appendChild(
    keepaRow(
      doc,
      request.coupon ? 'Hoje na Amazon, sem cupom' : 'Hoje na Amazon',
      keepaApprox(stats.today) + (stats.couponSaves ? ' → o cupom tira ' + keepaApprox(stats.couponSaves) : '')
    )
  );
  body.appendChild(keepaRow(doc, 'Menor em 180 dias', keepaApprox(stats.lowest.price) + ' em ' + stats.lowest.date));
  body.appendChild(keepaRow(doc, 'Média em 180 dias', keepaApprox(stats.average)));
  const ago = [
    ['Há 1 mês', stats.ago[30]],
    ['Há 3 meses', stats.ago[90]],
    ['Há 6 meses', stats.ago[180]],
  ]
    .map(function (pair) {
      return pair[0] + ' ' + (pair[1] === null ? '—' : keepaApprox(pair[1]));
    })
    .join(' · ');
  body.appendChild(keepaElement(doc, 'div', 'ago', ago));
  body.appendChild(
    request.coupon
      ? keepaElement(
          doc,
          'div',
          'coupon ' + PELANDO_KEEPA_CLASS + '-coupon--long',
          '⚠️ O Keepa não considera cupom. O preço anunciado usa o cupom ' + request.coupon + '; o histórico é sempre sem cupom.'
        )
      : keepaElement(doc, 'div', 'coupon', 'Os preços do Keepa não consideram cupom.')
  );
  body.appendChild(keepaChart(doc, response.image));
  body.appendChild(keepaFooter(doc, response.asin));
}

// The card for one deal: hidden until the deal turns out to be from Amazon.
function createKeepaCard(doc, dealId, deps) {
  const card = doc.createElement('div');
  card.className = PELANDO_KEEPA_CLASS;
  card.dataset.dealId = dealId;
  card.hidden = true;
  const header = keepaElement(doc, 'div', 'header');
  const toggle = keepaElement(doc, 'button', 'toggle', '▾');
  toggle.type = 'button';
  toggle.title = 'Recolher';
  header.append(keepaElement(doc, 'span', 'title', '📈 Histórico Keepa · 180 dias'), toggle);
  const body = keepaElement(doc, 'div', 'body');
  card.append(header, body);
  toggle.addEventListener('click', function () {
    body.hidden = !body.hidden;
    toggle.textContent = body.hidden ? '▸' : '▾';
    toggle.title = body.hidden ? 'Abrir' : 'Recolher';
  });

  // The moderation summary (src/summary): a failure there leaves the card be.
  function publish(response) {
    try {
      deps.publish(dealId, response);
    } catch (err) {
      console.warn('[pelando-chat-ext] resumo da moderação falhou:', err);
    }
  }

  function load(request, fresh) {
    body.textContent = '';
    body.appendChild(keepaElement(doc, 'div', 'message', 'Buscando histórico no Keepa…'));
    publish(null);
    deps
      .report({ url: request.url, price: request.price, coupon: request.coupon, fresh: fresh })
      .then(
        function (response) {
          return response || { ok: false, asin: null, image: null, error: 'rede' };
        },
        function () {
          return { ok: false, asin: null, image: null, error: 'rede' };
        }
      )
      .then(function (response) {
        const retry = function () {
          load(request, true);
        };
        try {
          renderKeepaReport(body, response, request, retry);
        } catch (err) {
          // A malformed answer must not leave the card on "Buscando…".
          response = { ok: false, asin: null, image: null, error: 'rede' };
          body.textContent = '';
          renderKeepaReport(body, response, request, retry);
        }
        publish(response);
      });
  }

  deps.fetchDeal(dealId).then(
    function (deal) {
      if (storeBrandFor(deal) !== 'amazon') return;
      card.hidden = false;
      load(
        {
          url: deal.sourceUrl || deal.redirectUrl || null,
          price: typeof deal.price === 'number' ? deal.price : null,
          coupon: deal.couponCode || null,
        },
        false
      );
    },
    function () {}
  );
  return card;
}

// Where the card goes: no title field (priceTestTitleField), no card. Down the
// chain title → moderation summary → "Testar Promoção", the last of them that
// sits right after the one before (the box only when not floating).
function keepaAnchor(doc) {
  const title = priceTestTitleField(doc);
  if (!title) return null;
  let anchor = title;
  const summary = anchor.nextElementSibling;
  if (summary && summary.classList.contains('pelando-summary')) anchor = summary;
  const test = anchor.nextElementSibling;
  if (
    test &&
    test.classList.contains(PELANDO_PRICE_TEST_CLASS) &&
    !test.classList.contains(PELANDO_PRICE_TEST_CLASS + '--floating')
  ) {
    anchor = test;
  }
  return anchor;
}

// One card, for the deal in the URL (the backoffice is a single-page app).
function syncKeepaReport(doc, pathname, deps) {
  const dealId = backofficeDealIdFromPath(pathname);
  let card = doc.querySelector('.' + PELANDO_KEEPA_CLASS);
  if (card && card.dataset.dealId !== dealId) {
    card.remove();
    card = null;
  }
  if (!dealId) return;
  const anchor = keepaAnchor(doc);
  if (!anchor) return;
  if (!card) card = createKeepaCard(doc, dealId, deps);
  if (anchor.nextElementSibling !== card) anchor.insertAdjacentElement('afterend', card);
}

const pelandoKeepaDeps = {
  fetchDeal: function (dealId) {
    return fetchDealById(dealId);
  },
  report: function (request) {
    return sendExtensionMessage({ type: 'keepaReport', request: request });
  },
  publish: function (dealId, response) {
    publishSummarySignal(dealId, summarySignalFromKeepa(response));
  },
};

if (typeof module !== 'undefined' && module.exports) {
  module.exports = { keepaMoney, keepaApprox, keepaVerdictText, renderKeepaReport, syncKeepaReport, KEEPA_ERROR_TEXTS };
}
