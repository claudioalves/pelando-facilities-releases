// Turns a Keepa price chart (graph.keepa.com, see graph.js) into prices: one
// per day for the chart's days, plus today's. Uses keepaLevel and
// keepaReadNumber (digits.js). Runs in the service worker (importScripts).
//
// The chart: a black frame around the plot; the prices written left of the
// frame ("R$ 700"), the top of their digits 4 rows above their grid line;
// the price lines inside (orange "Amazon", blue "New", a brownish mix where
// both overlap) over a pale orange fill; a dot on the right border at
// today's price of each line.

function keepaIsBlack(img, x, y) {
  const i = (y * img.width + x) * 4;
  return img.data[i] < 40 && img.data[i + 1] < 40 && img.data[i + 2] < 40;
}

// The frame: its bottom is the lowest row black across most of the picture,
// its sides the ends of that row's longest black stretch (the bottom price
// is written on the same row), its top the first row black across it.
// null when there's no frame: Keepa's "no price history" picture.
function keepaFindFrame(img) {
  let bottom = -1;
  for (let y = img.height - 1; y >= 0 && bottom < 0; y--) {
    let black = 0;
    for (let x = 0; x < img.width; x++) if (keepaIsBlack(img, x, y)) black++;
    if (black > img.width * 0.6) bottom = y;
  }
  if (bottom < 0) return null;
  let left = -1;
  let right = -1;
  for (let x = 0, start = -1; x <= img.width; x++) {
    const black = x < img.width && keepaIsBlack(img, x, bottom);
    if (black && start < 0) start = x;
    if (!black && start >= 0) {
      if (x - 1 - start > right - left) {
        left = start;
        right = x - 1;
      }
      start = -1;
    }
  }
  let top = -1;
  for (let y = 0; y < bottom && top < 0; y++) {
    let black = 0;
    for (let x = left; x <= right; x++) if (keepaIsBlack(img, x, y)) black++;
    if (black > (right - left) * 0.6) top = y;
  }
  if (top < 0 || bottom - top < 100) return null;
  return { left: left, right: right, top: top, bottom: bottom };
}

// Rows y0..y1 with dark pixels between columns x0..x1, as [first, last]
// stretches.
function keepaTextRows(img, x0, x1, y0, y1) {
  const stretches = [];
  let start = -1;
  for (let y = y0; y <= y1 + 1; y++) {
    let ink = false;
    for (let x = x0; x <= x1 && y <= y1 && !ink; x++) if (keepaLevel(img, x, y) >= 2) ink = true;
    if (ink && start < 0) start = y;
    if (!ink && start >= 0) {
      stretches.push([start, y - 1]);
      start = -1;
    }
  }
  return stretches;
}

// The prices written left of the frame, top to bottom: [{ y, value }] with y
// the row of the grid line. All are right-aligned to the same column; value
// is null when it doesn't read.
function keepaReadAxis(img, frame) {
  const y0 = Math.max(0, frame.top - 6);
  const y1 = Math.min(img.height - 1, frame.bottom + 6);
  const labels = keepaTextRows(img, 0, frame.left - 1, y0, y1)
    .filter(function (rows) {
      return rows[1] - rows[0] >= 7;
    })
    .map(function (rows) {
      let first = 0;
      for (; first < frame.left; first++) {
        let ink = false;
        for (let y = rows[0]; y <= rows[1] && !ink; y++) if (keepaLevel(img, first, y) >= 2) ink = true;
        if (ink) break;
      }
      // The top of the "R", as tall as the digits.
      let top = rows[0];
      for (; top <= rows[1]; top++) {
        let ink = false;
        for (let x = first; x < first + 5 && !ink; x++) if (keepaLevel(img, x, top) >= 2) ink = true;
        if (ink) break;
      }
      return { first: first, top: top };
    });
  let right = -1;
  labels.forEach(function (label) {
    for (let x = frame.left - 1; x > label.first + 12; x--) {
      let ink = false;
      for (let y = label.top; y < label.top + 8 && !ink; y++) if (keepaLevel(img, x, y) > 0) ink = true;
      if (ink) {
        right = Math.max(right, x);
        break;
      }
    }
  });
  return labels.map(function (label) {
    // "R$ " takes the label's first 12 columns.
    const text = keepaReadNumber(img, right, label.top, label.first + 12);
    return { y: label.top + 4, value: keepaNumberValue(text) };
  });
}

// The axis is trusted when at least 2 prices read, they go down in equal
// steps and their grid lines are equally spaced (to a pixel).
function keepaAxisIsSound(axis) {
  if (axis.length < 2) return false;
  if (axis.some((label) => label.value === null)) return false;
  const step = axis[0].value - axis[1].value;
  const gap = axis[1].y - axis[0].y;
  if (!(step > 0) || !(gap > 0)) return false;
  for (let i = 1; i < axis.length; i++) {
    if (Math.abs(axis[i - 1].value - axis[i].value - step) > step / 1000) return false;
    if (Math.abs(axis[i].y - axis[i - 1].y - gap) > 1) return false;
  }
  return true;
}

// A pixel of a price line: not the white background, not the pale orange
// fill (nor the grid seen through it), and colored. Greys are the grid, the
// month ticks, the frame and the text.
function keepaIsLinePixel(r, g, b) {
  if (r >= 235 && g >= 200 && b >= 170) return false;
  return Math.max(r, g, b) - Math.min(r, g, b) >= 25;
}

function keepaLineAt(img, x, y) {
  const i = (y * img.width + x) * 4;
  return keepaIsLinePixel(img.data[i], img.data[i + 1], img.data[i + 2]);
}

// { ok: true, prices, today } or { ok: false, error }.
// prices[d] is the lowest price on day d, 0 the chart's first day and `days`
// today, null on days without a line (nothing on sale). It's the lowest of
// the lines: Amazon or any seller of a new one. today is the lowest of the
// dots on the right border, null when there's none.
// Errors: 'sem-historico' (no chart), 'nao-li-eixo' (prices unreadable),
// 'leitura-incoerente' (no line, or a dot off the lines).
function keepaParseGraph(img, days) {
  const frame = keepaFindFrame(img);
  if (!frame) return { ok: false, error: 'sem-historico' };
  const axis = keepaReadAxis(img, frame);
  if (!keepaAxisIsSound(axis)) return { ok: false, error: 'nao-li-eixo' };
  const first = axis[0];
  const last = axis[axis.length - 1];
  const perPixel = (first.value - last.value) / (last.y - first.y);
  const priceAt = (y) => first.value + (first.y - y) * perPixel;

  const left = frame.left + 1;
  const right = frame.right - 1;
  const prices = new Array(days + 1).fill(null);
  for (let x = left; x <= right; x++) {
    const day = Math.round(((x - left) / (right - left)) * days);
    let lowest = -1;
    for (let y = frame.top + 1; y < frame.bottom; y++) if (keepaLineAt(img, x, y)) lowest = y;
    if (lowest < 0) continue;
    const price = priceAt(lowest);
    if (prices[day] === null || price < prices[day]) prices[day] = price;
  }
  if (prices.every((p) => p === null)) return { ok: false, error: 'leitura-incoerente' };

  // Today's dots: colored stretches just right of the frame, each centered
  // on a line's price, each touching a line in the plot's last columns.
  const dots = [];
  for (let y = frame.top; y < frame.bottom; y++) {
    let colored = false;
    for (let x = frame.right + 1; x <= Math.min(img.width - 1, frame.right + 4) && !colored; x++) colored = keepaLineAt(img, x, y);
    const open = dots.length > 0 && dots[dots.length - 1].end === y - 1;
    if (colored && open) dots[dots.length - 1].end = y;
    else if (colored) dots.push({ start: y, end: y });
  }
  let today = null;
  for (const dot of dots) {
    const middle = Math.round((dot.start + dot.end) / 2);
    let onLine = false;
    for (let x = right - 2; x <= right && !onLine; x++) {
      for (let y = middle - 2; y <= middle + 2 && !onLine; y++) onLine = keepaLineAt(img, x, y);
    }
    if (!onLine) return { ok: false, error: 'leitura-incoerente' };
    const price = priceAt((dot.start + dot.end) / 2);
    if (today === null || price < today) today = price;
  }
  return { ok: true, prices: prices, today: today };
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = { keepaFindFrame, keepaReadAxis, keepaAxisIsSound, keepaIsLinePixel, keepaParseGraph };
}
