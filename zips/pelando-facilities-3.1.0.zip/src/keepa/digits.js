// Reads the numbers on the price axis of a Keepa chart (graph.keepa.com):
// "R$ 700", "R$ 3,400", "R$ 12". Each digit sits in a 6-pixel cell and is
// drawn the same way wherever it appears, so a cell is compared with one
// drawing per digit. Runs in the service worker (importScripts).
//
// A picture is { width, height, data } with RGBA bytes, like ImageData.

// Darkness of a pixel in 5 steps: 0 white … 4 black.
function keepaLevel(img, x, y) {
  const i = (y * img.width + x) * 4;
  const luma = (img.data[i] * 299 + img.data[i + 1] * 587 + img.data[i + 2] * 114) / 1000;
  if (luma > 235) return 0;
  if (luma > 190) return 1;
  if (luma > 140) return 2;
  if (luma > 90) return 3;
  return 4;
}

// The digits as Keepa draws them on the axis, 6 columns by 8 rows from the
// top of the digits, in the steps of keepaLevel: . : + * #
function keepaDigitDrawings() {
  return {
    0: ['.+##+.', '.#:.#:', '+#..**', '+*..+*', '+*..+*', '+#..**', ':#..#+', '.*##*.'],
    1: ['..+#..', '.#*#..', '..:#..', '..:#..', '..:#..', '..:#..', '..:#..', '..:#..'],
    2: ['.+##*.', '+#..#+', ':+..#+', '...:#.', '...#+.', '..#+..', '.**...', '+####*'],
    3: ['.+##+.', ':#..#:', '::..#+', '..+*#.', '..+*#.', '....*+', '+#..#+', '.###*.'],
    4: ['...+#.', '..:##.', '..#+#.', '.+*:#.', ':#.:#.', '*#*##*', ':::+#:', '...:#.'],
    5: ['.*###+', '.*+::.', '.#:...', '.####:', '.:..**', '....+#', '.#..**', '.+###:'],
    6: ['..+#+.', '.*#:..', '.#:...', ':####.', '+#..**', ':#..+*', '.#:.*+', '.+###.'],
    7: ['*####*', '....*+', '...:#.', '...**.', '...#..', '..+*..', '..#:..', '.+#...'],
    8: ['.+##*.', ':#:.#:', ':#..#+', '.***#.', '.#**#:', '+#..**', '+#..**', '.*###.'],
    9: ['.+##+.', ':#.:#:', '+*..*+', '+#..*+', '.#**#+', '..+:#:', '...+#.', '.+##:.'],
  };
}

// How far the cell whose right column is `right` (digits' top at `top`) is
// from each drawing; the closest digit and its distance.
function keepaClosestDigit(img, right, top) {
  const steps = { '.': 0, ':': 1, '+': 2, '*': 3, '#': 4 };
  const drawings = keepaDigitDrawings();
  let best = { digit: null, distance: Infinity };
  Object.keys(drawings).forEach(function (digit) {
    let distance = 0;
    drawings[digit].forEach(function (row, y) {
      for (let x = 0; x < 6; x++) distance += Math.abs(steps[row[x]] - keepaLevel(img, right - 5 + x, top + y));
    });
    if (distance < best.distance) best = { digit: digit, distance: distance };
  });
  return best;
}

// A cell this close to a drawing is that digit.
const KEEPA_DIGIT_MAX_DISTANCE = 8;

// The number written right-aligned at column `right` (its last digit's
// right column), digits' top at `top`, reading leftwards no further than
// `stopX`: "3,400", "12", "" when nothing reads. A "," or "." between digits
// shifts the cells by a few columns; the mark is "," when it reaches below
// the digits.
function keepaReadNumber(img, right, top, stopX) {
  let text = '';
  let x = right;
  while (x - 5 >= stopX) {
    const here = keepaClosestDigit(img, x, top);
    if (here.distance <= KEEPA_DIGIT_MAX_DISTANCE) {
      text = here.digit + text;
      x -= 6;
      continue;
    }
    let shift = 0;
    for (let s = 1; s <= 4 && !shift; s++) {
      if (x - s - 5 >= stopX && keepaClosestDigit(img, x - s, top).distance <= KEEPA_DIGIT_MAX_DISTANCE) shift = s;
    }
    if (!shift || !text) break;
    let below = false;
    for (let mx = x - shift + 1; mx <= x; mx++) {
      for (let y = top + 8; y < top + 10; y++) if (keepaLevel(img, mx, y) >= 2) below = true;
    }
    text = (below ? ',' : '.') + text;
    x -= shift;
  }
  return text;
}

// "3,400" → 3400, "12.5" → 12.5; null when there are no digits. Keepa writes
// numbers the American way: "," groups thousands, "." starts the decimals.
function keepaNumberValue(text) {
  if (!/^(\d{1,3}(,\d{3})+|\d+)(\.\d+)?$/.test(String(text || ''))) return null;
  return Number(text.replace(/,/g, ''));
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = { keepaLevel, keepaClosestDigit, keepaReadNumber, keepaNumberValue, KEEPA_DIGIT_MAX_DISTANCE };
}
