// The Keepa card's work in the service worker: downloads the chart of the
// deal's product, reads it (parse.js) and works out the numbers (stats.js).
// Pages can't read pictures from other sites; the service worker can.
// Nothing is stored but a memory cache that dies with the service worker.
const KEEPA_TIMEOUT_MS = 10000;
const KEEPA_CACHE_MS = 30 * 60 * 1000;
// By ASIN: { at, image, parsed }.
const keepaCache = new Map();

// fetch that gives up after KEEPA_TIMEOUT_MS; resolves null on any failure.
// readBody(response), when given, runs inside the same deadline (a stalled
// or failing body counts as a failure) and its result is what resolves.
async function keepaFetch(url, deps, readBody) {
  const controller = new AbortController();
  let timer;
  const deadline = new Promise(function (resolve, reject) {
    timer = setTimeout(function () {
      controller.abort();
      reject(new Error('timeout'));
    }, KEEPA_TIMEOUT_MS);
  });
  const work = (async function () {
    const response = await deps.fetch(url, { credentials: 'omit', signal: controller.signal });
    return readBody ? readBody(response) : response;
  })();
  work.catch(function () {});
  try {
    return await Promise.race([work, deadline]);
  } catch (err) {
    return null;
  } finally {
    clearTimeout(timer);
  }
}

// The chart's bytes and blob, or null when the answer is not a PNG.
async function keepaReadPng(response) {
  const type = response && response.headers ? String(response.headers.get('content-type') || '') : '';
  if (!response || !response.ok || type.indexOf('image/png') !== 0) return null;
  const blob = await response.blob();
  return { blob: blob, bytes: new Uint8Array(await blob.arrayBuffer()) };
}

// "data:image/png;base64,…" of the bytes.
function keepaDataUrl(bytes) {
  let binary = '';
  for (let i = 0; i < bytes.length; i += 0x8000) {
    binary += String.fromCharCode.apply(null, bytes.subarray(i, i + 0x8000));
  }
  return 'data:image/png;base64,' + btoa(binary);
}

// RGBA pixels of a PNG, as Chrome draws it, untouched by color management.
async function keepaDecodeWithCanvas(blob) {
  const bitmap = await createImageBitmap(blob, { colorSpaceConversion: 'none', premultiplyAlpha: 'none' });
  const canvas = new OffscreenCanvas(bitmap.width, bitmap.height);
  try {
    const context = canvas.getContext('2d');
    context.drawImage(bitmap, 0, 0);
    const data = context.getImageData(0, 0, bitmap.width, bitmap.height).data;
    return { width: bitmap.width, height: bitmap.height, data: data };
  } finally {
    if (typeof bitmap.close === 'function') bitmap.close();
  }
}

// request: { url, price, coupon, fresh } from the deal page (keepa/panel.js).
// deps: { fetch, decode(blob) → picture, now() → ms }.
// Resolves { ok: true, asin, image, stats } or { ok: false, asin, image, error }
// with error 'sem-asin', 'rede', 'sem-historico', 'nao-li-eixo' or
// 'leitura-incoerente'. image is the chart (a data URL) when there's one to show.
async function handleKeepaReport(request, deps) {
  let asin = keepaAsinFromUrl(request.url);
  if (!asin && /^https?:\/\//i.test(String(request.url || ''))) {
    // Short links (amzn.to) say the product only after the redirect.
    const response = await keepaFetch(request.url, deps);
    if (!response) return { ok: false, asin: null, image: null, error: 'rede' };
    asin = keepaAsinFromUrl(response.url);
    // Only the final address mattered; don't leave the page body unread.
    if (response.body && typeof response.body.cancel === 'function') response.body.cancel().catch(function () {});
  }
  if (!asin) return { ok: false, asin: null, image: null, error: 'sem-asin' };

  let entry = keepaCache.get(asin);
  if (!entry || request.fresh || deps.now() - entry.at > KEEPA_CACHE_MS) {
    const png = await keepaFetch(keepaGraphUrl(asin), deps, keepaReadPng);
    if (!png) return { ok: false, asin: asin, image: null, error: 'rede' };
    const blob = png.blob;
    const bytes = png.bytes;
    let parsed;
    try {
      parsed = keepaParseGraph(await deps.decode(blob), KEEPA_GRAPH_DAYS);
    } catch (err) {
      parsed = { ok: false, error: 'nao-li-eixo' };
    }
    entry = { at: deps.now(), image: keepaDataUrl(bytes), parsed: parsed };
    keepaCache.set(asin, entry);
  }

  if (!entry.parsed.ok) {
    const image = entry.parsed.error === 'sem-historico' ? null : entry.image;
    return { ok: false, asin: asin, image: image, error: entry.parsed.error };
  }
  return {
    ok: true,
    asin: asin,
    image: entry.image,
    stats: keepaStats(entry.parsed, request.price, request.coupon, deps.now()),
  };
}

function chromeKeepaDeps() {
  return {
    fetch: (url, init) => fetch(url, init),
    decode: keepaDecodeWithCanvas,
    now: () => Date.now(),
  };
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = { KEEPA_CACHE_MS, keepaCache, keepaDataUrl, handleKeepaReport };
}
