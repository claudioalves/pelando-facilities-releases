// Keepa's public price chart of an Amazon Brasil product (no API key):
// always the same size and lines, so parse.js knows where everything is.
// Runs in the service worker (importScripts).
const KEEPA_GRAPH_DAYS = 180;

function keepaGraphUrl(asin) {
  return (
    'https://graph.keepa.com/pricehistory.png?asin=' +
    encodeURIComponent(asin) +
    '&domain=12&range=' +
    KEEPA_GRAPH_DAYS +
    '&width=1000&height=500&amazon=1&new=1&used=0&salesrank=0'
  );
}

// The product code (ASIN) in an Amazon address: /dp/B09B8XVSDP,
// /gp/product/B09B8XVSDP, /Echo-Dot/dp/B09B8XVSDP?tag=x. null without one
// (short links like amzn.to/3abc).
function keepaAsinFromUrl(url) {
  const match = /\/(?:dp|gp\/product|gp\/aw\/d)\/([A-Z0-9]{10})(?=[/?#]|$)/i.exec(String(url || ''));
  return match ? match[1].toUpperCase() : null;
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = { KEEPA_GRAPH_DAYS, keepaGraphUrl, keepaAsinFromUrl };
}
