// The numbers of the Keepa card from the chart's prices (keepaParseGraph,
// parse.js): lowest, average, prices some months ago and how the deal's
// price compares. Runs in the service worker (importScripts).

// "07/11" for the day `daysAgo` days before `now` (ms), in the browser's
// time zone.
function keepaDayMonth(now, daysAgo) {
  const date = new Date(now - daysAgo * 86400000);
  return String(date.getDate()).padStart(2, '0') + '/' + String(date.getMonth() + 1).padStart(2, '0');
}

// The prices read from a picture are a pixel off at worst: two prices this
// close are the same.
function keepaTie(lowest) {
  return Math.max(lowest * 0.01, 2);
}

// The price `daysAgo` days back, or the closest day with one up to 3 days
// away (earlier first); null without one.
function keepaPriceDaysAgo(prices, daysAgo) {
  const days = prices.length - 1;
  for (let off = 0; off <= 3; off++) {
    for (const d of [days - daysAgo - off, days - daysAgo + off]) {
      if (d >= 0 && d <= days && prices[d] !== null) return prices[d];
    }
  }
  return null;
}

// parsed: { prices, today } from keepaParseGraph. price: the deal's price
// (null when it has none). coupon: the deal's coupon code or null. now: ms.
//
// {
//   lowest: { price, date },  average,
//   ago: { 30, 90, 180 } (prices or null),
//   today (the lowest dot on the chart's border, else the last price),
//   verdict: null without the deal's price, else
//     { kind: 'ok' | 'slight' | 'diverges', difference },
//   cheaperSince: 'DD/MM' or null,
//   couponSaves: how much less than today the deal costs, with a coupon;
//     else null,
// }
function keepaStats(parsed, price, coupon, now) {
  const prices = parsed.prices;
  const days = prices.length - 1;
  let lowestDay = -1;
  let sum = 0;
  let count = 0;
  prices.forEach(function (p, d) {
    if (p === null) return;
    sum += p;
    count++;
    if (lowestDay < 0 || p < prices[lowestDay]) lowestDay = d;
  });
  const lowest = prices[lowestDay];
  let lastDay = days;
  while (prices[lastDay] === null) lastDay--;
  const today = parsed.today !== null && parsed.today !== undefined ? parsed.today : prices[lastDay];

  const stats = {
    lowest: { price: lowest, date: keepaDayMonth(now, days - lowestDay) },
    average: sum / count,
    ago: { 30: keepaPriceDaysAgo(prices, 30), 90: keepaPriceDaysAgo(prices, 90), 180: keepaPriceDaysAgo(prices, 180) },
    today: today,
    verdict: null,
    cheaperSince: null,
    couponSaves: null,
  };
  if (typeof price !== 'number') return stats;

  const tie = keepaTie(lowest);
  const kind = price <= lowest + tie ? 'ok' : price <= lowest * 1.05 + tie ? 'slight' : 'diverges';
  stats.verdict = { kind: kind, difference: Math.max(0, price - lowest) };

  if (kind !== 'ok') {
    // The last day before today as cheap as the deal; the deal beats every
    // day since the next one. Shown when that's a week or more.
    let lastAsCheap = -1;
    for (let d = days - 1; d >= 0 && lastAsCheap < 0; d--) if (prices[d] !== null && prices[d] <= price + tie) lastAsCheap = d;
    const since = lastAsCheap + 1;
    if (lastAsCheap >= 0 && days - since >= 7) stats.cheaperSince = keepaDayMonth(now, days - since);
  }
  if (coupon && today - price > 0) stats.couponSaves = today - price;
  return stats;
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = { keepaDayMonth, keepaTie, keepaPriceDaysAgo, keepaStats };
}
