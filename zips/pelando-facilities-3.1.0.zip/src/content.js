// Starts only for a Pelando account (see access.js).
pelandoWhenAllowed(function () {
  function log(message) {
    console.warn('[pelando-chat-ext] ' + message);
  }

  function closeExistingPopover() {
    const existing = document.querySelector('.pelando-chat-ext-popover');
    if (existing) existing.remove();
    const existingTooltip = document.querySelector('.pelando-chat-ext-tooltip');
    if (existingTooltip) existingTooltip.remove();
  }

  function captureVisibleTab() {
    return new Promise(function (resolve, reject) {
      try {
        chrome.runtime.sendMessage({ type: 'PELANDO_CHAT_EXT_CAPTURE_TAB' }, function (response) {
          if (chrome.runtime.lastError) {
            reject(new Error(chrome.runtime.lastError.message));
            return;
          }
          if (!response || response.error) {
            reject(new Error((response && response.error) || 'resposta vazia do background'));
            return;
          }
          if (!response.dataUrl) {
            reject(new Error('captura sem dataUrl'));
            return;
          }
          resolve(response.dataUrl);
        });
      } catch (err) {
        reject(err);
      }
    });
  }

  function waitForNextPaint() {
    return new Promise(function (resolve) {
      requestAnimationFrame(function () {
        requestAnimationFrame(resolve);
      });
    });
  }

  function loadImage(src) {
    return new Promise(function (resolve, reject) {
      const img = new Image();
      img.onload = function () {
        resolve(img);
      };
      img.onerror = function () {
        reject(new Error('falha ao carregar a imagem capturada'));
      };
      img.src = src;
    });
  }

  // Crops the full-tab screenshot down to just the chat panel (header,
  // messages and input), so the copied image isn't zoomed out to the whole
  // page. Falls back to the untouched screenshot if the chat panel can't be
  // located or the crop fails for any reason.
  async function cropScreenshotToChatPanel(dataUrl) {
    const bounds = getChatPanelBounds();
    if (!bounds || bounds.width <= 0 || bounds.height <= 0) return dataUrl;

    try {
      const img = await loadImage(dataUrl);
      const scaleX = img.width / window.innerWidth;
      const scaleY = img.height / window.innerHeight;

      const canvas = document.createElement('canvas');
      canvas.width = Math.round(bounds.width * scaleX);
      canvas.height = Math.round(bounds.height * scaleY);
      const ctx = canvas.getContext('2d');
      ctx.drawImage(
        img,
        bounds.left * scaleX,
        bounds.top * scaleY,
        bounds.width * scaleX,
        bounds.height * scaleY,
        0,
        0,
        canvas.width,
        canvas.height
      );
      return canvas.toDataURL('image/png');
    } catch (err) {
      log('falha ao cortar o print, usando a imagem inteira: ' + err.message);
      return dataUrl;
    }
  }

  async function copyChatScreenshotToClipboard() {
    const popover = document.querySelector('.pelando-chat-ext-popover');
    const previousVisibility = popover ? popover.style.visibility : null;
    try {
      if (popover) {
        popover.style.visibility = 'hidden';
        await waitForNextPaint();
      }
      const dataUrl = await captureVisibleTab();
      const croppedDataUrl = await cropScreenshotToChatPanel(dataUrl);
      const blob = await (await fetch(croppedDataUrl)).blob();
      await navigator.clipboard.write([new window.ClipboardItem({ [blob.type]: blob })]);
    } catch (err) {
      log('falha ao copiar print do chat: ' + err.message);
    } finally {
      if (popover) popover.style.visibility = previousVisibility || '';
    }
  }

  async function copyConversationTranscriptToClipboard() {
    try {
      const messagesList = findMessagesList();
      const contactName = findContactName();
      const entries = getConversationEntries(messagesList);
      if (entries.length === 0) return;

      const greetingText = fillGreeting(contactName);
      const startIndex = findLastInteractionStart(entries, greetingText);
      const lastInteraction = entries.slice(startIndex);

      const lines = formatConversationTranscript(lastInteraction, contactName);
      if (lines.length === 0) return;
      await navigator.clipboard.writeText(lines.join('\n'));
    } catch (err) {
      log('falha ao copiar a conversa: ' + err.message);
    }
  }

  // The moderator's chosen size, through the CSS variables styles.css reads.
  function applyPopoverSize(popover, size) {
    popover.style.setProperty('--pelando-chat-ext-width', size.width + 'px');
    popover.style.setProperty('--pelando-chat-ext-height', size.height + 'px');
  }

  async function safeGetPopoverSize() {
    try {
      return await getPopoverSize();
    } catch (err) {
      log('falha ao ler o tamanho da janela: ' + err.message);
      return PELANDO_CHAT_EXT_DEFAULT_POPOVER_SIZE;
    }
  }

  async function safeGetPopoverLayout() {
    try {
      return await getPopoverLayout();
    } catch (err) {
      log('falha ao ler o modo de exibição: ' + err.message);
      return 'balloon';
    }
  }

  // The side panel takes the right of the screen and the chat page makes
  // room for it (see styles.css), so they sit side by side.
  // `widthPercent` is the share of the screen's width the panel takes.
  function openSidePanelLayout(popover, widthPercent) {
    const width = widthPercent + 'vw';
    popover.classList.add('pelando-chat-ext-popover--panel');
    popover.style.left = '';
    popover.style.top = '';
    popover.style.setProperty('--pelando-chat-ext-width', width);
    document.documentElement.classList.add(SIDE_PANEL_OPEN_CLASS);
    document.documentElement.style.setProperty('--pelando-chat-ext-panel-width', width);
    sidePanelOpen = true;
  }

  async function safeGetPanelWidthPercent() {
    try {
      return await getPanelWidthPercent();
    } catch (err) {
      log('falha ao ler a largura do painel: ' + err.message);
      return PELANDO_CHAT_EXT_DEFAULT_PANEL_WIDTH_PERCENT;
    }
  }

  function closeSidePanelLayout() {
    document.documentElement.classList.remove(SIDE_PANEL_OPEN_CLASS);
    document.documentElement.style.removeProperty('--pelando-chat-ext-panel-width');
    sidePanelOpen = false;
  }

  async function safeGetPopoverPosition() {
    try {
      return await getPopoverPosition();
    } catch (err) {
      log('falha ao ler a posição da janela: ' + err.message);
      return null;
    }
  }

  function viewportSize() {
    return { width: window.innerWidth, height: window.innerHeight };
  }

  // Where the moderator last left it (kept on screen), or above the chat's
  // button when there's no saved position.
  function positionPopover(popover, anchor, savedPosition) {
    const popoverRect = popover.getBoundingClientRect();
    if (savedPosition) {
      const position = clampPopoverPosition(savedPosition, popoverRect, viewportSize());
      popover.style.left = position.left + 'px';
      popover.style.top = position.top + 'px';
      return;
    }
    const anchorRect = anchor.getBoundingClientRect();
    popover.style.left = Math.max(8, anchorRect.right - popoverRect.width) + 'px';
    popover.style.top = Math.max(8, anchorRect.top - popoverRect.height - 8) + 'px';
  }

  // Dragging the handle moves the popover, kept on screen; `onDrop` gets
  // where it was left.
  function makePopoverMovable(popover, handle, onDrop) {
    handle.addEventListener('pointerdown', function (event) {
      if (event.button !== 0) return;
      event.preventDefault();
      const start = popover.getBoundingClientRect();
      const offsetX = event.clientX - start.left;
      const offsetY = event.clientY - start.top;
      handle.setPointerCapture(event.pointerId);
      popover.classList.add('pelando-chat-ext-popover-moving');

      function onMove(moveEvent) {
        const position = clampPopoverPosition(
          { left: moveEvent.clientX - offsetX, top: moveEvent.clientY - offsetY },
          start,
          viewportSize()
        );
        popover.style.left = position.left + 'px';
        popover.style.top = position.top + 'px';
      }

      function onEnd() {
        handle.removeEventListener('pointermove', onMove);
        handle.removeEventListener('pointerup', onEnd);
        handle.removeEventListener('pointercancel', onEnd);
        popover.classList.remove('pelando-chat-ext-popover-moving');
        onDrop({ left: parseFloat(popover.style.left), top: parseFloat(popover.style.top) });
      }

      handle.addEventListener('pointermove', onMove);
      handle.addEventListener('pointerup', onEnd);
      handle.addEventListener('pointercancel', onEnd);
    });
  }

  function downloadJson(data, filename) {
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    link.click();
    URL.revokeObjectURL(url);
  }

  function readFileAsJson(file) {
    return new Promise(function (resolve, reject) {
      const reader = new FileReader();
      reader.onload = function () {
        try {
          resolve(JSON.parse(reader.result));
        } catch (err) {
          reject(err);
        }
      };
      reader.onerror = function () {
        reject(reader.error);
      };
      reader.readAsText(file);
    });
  }

  // The default messages plus one per rejection reason message from the sheet.
  const seedingReady = applyNewSeeds(
    PELANDO_CHAT_EXT_SEED_THEMES.concat(PELANDO_REASON_SEED_THEMES),
    PELANDO_CHAT_EXT_SEED_MESSAGES.concat(buildReasonSeedMessages(reasonCatalog()))
  )
    .then(ensureGreetingProtected)
    .catch(function (err) {
      log('falha ao semear dados iniciais: ' + err.message);
    });

  let activeCleanup = null;
  // Set while the quick replies are open as the side panel, which the chat's
  // button then closes instead of reopening.
  let sidePanelOpen = false;
  const SIDE_PANEL_OPEN_CLASS = 'pelando-chat-ext-panel-open';

  let audioCtx = null;

  function ensureAudioContext() {
    if (!audioCtx) {
      try {
        audioCtx = new (window.AudioContext || window.webkitAudioContext)();
      } catch (err) {
        log('não foi possível iniciar o áudio: ' + err.message);
        return null;
      }
    }
    return audioCtx;
  }

  document.addEventListener(
    'click',
    function () {
      const ctx = ensureAudioContext();
      if (ctx && ctx.state === 'suspended') {
        ctx.resume().catch(function () {});
      }
    },
    true
  );

  async function playNotificationSound() {
    let enabled = true;
    try {
      enabled = await getNotificationsEnabled();
    } catch (err) {
      log('falha ao ler preferência de notificações: ' + err.message);
    }
    if (!enabled) return;

    const ctx = ensureAudioContext();
    if (!ctx) return;
    if (ctx.state === 'suspended') {
      ctx.resume().catch(function () {});
    }
    try {
      const oscillator = ctx.createOscillator();
      const gainNode = ctx.createGain();
      oscillator.type = 'sine';
      oscillator.frequency.value = 880;
      gainNode.gain.setValueAtTime(0.2, ctx.currentTime);
      gainNode.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.3);
      oscillator.connect(gainNode);
      gainNode.connect(ctx.destination);
      oscillator.start();
      oscillator.stop(ctx.currentTime + 0.3);
    } catch (err) {
      log('falha ao tocar som de notificação: ' + err.message);
    }
  }

  let notifiedConversationKey = null;
  let lastOtherMessageCount = 0;
  let lastHeaderUnreadCount = null;
  let lastSidebarUnreadTotal = null;
  let incomingMessageCheckTimer = null;

  function checkForNewIncomingMessage() {
    const messagesList = findMessagesList();
    const conversationKey = findContactName();
    const otherCount = countContactMessages(messagesList);

    if (conversationKey !== notifiedConversationKey) {
      notifiedConversationKey = conversationKey;
      lastOtherMessageCount = otherCount;
      return;
    }

    if (otherCount > lastOtherMessageCount) {
      playNotificationSound();
    }
    lastOtherMessageCount = otherCount;
  }

  function checkForUnreadIncrease() {
    const headerCount = getHeaderUnreadCount();
    const sidebarTotal = getSidebarUnreadTotal();

    const headerIncreased = lastHeaderUnreadCount !== null && headerCount > lastHeaderUnreadCount;
    const sidebarIncreased = lastSidebarUnreadTotal !== null && sidebarTotal > lastSidebarUnreadTotal;

    if (headerIncreased || sidebarIncreased) {
      playNotificationSound();
    }

    lastHeaderUnreadCount = headerCount;
    lastSidebarUnreadTotal = sidebarTotal;
  }

  function scheduleIncomingMessageCheck() {
    if (document.hidden) {
      if (incomingMessageCheckTimer) {
        clearTimeout(incomingMessageCheckTimer);
        incomingMessageCheckTimer = null;
      }
      checkForNewIncomingMessage();
      checkForUnreadIncrease();
      return;
    }

    if (incomingMessageCheckTimer) {
      clearTimeout(incomingMessageCheckTimer);
    }
    incomingMessageCheckTimer = setTimeout(function () {
      incomingMessageCheckTimer = null;
      checkForNewIncomingMessage();
      checkForUnreadIncrease();
    }, 600);
  }

  document.addEventListener('visibilitychange', function () {
    if (!document.hidden) {
      checkForNewIncomingMessage();
      checkForUnreadIncrease();
    }
  });

  function handleButtonClick(button) {
    if (activeCleanup && sidePanelOpen) {
      activeCleanup();
      return;
    }
    if (activeCleanup) {
      activeCleanup();
    }

    const textarea = findChatInputTextarea();
    if (!textarea) {
      log('textarea do chat não encontrado');
      return;
    }

    const messagesList = findMessagesList();
    if (!messagesList) {
      log('lista de mensagens não encontrada');
    }
    const contactName = findContactName();
    if (!contactName) {
      log('nome do contato não encontrado');
    }

    if (!hasOwnMessage(messagesList)) {
      textarea.value = fillGreeting(contactName);
      textarea.dispatchEvent(new Event('input', { bubbles: true }));
      return;
    }

    openPopover(button, textarea, contactName, messagesList);
  }

  function handleQuickAddClick(button) {
    if (activeCleanup) {
      activeCleanup();
    }

    const textarea = findChatInputTextarea();
    if (!textarea) {
      log('textarea do chat não encontrado');
      return;
    }

    openQuickAddPopover(button, textarea);
  }

  async function safeGetAllThemes() {
    try {
      return await getAllThemes();
    } catch (err) {
      log('falha ao ler temas do armazenamento: ' + err.message);
      return [];
    }
  }

  async function safeGetMessagesForTheme(temaId) {
    if (!temaId) return [];
    try {
      return await getMessagesForTheme(temaId);
    } catch (err) {
      log('falha ao ler mensagens do armazenamento: ' + err.message);
      return [];
    }
  }

  async function safeGetAllReasonMessages() {
    try {
      return await getAllReasonMessages();
    } catch (err) {
      log('falha ao ler motivos de reprova: ' + err.message);
      return [];
    }
  }

  async function safeGetAllMessages() {
    try {
      return await getAllMessages();
    } catch (err) {
      log('falha ao ler mensagens do armazenamento: ' + err.message);
      return [];
    }
  }

  async function safeGetNotificationsEnabled() {
    try {
      return await getNotificationsEnabled();
    } catch (err) {
      log('falha ao ler preferência de notificações: ' + err.message);
      return true;
    }
  }

  async function safeGetReportHighlightEnabled() {
    try {
      return await getReportHighlightEnabled();
    } catch (err) {
      log('falha ao ler preferência de destaque dos reportados: ' + err.message);
      return false;
    }
  }

  async function safeGetPriceTestEnabled() {
    try {
      return await getPriceTestEnabled();
    } catch (err) {
      log('falha ao ler preferência do Testar Promoção: ' + err.message);
      return false;
    }
  }

  async function safeGetSiteMonitorMinutes() {
    try {
      return await getSiteMonitorMinutes();
    } catch (err) {
      log('falha ao ler o intervalo do monitor dos sites: ' + err.message);
      return PELANDO_CHAT_EXT_SITE_MONITOR_MINUTES.default;
    }
  }

  async function openPopover(button, textarea, contactName, messagesList) {
    activeCleanup = cleanup;

    await seedingReady;
    const themes = await safeGetAllThemes();
    const lastContactText = findLastContactMessageText(messagesList);
    const suggestedThemeId = detectTheme(themes, lastContactText);
    const notificationsEnabled = await safeGetNotificationsEnabled();
    const popoverSize = await safeGetPopoverSize();
    const popoverPosition = await safeGetPopoverPosition();
    const popoverLayout = await safeGetPopoverLayout();
    const panelWidthPercent = await safeGetPanelWidthPercent();
    const reportHighlightEnabled = await safeGetReportHighlightEnabled();
    const priceTestEnabled = await safeGetPriceTestEnabled();
    const siteMonitorMinutes = await safeGetSiteMonitorMinutes();

    const state = {
      themes: themes,
      activeThemeId: suggestedThemeId || (themes[0] ? themes[0].id : null),
      suggestedThemeId: suggestedThemeId,
      // 'edit' (the pencil: themes and texts), 'settings' (the gear) or null.
      manageMode: null,
      formMode: null,
      importError: null,
      notificationsEnabled: notificationsEnabled,
      searchQuery: '',
      popoverSize: popoverSize,
      popoverPosition: popoverPosition,
      layout: popoverLayout,
      panelWidthPercent: panelWidthPercent,
      reportHighlightEnabled: reportHighlightEnabled,
      priceTestEnabled: priceTestEnabled,
      siteMonitorMinutes: siteMonitorMinutes,
    };

    function cleanup() {
      closeExistingPopover();
      closeSidePanelLayout();
      document.removeEventListener('click', onOutsideClick, true);
      document.removeEventListener('keydown', onEscape, true);
      if (activeCleanup === cleanup) {
        activeCleanup = null;
      }
    }

    // The side panel sits next to the chat and stays open while it's used;
    // only the balloon closes on a click elsewhere.
    function onOutsideClick(event) {
      if (state.layout === 'panel') return;
      const currentPopover = document.querySelector('.pelando-chat-ext-popover');
      if (currentPopover && !currentPopover.contains(event.target) && event.target !== button) {
        cleanup();
      }
    }

    function onEscape(event) {
      if (event.key === 'Escape') cleanup();
    }

    async function refreshThemes() {
      state.themes = await safeGetAllThemes();
      if (!state.themes.some(function (t) { return t.id === state.activeThemeId; })) {
        state.activeThemeId = state.themes[0] ? state.themes[0].id : null;
      }
    }

    async function render() {
      closeExistingPopover();

      const popover = document.createElement('div');
      popover.className = 'pelando-chat-ext-popover';
      applyPopoverSize(popover, state.popoverSize);

      if (state.formMode && state.formMode.type === 'theme') {
        const form = createThemeForm(state.formMode.theme, {
          onSave: async function (values) {
            if (state.formMode.theme) {
              await updateTheme(state.formMode.theme.id, values);
            } else {
              const created = await createTheme(values.nome, values.palavrasChave);
              state.activeThemeId = created.id;
            }
            state.formMode = null;
            await refreshThemes();
            await render();
          },
          onCancel: async function () {
            state.formMode = null;
            await render();
          },
        });
        popover.appendChild(form);
      } else if (state.formMode && state.formMode.type === 'reasons') {
        const reasons = await safeGetAllReasonMessages();
        const list = createReasonsList(reasons, {
          onEdit: async function (reason) {
            state.formMode = { type: 'reason', reason: reason };
            await render();
          },
          onBack: async function () {
            state.formMode = null;
            await render();
          },
        });
        popover.appendChild(list);
      } else if (state.formMode && state.formMode.type === 'reason') {
        const reason = state.formMode.reason;
        const backToReasons = async function () {
          state.formMode = { type: 'reasons' };
          await render();
        };
        const form = createReasonForm(reason, {
          onSave: async function (values) {
            await saveReasonMessage(reason.id, values);
            await backToReasons();
          },
          onReset: async function () {
            await resetReasonMessage(reason.id);
            await backToReasons();
          },
          onCancel: backToReasons,
        });
        popover.appendChild(form);
      } else if (state.formMode && state.formMode.type === 'message') {
        const form = createMessageForm(state.formMode.message, {
          onSave: async function (values) {
            if (state.formMode.message) {
              await updateMessage(state.formMode.message.id, values);
            } else {
              await createMessage(state.activeThemeId, values.nome, values.texto);
            }
            state.formMode = null;
            await render();
          },
          onCancel: async function () {
            state.formMode = null;
            await render();
          },
        });
        popover.appendChild(form);
      } else {
        const header = createTabBar(state.themes, state.activeThemeId, state.suggestedThemeId, state.manageMode, state.notificationsEnabled, {
          onSelectTheme: async function (themeId) {
            state.activeThemeId = themeId;
            state.searchQuery = '';
            await render();
          },
          onToggleManage: async function () {
            state.manageMode = state.manageMode === 'settings' ? null : 'settings';
            await render();
          },
          onToggleEdit: async function () {
            state.manageMode = state.manageMode === 'edit' ? null : 'edit';
            await render();
          },
          onAddTheme: async function () {
            state.formMode = { type: 'theme', theme: null };
            await render();
          },
          onOpenReasons: async function () {
            state.formMode = { type: 'reasons' };
            await render();
          },
          onRenameTheme: async function (theme) {
            state.formMode = { type: 'theme', theme: theme };
            await render();
          },
          onDeleteTheme: async function (theme) {
            if (!window.confirm('Excluir o tema "' + theme.nome + '" e todas as suas mensagens?')) return;
            try {
              await deleteTheme(theme.id);
              await refreshThemes();
              await render();
            } catch (err) {
              window.alert('Não deu pra excluir o tema: ' + err.message);
            }
          },
          onOpenAiText: async function () {
            await copyConversationTranscriptToClipboard();
            window.open('https://gemini.google.com/gem/cb3078320590', '_blank', 'noopener,noreferrer');
          },
          onOpenAiScreenshot: async function () {
            await copyChatScreenshotToClipboard();
            window.open('https://gemini.google.com/gem/cb3078320590', '_blank', 'noopener,noreferrer');
          },
          onToggleNotifications: async function () {
            const newValue = !state.notificationsEnabled;
            try {
              await setNotificationsEnabled(newValue);
              state.notificationsEnabled = newValue;
            } catch (err) {
              window.alert('Não deu pra salvar a preferência de notificações: ' + err.message);
            }
            await render();
          },
        }, { movable: state.layout !== 'panel' });
        popover.appendChild(header);

        const messages = await safeGetMessagesForTheme(state.activeThemeId);

        if (state.manageMode === 'edit') {
          const body = createManageMessageList(messages, {
            onEdit: async function (message) {
              state.formMode = { type: 'message', message: message };
              await render();
            },
            onDelete: async function (message) {
              if (!window.confirm('Excluir a mensagem "' + message.nome + '"?')) return;
              try {
                await deleteMessage(message.id);
                await render();
              } catch (err) {
                window.alert('Não deu pra excluir a mensagem: ' + err.message);
              }
            },
            onAdd: async function () {
              if (!state.activeThemeId) {
                window.alert('Crie um tema antes de adicionar mensagens.');
                return;
              }
              state.formMode = { type: 'message', message: null };
              await render();
            },
            onReorder: async function (reorderedMessages) {
              try {
                await reorderMessagesForTheme(state.activeThemeId, reorderedMessages.map((m) => m.id));
              } catch (err) {
                window.alert('Não deu pra reordenar as mensagens: ' + err.message);
              }
              await render();
            },
          });
          popover.appendChild(body);
        } else if (state.manageMode === 'settings') {
          const exportImport = createExportImportControls(
            {
              onOpenBackup: function () {
                try {
                  chrome.runtime.sendMessage({ type: 'PELANDO_OPEN_OPTIONS' });
                } catch (err) {
                  log('falha ao abrir o backup: ' + err.message);
                }
              },
              onExport: async function () {
                try {
                  const data = await exportAll();
                  downloadJson(data, 'pelando-chat-ext-mensagens.json');
                } catch (err) {
                  window.alert('Não deu pra exportar: ' + err.message);
                }
              },
              onImport: async function (file) {
                try {
                  const data = await readFileAsJson(file);
                  await importAll(data);
                  state.importError = null;
                  await refreshThemes();
                  await render();
                } catch (err) {
                  state.importError = err.message;
                  await render();
                }
              },
            },
            state.importError
          );
          popover.appendChild(exportImport);

          // Resized live, and re-anchored above the chat's button.
          const resize = async function (size) {
            try {
              state.popoverSize = await setPopoverSize(size);
            } catch (err) {
              window.alert('Não deu pra salvar o tamanho da janela: ' + err.message);
              return;
            }
            await render();
          };
          const resizePanel = async function (percent) {
            try {
              state.panelWidthPercent = await setPanelWidthPercent(percent);
            } catch (err) {
              window.alert('Não deu pra salvar a largura do painel: ' + err.message);
              return;
            }
            await render();
          };
          const sizeSettings = createSizeSettings(state.popoverSize, PELANDO_CHAT_EXT_POPOVER_SIZE_LIMITS, {
            onChange: resize,
            onReset: function () {
              return resize(PELANDO_CHAT_EXT_DEFAULT_POPOVER_SIZE);
            },
            onResetPosition: async function () {
              try {
                state.popoverPosition = await setPopoverPosition(null);
              } catch (err) {
                window.alert('Não deu pra restaurar a posição da janela: ' + err.message);
                return;
              }
              await render();
            },
            onPanelWidthChange: function (percent) {
              return resizePanel(percent);
            },
            onResetPanelWidth: function () {
              return resizePanel(PELANDO_CHAT_EXT_DEFAULT_PANEL_WIDTH_PERCENT);
            },
            onLayoutChange: async function (layout) {
              try {
                state.layout = await setPopoverLayout(layout);
              } catch (err) {
                window.alert('Não deu pra salvar o modo de exibição: ' + err.message);
                return;
              }
              await render();
            },
          }, state.layout, {
            percent: state.panelWidthPercent,
            min: PELANDO_CHAT_EXT_PANEL_WIDTH_LIMITS.min,
            max: PELANDO_CHAT_EXT_PANEL_WIDTH_LIMITS.max,
          });
          popover.appendChild(sizeSettings);

          popover.appendChild(
            createReportHighlightSettings(state.reportHighlightEnabled, async function (enabled) {
              try {
                await setReportHighlightEnabled(enabled);
                state.reportHighlightEnabled = enabled;
              } catch (err) {
                window.alert('Não deu pra salvar o destaque dos reportados: ' + err.message);
              }
              await render();
            })
          );

          popover.appendChild(
            createPriceTestSettings(state.priceTestEnabled, async function (enabled) {
              try {
                await setPriceTestEnabled(enabled);
                state.priceTestEnabled = enabled;
              } catch (err) {
                window.alert('Não deu pra salvar a opção do Testar Promoção: ' + err.message);
              }
              await render();
            })
          );

          popover.appendChild(
            createSiteMonitorSettings(state.siteMonitorMinutes, PELANDO_CHAT_EXT_SITE_MONITOR_MINUTES, async function (minutes) {
              try {
                await setSiteMonitorMinutes(minutes);
                state.siteMonitorMinutes = await getSiteMonitorMinutes();
              } catch (err) {
                window.alert('Não deu pra salvar o intervalo do monitor dos sites: ' + err.message);
              }
              await render();
            })
          );
        } else {
          // Read the input and name on each pick: with the side panel open
          // the moderator may have switched conversations since.
          const onSelectMessage = function (message) {
            const input = findChatInputTextarea() || textarea;
            input.value = fillTemplate(message.texto, findContactName() || contactName);
            input.dispatchEvent(new Event('input', { bubbles: true }));
            if (state.layout === 'panel') input.focus();
            else cleanup();
          };
          const allMessages = await safeGetAllMessages();
          const themeNames = new Map(state.themes.map(function (t) { return [t.id, t.nome]; }));
          const results = document.createElement('div');
          results.className = 'pelando-chat-ext-search-results';

          // Only the list is redrawn while typing, so the search box keeps
          // focus and what was typed. From 3 letters it searches every
          // theme; below that it shows the active theme's messages.
          const showMessages = function () {
            // A preview left open by the list being replaced under the mouse.
            const tooltip = document.querySelector('.pelando-chat-ext-tooltip');
            if (tooltip) tooltip.remove();
            const query = state.searchQuery.trim();
            if (query.length < PELANDO_CHAT_EXT_SEARCH_MIN_LENGTH) {
              results.replaceChildren(createMessageList(messages, onSelectMessage));
              return;
            }
            const found = searchMessages(allMessages, query).map(function (m) {
              const themeName = themeNames.get(m.temaId);
              return themeName ? { ...m, nome: m.nome + ' (' + themeName + ')' } : m;
            });
            results.replaceChildren(
              found.length
                ? createMessageList(found, onSelectMessage)
                : createSearchEmptyState('Nenhuma mensagem encontrada para “' + query + '”.')
            );
          };
          const search = createMessageSearch(state.searchQuery, function (value) {
            state.searchQuery = value;
            showMessages();
          });
          popover.append(search, results);
          showMessages();
          if (state.searchQuery) setTimeout(function () { search.focus(); }, 0);
        }
      }

      if (activeCleanup !== cleanup) return;

      document.body.appendChild(popover);
      if (state.layout === 'panel') {
        openSidePanelLayout(popover, state.panelWidthPercent);
      } else {
        closeSidePanelLayout();
        positionPopover(popover, button, state.popoverPosition);
      }

      const moveHandle = popover.querySelector('.pelando-chat-ext-move-handle');
      if (moveHandle) {
        makePopoverMovable(popover, moveHandle, async function (position) {
          try {
            state.popoverPosition = await setPopoverPosition(position);
          } catch (err) {
            log('falha ao salvar a posição da janela: ' + err.message);
          }
        });
      }
    }

    await render();
    setTimeout(function () {
      if (activeCleanup !== cleanup) return;
      document.addEventListener('click', onOutsideClick, true);
      document.addEventListener('keydown', onEscape, true);
    }, 0);
  }

  async function openQuickAddPopover(button, textarea) {
    activeCleanup = cleanup;

    const themes = await safeGetAllThemes();
    const popoverSize = await safeGetPopoverSize();
    const initialTexto = textarea.value;
    let createdThemeId = null;

    function cleanup() {
      closeExistingPopover();
      document.removeEventListener('click', onOutsideClick, true);
      document.removeEventListener('keydown', onEscape, true);
      if (activeCleanup === cleanup) {
        activeCleanup = null;
      }
    }

    function onOutsideClick(event) {
      const currentPopover = document.querySelector('.pelando-chat-ext-popover');
      if (currentPopover && !currentPopover.contains(event.target) && event.target !== button) {
        cleanup();
      }
    }

    function onEscape(event) {
      if (event.key === 'Escape') cleanup();
    }

    async function render() {
      closeExistingPopover();

      const popover = document.createElement('div');
      popover.className = 'pelando-chat-ext-popover';
      applyPopoverSize(popover, popoverSize);

      const form = createQuickAddForm(themes, initialTexto, {
        onSave: async function (values) {
          let temaId = values.temaId;
          if (!temaId) {
            if (!createdThemeId) {
              const createdTheme = await createTheme(values.novoTemaNome, []);
              createdThemeId = createdTheme.id;
            }
            temaId = createdThemeId;
          }
          await createMessage(temaId, values.nome, values.texto);
          cleanup();
        },
        onCancel: function () {
          cleanup();
        },
      });
      popover.appendChild(form);

      if (activeCleanup !== cleanup) return;

      document.body.appendChild(popover);
      positionPopover(popover, button);
    }

    await render();
    setTimeout(function () {
      if (activeCleanup !== cleanup) return;
      document.addEventListener('click', onOutsideClick, true);
      document.addEventListener('keydown', onEscape, true);
    }, 0);
  }

  // Left by "Justificar ao usuário" when it opens a chat: the reason message
  // to prefill, below the greeting. With a `chatId` it's for that chat only;
  // without one (the backoffice's own "Conversar" button opened the chat, so
  // its id isn't known) it's for the next chat tab that opens, so a chat that
  // was already open never picks it up.
  const PENDING_CHAT_MESSAGE_KEY = 'pendingChatMessage';
  const PENDING_CHAT_MESSAGE_MAX_AGE_MS = 5 * 60 * 1000;
  const PENDING_ANY_CHAT_MAX_AGE_MS = 60 * 1000;
  const pageLoadedAt = Date.now();
  let pendingChatMessage = null;
  let applyingPendingChatMessage = false;

  chrome.storage.local.get(PENDING_CHAT_MESSAGE_KEY).then(
    function (stored) {
      pendingChatMessage = stored[PENDING_CHAT_MESSAGE_KEY] || null;
      applyPendingChatMessage();
    },
    function (err) {
      log('falha ao ler a mensagem pendente: ' + err.message);
    }
  );
  chrome.storage.onChanged.addListener(function (changes, area) {
    if (area !== 'local' || !changes[PENDING_CHAT_MESSAGE_KEY]) return;
    pendingChatMessage = changes[PENDING_CHAT_MESSAGE_KEY].newValue || null;
    applyPendingChatMessage();
  });

  // The greeting registered in the chat's own messages ("Saudações"), so a
  // moderator's edit to it is respected.
  async function getGreetingTemplate() {
    await seedingReady;
    try {
      const messages = await getAllMessages();
      const greeting =
        messages.find(function (m) { return m.id === 'greeting'; }) ||
        messages.find(function (m) { return m.temaId === 'saudacoes'; });
      if (greeting) return greeting.texto;
    } catch (err) {
      log('falha ao ler a saudação: ' + err.message);
    }
    return PELANDO_CHAT_EXT_GREETING_TEMPLATE;
  }

  // Waits for the chat to finish loading (its header shows the contact's
  // name) before filling the input, so the greeting carries the name.
  async function applyPendingChatMessage() {
    const pending = pendingChatMessage;
    if (!pending || applyingPendingChatMessage) return;
    const maxAge = pending.chatId ? PENDING_CHAT_MESSAGE_MAX_AGE_MS : PENDING_ANY_CHAT_MAX_AGE_MS;
    if (Date.now() - pending.createdAt > maxAge) {
      pendingChatMessage = null;
      chrome.storage.local.remove(PENDING_CHAT_MESSAGE_KEY).catch(function (err) {
        log('falha ao limpar a mensagem pendente: ' + err.message);
      });
      return;
    }
    const chatId = decodeURIComponent(window.location.pathname.split('/')[2] || '');
    if (pending.chatId ? chatId !== pending.chatId : !chatId || pageLoadedAt < pending.createdAt) return;
    const textarea = findChatInputTextarea();
    const contactName = findContactName();
    if (!textarea || !contactName) return;

    applyingPendingChatMessage = true;
    try {
      pendingChatMessage = null;
      await chrome.storage.local.remove(PENDING_CHAT_MESSAGE_KEY);
      const greeting = fillTemplate(await getGreetingTemplate(), contactName);
      textarea.value = greeting + '\n' + pending.text;
      textarea.dispatchEvent(new Event('input', { bubbles: true }));
      textarea.focus();
    } catch (err) {
      log('falha ao preencher a justificativa: ' + err.message);
    } finally {
      applyingPendingChatMessage = false;
    }
  }

  function injectButton() {
    const field = findChatInputField();
    if (!field) return;

    const anchor = findChatInputImageButton(field);

    let mainButton = findExistingInjectedButton(field);
    if (!mainButton) {
      mainButton = createInjectedButton(function () {
        handleButtonClick(mainButton);
      });
      if (anchor && anchor.parentNode) {
        anchor.parentNode.insertBefore(mainButton, anchor.nextSibling);
      } else {
        field.appendChild(mainButton);
      }
    }

    let quickAddButton = findExistingQuickAddButton(field);
    if (!quickAddButton) {
      quickAddButton = createQuickAddButton(function () {
        handleQuickAddClick(quickAddButton);
      });
      mainButton.parentNode.insertBefore(quickAddButton, mainButton.nextSibling);
    }
  }

  // The user's profile and backoffice page, next to their nickname (see chatUserLinks.js).
  const syncChatUserLinks = createChatUserLinks(function (nickname) {
    return findBackofficeUserId(nickname, callBackoffice);
  });

  const observer = new MutationObserver(function () {
    syncChatUserLinks(document);
    injectButton();
    applyPendingChatMessage();
    scheduleIncomingMessageCheck();
  });
  observer.observe(document.body, { childList: true, subtree: true, characterData: true });

  syncChatUserLinks(document);
  injectButton();
  checkForNewIncomingMessage();
  checkForUnreadIncrease();
});
