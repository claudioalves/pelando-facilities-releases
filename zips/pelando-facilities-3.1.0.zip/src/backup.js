// A full backup of this extension's data, to carry it between Chrome profiles
// (each profile keeps its own extension data). It holds everything in sync
// storage (themes, messages, rejection reason replies, window and sound
// settings) and in local storage (keyword examples and settings), except the
// text on its way to a chat, which lasts a minute.
var PELANDO_BACKUP_FORMAT = 'pelando-facilities-backup';
var PELANDO_BACKUP_VERSION = 1;
var PELANDO_BACKUP_TRANSIENT_LOCAL_KEYS = ['pendingChatMessage'];
// chrome.storage.sync limits.
var PELANDO_SYNC_LIMITS = { totalBytes: 102400, itemBytes: 8192, items: 512 };

function byteLength(value) {
  return new TextEncoder().encode(value).length;
}

async function collectBackup(storage, meta) {
  const sync = await storage.sync.get(null);
  const local = await storage.local.get(null);
  PELANDO_BACKUP_TRANSIENT_LOCAL_KEYS.forEach(function (key) {
    delete local[key];
  });
  return {
    format: PELANDO_BACKUP_FORMAT,
    version: PELANDO_BACKUP_VERSION,
    exportedAt: (meta && meta.exportedAt) || new Date().toISOString(),
    account: (meta && meta.account) || '',
    sync: sync,
    local: local,
  };
}

// What a backup (or the current profile) holds, in the terms the page shows.
function summarizeData(sync, local) {
  const keys = Object.keys(sync || {});
  const examples = (local && local.pelandoKeywordExamples) || [];
  return {
    themes: keys.filter(function (k) { return k.indexOf('theme:') === 0; }).length,
    messages: keys.filter(function (k) { return k.indexOf('message:') === 0; }).length,
    reasonEdits: keys.filter(function (k) { return k.indexOf('reasonMessage:') === 0; }).length,
    keywordExamples: Array.isArray(examples) ? examples.length : 0,
  };
}

// Throws with a message the page can show when `data` isn't a backup this
// version can restore, or wouldn't fit in sync storage.
function validateBackup(data) {
  if (!data || typeof data !== 'object' || data.format !== PELANDO_BACKUP_FORMAT) {
    throw new Error('Esse arquivo não é um backup da Pelando Facilities.');
  }
  if (typeof data.version !== 'number' || data.version > PELANDO_BACKUP_VERSION) {
    throw new Error('Esse backup é de uma versão mais nova da extensão. Atualize a extensão e tente de novo.');
  }
  const isPlainObject = function (v) {
    return v && typeof v === 'object' && !Array.isArray(v);
  };
  if (!isPlainObject(data.sync) || !isPlainObject(data.local)) {
    throw new Error('O arquivo de backup está incompleto.');
  }
  const keys = Object.keys(data.sync);
  if (keys.length > PELANDO_SYNC_LIMITS.items) {
    throw new Error('O backup tem itens demais para o Chrome guardar.');
  }
  let total = 0;
  keys.forEach(function (key) {
    const size = byteLength(key) + byteLength(JSON.stringify(data.sync[key]));
    if (size > PELANDO_SYNC_LIMITS.itemBytes) {
      throw new Error('Um item do backup é grande demais para o Chrome guardar: ' + key + '.');
    }
    total += size;
  });
  if (total > PELANDO_SYNC_LIMITS.totalBytes) {
    throw new Error('O backup passa do espaço que o Chrome reserva para a extensão.');
  }
}

async function replaceArea(area, items) {
  const before = await area.get(null);
  await area.clear();
  try {
    await area.set(items);
  } catch (err) {
    // Put back what was there, so a failed restore loses nothing.
    await area.clear();
    await area.set(before);
    throw err;
  }
  return before;
}

// Makes this profile's data the same as the backup's. If writing the local
// part fails after sync was replaced, sync is put back too.
async function restoreBackup(storage, data) {
  validateBackup(data);
  const local = Object.assign({}, data.local);
  PELANDO_BACKUP_TRANSIENT_LOCAL_KEYS.forEach(function (key) {
    delete local[key];
  });
  // "Testar Promoção" turned on stays on: a backup made before its switch
  // existed doesn't turn it off.
  const sync = Object.assign({}, data.sync);
  if (!('priceTestEnabled' in sync)) {
    const current = await storage.sync.get('priceTestEnabled');
    if (current.priceTestEnabled === true) sync.priceTestEnabled = true;
  }
  const syncBefore = await replaceArea(storage.sync, sync);
  try {
    await replaceArea(storage.local, local);
  } catch (err) {
    await storage.sync.clear();
    await storage.sync.set(syncBefore);
    throw err;
  }
}

function backupFileName(account, date) {
  const who = (account || 'perfil').split('@')[0].replace(/[^a-z0-9._-]+/gi, '-');
  return 'pelando-facilities-backup-' + who + '-' + date.toISOString().slice(0, 10) + '.json';
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = {
    PELANDO_BACKUP_FORMAT,
    collectBackup,
    summarizeData,
    validateBackup,
    restoreBackup,
    backupFileName,
  };
}
