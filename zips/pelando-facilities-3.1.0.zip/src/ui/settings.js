const PELANDO_CHAT_EXT_LAYOUT_OPTIONS = [
  { value: 'balloon', label: 'Balão' },
  { value: 'panel', label: 'Painel lateral' },
];

// The popover's window settings, in manage mode: how it opens (`layout`),
// then its size. `onLayoutChange` gets the chosen layout. As a balloon,
// `onChange` gets the new size (px) each time a value is committed (Enter,
// the arrows, or leaving the field) and `onReset` puts back the default size;
// `onResetPosition` sends it back above the chat's button. As a side panel it
// fills the screen's height and doesn't move, so height and position are
// disabled, and its width is a share of the screen (`panelWidth`: percent,
// min, max): `onPanelWidthChange` gets the new percent and
// `onResetPanelWidth` puts back the default.
function createSizeSettings(size, limits, callbacks, layout, panelWidth) {
  const isPanel = layout === 'panel';
  const container = document.createElement('div');
  container.className = 'pelando-chat-ext-settings';

  const title = document.createElement('div');
  title.className = 'pelando-chat-ext-settings-title';
  title.textContent = 'Janela';
  container.appendChild(title);

  const layoutRow = document.createElement('div');
  layoutRow.className = 'pelando-chat-ext-settings-row';
  layoutRow.setAttribute('role', 'radiogroup');
  layoutRow.setAttribute('aria-label', 'Modo de exibição');
  const layoutLabel = document.createElement('span');
  layoutLabel.textContent = 'Modo de exibição';
  const layoutOptions = document.createElement('div');
  layoutOptions.className = 'pelando-chat-ext-settings-layouts';
  PELANDO_CHAT_EXT_LAYOUT_OPTIONS.forEach((option) => {
    const label = document.createElement('label');
    label.className = 'pelando-chat-ext-settings-layout';
    const radio = document.createElement('input');
    radio.type = 'radio';
    radio.name = 'pelando-chat-ext-layout';
    radio.value = option.value;
    radio.checked = (layout || 'balloon') === option.value;
    radio.addEventListener('change', () => {
      if (radio.checked) callbacks.onLayoutChange(option.value);
    });
    label.append(radio, document.createTextNode(option.label));
    layoutOptions.appendChild(label);
  });
  layoutRow.append(layoutLabel, layoutOptions);
  container.appendChild(layoutRow);

  function createNumberInput(labelText, value, inputLimits, unitText, step, disabled, onCommit) {
    const row = document.createElement('label');
    row.className = 'pelando-chat-ext-settings-row';
    row.textContent = labelText;
    const input = document.createElement('input');
    input.type = 'number';
    input.className = 'pelando-chat-ext-settings-input';
    input.min = String(inputLimits.min);
    input.max = String(inputLimits.max);
    input.step = String(step);
    input.value = String(value);
    input.disabled = !!disabled;
    input.addEventListener('change', () => onCommit());
    // The chat may react to Enter on the page.
    input.addEventListener('keydown', (event) => event.stopPropagation());
    const unit = document.createElement('span');
    unit.className = 'pelando-chat-ext-settings-unit';
    unit.textContent = unitText;
    row.append(input, unit);
    container.appendChild(row);
    return input;
  }

  function commitSize() {
    callbacks.onChange({ width: Number(widthInput.value), height: Number(heightInput.value) });
  }

  let widthInput;
  if (isPanel) {
    const panelInput = createNumberInput(
      'Largura do painel',
      panelWidth.percent,
      panelWidth,
      '%',
      5,
      false,
      () => callbacks.onPanelWidthChange(Number(panelInput.value))
    );
    widthInput = panelInput;
  } else {
    widthInput = createNumberInput('Largura', size.width, limits.width, 'px', 10, false, commitSize);
  }
  const heightInput = createNumberInput('Altura', size.height, limits.height, 'px', 10, isPanel, commitSize);

  if (isPanel) {
    const hint = document.createElement('div');
    hint.className = 'pelando-chat-ext-settings-hint';
    hint.textContent = 'No painel lateral a largura é uma parte da tela, a altura é a da tela toda e a posição é fixa à direita.';
    container.appendChild(hint);
  }

  const resetButton = document.createElement('button');
  resetButton.type = 'button';
  resetButton.className = 'pelando-chat-ext-settings-reset';
  resetButton.textContent = 'Restaurar padrão';
  resetButton.addEventListener('click', () => (isPanel ? callbacks.onResetPanelWidth() : callbacks.onReset()));

  const resetPositionButton = document.createElement('button');
  resetPositionButton.type = 'button';
  resetPositionButton.className = 'pelando-chat-ext-settings-reset';
  resetPositionButton.textContent = 'Restaurar posição';
  resetPositionButton.disabled = isPanel;
  resetPositionButton.addEventListener('click', () => callbacks.onResetPosition());

  const resets = document.createElement('div');
  resets.className = 'pelando-chat-ext-settings-resets';
  resets.append(resetButton, resetPositionButton);
  container.appendChild(resets);

  return container;
}

// The backoffice option, in manage mode: whether its "Reportadas" tabs
// highlight "duplicada" and the listed nicknames. `onChange` gets the new
// choice.
function createReportHighlightSettings(enabled, onChange) {
  const container = document.createElement('div');
  container.className = 'pelando-chat-ext-settings';

  const title = document.createElement('div');
  title.className = 'pelando-chat-ext-settings-title';
  title.textContent = 'Backoffice';
  container.appendChild(title);

  const row = document.createElement('label');
  row.className = 'pelando-chat-ext-settings-row';
  const checkbox = document.createElement('input');
  checkbox.type = 'checkbox';
  checkbox.checked = !!enabled;
  checkbox.addEventListener('change', () => onChange(checkbox.checked));
  row.append(checkbox, document.createTextNode('Destacar reportados no backoffice'));
  container.appendChild(row);

  const hint = document.createElement('div');
  hint.className = 'pelando-chat-ext-settings-hint';
  hint.textContent = 'Nas abas de reportados do backoffice do Pelando, realça "duplicada" e os nicknames da lista.';
  container.appendChild(hint);

  return container;
}

// "Testar Promoção" in the backoffice, in manage mode, right below the
// reports option: off unless the moderator turns it on. `onChange` gets the
// new choice.
function createPriceTestSettings(enabled, onChange) {
  const container = document.createElement('div');
  container.className = 'pelando-chat-ext-settings';

  const row = document.createElement('label');
  row.className = 'pelando-chat-ext-settings-row';
  const checkbox = document.createElement('input');
  checkbox.type = 'checkbox';
  checkbox.checked = !!enabled;
  checkbox.addEventListener('change', () => onChange(checkbox.checked));
  row.append(checkbox, document.createTextNode('Ativar Testar Promoção no backoffice'));
  container.appendChild(row);

  const hint = document.createElement('div');
  hint.className = 'pelando-chat-ext-settings-hint';
  hint.textContent = 'Mostra o botão Testar Promoção na página da promoção, para conferir o preço no checkout da loja.';
  container.appendChild(hint);

  return container;
}

// The backoffice's site monitor, in manage mode: how often it checks the
// sites, in minutes. `onChange` gets the new number.
function createSiteMonitorSettings(minutes, limits, onChange) {
  const container = document.createElement('div');
  container.className = 'pelando-chat-ext-settings';

  const row = document.createElement('label');
  row.className = 'pelando-chat-ext-settings-row';
  row.textContent = 'Monitor dos sites: testar a cada';
  const input = document.createElement('input');
  input.type = 'number';
  input.className = 'pelando-chat-ext-settings-input';
  input.min = String(limits.min);
  input.max = String(limits.max);
  input.step = '1';
  input.value = String(minutes);
  input.addEventListener('change', () => onChange(Number(input.value)));
  // The chat may react to Enter on the page.
  input.addEventListener('keydown', (event) => event.stopPropagation());
  const unit = document.createElement('span');
  unit.className = 'pelando-chat-ext-settings-unit';
  unit.textContent = 'min';
  row.append(input, unit);
  container.appendChild(row);

  const hint = document.createElement('div');
  hint.className = 'pelando-chat-ext-settings-hint';
  hint.textContent =
    'Na moderação de promoções do backoffice, o quadro testa o Pelando e o Promoninja nesse intervalo; abrindo a página antes disso, mostra o último teste.';
  container.appendChild(hint);

  return container;
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = { createSizeSettings, createReportHighlightSettings, createPriceTestSettings, createSiteMonitorSettings };
}
