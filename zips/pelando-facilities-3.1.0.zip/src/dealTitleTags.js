// Buttons under a Pelando deal's title in the backoffice that put a tag in
// brackets at its start ("[REC] Energy Drink"), or take it out again: REC,
// Meli+ and Prime always, plus the ones the moderator adds (saved in
// chrome.storage.sync, under the account). Nothing is saved on the deal:
// the moderator checks the title and saves it.
const DEAL_TITLE_TAGS_KEY = 'dealTitleTags';
const DEAL_TITLE_FIXED_TAGS = ['REC', 'Meli+', 'Prime'];
const PELANDO_TITLE_TAGS_CLASS = 'pelando-title-tags';

// The tags in brackets at the start of a title ("[REC] [Prime] Tênis", or
// written without spaces), and the text after them.
function splitTitleTags(title) {
  const text = String(title);
  const lead = /^(?:\s*\[[^\]]*\])*\s*/.exec(text)[0];
  const tags = (lead.match(/\[[^\]]*\]/g) || []).map(function (tag) {
    return tag.slice(1, -1);
  });
  return { tags: tags, rest: tags.length ? text.slice(lead.length) : text };
}

function titleTags(title) {
  return splitTitleTags(title).tags;
}

// The title with the tag taken out when it is among the leading ones, or
// put in after them (click order), each tag followed by a space.
function toggleTitleTag(title, tag) {
  const parts = splitTitleTags(title);
  const lower = tag.toLowerCase();
  const kept = parts.tags.filter(function (t) {
    return t.toLowerCase() !== lower;
  });
  if (kept.length === parts.tags.length) kept.push(tag);
  return (
    kept
      .map(function (t) {
        return '[' + t + '] ';
      })
      .join('') + parts.rest
  );
}

function checkNewTagName(raw, existing) {
  const name = String(raw || '').trim();
  if (!name) return { ok: false, message: 'Escreva o nome da tag.' };
  if (/[[\]]/.test(name)) return { ok: false, message: 'O nome não pode ter [ nem ].' };
  const same = existing.find(function (tag) {
    return tag.toLowerCase() === name.toLowerCase();
  });
  if (same) return { ok: false, message: 'Já existe a tag [' + same + '].' };
  return { ok: true, name: name };
}

// A deal's edit page: a discussion shares it, without Link original or Preço.
function isDealTitleForm(doc, pathname) {
  if (!/^\/promocao\/[^/]+/.test(pathname)) return false;
  return !!doc.querySelector('input[name="title"]') && !!doc.querySelector('[name="sourceUrl"], [name="price"]');
}

// The form item holding the title's input.
function dealTitleItem(doc) {
  const input = doc.querySelector('input[name="title"]');
  return input ? input.closest('[data-slot="form-item"]') : null;
}

// The value through the input's own setter, then the events, so the page's
// form (React) takes it as typed.
function setDealTitle(input, value) {
  const view = input.ownerDocument.defaultView;
  Object.getOwnPropertyDescriptor(view.HTMLInputElement.prototype, 'value').set.call(input, value);
  input.dispatchEvent(new view.Event('input', { bubbles: true }));
  input.dispatchEvent(new view.Event('change', { bubbles: true }));
}

function chromeTitleTagsStorage() {
  return {
    get: function (key) {
      return chrome.storage.sync.get(key);
    },
    set: function (items) {
      return chrome.storage.sync.set(items);
    },
  };
}

async function loadCustomTitleTags(storage) {
  try {
    const stored = (await storage.get(DEAL_TITLE_TAGS_KEY))[DEAL_TITLE_TAGS_KEY];
    return Array.isArray(stored)
      ? stored.filter(function (tag) {
          return typeof tag === 'string' && tag.trim();
        })
      : [];
  } catch (err) {
    return [];
  }
}

function createDealTitleTagsRow(doc, deps) {
  const row = doc.createElement('div');
  row.className = PELANDO_TITLE_TAGS_CLASS;
  const buttons = doc.createElement('div');
  buttons.className = PELANDO_TITLE_TAGS_CLASS + '-buttons';
  const add = doc.createElement('button');
  add.type = 'button';
  add.className = PELANDO_TITLE_TAGS_CLASS + '-add';
  add.textContent = '+ Adicionar';
  const adder = doc.createElement('div');
  adder.className = PELANDO_TITLE_TAGS_CLASS + '-new';
  adder.hidden = true;
  const field = doc.createElement('input');
  field.type = 'text';
  field.placeholder = 'Nome da tag';
  field.maxLength = 30;
  const confirm = doc.createElement('button');
  confirm.type = 'button';
  confirm.textContent = '✓';
  confirm.title = 'Criar botão';
  adder.append(field, confirm);
  const message = doc.createElement('div');
  message.className = PELANDO_TITLE_TAGS_CLASS + '-message';
  message.setAttribute('role', 'status');
  row.append(buttons, adder, message);

  let custom = [];

  function input() {
    return doc.querySelector('input[name="title"]');
  }

  function refresh() {
    if (!row.isConnected) return;
    const current = input();
    const on = titleTags(current ? current.value : '').map(function (tag) {
      return tag.toLowerCase();
    });
    row.querySelectorAll('.pelando-title-tag').forEach(function (button) {
      button.setAttribute('aria-pressed', String(on.indexOf(button.dataset.tag.toLowerCase()) !== -1));
    });
  }

  function say(text) {
    message.textContent = text;
  }

  async function saveCustom(next) {
    try {
      await deps.storage.set({ [DEAL_TITLE_TAGS_KEY]: next });
      custom = next;
      render();
      return true;
    } catch (err) {
      say('Não deu para salvar a tag. Recarregue a página e tente de novo.');
      return false;
    }
  }

  function tagButton(tag, removable) {
    const wrap = doc.createElement('span');
    wrap.className = 'pelando-title-tag-wrap';
    const button = doc.createElement('button');
    button.type = 'button';
    button.className = 'pelando-title-tag';
    button.dataset.tag = tag;
    button.textContent = tag;
    button.title = 'Põe ou tira [' + tag + '] no início do título';
    button.addEventListener('click', function (event) {
      event.preventDefault();
      const current = input();
      if (!current) return;
      setDealTitle(current, toggleTitleTag(current.value, tag));
      refresh();
    });
    wrap.appendChild(button);
    if (removable) {
      const del = doc.createElement('button');
      del.type = 'button';
      del.className = 'pelando-title-tag-delete';
      del.textContent = '×';
      del.title = 'Apagar o botão ' + tag;
      del.setAttribute('aria-label', 'Apagar o botão ' + tag);
      del.addEventListener('click', function (event) {
        event.preventDefault();
        saveCustom(
          custom.filter(function (t) {
            return t !== tag;
          })
        );
      });
      wrap.appendChild(del);
    }
    return wrap;
  }

  function render() {
    buttons.textContent = '';
    DEAL_TITLE_FIXED_TAGS.forEach(function (tag) {
      buttons.appendChild(tagButton(tag, false));
    });
    custom.forEach(function (tag) {
      buttons.appendChild(tagButton(tag, true));
    });
    buttons.appendChild(add);
    refresh();
  }

  async function create() {
    const checked = checkNewTagName(field.value, DEAL_TITLE_FIXED_TAGS.concat(custom));
    if (!checked.ok) {
      say(checked.message);
      return;
    }
    if (await saveCustom(custom.concat(checked.name))) {
      field.value = '';
      adder.hidden = true;
      say('');
    }
  }

  add.addEventListener('click', function (event) {
    event.preventDefault();
    adder.hidden = !adder.hidden;
    say('');
    if (!adder.hidden) field.focus();
  });
  confirm.addEventListener('click', function (event) {
    event.preventDefault();
    create();
  });
  field.addEventListener('keydown', function (event) {
    // Enter would submit the deal's form.
    if (event.key === 'Enter') {
      event.preventDefault();
      create();
    } else if (event.key === 'Escape') {
      adder.hidden = true;
      say('');
    }
  });
  row.refresh = refresh;
  render();
  loadCustomTitleTags(deps.storage).then(function (tags) {
    custom = tags;
    render();
  });
  return row;
}

// The backoffice is a single-page app: keep one row, right below the
// title's box (above the slug), on a Pelando deal's page.
function syncDealTitleTags(doc, pathname, deps) {
  let row = doc.querySelector('.' + PELANDO_TITLE_TAGS_CLASS);
  const item = isDealTitleForm(doc, pathname) ? dealTitleItem(doc) : null;
  if (!item) {
    if (row) row.remove();
    return;
  }
  // The marks follow what is typed in the title: one listener per page,
  // for whichever row is there (deal pages come and go in the same page).
  if (!doc.pelandoTitleTagsListening) {
    doc.pelandoTitleTagsListening = true;
    doc.addEventListener('input', function (event) {
      const current = doc.querySelector('.' + PELANDO_TITLE_TAGS_CLASS);
      if (current && event.target && event.target.name === 'title') current.refresh();
    });
  }
  if (!row) row = createDealTitleTagsRow(doc, deps || { storage: chromeTitleTagsStorage() });
  let box = doc.querySelector('input[name="title"]');
  while (box.parentElement !== item) box = box.parentElement;
  if (box.nextElementSibling !== row) box.after(row);
  row.refresh();
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = {
    DEAL_TITLE_TAGS_KEY,
    titleTags,
    toggleTitleTag,
    checkNewTagName,
    syncDealTitleTags,
  };
}
