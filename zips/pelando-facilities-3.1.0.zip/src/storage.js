function generateId() {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
}

// Ids seeded by every install of the extension before `applyNewSeeds` (and its
// applied-seed tracking) existed. Used only to bootstrap `appliedSeedThemeIds`/
// `appliedSeedMessageIds` for installs upgrading from that era, so their
// pre-existing themes/messages (whether kept or since deleted by the user)
// are never mistaken for "new" seed content and re-added.
const PELANDO_CHAT_EXT_LEGACY_SEED_THEME_IDS = ['saudacoes', 'sentimos-muito', 'exclusao-conta', 'cashback'];
const PELANDO_CHAT_EXT_LEGACY_SEED_MESSAGE_IDS = ['greeting', 'promo-sing', 'promo-plural', 'coment-sing', 'coment-plural'];

async function getIndex(key) {
  const result = await chrome.storage.sync.get(key);
  return result[key] || [];
}

async function getAllThemes() {
  const ids = await getIndex('themeIds');
  if (ids.length === 0) return [];
  const keys = ids.map((id) => 'theme:' + id);
  const result = await chrome.storage.sync.get(keys);
  return keys.map((k) => result[k]).filter(Boolean);
}

async function getAllMessages() {
  const ids = await getIndex('messageIds');
  if (ids.length === 0) return [];
  const keys = ids.map((id) => 'message:' + id);
  const result = await chrome.storage.sync.get(keys);
  return keys.map((k) => result[k]).filter(Boolean);
}

async function getMessagesForTheme(temaId) {
  const all = await getAllMessages();
  return all.filter((m) => m.temaId === temaId);
}

async function ensureSeeded(seedThemes, seedMessages) {
  const existingIds = await getIndex('themeIds');
  if (existingIds.length > 0) return;

  const items = {
    themeIds: seedThemes.map((t) => t.id),
    messageIds: seedMessages.map((m) => m.id),
    appliedSeedThemeIds: seedThemes.map((t) => t.id),
    appliedSeedMessageIds: seedMessages.map((m) => m.id),
  };
  seedThemes.forEach((t) => {
    items['theme:' + t.id] = t;
  });
  seedMessages.forEach((m) => {
    items['message:' + m.id] = m;
  });
  await chrome.storage.sync.set(items);
}

// Keeps existing installs in sync with new seed content across versions,
// without touching anything the user has already customized. Only seed
// themes/messages whose id was never applied before are written; ids applied
// in a previous run are skipped even if the user has since deleted them, so
// a deletion is never undone by a later version's seed data.
async function applyNewSeeds(seedThemes, seedMessages) {
  const hadThemesBefore = (await getIndex('themeIds')).length > 0;
  await ensureSeeded(seedThemes, seedMessages);
  if (!hadThemesBefore) return;

  const themeIds = await getIndex('themeIds');
  const messageIds = await getIndex('messageIds');
  const stored = await chrome.storage.sync.get(['appliedSeedThemeIds', 'appliedSeedMessageIds']);
  const appliedThemeIds = stored.appliedSeedThemeIds || PELANDO_CHAT_EXT_LEGACY_SEED_THEME_IDS;
  const appliedMessageIds = stored.appliedSeedMessageIds || PELANDO_CHAT_EXT_LEGACY_SEED_MESSAGE_IDS;

  const newThemes = seedThemes.filter((t) => !appliedThemeIds.includes(t.id));
  const newMessages = seedMessages.filter((m) => !appliedMessageIds.includes(m.id));

  const items = {
    appliedSeedThemeIds: [...new Set([...appliedThemeIds, ...seedThemes.map((t) => t.id)])],
    appliedSeedMessageIds: [...new Set([...appliedMessageIds, ...seedMessages.map((m) => m.id)])],
  };
  if (newThemes.length > 0) {
    newThemes.forEach((t) => {
      items['theme:' + t.id] = t;
    });
    items.themeIds = [...themeIds, ...newThemes.map((t) => t.id)];
  }
  if (newMessages.length > 0) {
    newMessages.forEach((m) => {
      items['message:' + m.id] = m;
    });
    items.messageIds = [...messageIds, ...newMessages.map((m) => m.id)];
  }
  await chrome.storage.sync.set(items);
}

async function saveIndex(key, ids) {
  await chrome.storage.sync.set({ [key]: ids });
}

async function getNotificationsEnabled() {
  const result = await chrome.storage.sync.get('notificationsEnabled');
  return result.notificationsEnabled !== false;
}

async function setNotificationsEnabled(enabled) {
  await chrome.storage.sync.set({ notificationsEnabled: enabled });
}

// Highlights "duplicada" and the listed nicknames on the backoffice's
// reports (reportHighlight.js reads the same key). Off unless turned on.
async function getReportHighlightEnabled() {
  const result = await chrome.storage.sync.get('reportHighlightEnabled');
  return result.reportHighlightEnabled === true;
}

async function setReportHighlightEnabled(enabled) {
  await chrome.storage.sync.set({ reportHighlightEnabled: enabled === true });
}

// "Testar Promoção" in the backoffice (priceTest/panel.js reads the same
// key). Off for whoever never turned it on; only this switch changes it, so
// once on it stays on across updates.
async function getPriceTestEnabled() {
  const result = await chrome.storage.sync.get('priceTestEnabled');
  return result.priceTestEnabled === true;
}

async function setPriceTestEnabled(enabled) {
  await chrome.storage.sync.set({ priceTestEnabled: enabled === true });
}

// How often the backoffice's site monitor checks the sites, in minutes
// (siteMonitor.js reads the same key, with the same limits).
const PELANDO_CHAT_EXT_SITE_MONITOR_MINUTES = { default: 5, min: 1, max: 120 };

function clampSiteMonitorMinutes(value) {
  const limits = PELANDO_CHAT_EXT_SITE_MONITOR_MINUTES;
  const minutes = Math.round(Number(value));
  if (!Number.isFinite(minutes)) return limits.default;
  return Math.min(Math.max(minutes, limits.min), limits.max);
}

async function getSiteMonitorMinutes() {
  const result = await chrome.storage.sync.get('siteMonitorMinutes');
  if (result.siteMonitorMinutes === undefined) return PELANDO_CHAT_EXT_SITE_MONITOR_MINUTES.default;
  return clampSiteMonitorMinutes(result.siteMonitorMinutes);
}

async function setSiteMonitorMinutes(minutes) {
  await chrome.storage.sync.set({ siteMonitorMinutes: clampSiteMonitorMinutes(minutes) });
}

// Each moderator picks the popover's size; kept within limits that leave it
// usable on any screen.
const PELANDO_CHAT_EXT_DEFAULT_POPOVER_SIZE = { width: 700, height: 450 };
const PELANDO_CHAT_EXT_POPOVER_SIZE_LIMITS = {
  width: { min: 400, max: 1200 },
  height: { min: 250, max: 900 },
};

function clampPopoverDimension(value, limits, fallback) {
  const num = Number(value);
  if (value === null || value === undefined || value === '' || !Number.isFinite(num)) return fallback;
  return Math.round(Math.min(limits.max, Math.max(limits.min, num)));
}

function clampPopoverSize(size) {
  const defaults = PELANDO_CHAT_EXT_DEFAULT_POPOVER_SIZE;
  const limits = PELANDO_CHAT_EXT_POPOVER_SIZE_LIMITS;
  return {
    width: clampPopoverDimension(size && size.width, limits.width, defaults.width),
    height: clampPopoverDimension(size && size.height, limits.height, defaults.height),
  };
}

async function getPopoverSize() {
  const result = await chrome.storage.sync.get('popoverSize');
  return clampPopoverSize(result.popoverSize);
}

// Saves the size, clamped to the limits, and returns what was saved.
async function setPopoverSize(size) {
  const clamped = clampPopoverSize(size);
  await chrome.storage.sync.set({ popoverSize: clamped });
  return clamped;
}

// Keeps a window of `size` whole inside `viewport`, `margin` px from the
// edges, so a position saved on a bigger screen still shows it all.
function clampPopoverPosition(position, size, viewport, margin) {
  const gap = typeof margin === 'number' ? margin : 8;
  const maxLeft = Math.max(gap, viewport.width - size.width - gap);
  const maxTop = Math.max(gap, viewport.height - size.height - gap);
  return {
    left: Math.round(Math.min(maxLeft, Math.max(gap, position.left))),
    top: Math.round(Math.min(maxTop, Math.max(gap, position.top))),
  };
}

// How the quick replies open: as a balloon above the chat's button, or as a
// panel on the right of the screen, next to the chat.
const PELANDO_CHAT_EXT_LAYOUTS = ['balloon', 'panel'];

async function getPopoverLayout() {
  const result = await chrome.storage.sync.get('popoverLayout');
  return PELANDO_CHAT_EXT_LAYOUTS.includes(result.popoverLayout) ? result.popoverLayout : 'balloon';
}

async function setPopoverLayout(layout) {
  const saved = PELANDO_CHAT_EXT_LAYOUTS.includes(layout) ? layout : 'balloon';
  await chrome.storage.sync.set({ popoverLayout: saved });
  return saved;
}

// The side panel's width is a share of the screen, so it keeps its
// proportion on any monitor; the balloon keeps its own size in pixels.
const PELANDO_CHAT_EXT_DEFAULT_PANEL_WIDTH_PERCENT = 30;
const PELANDO_CHAT_EXT_PANEL_WIDTH_LIMITS = { min: 15, max: 60 };

async function getPanelWidthPercent() {
  const result = await chrome.storage.sync.get('panelWidthPercent');
  return clampPopoverDimension(
    result.panelWidthPercent,
    PELANDO_CHAT_EXT_PANEL_WIDTH_LIMITS,
    PELANDO_CHAT_EXT_DEFAULT_PANEL_WIDTH_PERCENT
  );
}

async function setPanelWidthPercent(percent) {
  const clamped = clampPopoverDimension(
    percent,
    PELANDO_CHAT_EXT_PANEL_WIDTH_LIMITS,
    PELANDO_CHAT_EXT_DEFAULT_PANEL_WIDTH_PERCENT
  );
  await chrome.storage.sync.set({ panelWidthPercent: clamped });
  return clamped;
}

// Where the moderator last dropped the popover, or null to open it above
// the chat's button.
async function getPopoverPosition() {
  const result = await chrome.storage.sync.get('popoverPosition');
  const position = result.popoverPosition;
  if (!position || !Number.isFinite(position.left) || !Number.isFinite(position.top)) return null;
  return { left: position.left, top: position.top };
}

async function setPopoverPosition(position) {
  if (!position) {
    await chrome.storage.sync.remove('popoverPosition');
    return null;
  }
  const saved = { left: Math.round(position.left), top: Math.round(position.top) };
  await chrome.storage.sync.set({ popoverPosition: saved });
  return saved;
}

async function createTheme(nome, palavrasChave) {
  const theme = { id: generateId(), nome, palavrasChave: palavrasChave || [] };
  const ids = await getIndex('themeIds');
  await chrome.storage.sync.set({ ['theme:' + theme.id]: theme });
  await saveIndex('themeIds', [...ids, theme.id]);
  return theme;
}

// The greeting opens every conversation (and the justification of a rejected
// deal), so it can't be deleted or renamed, nor can its "Saudações" theme:
// only its text can be edited.
const PELANDO_CHAT_EXT_GREETING_THEME = { id: 'saudacoes', nome: 'Saudações', palavrasChave: [] };
const PELANDO_CHAT_EXT_GREETING_MESSAGE = {
  id: 'greeting',
  temaId: 'saudacoes',
  nome: 'Salve {nome}, tudo bem?',
  texto: 'Salve {nome}, tudo bem?',
};
const PELANDO_CHAT_EXT_GREETING_PROTECTED_ERROR = 'A saudação não pode ser apagada nem renomeada, só o texto dela pode ser editado.';

function isProtectedTheme(id) {
  return id === PELANDO_CHAT_EXT_GREETING_THEME.id;
}

function isProtectedMessage(id) {
  return id === PELANDO_CHAT_EXT_GREETING_MESSAGE.id;
}

// Puts the greeting and its theme back when missing (deleted before they were
// protected, or left out of an import), and undoes a rename; its text, and
// any keywords on the theme, are kept.
async function ensureGreetingProtected() {
  const theme = PELANDO_CHAT_EXT_GREETING_THEME;
  const message = PELANDO_CHAT_EXT_GREETING_MESSAGE;
  const themeIds = await getIndex('themeIds');
  const messageIds = await getIndex('messageIds');
  const stored = await chrome.storage.sync.get(['theme:' + theme.id, 'message:' + message.id]);
  const storedTheme = stored['theme:' + theme.id];
  const storedMessage = stored['message:' + message.id];
  const items = {};

  if (!storedTheme || storedTheme.nome !== theme.nome) {
    items['theme:' + theme.id] = { ...theme, ...(storedTheme || {}), id: theme.id, nome: theme.nome };
  }
  if (!themeIds.includes(theme.id)) items.themeIds = [theme.id, ...themeIds];

  if (!storedMessage || storedMessage.nome !== message.nome || storedMessage.temaId !== message.temaId) {
    items['message:' + message.id] = {
      ...message,
      texto: (storedMessage && storedMessage.texto) || message.texto,
    };
  }
  if (!messageIds.includes(message.id)) items.messageIds = [message.id, ...messageIds];

  if (Object.keys(items).length > 0) await chrome.storage.sync.set(items);
}

async function updateTheme(id, changes) {
  const result = await chrome.storage.sync.get('theme:' + id);
  const existing = result['theme:' + id];
  if (!existing) return;
  const updated = { ...existing, ...changes, id };
  if (isProtectedTheme(id)) updated.nome = existing.nome;
  await chrome.storage.sync.set({ ['theme:' + id]: updated });
}

async function deleteTheme(id) {
  if (isProtectedTheme(id)) throw new Error(PELANDO_CHAT_EXT_GREETING_PROTECTED_ERROR);
  const themeIds = await getIndex('themeIds');
  await saveIndex('themeIds', themeIds.filter((tid) => tid !== id));
  await chrome.storage.sync.remove('theme:' + id);

  const messages = await getMessagesForTheme(id);
  const messageIds = await getIndex('messageIds');
  await saveIndex(
    'messageIds',
    messageIds.filter((mid) => !messages.some((m) => m.id === mid))
  );
  if (messages.length > 0) {
    await chrome.storage.sync.remove(messages.map((m) => 'message:' + m.id));
  }
}

async function createMessage(temaId, nome, texto) {
  const message = { id: generateId(), temaId, nome, texto };
  const ids = await getIndex('messageIds');
  await chrome.storage.sync.set({ ['message:' + message.id]: message });
  await saveIndex('messageIds', [...ids, message.id]);
  return message;
}

async function updateMessage(id, changes) {
  const result = await chrome.storage.sync.get('message:' + id);
  const existing = result['message:' + id];
  if (!existing) return;
  const updated = { ...existing, ...changes, id };
  if (isProtectedMessage(id)) {
    updated.nome = existing.nome;
    updated.temaId = existing.temaId;
  }
  await chrome.storage.sync.set({ ['message:' + id]: updated });
}

// Reorders only the messages belonging to `temaId`, preserving the relative
// position of every other theme's messages in the shared `messageIds` index.
async function reorderMessagesForTheme(temaId, orderedIds) {
  const messageIds = await getIndex('messageIds');
  const messages = await getAllMessages();
  const idToMessage = new Map(messages.map((m) => [m.id, m]));

  const themeIdCount = messageIds.filter((id) => {
    const m = idToMessage.get(id);
    return m && m.temaId === temaId;
  }).length;
  if (orderedIds.length !== themeIdCount) return;

  let cursor = 0;
  const newOrder = messageIds.map((id) => {
    const m = idToMessage.get(id);
    if (m && m.temaId === temaId) {
      return orderedIds[cursor++];
    }
    return id;
  });
  await saveIndex('messageIds', newOrder);
}

async function deleteMessage(id) {
  if (isProtectedMessage(id)) throw new Error(PELANDO_CHAT_EXT_GREETING_PROTECTED_ERROR);
  const messageIds = await getIndex('messageIds');
  await saveIndex('messageIds', messageIds.filter((mid) => mid !== id));
  await chrome.storage.sync.remove('message:' + id);
}

async function exportAll() {
  const themes = await getAllThemes();
  const messages = await getAllMessages();
  return { themes, messages };
}

function isValidExportShape(data) {
  if (!data || typeof data !== 'object') return false;
  if (!Array.isArray(data.themes) || !Array.isArray(data.messages)) return false;
  const themesValid = data.themes.every(
    (t) =>
      t &&
      typeof t.id === 'string' &&
      typeof t.nome === 'string' &&
      Array.isArray(t.palavrasChave) &&
      t.palavrasChave.every((k) => typeof k === 'string')
  );
  const messagesValid = data.messages.every(
    (m) => m && typeof m.id === 'string' && typeof m.temaId === 'string' && typeof m.nome === 'string' && typeof m.texto === 'string'
  );
  if (!themesValid || !messagesValid) return false;

  const allIds = data.themes.map((t) => t.id).concat(data.messages.map((m) => m.id));
  if (new Set(allIds).size !== allIds.length) return false;

  if (data.themes.length + data.messages.length + 2 > 512) return false;

  return true;
}

async function importAll(data) {
  if (!isValidExportShape(data)) {
    throw new Error('Formato de importação inválido');
  }

  const oldThemeIds = await getIndex('themeIds');
  const oldMessageIds = await getIndex('messageIds');
  if (oldThemeIds.length > 0) {
    await chrome.storage.sync.remove(oldThemeIds.map((id) => 'theme:' + id));
  }
  if (oldMessageIds.length > 0) {
    await chrome.storage.sync.remove(oldMessageIds.map((id) => 'message:' + id));
  }

  const items = {
    themeIds: data.themes.map((t) => t.id),
    messageIds: data.messages.map((m) => m.id),
  };
  data.themes.forEach((t) => {
    items['theme:' + t.id] = t;
  });
  data.messages.forEach((m) => {
    items['message:' + m.id] = m;
  });
  await chrome.storage.sync.set(items);
  // An imported file without the greeting (or with it renamed) keeps it.
  await ensureGreetingProtected();
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = {
    generateId,
    getAllThemes,
    getAllMessages,
    getMessagesForTheme,
    ensureSeeded,
    applyNewSeeds,
    createTheme,
    updateTheme,
    deleteTheme,
    createMessage,
    updateMessage,
    deleteMessage,
    reorderMessagesForTheme,
    exportAll,
    importAll,
    getNotificationsEnabled,
    setNotificationsEnabled,
    getReportHighlightEnabled,
    setReportHighlightEnabled,
    getPriceTestEnabled,
    setPriceTestEnabled,
    getSiteMonitorMinutes,
    setSiteMonitorMinutes,
    PELANDO_CHAT_EXT_SITE_MONITOR_MINUTES,
    getPopoverSize,
    setPopoverSize,
    clampPopoverSize,
    isProtectedTheme,
    isProtectedMessage,
    ensureGreetingProtected,
    getPopoverLayout,
    setPopoverLayout,
    getPanelWidthPercent,
    setPanelWidthPercent,
    PELANDO_CHAT_EXT_DEFAULT_PANEL_WIDTH_PERCENT,
    PELANDO_CHAT_EXT_PANEL_WIDTH_LIMITS,
    getPopoverPosition,
    setPopoverPosition,
    clampPopoverPosition,
    PELANDO_CHAT_EXT_DEFAULT_POPOVER_SIZE,
    PELANDO_CHAT_EXT_POPOVER_SIZE_LIMITS,
  };
}
