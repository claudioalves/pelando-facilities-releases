// "Resumo da moderação" on the backoffice deal page: what "Histórico Keepa"
// (src/keepa/panel.js) and "Testar Promoção" (src/priceTest/panel.js) found,
// as signals, and the verdict of all of them. No DOM here; the banner is
// src/summary/panel.js. Reads keepaApprox and KEEPA_ERROR_TEXTS
// (keepa/panel.js), priceTestFormat (priceTest/compare.js) and
// PELANDO_REJECTION_REASONS (rejectionReasonsData.js) when called.
//
// A signal: { source: 'keepa' | 'test', level, text, reason }, level one of
// ok (green), slight (yellow), bad (red), none (grey: nothing to say yet),
// reason the code of the rejection reason it points to (bad only) or null.

const SUMMARY_LEVEL_RANK = { none: 0, ok: 1, slight: 2, bad: 3 };

const SUMMARY_TITLES = {
  ok: '🟢 Tudo confere',
  slight: '🟡 Atenção',
  bad: '🔴 Não confere',
  none: '⚪ Aguardando — rode o Testar Promoção para conferir o preço na loja',
};

// Which bad signal names the reason when several do.
const SUMMARY_REASON_PRIORITY = [
  ['test', '11'],
  ['test', '13'],
  ['test', '03'],
  ['keepa', '03'],
];

// The banner's lines: the test first, then Keepa.
const SUMMARY_SOURCE_ORDER = ['test', 'keepa'];

// Codes of the test's errors that mean the deal is over (reason 11).
const SUMMARY_TEST_GONE_CODES = ['OUT_OF_STOCK', 'OFFER_GONE', 'VARIATION_GONE'];

function summarySignal(source, level, text, reason) {
  return { source: source, level: level, text: text, reason: reason || null };
}

// From the service worker's keepaReport response as the card gets it; null
// while it is on its way.
function summarySignalFromKeepa(response) {
  if (!response) return summarySignal('keepa', 'none', 'Keepa: carregando…');
  const stats = response.ok ? response.stats : null;
  if (!stats || !stats.lowest) {
    return summarySignal('keepa', 'none', 'Keepa: ' + (KEEPA_ERROR_TEXTS[response.error] || KEEPA_ERROR_TEXTS.rede));
  }
  const verdict = stats.verdict;
  if (!verdict) return summarySignal('keepa', 'none', 'Keepa: promoção sem preço para comparar');
  if (verdict.kind === 'ok') return summarySignal('keepa', 'ok', 'Keepa: menor preço dos últimos 180 dias');
  const text =
    'Keepa: ' + keepaApprox(verdict.difference) + ' acima do menor (' + keepaApprox(stats.lowest.price) + ' em ' + stats.lowest.date + ')';
  return verdict.kind === 'slight' ? summarySignal('keepa', 'slight', text) : summarySignal('keepa', 'bad', text, '03');
}

function summarySignalFromTestResult(message) {
  if (message.status === 'validated') return summarySignal('test', 'ok', 'Teste: preço confere na loja');
  const product = message.productCents;
  const advertised = message.advertisedCents;
  const known = typeof product === 'number' && typeof advertised === 'number';
  if (known && message.status === 'diverges' && product < advertised) {
    return summarySignal('test', 'slight', 'Teste: loja está ' + priceTestFormat(advertised - product) + ' mais barata — atualize o preço');
  }
  const charged = known
    ? 'loja cobra ' + priceTestFormat(product) + ' (promoção ' + priceTestFormat(advertised) + ')'
    : (message.lines || [])[0] || 'preço diferente na loja';
  const text = 'Teste: ' + (message.couponRejected ? 'cupom recusado; ' : '') + charged;
  if (message.status === 'slightly') return summarySignal('test', 'slight', text);
  return summarySignal('test', 'bad', text, message.couponRejected ? '13' : '03');
}

// From the last priceTest:* message of the page's deal; null before any.
function summarySignalFromPriceTest(message) {
  if (!message) return summarySignal('test', 'none', 'Teste: não rodado');
  if (message.type === 'priceTest:progress') return summarySignal('test', 'none', 'Teste: rodando…');
  if (message.type === 'priceTest:needsHuman') return summarySignal('test', 'none', 'Teste: precisa de ação na aba da loja');
  if (message.type === 'priceTest:result') return summarySignalFromTestResult(message);
  if (message.type !== 'priceTest:error') return null;
  const said = message.message || '';
  if (SUMMARY_TEST_GONE_CODES.indexOf(message.code) !== -1) return summarySignal('test', 'bad', 'Teste: ' + said, '11');
  if (message.code === 'COUPON_REJECTED') return summarySignal('test', 'bad', 'Teste: ' + said, '13');
  if (message.code === 'NO_FEATURED_OFFER') return summarySignal('test', 'slight', 'Teste: ' + said);
  return summarySignal('test', 'none', 'Teste: não concluiu — ' + said);
}

function summaryReason(signals) {
  for (let i = 0; i < SUMMARY_REASON_PRIORITY.length; i++) {
    const source = SUMMARY_REASON_PRIORITY[i][0];
    const code = SUMMARY_REASON_PRIORITY[i][1];
    const found = signals.some(function (signal) {
      return signal.level === 'bad' && signal.source === source && signal.reason === code;
    });
    if (!found) continue;
    const reason = PELANDO_REJECTION_REASONS.find(function (entry) {
      return entry.code === code;
    });
    return reason ? { code: code, title: reason.title } : null;
  }
  return null;
}

// The banner for these signals; null without any (no banner).
function summaryVerdict(signals) {
  if (!signals.length) return null;
  const ordered = signals.slice().sort(function (a, b) {
    return SUMMARY_SOURCE_ORDER.indexOf(a.source) - SUMMARY_SOURCE_ORDER.indexOf(b.source);
  });
  const level = ordered.reduce(function (worst, signal) {
    return SUMMARY_LEVEL_RANK[signal.level] > SUMMARY_LEVEL_RANK[worst] ? signal.level : worst;
  }, 'none');
  // Without the test (off in the chat's settings), grey names no button.
  const hasTest = ordered.some(function (signal) {
    return signal.source === 'test';
  });
  return {
    level: level,
    title: level === 'none' && !hasTest ? '⚪ Aguardando' : SUMMARY_TITLES[level],
    lines: ordered.map(function (signal) {
      return { level: signal.level, text: signal.text };
    }),
    reason: level === 'bad' ? summaryReason(ordered) : null,
  };
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = { summarySignalFromKeepa, summarySignalFromPriceTest, summaryVerdict };
}
