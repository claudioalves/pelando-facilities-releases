// "Resumo da moderação" on the backoffice deal page: a banner right below the
// deal's title field (above "Testar Promoção" and "Histórico Keepa") with the
// verdict of their signals (src/summary/summary.js, store.js) and, when the
// deal doesn't hold up, the suggested rejection reason, which is ticked once
// in the backoffice's reject dialog. The moderator still decides.
const PELANDO_SUMMARY_CLASS = 'pelando-summary';

function summaryElement(doc, tag, className, text) {
  const el = doc.createElement(tag);
  el.className = className;
  if (text !== undefined) el.textContent = text;
  return el;
}

// Draws the banner for its deal's signals; hidden without any. A failure
// hides it: the cards below stay as they are.
function renderModerationSummary(banner) {
  const doc = banner.ownerDocument;
  try {
    const verdict = summaryVerdict(summarySignals(banner.dataset.dealId));
    banner.textContent = '';
    delete banner.dataset.reasonTitle;
    if (!verdict) {
      banner.hidden = true;
      return;
    }
    banner.className = PELANDO_SUMMARY_CLASS + ' ' + PELANDO_SUMMARY_CLASS + '--' + verdict.level;
    banner.appendChild(summaryElement(doc, 'div', PELANDO_SUMMARY_CLASS + '-title', verdict.title));
    verdict.lines.forEach(function (line) {
      banner.appendChild(
        summaryElement(doc, 'div', PELANDO_SUMMARY_CLASS + '-line ' + PELANDO_SUMMARY_CLASS + '-line--' + line.level, line.text)
      );
    });
    if (verdict.reason) {
      banner.appendChild(summaryElement(doc, 'div', PELANDO_SUMMARY_CLASS + '-reason', 'Motivo sugerido: ' + verdict.reason.title));
      banner.dataset.reasonTitle = verdict.reason.title;
    }
    banner.hidden = false;
  } catch (err) {
    console.warn('[pelando-chat-ext] resumo da moderação falhou:', err);
    banner.textContent = '';
    delete banner.dataset.reasonTitle;
    banner.hidden = true;
  }
}

function createModerationSummary(doc, dealId) {
  const banner = doc.createElement('div');
  banner.className = PELANDO_SUMMARY_CLASS;
  banner.dataset.dealId = dealId;
  banner.hidden = true;
  const unsubscribe = onSummaryChange(function (changed) {
    // A banner the page dropped stops listening.
    if (!banner.isConnected) {
      unsubscribe();
      return;
    }
    if (changed === dealId) renderModerationSummary(banner);
  });
  banner.pelandoUnsubscribe = unsubscribe;
  renderModerationSummary(banner);
  return banner;
}

function removeModerationSummary(banner) {
  if (banner.pelandoUnsubscribe) banner.pelandoUnsubscribe();
  banner.remove();
}

// One banner, for the deal in the URL (the backoffice is a single-page app),
// right below the title field (priceTestTitleField); no title field, no banner.
function syncModerationSummary(doc, pathname) {
  const dealId = backofficeDealIdFromPath(pathname);
  let banner = doc.querySelector('.' + PELANDO_SUMMARY_CLASS);
  if (banner && banner.dataset.dealId !== dealId) {
    removeModerationSummary(banner);
    banner = null;
  }
  if (!dealId) return;
  const title = priceTestTitleField(doc);
  if (!title) {
    if (banner) removeModerationSummary(banner);
    return;
  }
  if (!banner) banner = createModerationSummary(doc, dealId);
  if (title.nextElementSibling !== banner) title.insertAdjacentElement('afterend', banner);
}

// On the deal page only: in the backoffice's reject dialog for deals
// (findBackofficeDecisionDialogs, which leaves the comment one alone), ticks
// the banner's suggested reason once per dialog. A reason the moderator
// unticks stays unticked.
function syncSummaryPreselect(doc, pathname) {
  const dealId = backofficeDealIdFromPath(pathname);
  if (!dealId) return;
  const banner = doc.querySelector('.' + PELANDO_SUMMARY_CLASS);
  if (!banner || banner.dataset.dealId !== dealId || !banner.dataset.reasonTitle) return;
  const wanted = normalizeReasonTitle(banner.dataset.reasonTitle);
  findBackofficeDecisionDialogs(doc).forEach(function (dialog) {
    if (dialog.hasAttribute('data-pelando-preselected')) return;
    const item = Array.from(dialog.querySelectorAll('[data-slot="command-item"]')).find(function (candidate) {
      return normalizeReasonTitle(candidate.textContent) === wanted;
    });
    if (!item) return;
    const box = item.querySelector('[data-slot="checkbox"]');
    if (!box || box.getAttribute('data-state') !== 'checked') item.click();
    dialog.setAttribute('data-pelando-preselected', '');
  });
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = { PELANDO_SUMMARY_CLASS, syncModerationSummary, syncSummaryPreselect };
}
