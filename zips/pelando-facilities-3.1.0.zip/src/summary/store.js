// The moderation summary's signals (src/summary/summary.js), in the page's
// memory: the last one of each source per deal. The Keepa card and "Testar
// Promoção" publish, the banner (src/summary/panel.js) listens. Nothing is
// stored anywhere else.

const summarySignalsByDeal = new Map();
const summaryListeners = new Set();

function publishSummarySignal(dealId, signal) {
  if (!dealId || !signal) return;
  let bySource = summarySignalsByDeal.get(dealId);
  if (!bySource) {
    bySource = new Map();
    summarySignalsByDeal.set(dealId, bySource);
  }
  bySource.set(signal.source, signal);
  summaryNotify(dealId);
}

// A source that no longer applies to the deal ("Testar Promoção" turned off
// in the chat's settings).
function summaryForgetSignal(dealId, source) {
  const bySource = summarySignalsByDeal.get(dealId);
  if (!bySource || !bySource.delete(source)) return;
  summaryNotify(dealId);
}

function summaryNotify(dealId) {
  Array.from(summaryListeners).forEach(function (listener) {
    try {
      listener(dealId);
    } catch (err) {
      console.warn('[pelando-chat-ext] resumo da moderação falhou:', err);
    }
  });
}

function summarySignals(dealId) {
  const bySource = summarySignalsByDeal.get(dealId);
  return bySource ? Array.from(bySource.values()) : [];
}

function onSummaryChange(listener) {
  summaryListeners.add(listener);
  return function () {
    summaryListeners.delete(listener);
  };
}

function resetSummaryStore() {
  summarySignalsByDeal.clear();
  summaryListeners.clear();
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = { publishSummarySignal, summarySignals, onSummaryChange, resetSummaryStore, summaryForgetSignal };
}
