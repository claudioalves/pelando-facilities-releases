// Sites whose deals are edited on their own backoffice: www.<domain> ->
// bo.<domain>. Pelando and the Promoninja countries.
const PELANDO_EDIT_SITE_DOMAINS = [
  'pelando.com.br',
  'promoninja.com',
  'promoninja.com.ar',
  'promoninja.co.uk',
  'promoninja.es',
  'promoninja.de',
  'promoninja.fr',
];
const PELANDO_EDIT_BUTTON_CLASS = 'pelando-edit-button';

// Deals live under /d/ and discussions under /t/; both have an edit page on
// the backoffice at the exact same path.
function isEditableDealPath(pathname) {
  return /^\/(d|t)\/[^/]+/.test(pathname);
}

// Returns the backoffice edit URL for a public deal URL, or null when the URL
// isn't a deal/discussion on www.pelando.com.br or a www.promoninja.* site.
function toBackofficeUrl(href, baseUrl) {
  let url;
  try {
    url = new URL(href, baseUrl);
  } catch (err) {
    return null;
  }
  const match = url.hostname.match(/^www\.(.+)$/);
  if (!match || !PELANDO_EDIT_SITE_DOMAINS.includes(match[1])) return null;
  if (!isEditableDealPath(url.pathname)) return null;
  url.hostname = 'bo.' + match[1];
  return url.toString();
}

function createEditButton(editUrl) {
  const button = document.createElement('a');
  button.className = PELANDO_EDIT_BUTTON_CLASS;
  button.href = editUrl;
  button.textContent = 'Editar';
  // Cards may react to clicks anywhere inside them; keep the click to the
  // button's own navigation.
  button.addEventListener('click', function (event) {
    event.stopPropagation();
  });
  return button;
}

// Appends Editar plus, when dealActions.js is loaded, the backoffice action
// buttons for the same deal.
function appendDealButtons(title, editUrl, options) {
  title.appendChild(createEditButton(editUrl));
  if (typeof createDealActionButtons === 'function') {
    createDealActionButtons(editUrl, options).forEach(function (button) {
      title.appendChild(button);
    });
  }
}

function hasEditButton(title) {
  return !!title.querySelector('.' + PELANDO_EDIT_BUTTON_CLASS);
}

function injectCardEditButtons(root, baseUrl) {
  const links = root.querySelectorAll('h3 > a[href]');
  links.forEach(function (link) {
    const title = link.parentElement;
    if (hasEditButton(title)) return;
    const editUrl = toBackofficeUrl(link.getAttribute('href'), baseUrl);
    if (!editUrl) return;
    appendDealButtons(title, editUrl);
  });
}

function injectDealPageEditButton(root, pageUrl) {
  const editUrl = toBackofficeUrl(pageUrl);
  if (!editUrl) return;
  const title = root.querySelector('header h1');
  if (!title || hasEditButton(title)) return;
  appendDealButtons(title, editUrl, { dealPage: true });
}

function injectEditButtons(root, pageUrl) {
  injectCardEditButtons(root, pageUrl);
  injectDealPageEditButton(root, pageUrl);
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = { isEditableDealPath, toBackofficeUrl, createEditButton, injectEditButtons };
}
