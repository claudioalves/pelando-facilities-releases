// Starts only for a Pelando account (see access.js).
pelandoWhenAllowed(function () {
  let scheduled = false;

  // One feature failing on some page must not keep the others from running.
  function runSync(name, sync) {
    try {
      sync();
    } catch (err) {
      console.warn('[pelando-chat-ext] ' + name + ' falhou:', err);
    }
  }

  // The backoffice is a single-page app and opens its dialogs on demand, so
  // re-check on DOM changes, batched to one pass per frame.
  function scheduleSync() {
    if (scheduled) return;
    scheduled = true;
    requestAnimationFrame(function () {
      scheduled = false;
      runSync('syncBackofficeJustifyButton', function () {
        syncBackofficeJustifyButton(document, window.location.pathname);
      });
      runSync('syncPriceTestButton', function () {
        syncPriceTestButton(document, window.location.pathname, pelandoPriceTestDeps);
      });
      runSync('sortBackofficeReasonLists', function () {
        sortBackofficeReasonLists(document.body);
      });
      runSync('syncBackofficeRejectReport', function () {
        syncBackofficeRejectReport(document);
      });
      runSync('syncDiscussionAiButton', function () {
        syncDiscussionAiButton(document, {
          copyText: (text) => navigator.clipboard.writeText(text),
          openTab: (url) => window.open(url, '_blank', 'noopener,noreferrer'),
        });
      });
    });
  }

  // Progress and result of "Testar Promoção" (src/priceTest/panel.js).
  listenForPriceTestMessages(document, pelandoPriceTestDeps);

  // Which card opened the backoffice's reasons dialog (see backofficeRejectReport.js).
  document.addEventListener('click', rememberBackofficeDecisionClick, true);

  const observer = new MutationObserver(scheduleSync);
  observer.observe(document.body, { childList: true, subtree: true });

  scheduleSync();
});
