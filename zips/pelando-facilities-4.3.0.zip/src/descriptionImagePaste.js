// "Colar imagem" on the backoffice deal page, next to the label of "Descrição
// curta": takes the image copied (a print of the cart with Win+Shift+S,
// Chrome's "Copiar imagem"), turns it into a JPG and puts it at the end of the
// description, on a line of its own, the way "Adicionar imagem na descrição"
// of "Testar Promoção" does: through the editor's own image button, so the
// backoffice uploads it. The deal only changes when the form is saved.
// Ctrl+V in the editor is left to the backoffice.
const PELANDO_DESCRIPTION_PASTE_CLASS = 'pelando-description-paste';

const DESCRIPTION_PASTE_MESSAGES = {
  'no-image': 'Não há imagem copiada. Tire um print (Win+Shift+S) ou use "Copiar imagem" e tente de novo',
  denied: 'O Chrome bloqueou a leitura do que foi copiado. Clique no cadeado da barra de endereço → Área de transferência → Permitir',
  'bad-image': 'Não consegui abrir a imagem copiada',
  'no-field': 'Não achei o campo "Descrição curta"',
};

const DESCRIPTION_PASTE_NOTICE_MS = 5000;

// The label of "Descrição curta" (not of "Descrição"), in a field that has
// the Quill editor.
function findShortDescriptionLabel(doc) {
  const items = doc.querySelectorAll('[data-slot="form-item"]');
  for (const item of items) {
    if (!item.querySelector('.ql-editor')) continue;
    const label = Array.from(item.querySelectorAll('label')).find(function (el) {
      return /^descri[cç][aã]o curta$/i.test((el.textContent || '').trim());
    });
    if (label) return label;
  }
  return null;
}

function syncDescriptionPasteButton(doc, deps) {
  const label = findShortDescriptionLabel(doc);
  if (!label || !label.parentElement) return;
  if (label.parentElement.querySelector('.' + PELANDO_DESCRIPTION_PASTE_CLASS)) return;
  const button = doc.createElement('button');
  button.type = 'button';
  button.className = PELANDO_DESCRIPTION_PASTE_CLASS;
  button.textContent = 'Colar imagem';
  button.title = 'Põe a imagem copiada (Win+Shift+S ou "Copiar imagem") no fim da descrição curta';
  button.addEventListener('click', function () {
    if (button.disabled) return;
    button.disabled = true;
    button.textContent = 'Colando imagem…';
    pasteImageIntoDescription(doc, deps).finally(function () {
      button.disabled = false;
      button.textContent = 'Colar imagem';
    });
  });
  label.insertAdjacentElement('afterend', button);
}

function descriptionPasteTwo(n) {
  return String(n).padStart(2, '0');
}

// print-2026-11-15-09h07m03s.jpg, local time.
function descriptionPasteFileName(date) {
  return (
    'print-' + date.getFullYear() + '-' + descriptionPasteTwo(date.getMonth() + 1) + '-' + descriptionPasteTwo(date.getDate()) +
    '-' + descriptionPasteTwo(date.getHours()) + 'h' + descriptionPasteTwo(date.getMinutes()) + 'm' + descriptionPasteTwo(date.getSeconds()) + 's.jpg'
  );
}

// Right after the button, one at a time, gone after 5 s.
function showDescriptionPasteNotice(doc, text) {
  const button = doc.querySelector('.' + PELANDO_DESCRIPTION_PASTE_CLASS);
  if (!button || !button.parentElement) return;
  let note = button.parentElement.querySelector('.pelando-description-paste-notice');
  if (!note) {
    note = doc.createElement('p');
    note.className = 'pelando-description-paste-notice';
    note.setAttribute('role', 'status');
    button.insertAdjacentElement('afterend', note);
  }
  note.textContent = text;
  clearTimeout(note.pelandoTimer);
  note.pelandoTimer = setTimeout(function () {
    note.remove();
  }, DESCRIPTION_PASTE_NOTICE_MS);
}

// The copied image, as a JPG, at the end of "Descrição curta". Answers what
// happened.
async function pasteImageIntoDescription(doc, deps) {
  const use = Object.assign({}, pelandoDescriptionPasteDeps, deps);
  if (!findShortDescriptionLabel(doc)) {
    showDescriptionPasteNotice(doc, DESCRIPTION_PASTE_MESSAGES['no-field']);
    return 'no-field';
  }
  let image;
  try {
    image = await use.readImage();
  } catch (err) {
    showDescriptionPasteNotice(doc, DESCRIPTION_PASTE_MESSAGES.denied);
    return 'denied';
  }
  if (!image) {
    showDescriptionPasteNotice(doc, DESCRIPTION_PASTE_MESSAGES['no-image']);
    return 'no-image';
  }
  let jpeg;
  try {
    jpeg = await use.toJpeg(image);
  } catch (err) {
    showDescriptionPasteNotice(doc, DESCRIPTION_PASTE_MESSAGES['bad-image']);
    return 'bad-image';
  }
  try {
    await use.addToDescription(jpeg, descriptionPasteFileName(use.now()));
  } catch (err) {
    showDescriptionPasteNotice(doc, (err && err.message) || 'A imagem não subiu');
    return 'failed';
  }
  return 'done';
}

// What the page really uses; tests pass their own. Reading the clipboard and
// the JPG come from "Colar imagem" of the deal's picture (dealImagePaste.js),
// the upload from "Testar Promoção" (priceTest/panel.js).
const pelandoDescriptionPasteDeps = {
  readImage: function () {
    return readDealImageFromClipboard(pelandoDealImagePasteDeps);
  },
  toJpeg: function (blob) {
    return pelandoDealImagePasteDeps.toJpeg(blob);
  },
  addToDescription: function (blob, fileName) {
    const url = URL.createObjectURL(blob);
    return priceTestAddImageToDescription(document, url, fileName).finally(function () {
      URL.revokeObjectURL(url);
    });
  },
  now: function () {
    return new Date();
  },
};

if (typeof module !== 'undefined' && module.exports) {
  module.exports = {
    PELANDO_DESCRIPTION_PASTE_CLASS,
    DESCRIPTION_PASTE_MESSAGES,
    findShortDescriptionLabel,
    syncDescriptionPasteButton,
    descriptionPasteFileName,
    pasteImageIntoDescription,
  };
}
