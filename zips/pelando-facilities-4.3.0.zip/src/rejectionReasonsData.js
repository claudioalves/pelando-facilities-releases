// Generated from motivos_reprova_ativos_com_alternativa.xlsx (deletion_reasons,
// 26/09/2026). `uses` is the sheet's "Total de usos" (deals + comments) and
// drives the order reasons are listed in; `principal` is the message shown to
// the user today and `alternativa` the suggested rewrite. `summary` is the
// internal summary the backoffice deal page shows under "motivo de deleção
// encontrado".
// 4.3.0 (24/11/2026): `principal`/`alternativa` revisados pelo Claudio
// (mensagens v5). `chatTitle` é o nome nas mensagens prontas do chat quando
// difere do título do backoffice; `chatHidden` tira o motivo das mensagens
// prontas (continua no backoffice).
const PELANDO_REJECTION_REASONS = [
  {
    "id": "80ac73d6-76d6-452b-91d9-5ab0a44fa20b",
    "code": "03",
    "title": "Preço não promocional",
    "summary": "O valor não parece uma boa oferta",
    "type": "Promoção / discussão",
    "principal": "Obrigado por compartilhar a promoção. Não consegui aceitá-la porque, na conferência, o preço não parecia promocional ou não mostrava uma economia clara para a comunidade. Para aumentar a chance de aprovação, envie quando o valor estiver abaixo do preço normal ou inclua informações que comprovem o desconto, como preço final, cupom aplicado e condições da promoção.",
    "alternativa": "A gente comparou o preço com o histórico do produto no Pelando e nas lojas nas últimas semanas, e o valor não ficou abaixo do que costuma aparecer. Por isso, a publicação foi recusada. Se o preço cair, ou se existir uma condição que deixe o produto mais barato (cupom, Pix, app da loja), envie de novo explicando o passo a passo que a gente revisa.",
    "uses": 2258
  },
  {
    "id": "f5362d60-c72c-43ac-acfd-38ac3ce2d6df",
    "code": "01",
    "title": "Autopromoção",
    "summary": "Benefício pessoal, vínculo com loja ou afiliado",
    "type": "Promoção / discussão",
    "principal": "Obrigado por compartilhar sua publicação com a comunidade. Não consegui aceitá-la porque identifiquei sinais de benefício pessoal, como vínculo com a loja, divulgação própria ou link de afiliado. Para ser aceita na próxima vez, envie uma promoção de forma neutra, sem ganho direto para você e com informações claras de preço, loja e desconto.",
    "alternativa": "Sua publicação foi recusada porque encontramos sinais de vínculo comercial, como link de afiliado, divulgação da sua própria loja ou outro ganho direto para quem postou. No Pelando isso não é permitido, mesmo quando a promoção é boa. Se quiser compartilhar de novo, use o link direto da loja, sem afiliado, e conte para a galera o preço, a loja e o desconto.",
    "uses": 1292
  },
  {
    "id": "c20b10b5-9346-44b7-a749-7b4bafc7d840",
    "code": "05",
    "title": "Loja ou vendedor não liberado",
    "summary": "Loja em análise, não cadastrada ou sem verificação",
    "type": "Promoção / discussão",
    "principal": "Obrigado por enviar sua publicação. Não consegui aceitá-la porque a loja, marketplace ou vendedor ainda não está liberado no Pelando ou não atende aos critérios de confiança usados para proteger a comunidade. Para ser aceita na próxima vez, envie uma promoção de uma loja ou vendedor já verificado, ou aguarde essa loja passar pela análise.",
    "alternativa": "A loja ou o vendedor dessa promoção ainda não está liberado no Pelando: pode estar em análise, sem cadastro ou sem cumprir nossos critérios de confiança. A gente faz essa checagem para proteger quem compra pelas promoções da comunidade. Se encontrar o mesmo produto em uma loja já cadastrada, ou no vendedor oficial dentro do marketplace, pode enviar de novo.",
    "uses": 797
  },
  {
    "id": "708f7f45-53a3-4438-8db5-34e4e480654d",
    "code": "04",
    "title": "Promoção duplicada",
    "summary": "Essa oferta já foi publicada",
    "type": "Promoção / discussão",
    "principal": "Obrigado por contribuir com a comunidade. Não consegui aceitar essa publicação porque a mesma promoção já havia sido compartilhada. Fazemos isso para manter o feed organizado e concentrar as informações em um só lugar. Na próxima vez, confira se a promoção já está no Pelando antes de enviar ou compartilhe uma promoção diferente.",
    "alternativa": "Essa mesma promoção já estava publicada no Pelando, então a gente recusou a sua para manter tudo reunido em um só lugar. Você pode comentar na publicação que já existe para somar informações, como um cupom novo ou outra cor disponível. Se o seu preço for melhor que o da publicação existente, envie de novo e avise na descrição que o valor caiu.",
    "uses": 594
  },
  {
    "id": "e6d2c94c-45dc-4ef3-ad19-0e812cbcefc3",
    "code": "07",
    "title": "Spam ou excesso de publicações",
    "summary": "Muitas publicações parecidas em pouco tempo",
    "type": "Promoção / discussão",
    "principal": "Obrigado pelas suas contribuições. Não consegui aceitar essa publicação porque identifiquei muitas publicações iguais ou muito parecidas em pouco tempo, o que pode prejudicar a experiência da comunidade no feed. Para ser aceito na próxima vez, envie apenas as melhores promoções, com informações completas, e evite publicar várias promoções semelhantes de uma só vez.",
    "alternativa": "Recebemos várias publicações suas, iguais ou muito parecidas, em pouco tempo, e isso acaba enchendo o feed da comunidade. Por isso, algumas foram recusadas. Escolha as melhores promoções e envie com calma, uma de cada vez e com todas as informações.",
    "uses": 477
  },
  {
    "id": "5c459282-b4f8-4a4b-98c5-cd7da1c79d0a",
    "code": "06",
    "title": "Informações insuficientes",
    "summary": "Não conseguimos validar a oferta",
    "type": "Promoção / discussão",
    "principal": "Obrigado por compartilhar sua publicação. Não consegui aceitá-la porque faltaram informações ou encontrei dados que não consegui validar com segurança. Para ser aceita na próxima vez, revise preço, loja, link, cupom, frete e condições da promoção, deixando tudo claro para a moderação e para a comunidade.",
    "alternativa": "A gente tentou conferir essa promoção, mas não conseguiu chegar no preço ou nas condições que você informou ao abrir o link. Por isso, a publicação foi recusada por inconsistência nas informações. Se tiver algum passo para chegar nesse valor, como cupom, app da loja, frete ou forma de pagamento, envie de novo contando tudo na descrição que a gente revisa.",
    "uses": 411
  },
  {
    "id": "a0a67a94-eed1-478a-88cb-9b2822456117",
    "code": "02",
    "title": "Conteúdo sem oferta clara",
    "summary": "Não identificamos uma promoção válida",
    "type": "Promoção / discussão",
    "principal": "Obrigado por enviar sua publicação. Não consegui aceitá-la porque não identifiquei uma promoção válida ou um benefício claro de economia para a comunidade. Para ser aceita na próxima vez, informe uma promoção ativa com loja, preço, desconto ou cupom, link direto e condições de uso bem claras.",
    "alternativa": "A gente olhou sua publicação, mas não encontrou uma vantagem real para a comunidade, como desconto, cupom ou preço abaixo do normal. Produtos com preço cheio, lançamentos ou divulgações não entram como promoção. Se houver uma promoção ativa, envie de novo com o link direto, o preço final e as condições para chegar nele.",
    "uses": 389
  },
  {
    "id": "d27384f6-734b-417c-aaaf-c7d80ca61968",
    "code": "C01",
    "title": "Divulgação de plataforma concorrente",
    "summary": "O comentário direciona para outro serviço de promoções",
    "type": "Comentário",
    "principal": "Removi seu comentário porque ele direcionava a comunidade para uma plataforma concorrente. Para manter a comunidade sustentável e organizada, não permitimos esse tipo de divulgação nos comentários.",
    "alternativa": "Seu comentário foi removido porque indicava outra plataforma de promoções. Esse tipo de divulgação não é permitido nos comentários, porque é o que mantém a comunidade sustentável. Se quiser ajudar a galera, compartilhe a dica aqui mesmo, com o link da loja.",
    "uses": 374
  },
  {
    "id": "704ff4c0-1d8d-4c06-a52a-8e8cb7e798ee",
    "code": "C07",
    "title": "Conteúdo ofensivo",
    "summary": "Linguagem ou abordagem desrespeitosa",
    "type": "Comentário",
    "principal": "Removi seu comentário porque ele continha ofensa ou ataque pessoal. Queremos manter o Pelando um espaço respeitoso, leve e útil para todo mundo.",
    "alternativa": "Seu comentário foi removido porque tinha ofensa ou linguagem que pesa o clima da conversa. Pode discordar à vontade, mas sempre com respeito. Se quiser, comente de novo com outras palavras.",
    "uses": 313
  },
  {
    "id": "ef57d23f-e125-4397-9567-9e7ce077e320",
    "code": "12",
    "title": "Link inválido ou encurtado",
    "summary": "Não conseguimos acessar ou conferir o destino",
    "type": "Promoção / discussão",
    "principal": "Obrigado por compartilhar a publicação. Não consegui aceitá-la porque o link enviado não permite conferir a promoção com segurança, seja por estar encurtado, quebrado ou com destino pouco claro. Para ser aceita na próxima vez, envie o link completo e direto da loja ou produto.",
    "alternativa": "Não conseguimos abrir ou conferir o destino do link que você enviou: ele estava encurtado, quebrado ou levava para uma página que não era a da promoção. Para a segurança da comunidade, só aceitamos links que mostram claramente para onde vão. Envie de novo com o link completo, direto da página do produto na loja.",
    "uses": 198
  },
  {
    "id": "94bc6856-6f81-4909-b055-ca394deffbc8",
    "code": "09",
    "title": "Discussão fora do formato",
    "summary": "O conteúdo não se encaixa como discussão",
    "type": "Promoção / discussão",
    "principal": "Obrigado por participar da comunidade. Não consegui aceitar essa publicação como discussão porque o tema não ficou claro ou não se encaixa nesse formato. Para ser aceita na próxima vez, escreva uma pergunta, experiência ou comparação objetiva, com contexto suficiente para outras pessoas conseguirem ajudar.",
    "alternativa": "Sua publicação foi enviada como discussão, mas não ficou claro qual é a pergunta ou o tema da conversa. Discussões funcionam melhor quando trazem uma dúvida, uma experiência ou uma comparação, com contexto para a galera responder. Se quiser, reescreva nesse formato e envie de novo. Se for uma promoção, publique como promoção.",
    "uses": 189
  },
  {
    "id": "192e3e11-1f40-4b86-b0e6-b6eed588e5e6",
    "code": "11",
    "title": "Oferta encerrada ou indisponível",
    "summary": "A promoção não estava mais ativa",
    "type": "Promoção / discussão",
    "principal": "Obrigado por enviar a promoção. Não consegui aceitá-la porque, no momento da conferência, a promoção já estava encerrada, indisponível ou não chegava mais ao preço informado. Se ela voltar a funcionar, envie novamente com link, preço final e condições atualizadas.",
    "alternativa": "Quando a gente abriu o link para conferir, a promoção já tinha acabado, o produto estava sem estoque ou o preço não era mais o informado. Por isso, a publicação foi recusada. Se a promoção voltar, envie de novo com o link e o preço atualizados.",
    "uses": 142
  },
  {
    "id": "3b295536-1e84-4bb6-bb05-4c2cccb52cd5",
    "code": "C05",
    "title": "Link inválido ou encurtado",
    "summary": "Não conseguimos acessar ou conferir o destino",
    "type": "Comentário",
    "principal": "Removi seu comentário porque ele continha um link encurtado ou redirecionador. Esses links podem esconder o destino real e trazer riscos para a comunidade. Quando permitido, envie o link completo e verificável.",
    "alternativa": "Seu comentário foi removido porque tinha um link encurtado ou que redireciona para outro lugar, e esse tipo de link pode esconder o destino real. Se o link for útil para a conversa, comente de novo com o endereço completo, que mostre para onde vai.",
    "uses": 120
  },
  {
    "id": "673253b7-b265-4ebf-b25e-a6c7379d2f2e",
    "code": "C12",
    "title": "Conteúdo político",
    "summary": "O tema foge do foco da comunidade",
    "type": "Comentário",
    "principal": "Ocultei ou removi seu comentário porque ele desviava a conversa para discussão política fora do foco da comunidade. O Pelando é um espaço voltado a promoções, compras e economia.",
    "alternativa": "Seu comentário foi ocultado ou removido porque levava a conversa para política, e no Pelando combinamos de deixar esse assunto de fora para evitar brigas. Pode continuar comentando sobre a promoção, o produto ou a sua experiência de compra.",
    "uses": 104
  },
  {
    "id": "650a283c-65e9-46ff-b734-506b39600833",
    "code": "C11",
    "title": "Spam ou excesso de comentários",
    "summary": "Muitos comentários parecidos em pouco tempo",
    "type": "Comentário",
    "principal": "Removi seu comentário porque ele fazia parte de um padrão de spam, repetição ou flood. Comentários repetidos, automatizados ou em excesso atrapalham a conversa e a experiência da comunidade.",
    "alternativa": "Seu comentário foi removido porque fazia parte de uma sequência de comentários repetidos ou em excesso, e isso atrapalha a conversa. Se tiver algo a acrescentar, deixe um comentário só, com a informação completa.",
    "uses": 87
  },
  {
    "id": "f380c92e-4f06-4396-963d-b567a21c2cb4",
    "code": "C02",
    "title": "Contato externo não permitido",
    "summary": "O comentário direciona para WhatsApp, Telegram, e-mail ou rede social",
    "type": "Comentário",
    "principal": "Removi seu comentário porque ele convidava ou direcionava pessoas para contato fora do Pelando, como WhatsApp, Telegram, Instagram, Discord, e-mail, telefone, direct ou grupos externos. Essa regra ajuda a proteger a comunidade contra golpes e abordagens indevidas.",
    "alternativa": "Seu comentário foi removido porque chamava pessoas para conversar fora do Pelando, como WhatsApp, Telegram, Instagram, Discord, e-mail ou grupos. Esse tipo de contato é muito usado em golpes, por isso não é permitido. Se quiser ajudar alguém, responda por aqui mesmo, nos comentários.",
    "uses": 86
  },
  {
    "id": "34e4b879-b004-4cdb-aae1-dd7562cd10cf",
    "code": "10",
    "title": "Divulgação de plataforma concorrente",
    "summary": "O conteúdo direciona para outro serviço de promoções",
    "type": "Promoção / discussão",
    "principal": "Obrigado por compartilhar sua publicação. Não consegui aceitá-la porque ela divulga ou direciona para uma plataforma concorrente, o que não é permitido no Pelando. Para ser aceita na próxima vez, envie a promoção diretamente, sem menções, convites ou links para outros serviços de promoções.",
    "alternativa": "Sua publicação menciona ou leva para outra plataforma de promoções, e esse tipo de divulgação não é permitido no Pelando, porque é o que mantém a comunidade sustentável. Se a promoção for boa, envie de novo com o link direto da loja, sem citar outros sites, grupos ou canais de promoção.",
    "uses": 83
  },
  {
    "id": "e0123d47-21bf-4bca-839a-01f9dc88ca99",
    "code": "R01",
    "title": "Review sem conteúdo",
    "summary": "A publicação não apresenta análise, experiência ou discussão sobre o produto",
    "type": "Review",
    "principal": "Obrigado por compartilhar seu review com a comunidade. Não conseguimos aceitá-lo porque ele não apresenta uma análise, experiência de uso, opinião ou informações que ajudem outros usuários. Apenas imagens ou vídeos do produto, especialmente materiais da própria loja ou fabricante, não são suficientes para caracterizar um review. Para aumentar a chance de aprovação, conte sua experiência, destaque pontos positivos e negativos, faça comparações ou compartilhe informações que realmente agreguem valor para a comunidade.",
    "alternativa": "Sua publicação foi enviada como review, mas trazia só fotos ou vídeos do produto, sem contar como foi a sua experiência. Um review precisa de opinião própria: o que você achou, pontos positivos e negativos, comparações. Se quiser, reescreva contando sua experiência e envie de novo. Se era uma oferta, publique como promoção.",
    "uses": 59,
    "chatHidden": true
  },
  {
    "id": "9bacb68c-d00e-43a0-bcaa-95284fa86305",
    "code": "13",
    "title": "Cupom inválido ou expirado",
    "summary": "O código não funcionou na conferência",
    "type": "Promoção / discussão",
    "principal": "Obrigado por enviar o cupom. Não consegui aceitá-lo porque o código não funcionou, estava expirado ou não levou ao benefício informado durante a conferência. Para ser aceito na próxima vez, teste o cupom antes de publicar e informe as condições de uso, como valor mínimo, app, categoria, validade ou usuários elegíveis.",
    "alternativa": "A gente testou o cupom na conferência, mas ele não funcionou, estava expirado ou não deu o desconto informado. Por isso, a publicação foi recusada. Se o cupom tiver alguma regra, como valor mínimo, primeira compra, uso só no app ou categoria específica, envie de novo explicando que a gente testa outra vez.",
    "uses": 58
  },
  {
    "id": "eefb6bf4-a1d4-4abe-b7fc-12c0fe39a6c4",
    "code": "16",
    "title": "Produto ou categoria não permitido",
    "summary": "O item não atende aos critérios atuais",
    "type": "Promoção / discussão",
    "principal": "Obrigado por enviar sua publicação. Não consegui aceitá-la porque esse produto ou categoria não atende aos critérios atuais do Pelando. Para aumentar a chance de aprovação na próxima vez, envie itens permitidos, de lojas confiáveis, com promoção clara e informações completas.",
    "alternativa": "Esse produto ou categoria não está entre os que aceitamos hoje no Pelando, mesmo com desconto. Por isso, a publicação foi recusada. Você pode continuar compartilhando outras promoções, de itens permitidos e lojas confiáveis.",
    "uses": 56
  },
  {
    "id": "6286f701-bfaf-4d93-8fa6-554c1d28b13b",
    "code": "C03",
    "title": "Autopromoção",
    "summary": "Benefício pessoal, venda recorrente ou divulgação própria",
    "type": "Comentário",
    "principal": "Removi seu comentário porque ele parecia divulgar algo com benefício próprio, como loja, canal, serviço, venda recorrente, cupom próprio, comissão ou indicação. No Pelando, as contribuições precisam ser genuínas e úteis para a comunidade.",
    "alternativa": "Seu comentário foi removido porque parecia divulgar algo seu, como loja, canal, serviço ou venda, com benefício próprio. Nos comentários, a ideia é trocar dicas e experiências de forma genuína. Pode continuar participando, só sem divulgação própria.",
    "uses": 54
  },
  {
    "id": "976d4227-ab47-422d-b202-d48250b3f1d4",
    "code": "C16",
    "title": "Comentário fora do contexto",
    "summary": "O conteúdo não contribui para a conversa",
    "type": "Comentário",
    "principal": "Removi seu comentário porque ele estava fora do contexto da conversa e não contribuía para a discussão da promoção. Tente manter os comentários relacionados à promoção, ao produto ou à experiência de compra.",
    "alternativa": "Seu comentário foi removido porque não tinha relação com a promoção nem ajudava na conversa. Os comentários funcionam melhor quando falam do produto, da loja ou da experiência de compra.",
    "uses": 53
  },
  {
    "id": "906f35ee-f6a9-4a4c-b2f4-709992448ac6",
    "code": "23",
    "title": "Conteúdo ofensivo",
    "summary": "Linguagem ou abordagem desrespeitosa",
    "type": "Promoção / discussão",
    "principal": "Obrigado por participar da comunidade. Não consegui aceitar essa publicação porque ela contém linguagem ou abordagem que pode ser ofensiva ou desrespeitosa. Para ser aceita na próxima vez, reescreva o conteúdo com tom respeitoso e foco em ajudar a comunidade.",
    "alternativa": "Sua publicação tinha linguagem ou tom que pode ofender outras pessoas, e por isso a gente recusou. Queremos que o Pelando seja um espaço respeitoso para todo mundo. Se quiser, reescreva o conteúdo com outras palavras e envie de novo.",
    "uses": 52
  },
  {
    "id": "9119ff9a-0978-4672-a874-84a30ed1251c",
    "code": "08",
    "title": "Verificação de segurança",
    "summary": "Não conseguimos validar a publicação com segurança",
    "type": "Promoção / discussão",
    "principal": "Obrigado por enviar sua publicação. Não consegui aceitá-la porque encontrei sinais que impediram uma validação segura da promoção. Para tentar novamente, revise o conteúdo, use um link direto e confiável, informe preço e condições com clareza e evite qualquer vínculo, repetição ou padrão que possa parecer artificial.",
    "alternativa": "Na conferência, essa publicação mostrou sinais que a gente não conseguiu validar com segurança, como link com destino estranho, padrão repetido ou vínculo que não ficou claro. Para proteger a comunidade de golpes, preferimos recusar. Se a promoção for legítima, envie de novo com o link direto da loja e as informações completas de preço e condições.",
    "uses": 42
  },
  {
    "id": "9f074e13-2558-442f-8914-9338926cf52b",
    "code": "C14",
    "title": "Negociação entre usuários",
    "summary": "Compra, venda ou troca direta nos comentários",
    "type": "Comentário",
    "principal": "Removi seu comentário porque ele tentava negociar compra, venda ou troca diretamente com outros usuários. Para proteger a comunidade, esse tipo de negociação não deve acontecer nos comentários.",
    "alternativa": "Seu comentário foi removido porque tentava comprar, vender ou trocar algo diretamente com outros usuários. Essas negociações não têm nenhuma proteção e abrem espaço para golpes, por isso não são permitidas nos comentários.",
    "uses": 35
  },
  {
    "id": "117090df-9d44-498e-a253-64eec1e98511",
    "code": "15",
    "title": "Categoria com critérios específicos",
    "summary": "Ebook, curso, workshop, bug ou oferta local",
    "type": "Promoção / discussão",
    "principal": "Obrigado por enviar sua publicação. Não consegui aceitar porque essa categoria tem critérios extras de aprovação e, neste caso, eles não foram atendidos. Para ser aceita na próxima vez, envie detalhes que comprovem a relevância da promoção, validade, abrangência, funcionamento e benefício real para a comunidade.",
    "alternativa": "Algumas categorias, como ebooks, cursos, workshops, bugs de preço e promoções de loja física, têm critérios extras para entrar no Pelando, e essa publicação não atendeu a eles. A gente costuma aprovar quando o benefício é real, vale para muita gente e tem chance de ser honrado pela loja. Se a sua promoção cumpre esses pontos, envie de novo mostrando a validade, a abrangência e a economia.",
    "uses": 33
  },
  {
    "id": "c520c0e3-1eaf-4fc5-9c5a-be07a8c97c5b",
    "code": "C04",
    "title": "Código ou afiliado pessoal",
    "summary": "O comentário contém indicação, cupom ou link com benefício próprio",
    "type": "Comentário",
    "principal": "Removi seu comentário porque ele continha código, indicação ou link que poderia gerar benefício pessoal para quem compartilhou. Para preservar a confiança da comunidade, não permitimos divulgação de indicação, afiliado ou comissão pessoal.",
    "alternativa": "Seu comentário foi removido porque tinha código de indicação, cupom pessoal ou link de afiliado, que gera benefício para quem compartilha. Isso não é permitido no Pelando, para manter a confiança da comunidade. Se souber de um cupom público da loja, pode comentar sem problemas.",
    "uses": 33
  },
  {
    "id": "a7968b73-1ca0-4990-bf7a-e527dc53e28a",
    "code": "C06",
    "title": "Verificação de segurança",
    "summary": "Link ou domínio suspeito no comentário",
    "type": "Comentário",
    "principal": "Removi seu comentário porque ele continha um link ou domínio com sinais de risco, como site falso, tentativa de golpe, phishing ou endereço que imita uma loja conhecida. Fazemos isso para proteger a comunidade.",
    "alternativa": "Seu comentário foi removido porque tinha um link ou site com sinais de risco, como página falsa, tentativa de golpe ou endereço parecido com o de uma loja conhecida. A gente faz isso para proteger a comunidade. Se achar que foi um engano, fale com o nosso suporte.",
    "uses": 32
  },
  {
    "id": "33e390a4-b8ca-4cbd-92a6-2ceef1fe4a88",
    "code": "C17",
    "title": "Outro motivo informado pela moderação",
    "summary": "Caso específico avaliado manualmente",
    "type": "Comentário",
    "principal": "Removi seu comentário por um motivo específico avaliado pela moderação. Consulte a observação enviada junto com esta decisão para entender melhor o caso.",
    "alternativa": "Seu comentário foi removido por um motivo específico, avaliado caso a caso pela moderação. Se quiser entender melhor o que aconteceu, fale com o nosso suporte que a gente explica.",
    "uses": 30
  },
  {
    "id": "da8d61f4-108f-47f2-ba59-9bb6c15862d4",
    "code": "19",
    "title": "Contato externo não permitido",
    "summary": "A publicação direciona para WhatsApp, Telegram, e-mail ou rede social",
    "type": "Promoção / discussão",
    "principal": "Obrigado por enviar sua publicação. Não consegui aceitá-la porque ela direciona para contato externo, como WhatsApp, Telegram, e-mail ou rede social. Para proteger a comunidade, envie a promoção com link direto da loja e sem canais externos de contato.",
    "alternativa": "Sua publicação leva para contato fora do Pelando, como WhatsApp, Telegram, e-mail ou redes sociais. Esse tipo de contato é um dos caminhos mais usados em golpes, por isso não é permitido. Se quiser compartilhar a promoção, envie de novo só com o link direto da loja.",
    "uses": 23
  },
  {
    "id": "c3cc626d-8c08-4ae9-9bdd-4f85bac89880",
    "code": "14",
    "title": "Discussão duplicada",
    "summary": "Esse tema já foi publicado",
    "type": "Promoção / discussão",
    "principal": "Obrigado por participar da comunidade. Não consegui aceitar essa discussão porque já existe um tópico igual ou muito parecido em andamento. Para ajudar a concentrar as respostas, participe da discussão existente ou reenvie apenas se tiver um novo ponto de vista ou informação relevante.",
    "alternativa": "Já existe uma discussão aberta sobre esse mesmo tema, então a gente recusou a sua para concentrar as respostas em um só lugar. Você pode participar da discussão que já existe e deixar sua opinião ou experiência por lá. Se tiver um ponto de vista bem diferente, pode abrir uma nova explicando o que muda.",
    "uses": 22
  },
  {
    "id": "662257b0-aaea-4b84-b625-9871c88cd437",
    "code": "18",
    "title": "Produto usado",
    "summary": "Aceitamos apenas produto novo, reembalado ou open box claro",
    "type": "Promoção / discussão",
    "principal": "Obrigado por compartilhar sua publicação. Não consegui aceitar porque o Pelando não aceita promoções de produtos usados. Para ser aceita na próxima vez, envie um produto novo, reembalado ou open box, com essa condição informada de forma clara e com link de uma loja confiável.",
    "alternativa": "Pelas informações da promoção, o produto é usado, e no Pelando só aceitamos itens novos, reembalados ou open box, informados com clareza. Isso porque não temos como garantir o estado de um produto usado. Se encontrar o mesmo item novo ou open box em uma loja confiável, pode enviar.",
    "uses": 20
  },
  {
    "id": "71921d4c-0228-4022-bd0c-8a1ec8bee907",
    "code": "C13",
    "title": "Produto ou serviço ilegal",
    "summary": "Pirataria, IPTV irregular, VPN indevida ou similares",
    "type": "Comentário",
    "principal": "Removi seu comentário porque recomendava pirataria, IPTV ilegal, crack, torrent, desbloqueio ou outro serviço ilegal. Não permitimos esse tipo de conteúdo no Pelando.",
    "alternativa": "Seu comentário foi removido porque indicava pirataria, IPTV irregular, crack, torrent, desbloqueio ou outro serviço ilegal. Esse tipo de conteúdo não é permitido no Pelando.",
    "uses": 19
  },
  {
    "id": "fade0c1c-611e-403a-8fbd-46b15059f5a4",
    "code": "20",
    "title": "Conteúdo político",
    "summary": "O tema foge do foco da comunidade",
    "type": "Promoção / discussão",
    "principal": "Obrigado por compartilhar sua publicação. Não consegui aceitar porque ela abre espaço para discussão política, assunto que fica fora do foco do Pelando. Para ser aceita na próxima vez, envie uma promoção com informações objetivas de preço, loja, desconto e condições, sem posicionamento político.",
    "alternativa": "Sua publicação abria espaço para discussão política, e no Pelando combinamos de deixar esse assunto de fora para evitar brigas e manter o foco em economia. Se a promoção for boa, envie de novo só com as informações do produto: preço, loja, desconto e condições.",
    "uses": 18
  },
  {
    "id": "0e82fabe-6678-443b-84fa-25da78f04339",
    "code": "17",
    "title": "Conteúdo provocativo ou sem contribuição",
    "summary": "A publicação prejudica o ambiente da comunidade",
    "type": "Promoção / discussão",
    "principal": "Obrigado por participar da comunidade. Não consegui aceitar essa publicação porque ela não contribui para um ambiente útil, respeitoso e colaborativo. Para ser aceita na próxima vez, envie uma promoção ou comentário com informações reais, tom respeitoso e foco em ajudar outras pessoas a economizar.",
    "alternativa": "Essa publicação parecia mais uma provocação ou brincadeira do que uma contribuição para a comunidade, e esse tipo de conteúdo costuma gerar discórdia. Por isso, a gente recusou. Aqui o foco é ajudar a galera a economizar: se tiver uma promoção ou informação útil, pode enviar de novo.",
    "uses": 15,
    "chatTitle": "Conteúdo provocativo ou sem contribuição (meme)"
  },
  {
    "id": "8353d119-1d33-4964-be17-0bd5de9533af",
    "code": "21",
    "title": "Produto ou serviço ilegal",
    "summary": "Pirataria, IPTV irregular, VPN indevida ou similares",
    "type": "Promoção / discussão",
    "principal": "Obrigado por enviar sua publicação. Não consegui aceitar porque ela envolve produto ou serviço ilegal, irregular ou não permitido, como pirataria, IPTV irregular ou similares. Para ser aceita na próxima vez, compartilhe apenas promoções legais, verificáveis e de lojas ou serviços autorizados.",
    "alternativa": "Sua publicação envolve um produto ou serviço ilegal ou irregular, como pirataria, IPTV não autorizado ou VPN usada de forma indevida. Esse tipo de conteúdo não é permitido no Pelando, mesmo com desconto. Continue compartilhando promoções legais, de lojas e serviços autorizados.",
    "uses": 12
  },
  {
    "id": "0602f300-cee2-4178-a04a-512d28be73c9",
    "code": "22",
    "title": "Promoção ainda não ativa",
    "summary": "A oferta só começa no futuro",
    "type": "Promoção / discussão",
    "principal": "Obrigado por compartilhar a promoção. Não consegui aceitá-la porque a promoção ainda não estava ativa no momento da análise. Para ser aceita na próxima vez, envie quando o desconto já estiver funcionando e inclua link, preço final, cupom se houver e condições da campanha.",
    "alternativa": "Quando a gente conferiu, a promoção ainda não tinha começado, então a comunidade não conseguiria aproveitar naquele momento. Por isso, a publicação foi recusada. Assim que o desconto estiver valendo, envie de novo com o link, o preço final e o cupom, se houver.",
    "uses": 11,
    "chatTitle": "Promoção ainda não ativa (futura)"
  },
  {
    "id": "121402fd-06d9-4493-b72c-46efdc88564e",
    "code": "26",
    "title": "Tentativa de contornar regras",
    "summary": "Uso da publicação para burlar regras do Pelando ou da loja",
    "type": "Promoção / discussão",
    "principal": "Obrigado por enviar sua publicação. Não consegui aceitá-la porque identifiquei uma tentativa de contornar regras do Pelando, da loja ou da própria promoção. Para ser aceita na próxima vez, compartilhe apenas condições oficiais, links diretos e formas de compra permitidas.",
    "alternativa": "A gente identificou nessa publicação uma forma de contornar regras do Pelando, da loja ou da própria promoção, como brechas ou condições que não são oficiais. Por isso, ela foi recusada. Envie apenas promoções com condições oficiais, que qualquer pessoa da comunidade consiga usar.",
    "uses": 7
  },
  {
    "id": "9e2fb08d-2088-48e5-9658-0ddb48d1a3c1",
    "code": "C10",
    "title": "Conteúdo adulto ou impróprio",
    "summary": "O comentário contém conteúdo sexual ou inadequado",
    "type": "Comentário",
    "principal": "Removi seu comentário porque ele continha conteúdo adulto, sexual ou impróprio para a comunidade. Mantemos esse tipo de conteúdo fora do Pelando para preservar um ambiente seguro e adequado para todos.",
    "alternativa": "Seu comentário foi removido porque tinha conteúdo adulto, sexual ou impróprio para a comunidade. Queremos manter o Pelando adequado para todo mundo que participa.",
    "uses": 3
  },
  {
    "id": "8daede3b-2189-439f-a8b4-6f8b6d06d995",
    "code": "C08",
    "title": "Ameaça ou constrangimento",
    "summary": "O comentário pode expor ou intimidar outra pessoa",
    "type": "Comentário",
    "principal": "Removi seu comentário porque ele poderia ameaçar, intimidar, constranger ou assediar outra pessoa. Esse tipo de abordagem não é permitido, pois queremos que todos se sintam seguros para participar.",
    "alternativa": "Seu comentário foi removido porque podia ameaçar, intimidar, constranger ou assediar outra pessoa. Esse tipo de abordagem não é permitido no Pelando. A gente quer que todo mundo se sinta seguro para participar.",
    "uses": 2
  },
  {
    "id": "d41122ca-b2ed-44b4-a0f0-98b1ce6d6427",
    "code": "25",
    "title": "Conta em análise",
    "summary": "Publicação pausada por revisão de segurança",
    "type": "Promoção / discussão",
    "principal": "Obrigado por enviar sua publicação. No momento, não consegui aceitá-la porque sua conta está passando por uma análise de segurança. Para os próximos envios, acompanhe os canais de suporte e garanta que suas publicações tenham link direto, loja confiável, preço claro e estejam alinhadas às regras da comunidade.",
    "alternativa": "Sua conta está passando por uma revisão de segurança, e por isso suas publicações estão pausadas por enquanto. Isso não quer dizer que a promoção era ruim: é uma checagem que a gente faz para proteger a comunidade. Se tiver dúvidas, fale com o nosso suporte pelos canais oficiais.",
    "uses": 1
  },
  {
    "id": "3c684d43-2e36-4906-a209-00f8b0dd9892",
    "code": "C09",
    "title": "Discurso de ódio ou discriminação",
    "summary": "Ataque a pessoa ou grupo protegido",
    "type": "Comentário",
    "principal": "Removi seu comentário porque ele continha discurso de ódio, racismo ou discriminação contra pessoas ou grupos. Esse tipo de conteúdo não é permitido no Pelando.",
    "alternativa": "Seu comentário foi removido porque tinha discurso de ódio, racismo ou discriminação contra pessoas ou grupos. Esse tipo de conteúdo não é aceito no Pelando em nenhuma situação.",
    "uses": 1
  },
  {
    "id": "6fd699c2-81a0-498d-9b3c-02f74738e60e",
    "code": "C15",
    "title": "Chamada indevida para moderação ou suporte",
    "summary": "O comentário usa a conversa fora do fluxo correto",
    "type": "Comentário",
    "principal": "Seu comentário foi tratado porque usava a conversa para acionar moderação ou suporte fora do fluxo correto. Quando precisar de ajuda, use os canais indicados na plataforma para que o time consiga acompanhar melhor.",
    "alternativa": "Seu comentário foi tratado porque usava a conversa da promoção para chamar a moderação ou o suporte, e por ali o time não consegue acompanhar direito. Para pedir ajuda ou avisar sobre algum problema, use a opção de reportar ou os canais de suporte da plataforma.",
    "uses": 1,
    "chatHidden": true
  },
  {
    "id": "eb2ca9bd-e40a-402a-b0e2-a9e2fec90361",
    "code": "24",
    "title": "Ameaça ou constrangimento",
    "summary": "O conteúdo pode expor ou intimidar outra pessoa",
    "type": "Promoção / discussão",
    "principal": "Obrigado por participar da comunidade. Não consegui aceitar essa publicação porque ela pode ameaçar, constranger ou expor outra pessoa. Para continuar contribuindo, mantenha as interações respeitosas e envie conteúdos focados em promoções, dúvidas ou experiências úteis para a comunidade.",
    "alternativa": "Sua publicação pode ameaçar, constranger ou expor outra pessoa, e esse tipo de conteúdo não é permitido no Pelando. A gente quer que todo mundo se sinta seguro para participar. Continue contribuindo com promoções, dúvidas e experiências, sempre com respeito.",
    "uses": 0
  },
  {
    "id": "daa9ffce-a868-4783-84bb-266eeb021d59",
    "code": "27",
    "title": "Lista de cupons",
    "summary": "A publicação reúne vários cupons sem uma oferta específica",
    "type": "Promoção / discussão",
    "principal": "Obrigado por compartilhar os cupons. Não consegui aceitar essa publicação porque ela reúne vários cupons em uma única página, sem uma promoção específica para a comunidade avaliar. Para ser aceita na próxima vez, envie um cupom individual, com loja, benefício, validade e condições de uso bem claras.",
    "alternativa": "Sua publicação reunia vários cupons em uma página só, sem uma promoção específica para a comunidade avaliar, e assim fica difícil para a galera saber o que vale a pena. Envie cada cupom separado, com a loja, o desconto, a validade e as regras de uso.",
    "uses": 0
  }
];

if (typeof module !== 'undefined' && module.exports) {
  module.exports = { PELANDO_REJECTION_REASONS };
}
