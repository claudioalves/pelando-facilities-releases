// The updater (src/updater) also runs here: the daily check of the releases
// list, the "1" on the icon and the usage report. Paths are relative to this
// file. Not loaded by the tests, which import this file in node.
if (typeof importScripts === 'function') {
  importScripts('updater/versions.js', 'updater/check.js', 'updater/usage.js', 'updater/worker.js', 'imageHash.js');
}

// Pelando and each Promoninja country run the same backoffice on their own
// domain: the page at bo.<domain>, its API at api-bo.<domain>.
const BO_SITE_DOMAINS = [
  'pelando.com.br',
  'promoninja.com',
  'promoninja.com.ar',
  'promoninja.co.uk',
  'promoninja.es',
  'promoninja.de',
  'promoninja.fr',
];
const BO_DEFAULT_DOMAIN = 'pelando.com.br';
// The backoffice keeps the logged-in moderator (JSON with a `token`) in this
// cookie; its own API client sends that token as a Bearer header.
const BO_AUTH_COOKIE_NAME = '__ptknbkfc';

// The backoffice of the site the request came from (a deal on
// www.promoninja.co.uk acts on bo.promoninja.co.uk); Pelando's for the chat,
// the extension's own pages and anything else.
function backofficeDomainFor(pageUrl) {
  let host = '';
  try {
    host = new URL(pageUrl).hostname;
  } catch (err) {
    return BO_DEFAULT_DOMAIN;
  }
  const domain = host.replace(/^(www|bo)\./, '');
  return BO_SITE_DOMAINS.includes(domain) ? domain : BO_DEFAULT_DOMAIN;
}

function backofficeLoginError(domain) {
  return 'Faça login no backoffice (bo.' + domain + ') e tente de novo.';
}

const SITE_CHAT_URL = 'https://www.pelando.com.br/chat/';
// Read by the chat content script to prefill the conversation it opens on.
const PENDING_CHAT_MESSAGE_KEY = 'pendingChatMessage';

function parseBackofficeToken(cookieValue) {
  if (!cookieValue) return null;
  try {
    const user = JSON.parse(decodeURIComponent(cookieValue));
    return (user && user.token) || null;
  } catch (err) {
    return null;
  }
}

// The backoffice's API fails with a 500 on actions that change data (reject,
// start a chat) when they come from this extension's origin, while its own
// page, sending the same body, succeeds: the API records each action with its
// origin. This rule makes the extension's own requests to the API carry the
// backoffice's Origin and Referer, as the page's do. It only matches requests
// this extension starts, so the pages' own requests are left alone.
// One rule per site, ids starting at BO_ORIGIN_RULE_ID.
const BO_ORIGIN_RULE_ID = 1;

function backofficeOriginRule(extensionId, domain, id) {
  const pageOrigin = 'https://bo.' + (domain || BO_DEFAULT_DOMAIN);
  return {
    id: id || BO_ORIGIN_RULE_ID,
    priority: 1,
    action: {
      type: 'modifyHeaders',
      requestHeaders: [
        { header: 'origin', operation: 'set', value: pageOrigin },
        { header: 'referer', operation: 'set', value: pageOrigin + '/' },
      ],
    },
    condition: {
      urlFilter: '||api-bo.' + (domain || BO_DEFAULT_DOMAIN) + '/',
      initiatorDomains: [extensionId],
      resourceTypes: ['xmlhttprequest', 'other'],
    },
  };
}

let backofficeOriginRuleReady = null;

// Registers the rule once per service worker start; the calls wait for it.
function ensureBackofficeOriginRule() {
  if (!backofficeOriginRuleReady) {
    const dnr = typeof chrome !== 'undefined' && chrome.declarativeNetRequest;
    const rules = dnr
      ? BO_SITE_DOMAINS.map(function (domain, index) {
          return backofficeOriginRule(chrome.runtime.id, domain, BO_ORIGIN_RULE_ID + index);
        })
      : [];
    backofficeOriginRuleReady = dnr
      ? dnr
          .updateDynamicRules({
            removeRuleIds: rules.map(function (rule) {
              return rule.id;
            }),
            addRules: rules,
          })
          .catch(function (err) {
            backofficeOriginRuleReady = null;
            console.warn('[pelando-chat-ext] não deu pra ajustar a origem dos pedidos ao backoffice', err);
          })
      : Promise.resolve();
  }
  return backofficeOriginRuleReady;
}

// Only people signed in to Chrome with a Pelando account use the extension.
// The email is read from the Chrome profile and compared here, on the
// computer; it isn't sent anywhere.
const PELANDO_ACCOUNT_DOMAIN = '@pelando.com.br';

function isPelandoAccount(email) {
  return typeof email === 'string' && email.trim().toLowerCase().endsWith(PELANDO_ACCOUNT_DOMAIN);
}

// { allowed, email } for the Chrome profile's account; `email` is empty when
// Chrome isn't signed in.
async function checkAccess() {
  let email = '';
  try {
    const info = await chrome.identity.getProfileUserInfo({ accountStatus: 'ANY' });
    email = (info && info.email) || '';
  } catch (err) {
    email = '';
  }
  return { allowed: isPelandoAccount(email), email: email };
}

// `sender` is the page that asked (chrome.runtime.onMessage's sender).
async function callBackofficeApi(message, sender) {
  await ensureBackofficeOriginRule();
  const domain = backofficeDomainFor(sender && (sender.url || (sender.tab && sender.tab.url)));
  const loginError = backofficeLoginError(domain);
  const cookie = await chrome.cookies.get({ url: 'https://bo.' + domain, name: BO_AUTH_COOKIE_NAME });
  const token = parseBackofficeToken(cookie && cookie.value);
  if (!token) return { error: loginError };

  const init = { method: message.method, headers: { Authorization: 'Bearer ' + token } };
  if (message.body !== undefined) {
    init.headers['Content-Type'] = 'application/json';
    init.body = JSON.stringify(message.body);
  }

  let response;
  try {
    response = await fetch('https://api-bo.' + domain + message.path, init);
  } catch (err) {
    return { error: 'Não foi possível falar com o backoffice. Verifique sua conexão.' };
  }
  if (response.status === 401 || response.status === 403) return { error: loginError };

  let json = null;
  try {
    json = await response.json();
  } catch (err) {
    // Some endpoints answer with an empty body.
  }
  if (!response.ok) {
    // Logged in the service worker console (chrome://extensions > "service
    // worker") with the request, to tell which call failed.
    console.warn('[pelando-chat-ext] backoffice ' + response.status, message.method, message.path, message.body, json);
    const detail = json && json.message ? ': ' + json.message : ' (erro ' + response.status + ')';
    return { error: 'O backoffice recusou a ação' + detail + ' [' + message.method + ' ' + message.path + ']' };
  }
  return { data: json ? json.data : null };
}

// Opens the chat `message.chatId` in a new tab, leaving `message.text` for
// the chat content script to put in the input box (never sent).
async function openChatWithMessage(message, sender) {
  const chatId = message.chatId;
  await chrome.storage.local.set({
    [PENDING_CHAT_MESSAGE_KEY]: { chatId: chatId, text: message.text, createdAt: Date.now() },
  });
  const index = sender.tab ? sender.tab.index + 1 : undefined;
  await chrome.tabs.create({ url: SITE_CHAT_URL + encodeURIComponent(chatId), index: index });
  return { data: { chatId: chatId } };
}

// What the updater needs here; the email only for a Pelando account. `fetch`
// is wrapped because calling it as a method of another object throws.
async function updaterContext() {
  const access = await checkAccess();
  return {
    fetch: function (url, init) {
      return fetch(url, init);
    },
    storage: chrome.storage,
    action: chrome.action,
    installed: chrome.runtime.getManifest().version,
    now: new Date(),
    email: access.allowed ? access.email : '',
    url: UPDATER_USAGE_URL,
  };
}

function logUpdaterError(err) {
  console.warn('[pelando-chat-ext] atualizador', err);
}

function ensureUpdaterAlarm() {
  return chrome.alarms.get(UPDATER_ALARM_NAME).then(function (alarm) {
    if (!alarm) return chrome.alarms.create(UPDATER_ALARM_NAME, { delayInMinutes: 1, periodInMinutes: 24 * 60 });
  });
}

if (typeof chrome !== 'undefined' && chrome.alarms && chrome.runtime && chrome.runtime.onInstalled) {
  chrome.runtime.onInstalled.addListener(function (details) {
    ensureUpdaterAlarm().catch(logUpdaterError);
    updaterContext()
      .then(function (context) {
        if (details.reason !== 'update') return runDailyUpdater(context);
        return handleVersionChange(details.previousVersion, context)
          .then(function (waited) {
            // The settings tab closed with the reload; reopen it to show how it went.
            if (waited) chrome.runtime.openOptionsPage();
          })
          .catch(logUpdaterError)
          .then(function () {
            return runUpdaterCheck(context);
          });
      })
      .catch(logUpdaterError);
  });

  chrome.runtime.onStartup.addListener(function () {
    ensureUpdaterAlarm().catch(logUpdaterError);
    chrome.storage.local
      .get(UPDATER_STATE_KEY)
      .then(function (items) {
        return showUpdateBadge(chrome.action, chrome.runtime.getManifest().version, items[UPDATER_STATE_KEY]);
      })
      .catch(logUpdaterError);
  });

  chrome.alarms.onAlarm.addListener(function (alarm) {
    if (alarm.name !== UPDATER_ALARM_NAME) return;
    updaterContext().then(runDailyUpdater).catch(logUpdaterError);
  });
}

if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.onMessage) {
  chrome.runtime.onMessage.addListener(function (message, sender, sendResponse) {
    if (!message) return;

    if (message.type === 'PELANDO_CHAT_EXT_CAPTURE_TAB') {
      const windowId = sender.tab ? sender.tab.windowId : undefined;
      chrome.tabs.captureVisibleTab(windowId, { format: 'png' }, function (dataUrl) {
        if (chrome.runtime.lastError) {
          sendResponse({ error: chrome.runtime.lastError.message });
          return;
        }
        sendResponse({ dataUrl: dataUrl });
      });
      return true;
    }

    if (message.type === 'PELANDO_BO_API') {
      callBackofficeApi(message, sender).then(sendResponse, function (err) {
        sendResponse({ error: err.message });
      });
      return true;
    }

    if (message.type === 'PELANDO_OPEN_CHAT') {
      openChatWithMessage(message, sender).then(sendResponse, function (err) {
        sendResponse({ error: err.message });
      });
      return true;
    }

    if (message.type === 'PELANDO_ACCESS') {
      checkAccess().then(
        function (access) {
          sendResponse({ data: access });
        },
        function (err) {
          sendResponse({ error: err.message });
        }
      );
      return true;
    }

    // Content scripts can't open the options page themselves.
    if (message.type === 'PELANDO_OPEN_OPTIONS') {
      chrome.runtime.openOptionsPage().then(
        function () {
          sendResponse({ data: null });
        },
        function (err) {
          sendResponse({ error: err.message });
        }
      );
      return true;
    }

    if (message.type === 'PELANDO_OPEN_TAB') {
      const index = sender.tab ? sender.tab.index + 1 : undefined;
      chrome.tabs.create({ url: message.url, index: index }).then(
        function () {
          sendResponse({ data: null });
        },
        function (err) {
          sendResponse({ error: err.message });
        }
      );
      return true;
    }

    // The thief's highlight on a competitor's page compares our deal's picture
    // with each card's (src/imageHash.js); the page can't read them itself.
    if (message.type === 'PELANDO_IMAGE_SIMILARITY') {
      compareImageUrls(message.a, message.b).then(
        function (similarity) {
          sendResponse({ data: similarity });
        },
        function () {
          sendResponse({ data: null });
        }
      );
      return true;
    }

    // The "Buscar atualizações" button on the settings page.
    if (message.type === 'PELANDO_UPDATER_CHECK') {
      updaterContext()
        .then(runUpdaterCheck)
        .then(
          function (state) {
            sendResponse({ data: state });
          },
          function (err) {
            sendResponse({ error: err.message });
          }
        );
      return true;
    }
  });
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = {
    parseBackofficeToken,
    callBackofficeApi,
    backofficeDomainFor,
    openChatWithMessage,
    backofficeOriginRule,
    ensureBackofficeOriginRule,
    isPelandoAccount,
    checkAccess,
  };
}
