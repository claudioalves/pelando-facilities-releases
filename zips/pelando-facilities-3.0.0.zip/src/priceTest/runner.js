// "Testar Promoção", the service worker's side: opens the deal's store in a
// small window of its own, runs the store's steps there one at a time and tells the
// backoffice how it goes. Each step injects compare.js, page.js and the
// store's file (chrome.scripting) and calls pelandoPriceTestStep. Reads and writes nothing
// in chrome.storage.

// Paths from the extension's root, as chrome.scripting wants them. The
// store's name comes with its article for the messages ("na Magalu", "no
// Mercado Livre"). Cleanup steps run after the result is read; a store whose
// "Comprar agora" leaves the product in the cart (Mercado Livre) takes it out
// there.
const PRICE_TEST_STORES = {
  magalu: {
    name: 'Magalu',
    article: 'a',
    // The link can lead anywhere (redirects, affiliate pages): the adapter
    // only runs on the store's own sites.
    hosts: /(^|\.)(magazineluiza|magalu|magazinevoce)\.com(\.br)?$/i,
    files: ['src/priceTest/compare.js', 'src/priceTest/page.js', 'src/priceTest/stores/magalu.js'],
    steps: [
      { key: 'checkProduct', name: 'produto', label: () => 'Abrindo produto na Magalu…' },
      { key: 'buyNow', name: 'Comprar agora', label: () => 'Indo para o checkout…' },
      { key: 'skipProtection', name: 'garantia estendida', label: () => 'Pulando a garantia estendida…' },
      { key: 'pickAddress', name: 'endereço', label: () => 'Escolhendo o endereço padrão…' },
      { key: 'pickShipping', name: 'frete', label: () => 'Escolhendo frete…' },
      {
        key: 'applyCoupon',
        name: 'cupom',
        label: (request) => 'Aplicando cupom ' + request.coupon + '…',
        when: (request) => !!request.coupon,
      },
      { key: 'selectPix', name: 'PIX', label: () => 'Selecionando PIX…' },
      { key: 'readTotals', name: 'valores', label: () => 'Calculando…' },
    ],
    cleanup: [],
  },
  mercadolivre: {
    name: 'Mercado Livre',
    article: 'o',
    hosts: /(^|\.)(mercadolivre|mercadolibre)\.com(\.br)?$/i,
    files: ['src/priceTest/compare.js', 'src/priceTest/page.js', 'src/priceTest/stores/mercadolivre.js'],
    steps: [
      { key: 'checkProduct', name: 'produto', label: () => 'Abrindo produto no Mercado Livre…' },
      // From here on the product is in the cart.
      { key: 'buyNow', name: 'Comprar agora', label: () => 'Indo para o checkout…', fillsCart: true },
      { key: 'skipProtection', name: 'garantia estendida', label: () => 'Pulando a garantia estendida…' },
      // Pix first: its list of every payment option sends the checkout
      // back to the delivery it had.
      { key: 'selectPix', name: 'PIX', label: () => 'Selecionando PIX…' },
      { key: 'pickShipping', name: 'frete', label: () => 'Escolhendo frete…' },
      {
        key: 'applyCoupon',
        name: 'cupom',
        label: (request) => 'Aplicando cupom ' + request.coupon + '…',
        when: (request) => !!request.coupon,
      },
      { key: 'readTotals', name: 'valores', label: () => 'Calculando…' },
    ],
    cleanup: [
      { key: 'openCart', name: 'carrinho', label: () => 'Tirando o produto do carrinho…' },
      { key: 'removeFromCart', name: 'carrinho' },
    ],
  },
  // "Comprar agora" opens a checkout of its own (isBuyNow), yet once left
  // the product stays in the cart: the cleanup takes it out. The coupon and
  // Pix are both on its payment page: the coupon first, which leaves the
  // test there for Pix.
  amazon: {
    name: 'Amazon',
    article: 'a',
    hosts: /(^|\.)amazon\.com\.br$/i,
    files: ['src/priceTest/compare.js', 'src/priceTest/page.js', 'src/priceTest/stores/amazon.js'],
    steps: [
      { key: 'checkProduct', name: 'produto', label: () => 'Abrindo produto na Amazon…' },
      // The checkout left behind puts the product in the cart.
      { key: 'buyNow', name: 'Comprar agora', label: () => 'Indo para o checkout…', fillsCart: true },
      { key: 'skipProtection', name: 'garantia estendida', label: () => 'Pulando a garantia estendida…' },
      { key: 'pickShipping', name: 'frete', label: () => 'Escolhendo frete…' },
      {
        key: 'applyCoupon',
        name: 'cupom',
        label: (request) => 'Aplicando cupom ' + request.coupon + '…',
        when: (request) => !!request.coupon,
      },
      { key: 'selectPix', name: 'PIX', label: () => 'Selecionando PIX…' },
      { key: 'readTotals', name: 'valores', label: () => 'Calculando…' },
    ],
    cleanup: [
      { key: 'openCart', name: 'carrinho', label: () => 'Tirando o produto do carrinho…' },
      { key: 'removeFromCart', name: 'carrinho' },
    ],
  },
  // "Comprar agora" puts the product in the cart; the checkout runs in steps
  // (/carrinho, /endereco with the coupon box, /entrega, /pagamento). The
  // test reads the Pix total on /pagamento, before /confirmacao.
  kabum: {
    name: 'KaBuM!',
    article: 'o',
    hosts: /(^|\.)kabum\.com\.br$/i,
    files: ['src/priceTest/compare.js', 'src/priceTest/page.js', 'src/priceTest/stores/kabum.js'],
    steps: [
      { key: 'checkProduct', name: 'produto', label: () => 'Abrindo produto no KaBuM!…' },
      { key: 'buyNow', name: 'Comprar agora', label: () => 'Indo para o carrinho…', fillsCart: true },
      { key: 'openCheckout', name: 'carrinho', label: () => 'Abrindo o checkout…' },
      {
        key: 'applyCoupon',
        name: 'cupom',
        label: (request) => 'Aplicando cupom ' + request.coupon + '…',
        when: (request) => !!request.coupon,
      },
      { key: 'pickShipping', name: 'frete', label: () => 'Escolhendo frete…' },
      { key: 'selectPix', name: 'PIX', label: () => 'Selecionando PIX…' },
      { key: 'readTotals', name: 'valores', label: () => 'Calculando…' },
    ],
    cleanup: [
      { key: 'openCart', name: 'carrinho', label: () => 'Tirando o produto do carrinho…' },
      { key: 'removeFromCart', name: 'carrinho' },
    ],
  },
  // The first size on sale; "Comprar agora" puts the product in the cart and
  // opens it, where the coupon goes in. Then /checkouts/entrega and
  // /checkouts/pagamento, where the test reads the Pix total.
  centauro: {
    name: 'Centauro',
    article: 'a',
    hosts: /(^|\.)centauro\.com\.br$/i,
    files: ['src/priceTest/compare.js', 'src/priceTest/page.js', 'src/priceTest/stores/centauro.js'],
    steps: [
      { key: 'checkProduct', name: 'produto', label: () => 'Abrindo produto na Centauro…' },
      { key: 'buyNow', name: 'Comprar agora', label: () => 'Indo para o carrinho…', fillsCart: true },
      { key: 'checkCart', name: 'carrinho', label: () => 'Conferindo o carrinho…' },
      {
        key: 'applyCoupon',
        name: 'cupom',
        label: (request) => 'Aplicando cupom ' + request.coupon + '…',
        when: (request) => !!request.coupon,
      },
      { key: 'pickShipping', name: 'frete', label: () => 'Escolhendo frete…' },
      { key: 'selectPix', name: 'PIX', label: () => 'Selecionando PIX…' },
      { key: 'readTotals', name: 'valores', label: () => 'Calculando…' },
    ],
    cleanup: [
      { key: 'openCart', name: 'carrinho', label: () => 'Tirando o produto do carrinho…' },
      { key: 'removeFromCart', name: 'carrinho' },
    ],
  },
  // "Comprar" opens a checkout of its own (/p/trade/confirm.html) and leaves
  // the cart alone: nothing to clean up. The coupon box and Pix ("Veja
  // mais") are both on it.
  aliexpress: {
    name: 'AliExpress',
    article: 'o',
    hosts: /(^|\.)aliexpress\.(com|us)(\.br)?$/i,
    files: ['src/priceTest/compare.js', 'src/priceTest/page.js', 'src/priceTest/stores/aliexpress.js'],
    steps: [
      { key: 'checkProduct', name: 'produto', label: () => 'Abrindo produto no AliExpress…' },
      { key: 'buyNow', name: 'Comprar', label: () => 'Indo para o checkout…' },
      {
        key: 'applyCoupon',
        name: 'cupom',
        label: (request) => 'Aplicando cupom ' + request.coupon + '…',
        when: (request) => !!request.coupon,
      },
      { key: 'selectPix', name: 'PIX', label: () => 'Selecionando PIX…' },
      { key: 'readTotals', name: 'valores', label: () => 'Calculando…' },
    ],
    cleanup: [],
  },
};

// A step may ask to run again on the page it led to (one size or voltage
// picked per page): at most this many times more.
const PRICE_TEST_MAX_REPEATS = 5;

// "a Magalu", "o Mercado Livre"; "na"/"no", "da"/"do", "pela"/"pelo".
function priceTestStoreWords(store) {
  const feminine = !store || store.article === 'a';
  const name = store ? store.name : 'loja';
  return {
    the: (feminine ? 'a ' : 'o ') + name,
    in: (feminine ? 'na ' : 'no ') + name,
    of: (feminine ? 'da ' : 'do ') + name,
    by: (feminine ? 'pela ' : 'pelo ') + name,
  };
}

function priceTestCapitalize(text) {
  return text.charAt(0).toUpperCase() + text.slice(1);
}

function priceTestErrorText(code, detail, step, request, deps, store) {
  const where = step ? step.name : '';
  const words = priceTestStoreWords(store);
  switch (code) {
    case 'UNSUPPORTED_STORE':
      return 'Por enquanto o teste só funciona com promoções da Magalu, do Mercado Livre, da Amazon, do KaBuM!, da Centauro e do AliExpress';
    case 'NO_URL':
      return 'A promoção não tem link da loja';
    case 'NO_PRICE':
      return 'A promoção não tem preço cadastrado';
    case 'SESSION_EXPIRED':
      return 'Sessão expirada: faça login ' + words.in + ' para testar novamente';
    case 'OUT_OF_STOCK':
      return 'Produto indisponível ' + words.in;
    case 'SUPERMARKET':
      return 'Produto de supermercado: ' + words.the + ' só vende pelo carrinho. Teste à mão';
    case 'OFFER_GONE':
      return 'O anúncio da promoção não está mais à venda ' + words.in;
    case 'NO_SELLER':
      return 'O produto não tem vendedor em destaque ' + words.in + ' e o link não diz qual anúncio testar';
    case 'NO_DELIVERY':
      return priceTestCapitalize(words.the) + ' não entrega este produto nos endereços da sua conta';
    case 'NO_CHOICE':
      return priceTestCapitalize(words.the) + ' pede para escolher "' + detail.name + '", mas não mostra opções: teste à mão';
    case 'BLOCKED':
      return priceTestCapitalize(words.the) + ' bloqueou o acesso por um momento (erro 403): tente de novo em 1 minuto';
    case 'OTHER_PRODUCT':
      return priceTestCapitalize(words.the) + ' abriu a compra de outro produto no "Comprar agora": teste à mão';
    case 'VARIATION_GONE':
      return 'A variação da promoção (tamanho, cor...) não está mais à venda ' + words.in;
    case 'DIGITAL_ONLY':
      return 'Produto digital (eBook Kindle): a Amazon só vende com "Comprar agora com 1-clique", no cartão, sem Pix. Teste à mão';
    case 'NO_FEATURED_OFFER':
      return 'Sem oferta em destaque ' + words.in + ' (não há "Comprar agora", só "Ver todas as opções de compra"): a promoção pode ter acabado';
    case 'NOT_PRODUCT':
      return 'O link da promoção não abre um produto ' + words.in;
    case 'COUPON_REJECTED':
      return 'Cupom "' + request.coupon + '" recusado ' + words.by + ': "' + detail.message + '"';
    case 'NEEDS_HUMAN':
      return 'Ação necessária ' + words.in + ' não foi resolvida em ' + Math.round(deps.humanWaitMs / 1000) + ' s: resolva na aba e teste de novo';
    case 'SELECTOR_NOT_FOUND':
      return 'Não encontrei "' + detail.element + '" na etapa "' + where + '" (' + words.the + ' pode ter mudado a página)';
    case 'TIMEOUT':
      return priceTestCapitalize(words.the) + ' demorou demais na etapa "' + where + '"';
    case 'WRONG_SITE':
      return 'O link da promoção não abriu ' + words.the + ' (' + detail.host + ')';
    case 'CANCELLED':
      return 'Teste cancelado (a aba ' + words.of + ' foi fechada)';
    case 'BAD_TOTAL':
      return 'Não consegui ler o total ' + words.in + ' ("' + detail.text + '")';
    case 'BAD_SHIPPING':
      return 'Não consegui ler o frete ' + words.in + ' ("' + detail.text + '")';
    default:
      if (!step) return 'Erro no teste: ' + ((detail && detail.message) || code);
      return 'Erro na etapa "' + where + '": ' + ((detail && detail.message) || code);
  }
}

// The tab's host when it isn't one of the store's, else null.
async function priceTestForeignHost(tabId, store, deps) {
  const host = await deps.tabHost(tabId);
  return store.hosts.test(host) ? null : host;
}

// One step, within the step's time (and never past the test's deadline). A
// step that fails because the page changed under it (a redirect), or answers
// nothing, runs once more on the new page.
// Resolves when the page a step runs on is replaced by another while the
// step is at work: its answer is lost with it, and the step would only end
// at its time limit (seen on Mercado Livre: "PIX ... + 20,0 s", twice). The
// pages are told apart by Chrome's id of the document the step was injected
// into (`watch.page`, from runStep) and the one the tab shows now: a mark
// left on the page went unseen when the page lasted under a check's pause.
// Stops when `watch.over`.
async function priceTestPageReplaced(tabId, deps, limitMs, watch) {
  if (!deps.pageId) return new Promise(function () {});
  const until = deps.now() + limitMs;
  let pause = 200;
  while (!watch.over && deps.now() < until) {
    await deps.sleep(pause);
    pause = 1000;
    if (watch.over) break;
    if (!watch.page) continue;
    const now = await deps.pageId(tabId);
    if (now && now !== watch.page && !watch.over) return;
  }
  return new Promise(function () {});
}

async function priceTestRunStep(tabId, files, step, input, deps, deadline) {
  for (let attempt = 0; ; attempt++) {
    const watch = { over: false, page: null };
    try {
      const limitMs = Math.max(0, Math.min(deps.stepTimeoutMs, deadline - deps.now()));
      const result = await Promise.race([
        deps.runStep(tabId, files, step.key, input, function (page) {
          watch.page = page;
        }),
        deps.timer(limitMs).then(function () {
          return { ok: false, code: 'TIMEOUT' };
        }),
        // Run again on the new page, as a step that navigated asks.
        priceTestPageReplaced(tabId, deps, limitMs, watch).then(function () {
          return { ok: true, navigates: true, repeat: true };
        }),
      ]);
      watch.over = true;
      if (!result) throw new Error('sem resposta da página');
      if (result.code === 'TIMEOUT' && !(await deps.isTabOpen(tabId))) return { ok: false, code: 'CANCELLED' };
      return result;
    } catch (err) {
      watch.over = true;
      if (!(await deps.isTabOpen(tabId))) return { ok: false, code: 'CANCELLED' };
      if (attempt > 0) return { ok: false, code: 'STEP_FAILED', detail: { message: err.message } };
      await deps.waitForLoad(tabId, deps.stepTimeoutMs);
    }
  }
}

// A captcha or confirmation: tell the backoffice, and try the step again
// every few seconds while someone solves it in the tab.
async function priceTestWaitForHuman(tabId, store, step, input, deps) {
  const files = store.files;
  deps.notify({ type: 'priceTest:needsHuman', tabId: tabId, message: 'Ação necessária ' + priceTestStoreWords(store).in + ': resolva na aba e o teste continua' });
  const until = deps.now() + deps.humanWaitMs;
  while (deps.now() < until) {
    await deps.sleep(deps.humanRetryMs);
    // Bounded by humanWaitMs, not by the test's deadline (which waits).
    const result = await priceTestRunStep(tabId, files, step, input, deps, Infinity);
    if (result.ok || result.code !== 'NEEDS_HUMAN') return result;
  }
  return { ok: false, code: 'NEEDS_HUMAN' };
}

// The store refused the deal's coupon and the test went on without it: say
// so, then the usual result, and how much more it is than the deal's.
function priceTestCouponRejectedLines(compared, coupon, refusal, store) {
  let lines = ['Cupom "' + coupon + '" não funcionou: "' + refusal + '"'];
  // Seen on Magalu with coupons from its app ("não é válido para esse canal").
  if (/\bcanal\b/i.test(refusal)) {
    lines.push(priceTestCapitalize(priceTestStoreWords(store).the) + ' diz que o cupom não vale neste canal: ele deve ser só do aplicativo, confira no app');
  }
  lines = lines.concat(priceTestResultLines(compared));
  if (compared.status === 'validated' || compared.productCents < compared.advertisedCents) return lines;
  return lines.concat(['Sem o cupom, está ' + priceTestFormat(compared.productCents - compared.advertisedCents) + ' mais caro que a promoção']);
}

// The area (CSS pixels of a page viewportWidth wide) in the picture's pixels,
// kept inside the picture.
function priceTestCropBox(area, imageWidth, imageHeight) {
  const scale = imageWidth / area.viewportWidth;
  const sx = Math.min(imageWidth - 1, Math.max(0, Math.round(area.x * scale)));
  const sy = Math.min(imageHeight - 1, Math.max(0, Math.round(area.y * scale)));
  return {
    sx: sx,
    sy: sy,
    sw: Math.max(1, Math.min(imageWidth - sx, Math.round(area.width * scale))),
    sh: Math.max(1, Math.min(imageHeight - sy, Math.round(area.height * scale))),
  };
}

// "2,1 s": tenths of a second, the Brazilian way.
function priceTestSeconds(ms) {
  return (Math.max(0, ms) / 1000).toFixed(1).replace('.', ',') + ' s';
}

// The result's last line: how long the test took, from the click.
function priceTestDurationLine(ms) {
  const seconds = Math.round(ms / 1000);
  if (seconds < 1) return 'O teste da promoção demorou menos de 1 segundo';
  return 'O teste da promoção demorou ' + seconds + (seconds === 1 ? ' segundo' : ' segundos');
}

// One step of the store's, again while it asks to (it picked a size and the
// page changed): a person's captcha doesn't count against the test, and what
// the step remembers (the product's title) goes to the later steps.
async function priceTestStepThrough(tabId, store, step, request, input, deps, clock) {
  for (let run = 0; ; run++) {
    // Every run again tells the backoffice the test is alive (its watchdog
    // gives up after 30 s of silence), with the same label.
    if (run > 0 && step.label) deps.notify({ type: 'priceTest:progress', step: step.key, label: step.label(request) });
    if (clock.runs) clock.runs.push(deps.now());
    let result = await priceTestRunStep(tabId, store.files, step, input, deps, clock.deadline);
    if (!result.ok && result.code === 'NEEDS_HUMAN') {
      const waitStarted = deps.now();
      result = await priceTestWaitForHuman(tabId, store, step, input, deps);
      clock.deadline += deps.now() - waitStarted;
    }
    if (!result.ok) return result;
    if (result.navigates) await deps.waitForLoad(tabId, deps.stepTimeoutMs);
    if (result.remember) Object.assign(input, result.remember);
    if (!result.repeat) return result;
    if (run >= PRICE_TEST_MAX_REPEATS) return { ok: false, code: 'STEP_FAILED', detail: { message: 'a página não parou de mudar' } };
    if (deps.now() > clock.deadline) return { ok: false, code: 'TIMEOUT' };
  }
}

async function runPriceTest(request, deps) {
  const started = deps.now();
  let tabId = null;
  let failedStep = null;
  // Past "Comprar agora" on a store that keeps the product in the cart.
  let cartFilled = false;
  // How long each step took, from its start to the next one's (the first
  // counts the tab opening): where a slow or failed test spent its time.
  const timings = [];
  let stepStarted = started;
  // When each run of the current step started (priceTestStepThrough): a
  // step that ran more than once shows each run's time ("PIX 22,8 s =
  // 0,8 s + 22,0 s"), its wait for the next page included.
  let runStarts = [];
  function stepDone(name, note) {
    const now = deps.now();
    let runs = '';
    if (runStarts.length > 1) {
      const ends = runStarts.slice(1).concat(now);
      runs = ' = ' + ends.map(function (end, i) {
        return priceTestSeconds(end - (i === 0 ? stepStarted : runStarts[i]));
      }).join(' + ');
    }
    timings.push(name + ' ' + priceTestSeconds(now - stepStarted) + runs + (note || ''));
    stepStarted = now;
    runStarts = [];
  }
  function timingsText() {
    return timings.length ? 'Tempo por etapa: ' + timings.join(' · ') : undefined;
  }

  const store = Object.prototype.hasOwnProperty.call(PRICE_TEST_STORES, request.store) ? PRICE_TEST_STORES[request.store] : null;

  function fail(code, detail) {
    if (tabId !== null && failedStep) stepDone(failedStep.name, ' (parou aqui)');
    const message = {
      type: 'priceTest:error',
      code: code,
      message: priceTestErrorText(code, detail || {}, failedStep, request, deps, store),
      tabId: tabId,
    };
    if (cartFilled) message.lines = [message.message, 'O produto pode ter ficado no carrinho ' + priceTestStoreWords(store).of];
    const text = timingsText();
    if (text) message.timings = text;
    deps.notify(message);
    return message;
  }

  if (!store) return fail('UNSUPPORTED_STORE');
  if (!request.url) return fail('NO_URL');
  const advertisedCents = priceTestCents(request.price);
  if (!advertisedCents) return fail('NO_PRICE');

  try {
    const steps = store.steps.filter(function (step) {
      return !step.when || step.when(request);
    });
    // The deal's link goes along: on a catalog page it names the listing to buy.
    // A deal for several units ("Leve 2", priceTestDealUnits): the store
    // buys that many where it can.
    const units = request.units > 1 ? request.units : 1;
    const input = { coupon: request.coupon || null, url: request.url, units: units, timeoutMs: deps.stepTimeoutMs - 2000 };
    const clock = { deadline: deps.now() + deps.totalTimeoutMs };
    let totals = null;
    let couponRejected = null;

    deps.notify({ type: 'priceTest:progress', step: steps[0].key, label: steps[0].label(request) });
    tabId = await deps.openTab(request.url);
    await deps.waitForLoad(tabId, deps.stepTimeoutMs);

    for (const step of steps) {
      failedStep = step;
      if (deps.now() > clock.deadline) return fail('TIMEOUT');
      const foreign = await priceTestForeignHost(tabId, store, deps);
      if (foreign !== null) return fail('WRONG_SITE', { host: foreign });
      // The first step's progress went out before opening the tab.
      if (step !== steps[0]) deps.notify({ type: 'priceTest:progress', step: step.key, label: step.label(request) });
      if (step.fillsCart) cartFilled = true;
      clock.runs = runStarts = [];
      const result = await priceTestStepThrough(tabId, store, step, request, input, deps, clock);
      if (!result.ok) return fail(result.code, result.detail);
      if (step.key === 'readTotals') totals = result;
      // The order still counts a coupon the store refused to take again.
      if (result.couponApplied) couponRejected = null;
      if (result.couponRejected) couponRejected = result.couponRejected;
      stepDone(step.name);
    }
    failedStep = null;

    const foreign = await priceTestForeignHost(tabId, store, deps);
    if (foreign !== null) return fail('WRONG_SITE', { host: foreign });
    const totalCents = priceTestCents(totals.totalText);
    if (totalCents === null) return fail('BAD_TOTAL', { text: totals.totalText });
    let shippingCents = 0;
    if (totals.shippingText && !/gr[aá]tis/i.test(totals.shippingText)) {
      shippingCents = priceTestCents(totals.shippingText);
      if (shippingCents === null) return fail('BAD_SHIPPING', { text: totals.shippingText });
    }
    // A store that sells a minimum quantity (Amazon) checks out several: the
    // deal's price is one unit's.
    const quantity = totals.quantity > 1 ? totals.quantity : 1;
    const compared = comparePrice({ advertisedCents: advertisedCents, totalCents: totalCents, shippingCents: shippingCents, quantity: quantity, units: units });
    // A picture of the review's values (the total in PIX) for the moderator,
    // taken before the window closes: the page first has to be clear of its
    // loading blur, at most 5 s more. Without it the result still goes out.
    let screenshot = null;
    try {
      const frame = { key: 'frameTotals', name: 'print' };
      const framed = await priceTestRunStep(tabId, store.files, frame, Object.assign({}, input, { timeoutMs: 5000 }), deps, deps.now() + 7000);
      if (framed && framed.ok && framed.area && deps.capture) screenshot = await deps.capture(tabId, framed.area);
    } catch (err) {
      screenshot = null;
    }
    // The product out of the cart (Mercado Livre). It doesn't change the
    // price: when it fails the result says so and the window stays open for
    // the moderator to take it out by hand.
    let cleaned = true;
    for (const step of store.cleanup) {
      if (step.label) deps.notify({ type: 'priceTest:progress', step: step.key, label: step.label(request) });
      const result = await priceTestStepThrough(tabId, store, step, request, input, deps, { deadline: deps.now() + deps.stepTimeoutMs * 2 });
      if (!result.ok) {
        cleaned = false;
        break;
      }
    }
    if (store.cleanup.length) stepDone('carrinho', cleaned ? '' : ' (não tirou)');
    // A tab that won't close must not discard the result.
    if (cleaned) {
      try {
        await deps.closeTab(tabId);
      } catch (err) {
        // Left open: the backoffice still gets the result.
      }
    }
    let lines = couponRejected ? priceTestCouponRejectedLines(compared, request.coupon, couponRejected, store) : priceTestResultLines(compared);
    if (units > 1) {
      const how = quantity === units ? 'compara o valor das ' + units : 'simulou ' + units + ' (valor de 1 × ' + units + ')';
      lines = lines.concat('Promoção de ' + units + ' unidades ("Leve ' + units + '"): o teste comprou ' + quantity + ' e ' + how);
    } else if (quantity > 1) {
      lines = lines.concat('Quantidade mínima: ' + quantity + ' (valor do teste por unidade)');
    }
    // Ticked on the product page (Amazon's "Aplicar Cupom de 11%").
    if (input.pageCoupon) lines = lines.concat('Cupom da página do produto aplicado: ' + input.pageCoupon);
    // "[Moedas R$5824] Impressora": AliExpress's coins discount is mostly
    // the app's, which the test can't reach.
    if (request.coins) lines = lines.concat('Promoção com Moedas: o desconto das moedas costuma valer só no app do AliExpress. Se o preço não bateu, confira no app');
    if (!cleaned) lines = lines.concat('Não consegui tirar o produto do carrinho ' + priceTestStoreWords(store).of + ': tire à mão');
    lines = lines.concat(priceTestDurationLine(deps.now() - started));
    const message = { type: 'priceTest:result', status: compared.status, lines: lines, timings: timingsText() };
    if (!cleaned) message.tabId = tabId;
    if (screenshot) message.screenshot = screenshot;
    deps.notify(message);
    return message;
  } catch (err) {
    if (tabId !== null && !(await deps.isTabOpen(tabId))) return fail('CANCELLED');
    return fail('STEP_FAILED', { message: err.message });
  }
}

// The test in progress, if any: one at a time in the browser. Backoffice
// tabs that asked for it ("watchers") get every message; one asking while it
// runs gets the latest right away.
let priceTestRunning = null;

function handlePriceTestStart(request, senderTabId, deps) {
  if (priceTestRunning) {
    priceTestRunning.watchers.add(senderTabId);
    if (priceTestRunning.last) deps.send(senderTabId, priceTestRunning.last);
    return { started: false, dealId: priceTestRunning.dealId };
  }
  const running = { watchers: new Set([senderTabId]), last: null, dealId: request.dealId };
  priceTestRunning = running;
  function notify(original) {
    // The backoffice tab shows only the messages of its own deal.
    const message = Object.assign({}, original, { dealId: running.dealId });
    running.last = message;
    running.watchers.forEach(function (tabId) {
      deps.send(tabId, message);
    });
  }
  runPriceTest(request, Object.assign({}, deps, { notify: notify }))
    .catch(function (err) {
      notify({ type: 'priceTest:error', code: 'STEP_FAILED', message: 'Erro no teste: ' + err.message, tabId: null });
    })
    .finally(function () {
      if (priceTestRunning === running) priceTestRunning = null;
    });
  return { started: true };
}

function resetPriceTest() {
  priceTestRunning = null;
}

// True in a web page that is not the one a step just left: the step that
// navigates flags its page (pelandoPriceTestStep), and a new document starts
// without the flag. Needs a body for the step to search.
function priceTestNewPageProbe() {
  return /^https?:$/.test(location.protocol) && !window.pelandoPriceTestLeft && !!document.body;
}

// Resolves once the tab shows a new page, without waiting for it to finish
// loading (images, ads): the next step looks for its button and clicks as
// soon as it shows. A page that changes without a full load (parts of the
// checkout are a single-page app) never starts loading: after a short grace
// the step goes on, and its own waits do the rest.
function priceTestWaitForLoad(tabId, timeoutMs) {
  return new Promise(function (resolve) {
    let loading = false;
    let finished = false;
    let probing = false;
    const started = Date.now();
    function done() {
      if (finished) return;
      finished = true;
      chrome.tabs.onUpdated.removeListener(listener);
      clearInterval(poll);
      clearTimeout(limit);
      resolve();
    }
    // A page that changes without reloading (Amazon's checkout and its
    // payment page) goes loading → complete while the same document, with
    // the step's mark, stays: complete ends the wait too.
    function listener(id, info) {
      if (id !== tabId) return;
      if (info.status === 'loading') loading = true;
      else if (info.status === 'complete' && loading) done();
    }
    chrome.tabs.onUpdated.addListener(listener);
    chrome.tabs.get(tabId).then(
      function (tab) {
        if (tab.status === 'loading') loading = true;
      },
      done
    );
    const poll = setInterval(function () {
      if (!loading) {
        if (Date.now() - started >= 2000) done();
        return;
      }
      if (probing) return;
      probing = true;
      chrome.scripting
        .executeScript({ target: { tabId: tabId }, injectImmediately: true, func: priceTestNewPageProbe })
        .then(
          function (injections) {
            if (injections && injections[0] && injections[0].result === true) done();
          },
          function () {
            // The page is being replaced: try again on the next tick.
          }
        )
        .finally(function () {
          probing = false;
        });
    }, 150);
    const limit = setTimeout(done, timeoutMs);
  });
}

function chromePriceTestDeps() {
  return {
    stepTimeoutMs: 20000,
    totalTimeoutMs: 90000,
    humanWaitMs: 60000,
    humanRetryMs: 3000,
    now: function () {
      return Date.now();
    },
    sleep: function (ms) {
      return new Promise(function (resolve) {
        setTimeout(resolve, ms);
      });
    },
    timer: function (ms) {
      return new Promise(function (resolve) {
        setTimeout(resolve, ms);
      });
    },
    // A small window of its own, on top in the corner of the current one: in
    // a background tab Chrome slows timers down, pauses animations and skips
    // the parts of the page out of view (the product page's shipping check,
    // which tells "Produto esgotado!"). Under 768 px wide Magalu shows its
    // phone layout, which the steps don't know.
    openTab: async function (url) {
      const size = { width: 800, height: 640 };
      const options = Object.assign({ url: url, type: 'popup', focused: true }, size);
      try {
        const current = await chrome.windows.getLastFocused();
        options.left = current.left + current.width - size.width - 16;
        options.top = current.top + current.height - size.height - 16;
      } catch (err) {
        // Chrome places it.
      }
      const win = await chrome.windows.create(options);
      return win.tabs[0].id;
    },
    closeTab: function (tabId) {
      return chrome.tabs.remove(tabId).catch(function () {});
    },
    tabHost: async function (tabId) {
      try {
        return new URL((await chrome.tabs.get(tabId)).url).hostname;
      } catch (err) {
        return '';
      }
    },
    isTabOpen: function (tabId) {
      return chrome.tabs.get(tabId).then(
        function () {
          return true;
        },
        function () {
          return false;
        }
      );
    },
    waitForLoad: priceTestWaitForLoad,
    // What the store window shows ("<all_urls>" lets the extension take it),
    // cut down to the area (the review's values).
    capture: async function (tabId, area) {
      const tab = await chrome.tabs.get(tabId);
      const shot = await chrome.tabs.captureVisibleTab(tab.windowId, { format: 'png' });
      const image = await createImageBitmap(await (await fetch(shot)).blob());
      const box = priceTestCropBox(area, image.width, image.height);
      const canvas = new OffscreenCanvas(box.sw, box.sh);
      canvas.getContext('2d').drawImage(image, box.sx, box.sy, box.sw, box.sh, 0, 0, box.sw, box.sh);
      const bytes = new Uint8Array(await (await canvas.convertToBlob({ type: 'image/jpeg', quality: 0.9 })).arrayBuffer());
      let binary = '';
      for (let i = 0; i < bytes.length; i += 0x8000) binary += String.fromCharCode.apply(null, bytes.subarray(i, i + 0x8000));
      return 'data:image/jpeg;base64,' + btoa(binary);
    },
    // onPage gets the id of the document the step runs in (pageId).
    runStep: async function (tabId, files, step, input, onPage) {
      // Right away, not when the page is idle: the step waits for its own elements.
      const loaded = await chrome.scripting.executeScript({ target: { tabId: tabId }, injectImmediately: true, files: files });
      const page = loaded && loaded[0] ? loaded[0].documentId : null;
      if (page && onPage) onPage(page);
      // In that same document: a page swapped in between hasn't the files.
      const target = page ? { tabId: tabId, documentIds: [page] } : { tabId: tabId };
      const injections = await chrome.scripting.executeScript({
        target: target,
        injectImmediately: true,
        func: function (step, input) {
          return pelandoPriceTestStep(step, input);
        },
        args: [step, input],
      });
      return injections && injections[0] ? injections[0].result : null;
    },
    // Chrome's id of the document the tab shows, or null while it is being
    // swapped.
    pageId: async function (tabId) {
      try {
        const injections = await chrome.scripting.executeScript({
          target: { tabId: tabId },
          injectImmediately: true,
          func: function () {
            return true;
          },
        });
        return (injections && injections[0] && injections[0].documentId) || null;
      } catch (err) {
        return null;
      }
    },
    send: function (tabId, message) {
      chrome.tabs.sendMessage(tabId, message).catch(function () {
        // That backoffice tab was closed or reloaded: nothing to show there.
      });
    },
  };
}

async function focusPriceTestTab(tabId) {
  const tab = await chrome.tabs.update(tabId, { active: true });
  await chrome.windows.update(tab.windowId, { focused: true });
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = { runPriceTest, handlePriceTestStart, resetPriceTest, chromePriceTestDeps, focusPriceTestTab, priceTestWaitForLoad, priceTestCropBox, PRICE_TEST_STORES };
}
