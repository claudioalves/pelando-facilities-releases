// "Testar Promoção": the steps on KaBuM!'s pages, injected after compare.js
// and page.js (which has the helpers and pelandoPriceTestStep). Product page
// → "Comprar agora" (it puts the product in the cart, /precarrinho) → the
// cart and its five-step checkout: /carrinho, /endereco (the account's
// address, and the coupon box), /entrega, /pagamento (Pix), /confirmacao.
// The test stops on /pagamento: /confirmacao only holds "FINALIZAR". The
// cleanup takes the product out of the cart, by its code (/produto/<code>).
//
// Elements are found by visible text and role, as on the other stores, with
// KaBuM!'s stable ids where it has them (inputAplicarCupom, remove-button-).

function kabumOnPage(doc, name) {
  return new RegExp('^/' + name + '/?$', 'i').test(doc.defaultView.location.pathname);
}

// The error page's own text ("O Ninja identificou um erro na sua compra e não
// podemos prosseguir", then the product and what went wrong), without the
// cookie notice; '' while the page is still drawing it.
function kabumErrorText(doc) {
  const main = doc.querySelector('main') || doc.body;
  const text = priceTestTextNodes(main)
    .filter(function (node) {
      return !node.parentElement.closest('[role="dialog"], [role="alertdialog"], button');
    })
    .map(function (node) {
      return node.nodeValue;
    })
    .join(' ')
    .replace(/\s+/g, ' ')
    .trim();
  const start = text.search(/identificou um erro/i);
  if (start === -1) return '';
  return text.slice(start).replace(/^.*?prosseguir\s*/i, '').trim();
}

// KaBuM!'s own stops on top of the common ones: its error page (/erro). An
// offer that ran out ("Oferta marketplace esgotada") is out of stock; any
// other error is told in the store's words.
function kabumErrorResult(text) {
  if (/esgot|sem estoque|indispon[ií]vel/i.test(text)) return { ok: false, code: 'OUT_OF_STOCK' };
  return { ok: false, code: 'STEP_FAILED', detail: { message: 'O KaBuM! recusou a compra: "' + (text.slice(0, 120) || 'erro na compra') + '"' } };
}

function kabumBlocker(doc) {
  const blocked = priceTestBlocker(doc);
  if (blocked) return blocked;
  if (!kabumOnPage(doc, 'erro')) return null;
  return kabumErrorResult(kabumErrorText(doc));
}

// At a step's start: the error page is read once it has drawn its reason.
async function kabumStop(doc, input) {
  const blocked = priceTestBlocker(doc);
  if (blocked) return blocked;
  if (!kabumOnPage(doc, 'erro')) return null;
  const text = await priceTestWaitFor(function () {
    return kabumErrorText(doc);
  }, Math.min(5000, input.timeoutMs));
  return kabumErrorResult(text || '');
}

// The product's code, from the deal's link (/produto/103657/...).
function kabumProductCode(url) {
  const match = /\/produto\/(\d+)/i.exec(String(url || ''));
  return match ? match[1] : null;
}

// "Produto indisponível", "Avise-me quando chegar": nothing to buy.
function kabumOutOfStock(doc) {
  return (
    priceTestTextNodes(doc.body).some(function (node) {
      return /produto indispon[ií]vel|esgotado/i.test(node.nodeValue) && priceTestIsVisible(node.parentElement) && !node.parentElement.closest('header, footer, nav');
    }) || !!priceTestFindClickable(doc, /^avise-me/i)
  );
}

async function kabumCheckProduct(doc, input) {
  const blocked = await kabumStop(doc, input);
  if (blocked) return blocked;
  const seen = await priceTestWaitFor(function () {
    if (priceTestFindClickable(doc, /^comprar agora$/i)) return 'buy';
    if (kabumOutOfStock(doc)) return 'out';
    return null;
  }, input.timeoutMs);
  if (!seen) return kabumBlocker(doc) || priceTestMissing('Comprar agora');
  if (seen === 'out') return { ok: false, code: 'OUT_OF_STOCK' };
  return { ok: true };
}

// "Comprar agora" puts the product in the cart and opens /precarrinho.
async function kabumBuyNow(doc, input) {
  const blocked = await kabumStop(doc, input);
  if (blocked) return blocked;
  const buy = priceTestFindClickable(doc, /^comprar agora$/i);
  if (!buy) return kabumOutOfStock(doc) ? { ok: false, code: 'OUT_OF_STOCK' } : priceTestMissing('Comprar agora');
  const code = kabumProductCode(doc.defaultView.location.href) || kabumProductCode(input.url);
  priceTestClickSoon(buy);
  const result = { ok: true, navigates: true };
  if (code) result.remember = { productCode: code };
  return result;
}

function kabumGoTo(doc, path) {
  priceTestSoon(function () {
    doc.defaultView.location.assign('https://www.kabum.com.br/' + path);
  });
  return Promise.resolve({ ok: true, navigates: true });
}

// The checkout's "CONTINUAR" (the summary has one, the page's foot another:
// both go on).
function kabumContinue(doc) {
  return priceTestFindClickable(doc, /^continuar$/i);
}

// The cart picks an extended warranty by itself ("12 Meses de Garantia
// Estendida Kabum", in "Serviços Adicionais"): the "Sem garantia" of each
// product's warranty list.
function kabumNoServiceOptions(doc) {
  return Array.from(doc.querySelectorAll('input[type="radio"]')).filter(function (radio) {
    return /^sem (garantia|seguro|servi[cç]o)/i.test(priceTestText(priceTestRadioLabel(doc, radio)));
  });
}

// The list can sit closed under "Seguros 1 seguro adicionado" (seen
// 2026-10-27), its radios not in the page until it opens: the line that
// counts what was added opens it.
function kabumClosedServices(doc) {
  const node = priceTestTextNodes(doc.body).find(function (text) {
    return /^\s*\d+ (seguros?|garantias?|servi[cç]os?) adicionad/i.test(text.nodeValue) && priceTestIsVisible(text.parentElement);
  });
  if (!node) return null;
  return node.parentElement.closest('[aria-expanded="false"]') || node.parentElement;
}

// Extra services in the summary ("Serviços Adicionais (1): R$ 132,68").
function kabumHasServices(doc) {
  const summary = kabumSummary(doc);
  return !!summary && /servi[cç]os adicionais/i.test(priceTestText(summary));
}

// From the pre-cart page, the cart; from the cart, without extra services,
// on to the address step, where the coupon box is.
async function kabumOpenCheckout(doc, input) {
  const blocked = await kabumStop(doc, input);
  if (blocked) return blocked;
  if (kabumOnPage(doc, 'endereco')) return { ok: true };
  if (!kabumOnPage(doc, 'carrinho')) return Object.assign(await kabumGoTo(doc, 'carrinho'), { repeat: true });
  if (!(await priceTestWaitFor(function () {
    return kabumSummary(doc);
  }, input.timeoutMs))) {
    return kabumBlocker(doc) || priceTestMissing('Resumo do pedido');
  }
  let tries = 0;
  let lastTry = 0;
  let opened = false;
  const plain = await priceTestWaitFor(function () {
    const pending = kabumNoServiceOptions(doc).filter(function (radio) {
      return !priceTestIsChosen(radio);
    });
    if (!pending.length && !kabumHasServices(doc)) return true;
    // Opening the closed list is no try: its radios get clicked right after.
    const closed = !kabumNoServiceOptions(doc).length && kabumClosedServices(doc);
    if (closed && !opened) {
      opened = true;
      priceTestClick(closed);
      return null;
    }
    if (pending.length && tries < 4 && Date.now() - lastTry >= 2000) {
      pending.forEach(function (radio) {
        priceTestClick(priceTestRadioLabel(doc, radio));
      });
      tries += 1;
      lastTry = Date.now();
    }
    return null;
  }, input.timeoutMs);
  if (!plain) return priceTestMissing('Sem garantia');
  const go = await priceTestWaitFor(function () {
    return kabumSummary(doc) ? kabumContinue(doc) : null;
  }, input.timeoutMs);
  if (!go) return kabumBlocker(doc) || priceTestMissing('CONTINUAR');
  priceTestClickSoon(go);
  return { ok: true, navigates: true, repeat: true };
}

// The order summary ("Resumo do pedido"), with its total.
function kabumSummary(doc) {
  const heading = Array.from(doc.querySelectorAll('h1, h2, h3')).find(function (el) {
    return /^resumo do pedido$/i.test(priceTestText(el)) && priceTestIsVisible(el);
  });
  if (!heading) return null;
  for (let box = heading.parentElement; box && box !== doc.body; box = box.parentElement) {
    if (/\btotal\s*:/i.test(priceTestText(box)) && /R\$/.test(priceTestText(box))) return box;
  }
  return null;
}

// The store's answer to a code, under the coupon box.
function kabumCouponAnswer(doc) {
  const text = priceTestText(doc.body);
  const refusal = /cupom inv[aá]lido[^.]*\.?|cupom (expirado|esgotado|n[aã]o (é )?v[aá]lido)[^.]*\.?/i.exec(text);
  // Without a period the match runs on into the page: keep the message's
  // length.
  if (refusal) return { ok: true, couponRejected: refusal[0].slice(0, 120).trim() };
  if (/cupom aplicado com sucesso/i.test(text)) return { ok: true };
  return null;
}

// The coupon goes in on the address step ("Cupom de desconto", OK).
async function kabumApplyCoupon(doc, input) {
  const blocked = await kabumStop(doc, input);
  if (blocked) return blocked;
  const field = await priceTestWaitFor(function () {
    const el = doc.getElementById('inputAplicarCupom') || doc.querySelector('input[name="coupon"]');
    return el && priceTestIsVisible(el) ? el : null;
  }, input.timeoutMs);
  if (!field) return priceTestMissing('campo de cupom');
  // The box sits in a grid with its OK button.
  const box = field.closest('.grid') || field.parentElement.parentElement.parentElement;
  const ok =
    Array.from((box || doc).querySelectorAll('button')).find(function (el) {
      return /^ok$/i.test(priceTestLabelOf(el)) && priceTestIsVisible(el);
    }) || priceTestFindClickable(doc, /^ok$/i);
  if (!ok) return priceTestMissing('OK do cupom');
  priceTestType(field, input.coupon);
  priceTestClick(ok);
  const answer = await priceTestWaitFor(function () {
    return kabumCouponAnswer(doc);
  }, input.timeoutMs);
  if (!answer) return priceTestMissing('resposta do cupom');
  return answer;
}

// The address step keeps the account's address; the delivery step takes the
// cheapest option; both go on with "CONTINUAR", to the payment step.
function kabumShippingOptions(doc) {
  return Array.from(doc.querySelectorAll('input[type="radio"]'))
    .filter(function (radio) {
      return /shipping/i.test(radio.name || '');
    })
    .map(function (radio) {
      const label = priceTestRadioLabel(doc, radio);
      const text = priceTestText(label);
      return { radio: radio, label: label, cents: /gr[aá]tis/i.test(text) ? 0 : priceTestCents(text) };
    })
    .filter(function (option) {
      return option.cents !== null && !option.radio.disabled;
    });
}

async function kabumPickShipping(doc, input) {
  const blocked = await kabumStop(doc, input);
  if (blocked) return blocked;
  if (kabumOnPage(doc, 'pagamento')) return { ok: true };
  if (kabumOnPage(doc, 'entrega')) {
    const ready = await priceTestWaitFor(function () {
      return kabumShippingOptions(doc).length && kabumContinue(doc) ? true : null;
    }, input.timeoutMs);
    if (!ready) return kabumBlocker(doc) || priceTestMissing('opções de entrega');
    const groups = {};
    kabumShippingOptions(doc).forEach(function (option) {
      const name = option.radio.name;
      if (!groups[name] || option.cents < groups[name].cents) groups[name] = option;
    });
    Object.keys(groups).forEach(function (name) {
      if (!priceTestIsChosen(groups[name].radio)) priceTestClick(groups[name].label);
    });
    const chosen = await priceTestWaitFor(function () {
      return Object.keys(groups).every(function (name) {
        return priceTestIsChosen(groups[name].radio);
      })
        ? true
        : null;
    }, input.timeoutMs);
    if (!chosen) return priceTestMissing('frete escolhido');
    priceTestClickSoon(kabumContinue(doc));
    return { ok: true, navigates: true, repeat: true };
  }
  // The address step (or the cart, when the coupon step didn't run there).
  const go = await priceTestWaitFor(function () {
    return kabumSummary(doc) ? kabumContinue(doc) : null;
  }, input.timeoutMs);
  if (!go) return kabumBlocker(doc) || priceTestMissing('CONTINUAR');
  priceTestClickSoon(go);
  return { ok: true, navigates: true, repeat: true };
}

// "Pix" on the payment step, an accordion: open is chosen.
function kabumPixButton(doc) {
  return (
    Array.from(doc.querySelectorAll('button')).find(function (el) {
      return /^pix\b/i.test(priceTestText(el)) && priceTestIsVisible(el);
    }) || null
  );
}

function kabumPixChosen(doc) {
  const pix = kabumPixButton(doc);
  return !!pix && pix.getAttribute('aria-expanded') === 'true';
}

async function kabumSelectPix(doc, input) {
  const blocked = await kabumStop(doc, input);
  if (blocked) return blocked;
  const pix = await priceTestWaitFor(function () {
    return kabumOnPage(doc, 'pagamento') ? kabumPixButton(doc) : null;
  }, input.timeoutMs);
  if (!pix) return kabumBlocker(doc) || priceTestMissing('PIX');
  let tries = 0;
  let lastTry = 0;
  const chosen = await priceTestWaitFor(function () {
    if (kabumPixChosen(doc)) return true;
    if (tries < 4 && Date.now() - lastTry >= 2000) {
      const current = kabumPixButton(doc);
      if (current) priceTestClick(current);
      tries += 1;
      lastTry = Date.now();
    }
    return null;
  }, input.timeoutMs);
  if (!chosen) return priceTestMissing('PIX selecionado');
  return { ok: true };
}

// "Total: À vista no Pix R$ 80,04", "Frete: R$ 12,55" (or "Grátis").
function kabumValues(doc) {
  const summary = kabumSummary(doc);
  if (!summary) return null;
  const text = priceTestText(summary);
  const total = /total\s*:\s*[àa] vista no pix\s*(R\$\s*[\d.]+,\d{2})/i.exec(text);
  if (!total) return null;
  const shipping = /frete\s*:\s*(R\$\s*[\d.]+,\d{2}|gr[aá]tis)/i.exec(text);
  return { total: total[1].replace(/\s+/g, ' '), shipping: shipping ? shipping[1].replace(/\s+/g, ' ') : '', coupon: /cupom aplicado/i.test(text) };
}

async function kabumReadTotals(doc, input) {
  const blocked = await kabumStop(doc, input);
  if (blocked) return blocked;
  // A summary still recalculating reads R$ 0,00.
  const found = await priceTestWaitFor(function () {
    const values = kabumPixChosen(doc) ? kabumValues(doc) : null;
    return values && priceTestCents(values.total) > 0 ? values : null;
  }, input.timeoutMs);
  if (!found) return kabumBlocker(doc) || priceTestMissing('Total no Pix');
  // Never a total with an extended warranty in it.
  if (kabumHasServices(doc)) return priceTestMissing('Sem garantia');
  const result = { ok: true, totalText: found.total, shippingText: found.shipping };
  if (input.coupon && found.coupon) result.couponApplied = true;
  return result;
}

// The summary on screen, for the picture.
async function kabumFrameTotals(doc, input) {
  const summary = await priceTestWaitFor(function () {
    return kabumSummary(doc);
  }, input.timeoutMs);
  if (!summary) return priceTestMissing('valores na tela');
  if (typeof summary.scrollIntoView === 'function') summary.scrollIntoView({ block: 'start' });
  await priceTestSettled(summary, Math.min(2000, input.timeoutMs));
  const box = summary.getBoundingClientRect();
  const margin = 8;
  return {
    ok: true,
    area: {
      x: Math.max(0, Math.floor(box.left - margin)),
      y: Math.max(0, Math.floor(box.top - margin)),
      width: Math.ceil(box.width + margin * 2),
      height: Math.max(1, Math.ceil(box.height + margin * 2)),
      viewportWidth: doc.defaultView.innerWidth,
    },
  };
}

function kabumOpenCart(doc) {
  return kabumGoTo(doc, 'carrinho');
}

// Its remove button opens a confirmation ("Remover Produto ... Não / Sim"),
// a menu that opens on the pointer going down, not on a click.
function kabumPress(el) {
  const view = el.ownerDocument.defaultView;
  const options = { bubbles: true, cancelable: true, button: 0, pointerType: 'mouse', isPrimary: true };
  const Pointer = view.PointerEvent || view.MouseEvent;
  el.dispatchEvent(new Pointer('pointerdown', options));
  el.dispatchEvent(new view.MouseEvent('mousedown', options));
  el.dispatchEvent(new Pointer('pointerup', options));
  el.dispatchEvent(new view.MouseEvent('mouseup', options));
  priceTestClick(el);
}

function kabumConfirmRemove(doc) {
  const dialog = Array.from(doc.querySelectorAll('[role="dialog"], [role="alertdialog"]')).find(function (el) {
    return /remover produto/i.test(priceTestText(el));
  });
  if (!dialog) return null;
  return (
    Array.from(dialog.querySelectorAll('button')).find(function (el) {
      return /^sim$/i.test(priceTestText(el));
    }) || null
  );
}

async function kabumRemoveFromCart(doc, input) {
  const blocked = await kabumStop(doc, input);
  if (blocked) return blocked;
  if (!input.productCode) return priceTestMissing('código do produto');
  const remover = function () {
    return doc.getElementById('remove-button-' + input.productCode);
  };
  const ready = await priceTestWaitFor(function () {
    return remover() || /carrinho est[aá] vazio/i.test(priceTestText(doc.body)) ? true : null;
  }, input.timeoutMs);
  if (!ready) return priceTestMissing('carrinho');
  if (!remover()) return { ok: true };
  let presses = 0;
  let lastPress = 0;
  const gone = await priceTestWaitFor(function () {
    if (!remover()) return true;
    const yes = kabumConfirmRemove(doc);
    if (yes) {
      priceTestClick(yes);
      return null;
    }
    if (presses < 5 && Date.now() - lastPress >= 2000) {
      kabumPress(remover());
      presses += 1;
      lastPress = Date.now();
    }
    return null;
  }, input.timeoutMs);
  return gone ? { ok: true } : priceTestMissing('Remover produto');
}

// The steps pelandoPriceTestStep (page.js) runs here.
function pelandoPriceTestSteps() {
  return {
    checkProduct: kabumCheckProduct,
    buyNow: kabumBuyNow,
    openCheckout: kabumOpenCheckout,
    applyCoupon: kabumApplyCoupon,
    pickShipping: kabumPickShipping,
    selectPix: kabumSelectPix,
    readTotals: kabumReadTotals,
    frameTotals: kabumFrameTotals,
    openCart: kabumOpenCart,
    removeFromCart: kabumRemoveFromCart,
  };
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = {
    kabumProductCode,
    kabumCheckProduct,
    kabumBuyNow,
    kabumOpenCheckout,
    kabumApplyCoupon,
    kabumPickShipping,
    kabumSelectPix,
    kabumReadTotals,
    kabumFrameTotals,
    kabumOpenCart,
    kabumRemoveFromCart,
    pelandoPriceTestSteps,
  };
}
