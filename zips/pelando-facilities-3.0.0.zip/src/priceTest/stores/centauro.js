// "Testar Promoção": the steps on Centauro's pages, injected after compare.js
// and page.js (which has the helpers and pelandoPriceTestStep). Product page
// (the first size on sale) → "Comprar agora", which puts the product in the
// cart and opens it → the checkout's pages: /checkouts/carrinho (the coupon
// box), /checkouts/entrega, /checkouts/pagamento (Pix, and "Finalizar
// compra", never clicked). The test reads the Pix total on /pagamento; the
// cleanup takes the product out of the cart, by its code (…-995490.html).
//
// Elements are found by visible text and role, as on the other stores, with
// Centauro's data-testid where it has them (summary-action, coupon-button,
// remove-from-cart).

function centauroOnPage(doc, name) {
  return new RegExp('^/checkouts/' + name + '/?$', 'i').test(doc.defaultView.location.pathname);
}

// Centauro's own stop on top of the common ones: after many pages in a row
// its CDN answers 403, "Access Denied" (seen 2026-10-30).
function centauroBlocker(doc) {
  const blocked = priceTestBlocker(doc);
  if (blocked) return blocked;
  if (/^access denied$/i.test(doc.title || '') || /you don.t have permission to access/i.test(priceTestText(doc.body).slice(0, 300))) {
    return { ok: false, code: 'BLOCKED' };
  }
  return null;
}

function centauroGoTo(doc, path) {
  priceTestSoon(function () {
    doc.defaultView.location.assign('https://www.centauro.com.br/' + path);
  });
  return Promise.resolve({ ok: true, navigates: true });
}

// The product's code, the link's last part before ".html"
// (camiseta-asics-…-995490.html, tenis-…-9976CY.html).
function centauroProductCode(url) {
  const match = /-([a-z0-9]+)\.html(?:[?#]|$)/i.exec(String(url || ''));
  return match ? match[1] : null;
}

// "Produto indisponível" in place of the sizes.
function centauroOutOfStock(doc) {
  return Array.from(doc.querySelectorAll('h1, h2, h3')).some(function (el) {
    return /^produto indispon[ií]vel$/i.test(priceTestText(el)) && priceTestIsVisible(el);
  });
}

// "Cor indisponível" ("A cor selecionada infelizmente acabou"): the deal's
// color is gone though others are on sale, and "Comprar agora" stays off.
function centauroColorGone(doc) {
  return Array.from(doc.querySelectorAll('h1, h2, h3')).some(function (el) {
    return /^cor indispon[ií]vel$/i.test(priceTestText(el)) && priceTestIsVisible(el);
  });
}

function centauroSizes(doc) {
  return Array.from(doc.querySelectorAll('[data-testid="size-selector"] [role="radio"]')).filter(priceTestIsVisible);
}

function centauroSizeOnSale(size) {
  return size.getAttribute('aria-disabled') !== 'true' && !size.disabled;
}

// The first size on sale (the user's choice, 2026-10-30): prices don't
// change with the size.
async function centauroCheckProduct(doc, input) {
  const blocked = centauroBlocker(doc);
  if (blocked) return blocked;
  const seen = await priceTestWaitFor(function () {
    if (centauroOutOfStock(doc)) return 'out';
    if (centauroColorGone(doc)) return 'color';
    if (centauroSizes(doc).length) return 'sizes';
    return priceTestFindClickable(doc, /^comprar agora$/i) ? 'buy' : null;
  }, input.timeoutMs);
  if (!seen) return centauroBlocker(doc) || priceTestMissing('Comprar agora');
  if (seen === 'out') return { ok: false, code: 'OUT_OF_STOCK' };
  if (seen === 'color') return { ok: false, code: 'VARIATION_GONE' };
  if (seen === 'sizes') {
    const onSale = centauroSizes(doc).filter(centauroSizeOnSale);
    if (!onSale.length) return { ok: false, code: 'OUT_OF_STOCK' };
    if (!onSale.some(priceTestIsChosen)) {
      const chosen = await priceTestWaitFor(function () {
        const first = centauroSizes(doc).filter(centauroSizeOnSale)[0];
        if (!first) return null;
        if (priceTestIsChosen(first)) return true;
        priceTestClick(first);
        return priceTestIsChosen(first) || null;
      }, input.timeoutMs);
      if (!chosen) return priceTestMissing('tamanho');
      // The page takes the size in over a moment: a "Comprar agora" right
      // away was lost, and the cart opened empty (Nike Revolution 8,
      // 2026-11-01). Quiet for 400 ms, 3 s at most.
      await priceTestSettle(
        doc,
        function () {
          return false;
        },
        400,
        Math.min(3000, input.timeoutMs)
      );
    }
  }
  const result = { ok: true };
  const code = centauroProductCode(doc.defaultView.location.href) || centauroProductCode(input.url);
  if (code) result.remember = { productCode: code };
  return result;
}

async function centauroBuyNow(doc, input) {
  const blocked = centauroBlocker(doc);
  if (blocked) return blocked;
  const buy = await priceTestWaitFor(function () {
    return priceTestFindClickable(doc, /^comprar agora$/i);
  }, input.timeoutMs);
  if (!buy) return centauroOutOfStock(doc) ? { ok: false, code: 'OUT_OF_STOCK' } : priceTestMissing('Comprar agora');
  priceTestClickSoon(buy);
  return { ok: true, navigates: true };
}

// The order summary every checkout page has, with its total and action.
function centauroSummary(doc) {
  const summary = doc.querySelector('[data-testid="summary-action-content"]');
  return summary && priceTestIsVisible(summary) ? summary : null;
}

// "Continuar" on the cart and the delivery step ("Finalizar compra" on the
// payment step is never this).
function centauroContinue(doc) {
  const summary = centauroSummary(doc);
  const action = summary && summary.querySelector('[data-testid="summary-action"]');
  return action && !action.disabled && /^continuar$/i.test(priceTestLabelOf(action)) ? action : null;
}

function centauroCartItems(doc) {
  return Array.from(doc.querySelectorAll('[data-testid="product-cart-card"]'));
}

function centauroCartEmpty(doc) {
  return /carrinho est[aá] vazio/i.test(priceTestText(doc.body));
}

// The coupon box: its field, its button ("Adicionar", or "Remover" once a
// coupon is in) and the store's answer under it.
function centauroCoupon(doc) {
  const field = doc.querySelector('[data-testid="discount-coupon-input"]');
  const button = doc.querySelector('[data-testid="coupon-button"]');
  if (!field || !button) return null;
  const error = doc.getElementById('discount-coupon-error');
  return {
    field: field,
    button: button,
    applied: /^remover$/i.test(priceTestLabelOf(button)),
    refusal: error ? priceTestText(error) : '',
  };
}

function centauroSameCoupon(box, coupon) {
  return !!coupon && box.applied && box.field.value.trim().toUpperCase() === String(coupon).trim().toUpperCase();
}

// The cart, with only the deal's product (one unit): any other would count
// in the total. A coupon left in it from before goes, unless it's the deal's.
async function centauroCheckCart(doc, input) {
  const blocked = centauroBlocker(doc);
  if (blocked) return blocked;
  if (!centauroOnPage(doc, 'carrinho')) return Object.assign(await centauroGoTo(doc, 'checkouts/carrinho?newcheckout=true'), { repeat: true });
  const ready = await priceTestWaitFor(function () {
    if (centauroCartEmpty(doc)) return 'empty';
    return centauroSummary(doc) && centauroCartItems(doc).length && centauroCoupon(doc) ? true : null;
  }, input.timeoutMs);
  if (ready === 'empty') {
    return { ok: false, code: 'STEP_FAILED', detail: { message: 'o "Comprar agora" da Centauro não colocou o produto no carrinho: teste de novo' } };
  }
  if (!ready) return centauroBlocker(doc) || priceTestMissing('carrinho');
  const items = centauroCartItems(doc);
  const units = items.reduce(function (sum, item) {
    const quantity = item.querySelector('[data-testid="cart-quantity"]');
    return sum + (quantity ? Number(priceTestText(quantity)) || 1 : 1);
  }, 0);
  if (units > 1) {
    return { ok: false, code: 'STEP_FAILED', detail: { message: 'O carrinho da Centauro já tinha outros produtos: tire-os de lá e teste de novo' } };
  }
  const box = centauroCoupon(doc);
  if (!box.applied || centauroSameCoupon(box, input.coupon)) return { ok: true };
  priceTestClick(box.button);
  const cleared = await priceTestWaitFor(function () {
    const now = centauroCoupon(doc);
    return now && !now.applied ? true : null;
  }, input.timeoutMs);
  return cleared ? { ok: true } : priceTestMissing('Remover cupom');
}

// Centauro's coupons are in capitals; deals sometimes have them in small
// letters ("toma10").
async function centauroApplyCoupon(doc, input) {
  const blocked = centauroBlocker(doc);
  if (blocked) return blocked;
  const box = await priceTestWaitFor(function () {
    return centauroOnPage(doc, 'carrinho') ? centauroCoupon(doc) : null;
  }, input.timeoutMs);
  if (!box) return centauroBlocker(doc) || priceTestMissing('campo de cupom');
  if (centauroSameCoupon(box, input.coupon)) return { ok: true };
  priceTestType(box.field, String(input.coupon).trim().toUpperCase());
  const enabled = await priceTestWaitFor(function () {
    const now = centauroCoupon(doc);
    return now && !now.button.disabled ? now.button : null;
  }, input.timeoutMs);
  if (!enabled) return priceTestMissing('Adicionar cupom');
  priceTestClick(enabled);
  const answer = await priceTestWaitFor(function () {
    const now = centauroCoupon(doc);
    if (!now) return null;
    if (now.applied) return { ok: true };
    if (now.refusal) return { ok: true, couponRejected: now.refusal.slice(0, 160) };
    return null;
  }, input.timeoutMs);
  return answer || priceTestMissing('resposta do cupom');
}

// The delivery options of each package, but the store pickup ("Retirar na
// loja"), with the price written beside each.
function centauroDeliveryOptions(doc) {
  return Array.from(doc.querySelectorAll('[data-testid="deliveries-available"] input[type="radio"]'))
    .filter(function (radio) {
      return !/pickup|retir/i.test(radio.value + ' ' + (radio.getAttribute('aria-label') || '')) && !radio.disabled;
    })
    .map(function (radio) {
      const text = priceTestText(radio.closest('li') || radio.parentElement);
      return { radio: radio, cents: /gr[aá]tis/i.test(text) ? 0 : priceTestCents(text) };
    })
    .filter(function (option) {
      return option.cents !== null;
    });
}

// "Meus endereços", which the delivery step can open by itself with the
// checkout's address checked: the page underneath stays aria-hidden, and
// closing it doesn't stick, until an address is confirmed.
function centauroAddressModal(doc) {
  return (
    Array.from(doc.querySelectorAll('[role="dialog"]')).find(function (el) {
      const heading = el.querySelector('h1, h2, h3');
      return !!heading && /^meus endere[cç]os$/i.test(priceTestText(heading));
    }) || null
  );
}

// Its "Confirmar" keeps the address already checked: never another one.
// The click skips priceTestClick, whose guard refuses any "Confirmar" (an
// order's), on this one button only: the dialog's address-confirm-button.
async function centauroConfirmAddress(doc, input) {
  const modal = centauroAddressModal(doc);
  const checked = Array.from(modal.querySelectorAll('input[type="radio"]')).some(priceTestIsChosen);
  const confirm = modal.querySelector('[data-testid="address-confirm-button"]');
  if (!checked) return priceTestMissing('endereço marcado');
  if (!confirm || confirm.disabled) return priceTestMissing('Confirmar endereço');
  confirm.click();
  const closed = await priceTestWaitFor(function () {
    return centauroAddressModal(doc) ? null : true;
  }, input.timeoutMs);
  return closed ? { ok: true } : priceTestMissing('Confirmar endereço');
}

// From the cart and the delivery step (the cheapest delivery, never the
// pickup) on to the payment step.
async function centauroPickShipping(doc, input) {
  const blocked = centauroBlocker(doc);
  if (blocked) return blocked;
  if (centauroOnPage(doc, 'pagamento')) return { ok: true };
  if (centauroOnPage(doc, 'entrega')) {
    if (centauroAddressModal(doc)) {
      const confirmed = await centauroConfirmAddress(doc, input);
      if (!confirmed.ok) return confirmed;
    }
    const ready = await priceTestWaitFor(function () {
      return centauroDeliveryOptions(doc).length && centauroSummary(doc) ? true : null;
    }, input.timeoutMs);
    if (!ready) return centauroBlocker(doc) || priceTestMissing('opções de entrega');
    const groups = {};
    centauroDeliveryOptions(doc).forEach(function (option) {
      const name = option.radio.name;
      if (!groups[name] || option.cents < groups[name].cents) groups[name] = option;
    });
    Object.keys(groups).forEach(function (name) {
      if (!priceTestIsChosen(groups[name].radio)) priceTestClick(groups[name].radio);
    });
    const go = await priceTestWaitFor(function () {
      const chosen = Object.keys(groups).every(function (name) {
        return priceTestIsChosen(groups[name].radio);
      });
      return chosen ? centauroContinue(doc) : null;
    }, input.timeoutMs);
    if (!go) return priceTestMissing('frete escolhido');
    priceTestClickSoon(go);
    return { ok: true, navigates: true, repeat: true };
  }
  const go = await priceTestWaitFor(function () {
    return centauroContinue(doc);
  }, input.timeoutMs);
  if (!go) return centauroBlocker(doc) || priceTestMissing('Continuar');
  priceTestClickSoon(go);
  return { ok: true, navigates: true, repeat: true };
}

// The payment options are a listbox: Pix is the option selected.
function centauroPixOption(doc) {
  const option =
    doc.querySelector('[data-testid="payment-method-card-pix"]') ||
    Array.from(doc.querySelectorAll('[role="option"]')).find(function (el) {
      return /^pix\b/i.test(priceTestText(el));
    });
  return option && priceTestIsVisible(option) ? option : null;
}

function centauroPixChosen(doc) {
  const pix = centauroPixOption(doc);
  return !!pix && pix.getAttribute('aria-selected') === 'true';
}

async function centauroSelectPix(doc, input) {
  const blocked = centauroBlocker(doc);
  if (blocked) return blocked;
  const pix = await priceTestWaitFor(function () {
    return centauroOnPage(doc, 'pagamento') ? centauroPixOption(doc) : null;
  }, input.timeoutMs);
  if (!pix) return centauroBlocker(doc) || priceTestMissing('PIX');
  let tries = 0;
  let lastTry = 0;
  const chosen = await priceTestWaitFor(function () {
    if (centauroPixChosen(doc)) return true;
    if (tries < 4 && Date.now() - lastTry >= 2000) {
      const current = centauroPixOption(doc);
      if (current) priceTestClick(current);
      tries += 1;
      lastTry = Date.now();
    }
    return null;
  }, input.timeoutMs);
  return chosen ? { ok: true } : priceTestMissing('PIX selecionado');
}

// A summary row's value by its title ("Frete", "Cupom").
function centauroSummaryRow(summary, title) {
  const name = Array.from(summary.querySelectorAll('[title]')).find(function (el) {
    return el.getAttribute('title').toLowerCase() === title.toLowerCase();
  });
  if (!name) return null;
  const row = name.closest('li') || name.parentElement;
  return priceTestText(row).slice(priceTestText(name).length).trim();
}

// "Total R$ 39,98 no Pix", "Frete R$ 10,06" (no row while it is free).
function centauroValues(doc) {
  const summary = centauroSummary(doc);
  if (!summary) return null;
  const total = summary.querySelector('[data-testid="total-order"]');
  const text = total ? priceTestText(total) : '';
  const match = /(R\$\s*[\d.]+,\d{2})\s*no pix/i.exec(text);
  if (!match) return null;
  const shipping = centauroSummaryRow(summary, 'Frete');
  return {
    total: match[1].replace(/\s+/g, ' '),
    shipping: shipping ? shipping.replace(/\s+/g, ' ') : '',
    coupon: centauroSummaryRow(summary, 'Cupom') !== null,
  };
}

async function centauroReadTotals(doc, input) {
  const blocked = centauroBlocker(doc);
  if (blocked) return blocked;
  const found = await priceTestWaitFor(function () {
    const values = centauroOnPage(doc, 'pagamento') && centauroPixChosen(doc) ? centauroValues(doc) : null;
    return values && priceTestCents(values.total) > 0 ? values : null;
  }, input.timeoutMs);
  if (!found) return centauroBlocker(doc) || priceTestMissing('Total no Pix');
  const result = { ok: true, totalText: found.total, shippingText: found.shipping };
  if (input.coupon && found.coupon) result.couponApplied = true;
  return result;
}

// The summary on screen, for the picture.
async function centauroFrameTotals(doc, input) {
  const summary = await priceTestWaitFor(function () {
    return centauroSummary(doc);
  }, input.timeoutMs);
  if (!summary) return priceTestMissing('valores na tela');
  if (typeof summary.scrollIntoView === 'function') summary.scrollIntoView({ block: 'start' });
  await priceTestSettled(summary, Math.min(2000, input.timeoutMs));
  const box = summary.getBoundingClientRect();
  const margin = 8;
  return {
    ok: true,
    area: {
      x: Math.max(0, Math.floor(box.left - margin)),
      y: Math.max(0, Math.floor(box.top - margin)),
      width: Math.ceil(box.width + margin * 2),
      height: Math.max(1, Math.ceil(box.height + margin * 2)),
      viewportWidth: doc.defaultView.innerWidth,
    },
  };
}

function centauroOpenCart(doc) {
  return centauroGoTo(doc, 'checkouts/carrinho?newcheckout=true');
}

// The deal's product in the cart, by the code in its link.
function centauroCartItemOf(doc, code) {
  const pattern = new RegExp('-' + code + '\\.html', 'i');
  return (
    centauroCartItems(doc).find(function (item) {
      return Array.from(item.querySelectorAll('a[href]')).some(function (link) {
        return pattern.test(link.getAttribute('href'));
      });
    }) || null
  );
}

// Its trash button ("Diminuir a quantidade… em 1", one unit) takes it out,
// with no confirmation.
async function centauroRemoveFromCart(doc, input) {
  const blocked = centauroBlocker(doc);
  if (blocked) return blocked;
  if (!input.productCode) return priceTestMissing('código do produto');
  const ready = await priceTestWaitFor(function () {
    return centauroCartItems(doc).length || centauroCartEmpty(doc) ? true : null;
  }, input.timeoutMs);
  if (!ready) return priceTestMissing('carrinho');
  let presses = 0;
  let lastPress = 0;
  const gone = await priceTestWaitFor(function () {
    const item = centauroCartItemOf(doc, input.productCode);
    if (!item) return true;
    const remove = item.querySelector('[data-testid="remove-from-cart"]');
    if (remove && presses < 5 && Date.now() - lastPress >= 2000) {
      priceTestClick(remove);
      presses += 1;
      lastPress = Date.now();
    }
    return centauroCartItemOf(doc, input.productCode) ? null : true;
  }, input.timeoutMs);
  return gone ? { ok: true } : priceTestMissing('Remover produto');
}

// The steps pelandoPriceTestStep (page.js) runs here.
function pelandoPriceTestSteps() {
  return {
    checkProduct: centauroCheckProduct,
    buyNow: centauroBuyNow,
    checkCart: centauroCheckCart,
    applyCoupon: centauroApplyCoupon,
    pickShipping: centauroPickShipping,
    selectPix: centauroSelectPix,
    readTotals: centauroReadTotals,
    frameTotals: centauroFrameTotals,
    openCart: centauroOpenCart,
    removeFromCart: centauroRemoveFromCart,
  };
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = {
    centauroProductCode,
    centauroCheckProduct,
    centauroBuyNow,
    centauroCheckCart,
    centauroApplyCoupon,
    centauroPickShipping,
    centauroSelectPix,
    centauroReadTotals,
    centauroFrameTotals,
    centauroOpenCart,
    centauroRemoveFromCart,
    pelandoPriceTestSteps,
  };
}
