// "Testar Promoção": the steps on AliExpress's pages, injected after compare.js
// and page.js (which has the helpers and pelandoPriceTestStep). Product page
// (/item/<id>.html: the variations already chosen, else the first on sale)
// → "Comprar", which opens the checkout (/p/trade/confirm.html) without
// touching the cart → the coupon box in the summary → Pix → the total. The
// checkout's order button ("Fazer o pedido", "Confirmar compra" once Pix is
// chosen) is never clicked.
//
// AliExpress's class names carry a hash (sku-item--selected--ITGY_EO): they
// are matched by their readable part only. Seen 2026-11-01.

function aliexpressOnCheckout(doc) {
  return /^\/p\/trade\/confirm\.html$/i.test(doc.defaultView.location.pathname);
}

function aliexpressOnItem(doc) {
  return /^\/item\/\d+\.html$/i.test(doc.defaultView.location.pathname);
}

// The product's id: /item/<id>.html, or the coins page's productIds=<id>.
function aliexpressProductId(url) {
  const match = /\/item\/(\d+)\.html/i.exec(String(url || '')) || /[?&]productIds=(\d+)/i.exec(String(url || ''));
  return match ? match[1] : null;
}

// A deal's "LOJA+AEMEGA6": the store's code and AliExpress's, both applied.
function aliexpressCoupons(coupon) {
  return String(coupon || '')
    .split(/[+,\s]+/)
    .map(function (code) {
      return code.trim().toUpperCase();
    })
    .filter(Boolean);
}

// AliExpress's own stop on top of the common ones: its "We need to check if
// you are a robot" dialog (baxia), over the page, after many pages in a row.
function aliexpressBlocker(doc) {
  const blocked = priceTestBlocker(doc);
  if (blocked) return blocked;
  if (/_____tmd_____|\/punish/i.test(doc.defaultView.location.pathname)) return { ok: false, code: 'NEEDS_HUMAN' };
  const dialog = doc.querySelector('.baxia-dialog, #baxia-dialog-content, iframe[src*="_____tmd_____"], iframe[src*="/punish"]');
  if (dialog && priceTestIsVisible(dialog)) return { ok: false, code: 'NEEDS_HUMAN' };
  return null;
}

function aliexpressGoTo(doc, url) {
  priceTestSoon(function () {
    doc.defaultView.location.assign(url);
  });
  return Promise.resolve({ ok: true, navigates: true, repeat: true });
}

// "Comprar", or "Comprar na pré-venda" on a product not out yet (same
// checkout, full price; seen on the Kobra X 2026-11-01).
function aliexpressBuyButton(doc) {
  return (
    Array.from(doc.querySelectorAll('button')).find(function (button) {
      return /^comprar( agora| na pr[eé]-venda)?$/i.test(priceTestLabelOf(button)) && priceTestIsVisible(button);
    }) || null
  );
}

// The variations, one row per property (color, plug, "Envio de").
function aliexpressSkuRows(doc) {
  return Array.from(doc.querySelectorAll('[data-sku-row]')).map(function (row) {
    return Array.from(row.querySelectorAll('[data-sku-col]'));
  });
}

function aliexpressSkuChosen(col) {
  return /--selected--/.test(col.className);
}

function aliexpressSkuOnSale(col) {
  return !/--soldOut--|--disabled--/i.test(col.className);
}

function aliexpressGone(doc) {
  return /(produto|item) (n[aã]o est[aá] mais dispon[ií]vel|est[aá] esgotado|indispon[ií]vel)/i.test(priceTestText(doc.body).slice(0, 4000));
}

// The variations already chosen stay; a row with none chosen (or a chosen
// one sold out) gets its first on sale (the user's rule, 2026-11-01). The
// deal's link can be the coins page (m.aliexpress.com/p/coin-index): it goes
// to the product's own page first.
async function aliexpressCheckProduct(doc, input) {
  const blocked = aliexpressBlocker(doc);
  if (blocked) return blocked;
  if (!aliexpressOnItem(doc)) {
    const id = aliexpressProductId(doc.defaultView.location.href) || aliexpressProductId(input.url);
    if (id) return aliexpressGoTo(doc, 'https://pt.aliexpress.com/item/' + id + '.html');
    return { ok: false, code: 'NOT_PRODUCT' };
  }
  // A product taken down shows "Este item não está mais disponível" and no
  // buy button at all (seen 2026-11-01): no use waiting for one.
  const buy = await priceTestWaitFor(function () {
    return aliexpressBuyButton(doc) || (aliexpressGone(doc) ? 'gone' : null);
  }, input.timeoutMs);
  if (buy === 'gone') return { ok: false, code: 'OUT_OF_STOCK' };
  if (!buy) return aliexpressBlocker(doc) || priceTestMissing('Comprar');
  if (buy.disabled) return { ok: false, code: 'OUT_OF_STOCK' };
  const rows = aliexpressSkuRows(doc);
  if (rows.some(function (cols) {
    return cols.length && !cols.some(aliexpressSkuOnSale);
  })) {
    return { ok: false, code: 'OUT_OF_STOCK' };
  }
  let lastClick = 0;
  const chosen = await priceTestWaitFor(function () {
    const open = aliexpressSkuRows(doc).find(function (cols) {
      return cols.length && !cols.some(function (col) {
        return aliexpressSkuChosen(col) && aliexpressSkuOnSale(col);
      });
    });
    if (!open) return true;
    const first = open.find(aliexpressSkuOnSale);
    if (!first) return 'out';
    if (Date.now() - lastClick >= 1500) {
      priceTestClick(first);
      lastClick = Date.now();
    }
    return null;
  }, input.timeoutMs);
  if (chosen === 'out') return { ok: false, code: 'OUT_OF_STOCK' };
  if (!chosen) return priceTestMissing('variação');
  const now = aliexpressBuyButton(doc);
  if (now && now.disabled) return { ok: false, code: 'OUT_OF_STOCK' };
  const result = { ok: true };
  const id = aliexpressProductId(doc.defaultView.location.href) || aliexpressProductId(input.url);
  if (id) result.remember = { productId: id };
  return result;
}

async function aliexpressBuyNow(doc, input) {
  const blocked = aliexpressBlocker(doc);
  if (blocked) return blocked;
  const buy = await priceTestWaitFor(function () {
    const button = aliexpressBuyButton(doc);
    return button && !button.disabled ? button : null;
  }, input.timeoutMs);
  if (!buy) return priceTestMissing('Comprar');
  priceTestClickSoon(buy);
  return { ok: true, navigates: true };
}

// A summary row by its title ("Frete", "Cupom de desconto").
function aliexpressSummaryRow(doc, title) {
  return (
    Array.from(doc.querySelectorAll('.pl-summary-container [class*="pl-summary__item-pc"]')).find(function (row) {
      const name = row.querySelector('[data-pl="pl-summary-title"]');
      return !!name && priceTestText(name).toLowerCase() === title.toLowerCase();
    }) || null
  );
}

function aliexpressSummaryValue(doc, title) {
  const row = aliexpressSummaryRow(doc, title);
  const value = row && row.querySelector('[data-pl="pl-summary-content"]');
  return value ? value.textContent.replace(/\s+/g, ' ').trim() : null;
}

// "R$62,37", written one character per span.
function aliexpressTotalText(doc) {
  const item = Array.from(doc.querySelectorAll('[class*="pl-order-toal-container__item"]')).find(function (el) {
    const title = el.querySelector('[class*="item-title"]');
    return !!title && /^total$/i.test(priceTestText(title));
  });
  const value = item && item.querySelector('[class*="item-content"]');
  return value ? value.textContent.replace(/\s+/g, '') : null;
}

function aliexpressTotalCents(doc) {
  return priceTestCents(aliexpressTotalText(doc));
}

function aliexpressCheckoutReady(doc) {
  return aliexpressOnCheckout(doc) && !!doc.querySelector('.pl-summary-container') && aliexpressTotalCents(doc) !== null;
}

function aliexpressCouponField(doc) {
  const field = doc.querySelector('.pl-promoCode-input');
  return field && priceTestIsVisible(field) ? field : null;
}

function aliexpressToastText(doc) {
  return Array.from(doc.querySelectorAll('.comet-toast-wrap'))
    .filter(priceTestIsVisible)
    .map(priceTestText)
    .filter(Boolean)
    .join(' ');
}

function aliexpressCouponError(doc) {
  const tip = Array.from(doc.querySelectorAll('.promoErrorTip')).find(priceTestIsVisible);
  return tip ? priceTestText(tip) : '';
}

// One code: the coupon row opens the box (a second click closes it, so it
// is clicked only while the box is shut). The store answers in a toast
// ("Parabéns, você acabou de conseguir um grande desconto.", "Você já usou
// este cupom") or under the box ("Este cupom não pode ser aplicado...");
// some codes get no answer at all (seen with AEMEGA2 on a R$ 109 order):
// then the total says whether it took.
async function aliexpressApplyOne(doc, code, input) {
  let lastToggle = 0;
  const field = await priceTestWaitFor(function () {
    const open = aliexpressCouponField(doc);
    if (open) return open;
    const row = aliexpressSummaryRow(doc, 'Cupom de desconto');
    const toggle = row && row.querySelector('[class*="pl-summary__item-content-wrapper"]');
    if (toggle && Date.now() - lastToggle >= 1500) {
      priceTestClick(toggle);
      lastToggle = Date.now();
    }
    return null;
  }, input.timeoutMs);
  if (!field) return { ok: false, result: aliexpressBlocker(doc) || priceTestMissing('campo de cupom') };
  // A toast left from the code before would read as this one's answer.
  await priceTestWaitFor(function () {
    return aliexpressToastText(doc) ? null : true;
  }, Math.min(6000, input.timeoutMs));
  priceTestType(field, code);
  const apply = await priceTestWaitFor(function () {
    const button = doc.querySelector('.pl-promoCode-input-button');
    return button && !button.disabled ? button : null;
  }, input.timeoutMs);
  if (!apply) return { ok: false, result: priceTestMissing('Aplicar cupom') };
  const totalBefore = aliexpressTotalCents(doc);
  const errorBefore = aliexpressCouponError(doc);
  priceTestClick(apply);
  const answer = await priceTestWaitFor(function () {
    const toast = aliexpressToastText(doc);
    if (/parab[eé]ns|cupom aplicado|aplicado com sucesso/i.test(toast)) return { applied: true };
    if (toast) return { refusal: toast };
    const error = aliexpressCouponError(doc);
    if (error && error !== errorBefore) return { refusal: error };
    return null;
  }, Math.min(8000, input.timeoutMs));
  if (answer) return { ok: true, applied: !!answer.applied, refusal: answer.refusal };
  const totalAfter = aliexpressTotalCents(doc);
  if (totalBefore !== null && totalAfter !== null && totalAfter < totalBefore) return { ok: true, applied: true };
  return { ok: true, applied: false, refusal: 'o AliExpress não respondeu e o total não mudou (o cupom pode pedir um valor mínimo de compra)' };
}

// The checkout's own error when a code goes in before the page has finished
// setting the order up (seen 2026-11-01 under 1 s after it opened): the
// same code a moment later gets the real answer.
function aliexpressCouponNotReady(refusal) {
  return /operator failed|system error|erro do sistema|tente novamente/i.test(refusal || '');
}

// Once the account has taken a code, AliExpress keeps it and puts it in
// later orders by itself (seen 2026-11-01: BRMVP4 answered this with the
// deal's total already on screen).
function aliexpressRefusalText(refusal) {
  if (/j[aá] usou este cupom/i.test(refusal)) {
    return refusal + ' (o AliExpress já tinha este cupom na conta: se ele ainda vale, o desconto já está no total)';
  }
  return refusal;
}

async function aliexpressApplyCoupon(doc, input) {
  const blocked = aliexpressBlocker(doc);
  if (blocked) return blocked;
  const ready = await priceTestWaitFor(function () {
    return aliexpressCheckoutReady(doc);
  }, input.timeoutMs);
  if (!ready) return aliexpressBlocker(doc) || priceTestMissing('resumo do pedido');
  await priceTestSettle(
    doc,
    function () {
      return false;
    },
    1500,
    Math.min(8000, input.timeoutMs)
  );
  const retryMs = input.retryMs === undefined ? 2000 : input.retryMs;
  const codes = aliexpressCoupons(input.coupon);
  const refusals = [];
  for (const code of codes) {
    let one = null;
    for (let attempt = 0; attempt < 3; attempt++) {
      if (attempt) {
        await new Promise(function (resolve) {
          setTimeout(resolve, retryMs);
        });
      }
      one = await aliexpressApplyOne(doc, code, input);
      if (!one.ok) return one.result;
      if (one.applied || !aliexpressCouponNotReady(one.refusal)) break;
    }
    if (!one.applied) {
      const refusal = aliexpressRefusalText(one.refusal);
      refusals.push(codes.length > 1 ? code + ': ' + refusal : refusal);
    }
  }
  return refusals.length ? { ok: true, couponRejected: refusals.join('; ').slice(0, 300) } : { ok: true };
}

// The method shown as chosen, outside the list ("Pix" and "mudança").
function aliexpressChosenMethod(doc) {
  const chosen = Array.from(doc.querySelectorAll('[class*="chosen-channel-title"]')).find(priceTestIsVisible);
  return chosen ? priceTestText(chosen) : '';
}

function aliexpressPixChosen(doc) {
  return /^pix$/i.test(aliexpressChosenMethod(doc));
}

function aliexpressPaymentModal(doc) {
  const modal = doc.querySelector('.payment-main-container');
  return modal && priceTestIsVisible(modal) ? modal : null;
}

// Pix's row in a list of methods: its radio's label is what takes the click.
function aliexpressPixRow(root) {
  const title = Array.from(root.querySelectorAll('[data-pl="payment-method-title"]')).find(function (el) {
    return /^pix$/i.test(priceTestText(el)) && priceTestIsVisible(el);
  });
  return title ? title.closest('[class*="radio-item--item-row"]') : null;
}

// "Veja mais" over the short list, or "mudança" beside another method chosen.
function aliexpressMoreMethods(doc) {
  const more = Array.from(doc.querySelectorAll('.placeorder-page-payment-container [class*="fold-title"]')).find(priceTestIsVisible);
  if (more) return more;
  return Array.from(doc.querySelectorAll('.placeorder-page-payment-container [class*="chosen-channel-change"] button')).find(priceTestIsVisible) || null;
}

// Pix is chosen in the short list, or in the "Veja mais" dialog, which keeps
// it only after its own "Confirmar". That button confirms the method, not
// the order: the click skips priceTestClick, whose guard refuses any
// "Confirmar", on the dialog's payment-confirm-btn only.
async function aliexpressSelectPix(doc, input) {
  const blocked = aliexpressBlocker(doc);
  if (blocked) return blocked;
  const ready = await priceTestWaitFor(function () {
    return aliexpressCheckoutReady(doc) && doc.querySelector('.placeorder-page-payment-container');
  }, input.timeoutMs);
  if (!ready) return aliexpressBlocker(doc) || priceTestMissing('métodos de pagamento');
  let last = '';
  let lastAt = 0;
  function act(kind, fn) {
    if (kind === last && Date.now() - lastAt < 1500) return;
    last = kind;
    lastAt = Date.now();
    fn();
  }
  const chosen = await priceTestWaitFor(function () {
    if (aliexpressPixChosen(doc)) return true;
    const modal = aliexpressPaymentModal(doc);
    if (modal) {
      const row = aliexpressPixRow(modal);
      if (!row) return null;
      const radio = row.querySelector('input[type="radio"]');
      if (radio && radio.checked) {
        const confirm = modal.querySelector('[class*="payment-confirm-btn"]');
        if (confirm && /^confirmar$/i.test(priceTestLabelOf(confirm))) {
          act('confirm', function () {
            confirm.click();
          });
        }
      } else {
        act('pix', function () {
          priceTestClick(row.querySelector('label') || row);
        });
      }
      return null;
    }
    const inline = aliexpressPixRow(doc.querySelector('.placeorder-page-payment-container'));
    if (inline) {
      act('inline', function () {
        priceTestClick(inline.querySelector('label') || inline);
      });
      const radio = inline.querySelector('input[type="radio"]');
      return radio && radio.checked ? true : null;
    }
    const more = aliexpressMoreMethods(doc);
    if (more) {
      act('more', function () {
        priceTestClick(more);
      });
    }
    return null;
  }, input.timeoutMs);
  return chosen ? { ok: true } : aliexpressBlocker(doc) || priceTestMissing('PIX selecionado');
}

// The total (taxes in: the deals' prices count them) with Pix chosen, once
// the page stops recomputing it after the change of method.
async function aliexpressReadTotals(doc, input) {
  const blocked = aliexpressBlocker(doc);
  if (blocked) return blocked;
  await priceTestSettle(
    doc,
    function () {
      return false;
    },
    800,
    Math.min(3000, input.timeoutMs)
  );
  const found = await priceTestWaitFor(function () {
    if (!aliexpressCheckoutReady(doc) || !aliexpressPixChosen(doc)) return null;
    const total = aliexpressTotalText(doc);
    return priceTestCents(total) > 0 ? total : null;
  }, input.timeoutMs);
  if (!found) return aliexpressBlocker(doc) || priceTestMissing('Total no Pix');
  return { ok: true, totalText: found, shippingText: aliexpressSummaryValue(doc, 'Frete') || '' };
}

// The summary and the total, for the picture.
async function aliexpressFrameTotals(doc, input) {
  const summary = await priceTestWaitFor(function () {
    return doc.querySelector('.pl-summary-container');
  }, input.timeoutMs);
  if (!summary) return priceTestMissing('valores na tela');
  const total = doc.querySelector('[class*="pl-order-toal-container__item"]') || summary;
  if (typeof summary.scrollIntoView === 'function') summary.scrollIntoView({ block: 'start' });
  await priceTestSettled(summary, Math.min(2000, input.timeoutMs));
  const a = summary.getBoundingClientRect();
  const b = total.getBoundingClientRect();
  const left = Math.min(a.left, b.left);
  const top = Math.min(a.top, b.top);
  const right = Math.max(a.right, b.right);
  const bottom = Math.max(a.bottom, b.bottom);
  const margin = 8;
  return {
    ok: true,
    area: {
      x: Math.max(0, Math.floor(left - margin)),
      y: Math.max(0, Math.floor(top - margin)),
      width: Math.ceil(right - left + margin * 2),
      height: Math.max(1, Math.ceil(bottom - top + margin * 2)),
      viewportWidth: doc.defaultView.innerWidth,
    },
  };
}

// The steps pelandoPriceTestStep (page.js) runs here.
function pelandoPriceTestSteps() {
  return {
    checkProduct: aliexpressCheckProduct,
    buyNow: aliexpressBuyNow,
    applyCoupon: aliexpressApplyCoupon,
    selectPix: aliexpressSelectPix,
    readTotals: aliexpressReadTotals,
    frameTotals: aliexpressFrameTotals,
  };
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = {
    aliexpressProductId,
    aliexpressCoupons,
    aliexpressCheckProduct,
    aliexpressBuyNow,
    aliexpressApplyCoupon,
    aliexpressSelectPix,
    aliexpressReadTotals,
    aliexpressFrameTotals,
    pelandoPriceTestSteps,
  };
}
