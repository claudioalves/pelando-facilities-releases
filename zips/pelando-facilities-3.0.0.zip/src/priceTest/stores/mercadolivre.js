// "Testar Promoção": the steps on Mercado Livre's pages, injected after
// compare.js and page.js (which has the helpers and pelandoPriceTestStep).
// Product page → "Comprar agora" → sometimes an extended warranty offer → a
// one-page checkout (/checkout/review/onestep) with shipping, payment, coupon
// and the summary together; Pix may hide behind "Mostrar todos", a page of its
// own. "Comprar agora" leaves the product in the cart: the cleanup steps take
// it out once the values are read.
//
// Elements are found by visible text and role, as on Magalu. Amounts are the
// exception: Mercado Livre writes them as separate pieces ("R$", "48", ",",
// "77") with the old price struck through (<s>) beside the current one, so
// they are read from the amount's aria-label ("48 reais com 77 centavos").

// Text a person sees, matched in the page (not in scripts or hidden parts).
function mlShows(doc, pattern) {
  return priceTestTextNodes(doc.body).some(function (node) {
    return pattern.test(node.nodeValue) && priceTestIsVisible(node.parentElement);
  });
}

// Cents of one amount element, from its aria-label: "48 reais com 77
// centavos", "-8 reais com 78 centavos", "107 reais", "1.299 reais".
function mlAmountCents(el) {
  const label = (el.getAttribute('aria-label') || '').replace(/^antes:\s*/i, '');
  const match = /(-?)\s*([\d.]+)\s*rea(?:l|is)(?:\s*com\s*(\d{1,2})\s*centavos?)?/i.exec(label);
  if (match) {
    const cents = Number(match[2].replace(/\./g, '')) * 100 + Number(match[3] || 0);
    return match[1] ? -cents : cents;
  }
  // Without the label, the text: "R$ 48 , 77" or "R$ 107".
  const text = priceTestText(el).replace(/\s*,\s*/g, ',');
  const cents = priceTestCents(/,\d{2}\b/.test(text) ? text : text.replace(/(\d)(?!.*\d)/, '$1,00'));
  return cents;
}

// The amounts inside el a buyer pays now: not the old price struck through.
function mlCurrentAmounts(el) {
  return Array.from(el.querySelectorAll('[aria-label*="rea" i], [class*="money-amount"]')).filter(function (amount) {
    if (amount.closest('s, del')) return false;
    // Only the outermost amount element: its parts are amounts' children.
    if (amount.parentElement && amount.parentElement.closest('[class*="money-amount"]')) return false;
    return /rea(l|is)\b/i.test(amount.getAttribute('aria-label') || '') || /R\$/.test(priceTestText(amount));
  });
}

// "R$ 48,77" for the last current amount inside el, or "Grátis" when el
// says so and has none: what runner.js reads.
function mlAmountText(el) {
  const amounts = mlCurrentAmounts(el).filter(priceTestIsVisible);
  if (!amounts.length) return /gr[aá]tis/i.test(priceTestText(el)) ? 'Grátis' : null;
  const cents = mlAmountCents(amounts[amounts.length - 1]);
  return cents === null ? null : priceTestFormat(cents);
}

// The listing the deal links to: "wid=MLB123" (in the fragment of catalog
// links) or "item_id:MLB123" in pdp_filters.
function mlWantedItem(url) {
  const match = /(?:[?#&]wid=|item_id(?:%3A|:|=))(MLB\d+)/i.exec(String(url || ''));
  return match ? match[1].toUpperCase() : null;
}

// The product page's own "out of stock" sentences, and the one for a product
// it doesn't deliver to the account's address ("não podemos enviar este
// produto para sua localização atual", with its buttons off).
function mlOutOfStock(doc) {
  return mlShows(
    doc,
    /produto est[aá] indispon[ií]vel|publica[cç][aã]o (est[aá] )?pausada|an[uú]ncio (est[aá] )?pausado|sem estoque|estoque esgotado|n[aã]o podemos enviar este produto/i
  );
}

// A variation still to choose: its title reads "Tamanho: Escolha". The
// options are the buttons next to it; the ones sold out say so in their
// aria-label ("Disponível em outras opções") or are marked disabled.
function mlLooseVariation(doc) {
  const title = Array.from(doc.querySelectorAll('p, span, div, label')).find(function (el) {
    return el.children.length <= 3 && /^[^:]{1,40}:\s*escolha$/i.test(priceTestText(el)) && priceTestIsVisible(el);
  });
  if (!title) return null;
  const name = priceTestText(title).replace(/:.*$/, '');
  for (let box = title.parentElement; box && box !== title.ownerDocument.body; box = box.parentElement) {
    // A box holding another variation's title ("Comprimento do cabo: 2 m")
    // is past this one: its options aren't ours. "Voltagem: Escolha" can
    // come with nothing to pick.
    const other = Array.from(box.querySelectorAll('p, span, div, label')).some(function (el) {
      return el !== title && !el.contains(title) && !title.contains(el) && el.children.length <= 3 && /^[^:]{1,40}:\s*\S/.test(priceTestText(el));
    });
    if (other) return { name: name, options: [] };
    const options = Array.from(box.querySelectorAll('a[role="button"], button, [role="radio"], [role="option"]')).filter(priceTestIsVisible);
    if (options.length) return { name: name, options: options };
  }
  return null;
}

function mlOptionOnSale(option) {
  const label = option.getAttribute('aria-label') || '';
  return (
    option.getAttribute('aria-disabled') !== 'true' &&
    !option.disabled &&
    !/--disabled\b/i.test(String(option.className)) &&
    !/dispon[ií]vel em outras|indispon[ií]vel|esgotad/i.test(label)
  );
}

// The offer list of a catalog product (/p/MLB.../s): one form per seller,
// with its listing's id.
function mlOfferForm(doc, item) {
  const field = Array.from(doc.querySelectorAll('form input[name="item_id"]')).find(function (input) {
    return String(input.value).toUpperCase() === item;
  });
  return field ? field.closest('form') : null;
}

function mlOnOfferList(doc) {
  return doc.querySelectorAll('form input[name="item_id"]').length > 0 && /\/p\/MLB\d+\/s\b/i.test(doc.defaultView.location.pathname);
}

// Once per page: the step runs again (runner.js) after each variation picked
// or after opening the offer list, until "Comprar agora" can be clicked.
async function mlCheckProduct(doc, input) {
  const blocked = priceTestBlocker(doc);
  if (blocked) return blocked;
  if (/\/social\//i.test(doc.defaultView.location.pathname)) return { ok: false, code: 'NOT_PRODUCT' };
  const item = mlWantedItem(input.url);
  if (mlOnOfferList(doc)) {
    if (item && mlOfferForm(doc, item)) return { ok: true };
    return { ok: false, code: item ? 'OFFER_GONE' : 'NO_SELLER' };
  }
  const seen = await priceTestWaitFor(function () {
    if (mlOutOfStock(doc)) return 'out';
    // Until a size is picked the button reads "Comprar agora. Escolha
    // Tamanho para continuar com sua compra.".
    const loose = mlLooseVariation(doc);
    if (loose && loose.options.length) return 'loose';
    // "Comprar agora. Escolha Voltagem..." with no voltage to pick.
    if (loose && priceTestFindClickable(doc, /^comprar agora\b.*\bescolha\b/i)) return 'nothing to choose';
    if (priceTestFindClickable(doc, /^comprar agora$/i)) return 'buy';
    if (priceTestFindClickable(doc, /^ver op[cç][oõ]es de compra$/i)) return 'options';
    if (priceTestFindClickable(doc, /^adicionar ao carrinho$/i)) return 'cart';
    return null;
  }, input.timeoutMs);
  if (!seen) return priceTestBlocker(doc) || priceTestMissing('Comprar agora');
  if (seen === 'out') return { ok: false, code: 'OUT_OF_STOCK' };
  const loose = mlLooseVariation(doc);
  if (seen === 'nothing to choose') return { ok: false, code: 'NO_CHOICE', detail: { name: loose ? loose.name : '' } };
  if (loose && loose.options.length) {
    const first = loose.options.find(mlOptionOnSale);
    if (!first) return { ok: false, code: 'OUT_OF_STOCK' };
    priceTestClickSoon(first);
    return { ok: true, navigates: true, repeat: true };
  }
  if (seen === 'options') {
    if (!item) return { ok: false, code: 'NO_SELLER' };
    priceTestClickSoon(priceTestFindClickable(doc, /^ver op[cç][oõ]es de compra$/i));
    return { ok: true, navigates: true, repeat: true };
  }
  // Supermarket products ("Full Super") are sold only through the cart.
  if (seen === 'cart') return { ok: false, code: 'SUPERMARKET' };
  return { ok: true };
}

async function mlBuyNow(doc, input) {
  const blocked = priceTestBlocker(doc);
  if (blocked) return blocked;
  const item = mlWantedItem(input.url);
  const form = item && mlOnOfferList(doc) ? mlOfferForm(doc, item) : null;
  const scope = form || doc;
  const buy = Array.from(scope.querySelectorAll('button, a, [role="button"], input[type="submit"]')).find(function (el) {
    return !el.disabled && priceTestIsVisible(el) && /^comprar agora$/i.test(priceTestLabelOf(el));
  });
  if (!buy) return mlOutOfStock(doc) ? { ok: false, code: 'OUT_OF_STOCK' } : priceTestMissing('Comprar agora');
  // The cleanup looks for the product in the cart by its title: known from
  // here, even when the test stops before the checkout's summary.
  const heading = doc.querySelector('h1');
  const title = heading ? priceTestText(heading) : '';
  priceTestClickSoon(buy);
  return title ? { ok: true, navigates: true, remember: { title: title } } : { ok: true, navigates: true };
}

// The one-page checkout has shown up: shipping, payment or the summary.
function mlOnCheckout(doc) {
  return mlShippingOptions(doc).length > 0 || mlPaymentRadios(doc).length > 0 || !!mlSummary(doc);
}

// "Esta compra não pode ser enviada para os seus endereços salvos": the
// checkout asks for another address.
function mlNoDelivery(doc) {
  return priceTestTextNodes(doc.body).some(function (node) {
    return /n[aã]o pode ser enviad[ao] para (os )?seus endere[cç]os/i.test(node.nodeValue) && priceTestIsVisible(node.parentElement);
  });
}

// Electronics get an extended warranty offer ("Adicione um seguro") first:
// always "Agora não", never "Adicionar".
async function mlSkipProtection(doc, input) {
  const blocked = priceTestBlocker(doc);
  if (blocked) return blocked;
  const seen = await priceTestWaitFor(function () {
    if (mlNoDelivery(doc)) return { nowhere: true };
    const decline = priceTestFindClickable(doc, /^agora n[aã]o$/i);
    if (decline) return { decline: decline };
    return mlOnCheckout(doc) || mlOnPaymentList(doc) ? { decline: null } : null;
  }, input.timeoutMs);
  if (!seen) return priceTestBlocker(doc) || priceTestMissing('checkout');
  if (seen.nowhere) return { ok: false, code: 'NO_DELIVERY' };
  if (!seen.decline) return { ok: true };
  // A click before the page is ready does nothing: the step runs again
  // (runner.js) and clicks once more while the offer stays.
  priceTestClickSoon(seen.decline);
  return { ok: true, navigates: true, repeat: true };
}

// The row of a radio: the largest box around it holding no other radio.
function mlRadioRow(radio) {
  let row = radio;
  while (row.parentElement && row.parentElement.querySelectorAll('input[type="radio"], [role="radio"]').length === 1) row = row.parentElement;
  return row;
}

function mlRadioLabel(doc, radio) {
  const byFor = radio.id && Array.from(doc.querySelectorAll('label')).find(function (label) {
    return label.htmlFor === radio.id;
  });
  return byFor ? priceTestText(byFor) : priceTestText(mlRadioRow(radio));
}

// Chooses an option the way a person does, on its label: a click on the
// hidden radio itself checks it without the page noticing (the summary
// keeps the old price).
function mlChoose(doc, radio) {
  const label = radio.id && Array.from(doc.querySelectorAll('label')).find(function (el) {
    return el.htmlFor === radio.id;
  });
  priceTestClick(label || radio);
}

// "Frete" or "Retirada": the switch above the delivery options.
function mlDeliveryModes(doc) {
  return Array.from(doc.querySelectorAll('input[type="radio"]'))
    .map(function (radio) {
      return { radio: radio, text: mlRadioLabel(doc, radio) };
    })
    .filter(function (mode) {
      return /^(frete|retirada)\b/i.test(mode.text) && mode.text.length <= 40;
    });
}

// Delivery choices: radios whose row tells when it arrives ("Chegará...")
// and its price or "Grátis". Rows the store greys out don't count.
function mlShippingOptions(doc) {
  return Array.from(doc.querySelectorAll('input[type="radio"]'))
    .map(function (radio) {
      const row = mlRadioRow(radio);
      return { radio: radio, row: row, text: priceTestText(row) };
    })
    .filter(function (option) {
      return /chegar|receb|entreg/i.test(option.text) && /gr[aá]tis|R\$/i.test(option.text) && priceTestIsVisible(option.row);
    })
    .map(function (option) {
      const amount = mlAmountText(option.row);
      option.cents = amount === 'Grátis' ? 0 : priceTestCents(amount);
      option.disabled = option.radio.disabled || /--disabled\b/i.test(String(option.row.className)) || option.row.getAttribute('aria-disabled') === 'true';
      return option;
    });
}

// The summary box ("Resumo da compra"), loaded: its skeleton gone.
function mlSummary(doc) {
  const heading = Array.from(doc.querySelectorAll('h1, h2, h3, [role="heading"], span, p')).find(function (el) {
    return /^resumo da compra$/i.test(priceTestText(el)) && priceTestIsVisible(el);
  });
  if (!heading) return null;
  for (let box = heading.parentElement; box && box !== doc.body; box = box.parentElement) {
    if (/\btotal\b/i.test(priceTestText(box)) && mlCurrentAmounts(box).length) return box;
  }
  return null;
}

// The summary is recalculating (its "Carregando..." skeleton shows).
function mlSummaryLoading(doc) {
  return Array.from(doc.querySelectorAll('[role="status"], [aria-busy="true"]')).some(function (el) {
    return (el.getAttribute('aria-busy') === 'true' || /carregando|cargando|loading/i.test(el.getAttribute('aria-label') || '')) && priceTestIsVisible(el);
  });
}

// The summary row starting with the label: the smallest box whose text
// starts with it and holds an amount (or "Grátis").
function mlSummaryRow(summary, label) {
  const rows = Array.from(summary.querySelectorAll('*')).filter(function (el) {
    const text = priceTestText(el);
    return text.length <= 120 && label.test(text) && (mlCurrentAmounts(el).length > 0 || /gr[aá]tis/i.test(text)) && priceTestIsVisible(el);
  });
  return (
    rows.find(function (el) {
      return !rows.some(function (other) {
        return other !== el && el.contains(other);
      });
    }) || null
  );
}

async function mlPickShipping(doc, input) {
  const blocked = priceTestBlocker(doc);
  if (blocked) return blocked;
  // The summary can come before the delivery options: give them a moment.
  // Some products have no choice to make (one way, already chosen).
  const options = await priceTestWaitFor(function () {
    return mlShippingOptions(doc).length ? true : null;
  }, Math.min(6000, input.timeoutMs));
  const ready =
    options ||
    (await priceTestWaitFor(function () {
      return mlSummary(doc) ? true : null;
    }, input.timeoutMs));
  if (!ready) return priceTestBlocker(doc) || priceTestMissing('opções de frete');
  // Always delivery to the account's address, never pickup.
  const modes = mlDeliveryModes(doc);
  const delivery = modes.find(function (mode) {
    return /^frete\b/i.test(mode.text);
  });
  if (delivery && !priceTestIsChosen(delivery.radio)) {
    mlChoose(doc, delivery.radio);
    await priceTestWaitFor(function () {
      return priceTestIsChosen(delivery.radio) && mlShippingOptions(doc).length ? true : null;
    }, input.timeoutMs);
  }
  // The cheapest delivery of each shipment ("Envio 1", "Envio 2"...).
  const groups = {};
  mlShippingOptions(doc).forEach(function (option) {
    if (option.disabled || option.cents === null) return;
    const name = option.radio.name || '';
    if (!groups[name] || option.cents < groups[name].cents) groups[name] = option;
  });
  const names = Object.keys(groups);
  if (!names.length) return { ok: true };
  const wanted = names.reduce(function (sum, name) {
    return sum + groups[name].cents;
  }, 0);
  // The only delivery, already chosen and free: the summary has no "Frete"
  // row to confirm it with.
  const allChosen = names.every(function (name) {
    return priceTestIsChosen(groups[name].radio);
  });
  if (allChosen && mlSummaryShippingCents(doc) === null) return { ok: true, remember: { shippingCents: wanted } };
  // The summary tells whether the page took the choice: a click that lands
  // before the page is ready checks the radio and changes nothing else. Then
  // choose another delivery and the cheapest again, a few times.
  let tries = 0;
  let lastTry = 0;
  const taken = await priceTestWaitFor(function () {
    if (!mlSummaryLoading(doc) && mlSummaryShippingCents(doc) === wanted) return true;
    if (tries < 4 && Date.now() - lastTry >= 2500) {
      names.forEach(function (name) {
        const cheapest = mlShippingOptions(doc).find(function (option) {
          return option.radio.name === name && option.cents === groups[name].cents && !option.disabled;
        });
        if (!cheapest) return;
        if (priceTestIsChosen(cheapest.radio) && tries > 0) {
          const other = mlShippingOptions(doc).find(function (option) {
            return option.radio.name === name && option.radio !== cheapest.radio && !option.disabled;
          });
          if (other) mlChoose(doc, other.radio);
        }
        mlChoose(doc, cheapest.radio);
      });
      tries += 1;
      lastTry = Date.now();
    }
    return false;
  }, input.timeoutMs);
  if (!taken) return priceTestMissing('frete escolhido no resumo');
  return { ok: true, remember: { shippingCents: wanted } };
}

// The summary's shipping in cents ("Grátis" is 0), or null without the row.
function mlSummaryShippingCents(doc) {
  const summary = mlSummary(doc);
  const row = summary && mlSummaryRow(summary, /^frete\b/i);
  const text = row && mlAmountText(row);
  if (!text) return null;
  return text === 'Grátis' ? 0 : priceTestCents(text);
}

// After a change the summary recalculates: wait for its skeleton to go and
// the page to stop changing for a moment.
async function mlSummarySettled(doc, input) {
  // Both waits within input.timeoutMs, not each.
  const until = Date.now() + input.timeoutMs;
  await priceTestSettle(
    doc,
    function () {
      return false;
    },
    800,
    Math.min(4000, input.timeoutMs)
  );
  await priceTestWaitFor(function () {
    return !mlSummaryLoading(doc) && mlSummary(doc) ? true : null;
  }, Math.max(0, until - Date.now()));
}

// The coupon box opens in a dialog holding a frame of Mercado Livre's own
// site (/cupons/...), so its document can be read from here.
function mlCouponFrameDoc(doc) {
  const frame = Array.from(doc.querySelectorAll('[role="dialog"] iframe, [aria-modal="true"] iframe')).find(priceTestIsVisible);
  try {
    return frame && frame.contentDocument && frame.contentDocument.body ? frame.contentDocument : null;
  } catch (err) {
    return null;
  }
}

function mlCouponField(frameDoc) {
  return (
    Array.from(frameDoc.querySelectorAll('input:not([type]), input[type="text"]')).find(function (field) {
      const hint = [field.placeholder, field.getAttribute('aria-label'), field.name, field.id].join(' ');
      return /c[oó]digo|cupom|coupon|inputcode/i.test(hint) && priceTestIsVisible(field);
    }) || null
  );
}

function mlCouponDialog(doc) {
  return Array.from(doc.querySelectorAll('[role="dialog"], [aria-modal="true"]')).find(function (dialog) {
    return priceTestIsVisible(dialog) && !!dialog.querySelector('iframe');
  }) || null;
}

// The store's refusal: the field marked invalid, with the message it points
// at, minus its icon's name, Portuguese or English ("Erro Confira se o
// cupom está correto" reads "Confira se...", "Error O cupom não está mais
// disponível." reads "O cupom...").
function mlCouponRefusal(field) {
  if (field.getAttribute('aria-invalid') !== 'true') return null;
  const ids = (field.getAttribute('aria-describedby') || '').split(/\s+/).filter(Boolean);
  const text = ids
    .map(function (id) {
      const el = field.ownerDocument.getElementById(id);
      return el ? priceTestText(el) : '';
    })
    .join(' ')
    .replace(/^err(o|or)\b\s*/i, '')
    .trim();
  return text || 'Cupom recusado';
}

// The dialog's only button outside its frame: the back arrow that closes it.
async function mlCloseCouponDialog(doc, input) {
  const dialog = mlCouponDialog(doc);
  if (!dialog) return true;
  const back = Array.from(dialog.querySelectorAll('button, [role="button"]')).find(priceTestIsVisible);
  if (!back) return false;
  priceTestClick(back);
  return !!(await priceTestWaitFor(function () {
    return !mlCouponDialog(doc);
  }, input.timeoutMs));
}

// The summary's way into the coupons: "Inserir código do cupom", or
// "Cupons (1/1 em uso)" once the account has one in use (it keeps it for the
// day, in every checkout).
function mlCouponOpener(doc) {
  return priceTestFindClickable(doc, /^inserir c[oó]digo do cupom$/i) || priceTestFindClickable(doc, /^cupons\s*\(\d+\/\d+ em uso\)$/i);
}

// The banner above the coupon list ("Você está economizando R$10 com 1
// cupom"), or '' without one.
function mlCouponSavings(frameDoc) {
  const node = priceTestTextNodes(frameDoc.body).find(function (text) {
    return /voc[eê] est[aá] economizando/i.test(text.nodeValue) && priceTestIsVisible(text.parentElement);
  });
  return node ? priceTestText(node.parentElement.parentElement) : '';
}

// The store is answering: a spinner in the "Inserir" button.
function mlCouponBusy(frameDoc) {
  return !!frameDoc.querySelector('[role="progressbar"], [aria-busy="true"]');
}

// The store's answer to the code, or null while there is none. An accepted
// code leaves the dialog open: the field empties, "Você aplicou o cupom de
// 10% OFF!" shows for a few seconds and the savings banner changes.
function mlCouponAnswer(doc, savingsBefore) {
  const frameDoc = mlCouponFrameDoc(doc);
  // The dialog closed by itself: the coupon went in.
  if (!frameDoc) return mlCouponDialog(doc) ? null : { ok: true };
  const field = mlCouponField(frameDoc);
  const refused = field && mlCouponRefusal(field);
  // Typed again once on the account, the store tells it as an error: "Este
  // cupom já foi adicionado, mas ainda pode ser usado...". It counts only if
  // this product takes it: the summary tells (mlTryCoupon).
  if (refused && /j[aá] foi adicionado/i.test(refused)) return { ok: true, already: refused };
  if (refused) return { ok: false, code: 'COUPON_REJECTED', detail: { message: refused } };
  if (mlShows(frameDoc, /voc[eê] aplicou o cupom|cupom (aplicado|ativado|adicionado)|desconto aplicado/i)) return { ok: true };
  const savings = mlCouponSavings(frameDoc);
  return savings && savings !== savingsBefore ? { ok: true } : null;
}

async function mlApplyCoupon(doc, input) {
  const blocked = priceTestBlocker(doc);
  if (blocked) return blocked;
  const opener = await priceTestWaitFor(function () {
    return mlCouponOpener(doc);
  }, input.timeoutMs);
  if (!opener) return priceTestMissing('Inserir código do cupom');
  priceTestClick(opener);
  // The field shows before the frame's page works: wait for it to load.
  const field = await priceTestWaitFor(function () {
    const frameDoc = mlCouponFrameDoc(doc);
    return frameDoc && frameDoc.readyState === 'complete' && mlCouponField(frameDoc);
  }, input.timeoutMs);
  if (!field) return priceTestMissing('campo de cupom');
  if (!priceTestFindClickable(field.ownerDocument, /^(inserir|aplicar)$/i)) return priceTestMissing('Inserir cupom');
  const savingsBefore = mlCouponSavings(field.ownerDocument);
  // A click that still comes too early does nothing and the page empties
  // the field: type and click again, a few times, but never while the store
  // is answering.
  let tries = 0;
  let lastTry = 0;
  const outcome = await priceTestWaitFor(function () {
    const answer = mlCouponAnswer(doc, savingsBefore);
    if (answer) return answer;
    const frameDoc = mlCouponFrameDoc(doc);
    if (!frameDoc) return null;
    if (mlCouponBusy(frameDoc)) {
      lastTry = Date.now();
      return null;
    }
    const current = mlCouponField(frameDoc);
    const apply = priceTestFindClickable(frameDoc, /^(inserir|aplicar)$/i);
    if (current && apply && tries < 3 && Date.now() - lastTry >= 2500) {
      if (current.value !== input.coupon) priceTestType(current, input.coupon);
      priceTestClick(apply);
      tries += 1;
      lastTry = Date.now();
    }
    return null;
  }, input.timeoutMs);
  if (!outcome) return priceTestMissing('resposta do cupom');
  return outcome;
}

// A coupon in use on this purchase: the summary's "Cupons (1/1 em uso)",
// in place of "Inserir código do cupom".
function mlCouponInUse(doc) {
  return !!priceTestFindClickable(doc, /^cupons\s*\(\d+\/\d+ em uso\)$/i) && !priceTestFindClickable(doc, /^inserir c[oó]digo do cupom$/i);
}

// A refused coupon doesn't stop the test: close the dialog and go on, telling
// the refusal so the result can show the price without it. One the store
// says it took counts only once the summary shows it in use.
async function mlTryCoupon(doc, input) {
  const result = await mlApplyCoupon(doc, input);
  if (!result.ok && result.code !== 'COUPON_REJECTED') return result;
  if (!(await mlCloseCouponDialog(doc, input))) return priceTestMissing('Fechar cupom');
  await mlSummarySettled(doc, input);
  if (!result.ok) return { ok: true, couponRejected: result.detail.message };
  if (mlCouponInUse(doc)) return { ok: true };
  return { ok: true, couponRejected: result.already || 'O cupom não entrou na compra' };
}

// The checkout's payment options: Pix, Mercado Pago balance, saved cards...
function mlPaymentRadios(doc) {
  return Array.from(doc.querySelectorAll('input[type="radio"]'))
    .map(function (radio) {
      return { radio: radio, text: mlRadioLabel(doc, radio) };
    })
    .filter(function (option) {
      return /payment/i.test(option.radio.name || '') || /^(pix|saldo no mercado pago|boleto|novo cart[aã]o)\b/i.test(option.text);
    });
}

// Pix on the checkout's own list (once used, Mercado Livre lists it there).
function mlPixRadio(doc) {
  return (
    mlPaymentRadios(doc).find(function (option) {
      return /^pix\b/i.test(option.text);
    }) || null
  );
}

// The page of every payment option (/checkout/payments).
function mlOnPaymentList(doc) {
  return /\/checkout\/payments\b/i.test(doc.defaultView.location.pathname) || mlShows(doc, /^\s*escolha como pagar\s*$/i);
}

// On the payment list, the Pix option: the clickable row whose text starts
// with "Pix" ("Pix - Não selecionado", "Pix Aprovação imediata"), with on
// pricier products its savings ("Economize até R$ 246,20").
function mlPixOnList(doc) {
  const rows = Array.from(doc.querySelectorAll('[role="button"], button, a, li, label, [role="radio"], [role="option"]')).filter(function (el) {
    const text = (el.getAttribute('aria-label') || priceTestText(el)).trim();
    return /^pix\b/i.test(text) && text.length <= 160 && priceTestIsVisible(el);
  });
  // The innermost: a list item wraps its own button.
  return (
    rows.find(function (el) {
      return !rows.some(function (other) {
        return other !== el && el.contains(other);
      });
    }) || null
  );
}

// The Mercado Pago balance, chosen on the checkout. The test never pays
// with it, not even part of the price.
function mlBalanceChosen(doc) {
  return mlPaymentRadios(doc).some(function (option) {
    return /^saldo no mercado pago\b/i.test(option.text) && priceTestIsChosen(option.radio);
  });
}

// Pix alone is chosen on the checkout.
function mlPixReady(doc) {
  const pix = mlPixRadio(doc);
  return !!pix && priceTestIsChosen(pix.radio) && !mlBalanceChosen(doc);
}

// "Combinar 2 meios de pagamento", turned on: it pays part with the balance.
function mlCombineSwitchOn(doc) {
  return (
    Array.from(doc.querySelectorAll('[role="switch"]')).find(function (el) {
      const label = (el.getAttribute('aria-label') || '') + ' ' + priceTestText(el.closest('label') || el.parentElement);
      return /combinar 2 meios/i.test(label) && priceTestIsChosen(el);
    }) || null
  );
}

// The radio of a row on the payment list: the one its label points at, or
// the one inside it.
function mlListRowChosen(doc, row) {
  const radio = row.htmlFor ? doc.getElementById(row.htmlFor) : row.querySelector('input[type="radio"], [role="radio"]');
  return !!radio && priceTestIsChosen(radio);
}

// A click that lands before the page is ready does nothing: click(), at most
// a few times a couple of seconds apart, until done() holds.
function mlClickUntil(done, click, timeoutMs) {
  let tries = 0;
  let lastTry = 0;
  return priceTestWaitFor(function () {
    if (done()) return true;
    if (tries < 4 && Date.now() - lastTry >= 2500) {
      click();
      tries += 1;
      lastTry = Date.now();
      return done() || null;
    }
    return null;
  }, timeoutMs);
}

// On the payment list, choosing Pix only marks it: "Continuar" goes back to
// the checkout. "Combinar 2 meios" goes off first.
async function mlPixFromList(doc, input) {
  const chosen = await mlClickUntil(
    function () {
      const row = mlPixOnList(doc);
      return !mlCombineSwitchOn(doc) && !!row && mlListRowChosen(doc, row);
    },
    function () {
      const combine = mlCombineSwitchOn(doc);
      if (combine) priceTestClick(combine);
      const row = mlPixOnList(doc);
      if (row && !mlListRowChosen(doc, row)) priceTestClick(row);
    },
    input.timeoutMs
  );
  if (!chosen) return priceTestBlocker(doc) || priceTestMissing('PIX selecionado');
  const back = priceTestFindClickable(doc, /^continuar$/i);
  if (!back) return priceTestMissing('Continuar');
  priceTestClickSoon(back);
  return { ok: true, navigates: true, repeat: true };
}

// Pix on the checkout: chosen right there when listed; otherwise through
// "Mostrar todos" and the payment list, which comes back to the checkout
// (the step runs again on each page). It goes on only with Pix chosen and
// the balance not.
async function mlSelectPix(doc, input) {
  const blocked = priceTestBlocker(doc);
  if (blocked) return blocked;
  // Every wait below shares the step's time: added up they went past it,
  // and the service worker gave up on the step ("demorou demais").
  const until = Date.now() + input.timeoutMs;
  function left() {
    return Math.max(0, until - Date.now());
  }
  const where = await priceTestWaitFor(function () {
    if (mlOnPaymentList(doc)) return mlPixOnList(doc) ? 'list' : null;
    if (mlPixRadio(doc)) return 'radio';
    return priceTestFindClickable(doc, /^mostrar todos$/i) ? 'more' : null;
  }, left());
  if (!where) return priceTestBlocker(doc) || priceTestMissing('PIX');
  if (where === 'list') return mlPixFromList(doc, Object.assign({}, input, { timeoutMs: left() }));
  if (where === 'more') {
    priceTestClickSoon(priceTestFindClickable(doc, /^mostrar todos$/i));
    return { ok: true, navigates: true, repeat: true };
  }
  if (mlPixReady(doc)) return { ok: true };
  const chosen = await mlClickUntil(
    function () {
      return mlPixReady(doc);
    },
    function () {
      const pix = mlPixRadio(doc);
      if (pix) mlChoose(doc, pix.radio);
    },
    left()
  );
  if (!chosen) return priceTestBlocker(doc) || priceTestMissing('PIX selecionado');
  // A summary still loading by then is readTotals' to wait for.
  await mlSummarySettled(doc, Object.assign({}, input, { timeoutMs: left() }));
  return { ok: true };
}

// The product's title on the checkout, to find it in the cart afterwards:
// the first text of the page's content, beside its picture ("Kit 12 Potes
// ... Transparente", with the variation, as the cart writes it). Not the
// header's links ("Pular para o conteúdo") nor the heading "Finalize sua
// compra".
function mlCheckoutTitle(doc) {
  const node = priceTestTextNodes(doc.querySelector('main') || doc.body).find(function (text) {
    return (
      text.nodeValue.trim().length >= 8 &&
      // A badge before the title ("ÚLTIMAS 2", "RESTAM 3").
      !/^\s*(últim[ao]s?|restam?|apenas)\s+\d+\s*$/i.test(text.nodeValue) &&
      priceTestIsVisible(text.parentElement) &&
      !text.parentElement.closest('a, h1, header, nav, [role="banner"], [role="navigation"]')
    );
  });
  return node ? node.nodeValue.replace(/\s+/g, ' ').trim() : '';
}

// The summary's values once it has Pix and is loaded: "Você pagará" is the
// amount in the chosen payment (Pix), "Total" when that row is missing.
function mlSummaryValues(doc) {
  if (mlSummaryLoading(doc) || !mlPixReady(doc)) return null;
  const summary = mlSummary(doc);
  if (!summary) return null;
  // Not \b after "á": JavaScript doesn't count accented letters as letters.
  const row = mlSummaryRow(summary, /^voc[eê] pagar[aá](?=\s|$)/i) || mlSummaryRow(summary, /^total\b/i);
  const total = row && mlAmountText(row);
  if (!total || total === 'Grátis') return null;
  const shippingRow = mlSummaryRow(summary, /^frete\b/i);
  return { total: total, shipping: (shippingRow && mlAmountText(shippingRow)) || '' };
}

async function mlReadTotals(doc, input) {
  const blocked = priceTestBlocker(doc);
  if (blocked) return blocked;
  // The summary catches up with the delivery chosen in pickShipping: a
  // moment for it to agree, then it is read as it is (it is what the
  // buyer would pay).
  const wanted = typeof input.shippingCents === 'number' ? input.shippingCents : null;
  const started = Date.now();
  // A change of delivery can put the checkout back on another payment (the
  // balance): Pix again, a few times.
  let tries = 0;
  let lastTry = 0;
  function values() {
    const pix = mlPixRadio(doc);
    if (pix && !mlPixReady(doc) && tries < 3 && Date.now() - lastTry >= 2500) {
      mlChoose(doc, pix.radio);
      tries += 1;
      lastTry = Date.now();
    }
    return mlSummaryValues(doc);
  }
  let found = await priceTestWaitFor(function () {
    const current = values();
    if (!current || wanted === null) return current;
    const shown = /gr[aá]tis/i.test(current.shipping) || !current.shipping ? 0 : priceTestCents(current.shipping);
    return shown === wanted ? current : null;
  }, Math.min(5000, input.timeoutMs));
  // What is left of the step's time, so a failure tells why before the
  // service worker gives up on it.
  if (!found) found = await priceTestWaitFor(values, Math.max(0, input.timeoutMs - (Date.now() - started)));
  if (!found) return priceTestBlocker(doc) || priceTestMissing(mlPixReady(doc) ? 'Total' : 'PIX selecionado');
  return { ok: true, totalText: found.total, shippingText: found.shipping, remember: { title: mlCheckoutTitle(doc) } };
}

// Where the summary's values are on screen, once loaded, for the picture:
// from "Resumo da compra" down to "Total" (and the savings under it), the
// heading at the top of the window so the bar with "Pagar e finalizar" at
// the bottom covers nothing.
async function mlFrameTotals(doc, input) {
  const box = await priceTestWaitFor(function () {
    return mlSummaryLoading(doc) ? null : mlSummary(doc);
  }, input.timeoutMs);
  if (!box) return priceTestMissing('valores na tela');
  const heading = Array.from(box.querySelectorAll('h1, h2, h3, [role="heading"], span, p')).find(function (el) {
    return /^resumo da compra$/i.test(priceTestText(el));
  });
  const total = mlSummaryRow(box, /^total\b/i);
  if (heading && typeof heading.scrollIntoView === 'function') heading.scrollIntoView({ block: 'start' });
  // Mercado Livre scrolls the page back a bit right after: measure once it stops.
  await priceTestSettled(box, Math.min(2000, input.timeoutMs));
  const outer = box.getBoundingClientRect();
  const top = heading ? heading.getBoundingClientRect().top : outer.top;
  const bottom = total ? Math.min(outer.bottom, total.getBoundingClientRect().bottom + 48) : outer.bottom;
  const margin = 8;
  return {
    ok: true,
    area: {
      x: Math.max(0, Math.floor(outer.left - margin)),
      y: Math.max(0, Math.floor(top - margin)),
      width: Math.ceil(outer.width + margin * 2),
      height: Math.max(1, Math.ceil(bottom - top + margin * 2)),
      viewportWidth: doc.defaultView.innerWidth,
    },
  };
}

function mlOpenCart(doc) {
  priceTestSoon(function () {
    doc.defaultView.location.assign('https://www.mercadolivre.com.br/gz/cart/v2');
  });
  return Promise.resolve({ ok: true, navigates: true });
}

function mlSameTitle(a, b) {
  const plain = function (text) {
    return String(text || '')
      .normalize('NFD')
      .replace(/[̀-ͯ]/g, '')
      .replace(/\s+/g, ' ')
      .trim()
      .toLowerCase();
  };
  return !!plain(a) && plain(a) === plain(b);
}

// The remove button of the tested product's card in the cart: from its title
// (a link or heading, as the checkout wrote it) up to the nearest box with an
// "Eliminar" / "Remover produto" button - its own card. A card has two (a
// swipe one for phones, hidden from readers, and an icon): the visible one.
function mlCartRemover(doc, title) {
  const names = Array.from(doc.querySelectorAll('a, h2, h3, [role="heading"]')).filter(function (name) {
    return mlSameTitle(priceTestText(name), title) && priceTestIsVisible(name);
  });
  for (const name of names) {
    for (let card = name.parentElement; card && card !== doc.body; card = card.parentElement) {
      const removers = Array.from(card.querySelectorAll('button, a, [role="button"]')).filter(function (el) {
        return /^(eliminar|remover produto|excluir)$/i.test(priceTestLabelOf(el)) || /^remover produto$/i.test(el.getAttribute('aria-label') || '');
      });
      if (removers.length) return removers.find(priceTestIsVisible) || removers[0];
    }
  }
  return null;
}

async function mlRemoveFromCart(doc, input) {
  const blocked = priceTestBlocker(doc);
  if (blocked) return blocked;
  if (!input.title) return priceTestMissing('nome do produto');
  const remover = await priceTestWaitFor(function () {
    return mlCartRemover(doc, input.title);
  }, input.timeoutMs);
  if (!remover) return priceTestMissing('produto no carrinho');
  // Right after loading, the cart shows its buttons before they work: while
  // the card stays, click again every couple of seconds, a few times.
  let clicks = 0;
  let lastClick = 0;
  const gone = await priceTestWaitFor(function () {
    const current = mlCartRemover(doc, input.title);
    if (!current) return true;
    if (clicks < 5 && Date.now() - lastClick >= 2000) {
      priceTestClick(current);
      clicks += 1;
      lastClick = Date.now();
    }
    return false;
  }, input.timeoutMs);
  return gone ? { ok: true } : priceTestMissing('Eliminar');
}

// The steps pelandoPriceTestStep (page.js) runs here.
function pelandoPriceTestSteps() {
  return {
    checkProduct: mlCheckProduct,
    buyNow: mlBuyNow,
    skipProtection: mlSkipProtection,
    pickShipping: mlPickShipping,
    applyCoupon: mlTryCoupon,
    selectPix: mlSelectPix,
    readTotals: mlReadTotals,
    frameTotals: mlFrameTotals,
    openCart: mlOpenCart,
    removeFromCart: mlRemoveFromCart,
  };
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = {
    mlAmountCents,
    mlAmountText,
    mlWantedItem,
    mlSummary,
    mlSummaryLoading,
    mlSummaryValues,
    mlPixRadio,
    mlCheckProduct,
    mlBuyNow,
    mlSkipProtection,
    mlPickShipping,
    mlApplyCoupon,
    mlTryCoupon,
    mlSelectPix,
    mlReadTotals,
    mlFrameTotals,
    mlOpenCart,
    mlRemoveFromCart,
    pelandoPriceTestSteps,
  };
}
