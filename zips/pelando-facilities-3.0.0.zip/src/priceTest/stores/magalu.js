// "Testar Promoção": the steps on Magalu's pages, injected after compare.js
// and page.js (which has the helpers and pelandoPriceTestStep). Magalu's
// markup isn't ours and changes, so elements are found by their visible text
// and role, not by class.

// Only text a person can see counts: a hidden or script-embedded phrase is
// not the page saying the product is out of stock.
function magaluOutOfStock(doc) {
  const pattern = /produto indispon[ií]vel|avise-me quando chegar|produto esgotado/i;
  return priceTestTextNodes(doc.body).some(function (node) {
    return pattern.test(node.nodeValue) && priceTestIsVisible(node.parentElement);
  });
}

// Variant pickers (size, color...): each option links to its variant's page.
// Disabled options are sold out.
function magaluVariantGroups(doc) {
  return Array.from(doc.querySelectorAll('[data-testid="attribute-type"]'))
    .map(function (group) {
      return Array.from(group.querySelectorAll('[data-testid="attribute-option"]')).filter(priceTestIsVisible);
    })
    .filter(function (options) {
      return options.length > 0;
    });
}

function magaluOptionOnSale(option) {
  return option.getAttribute('aria-disabled') !== 'true' && !option.hasAttribute('disabled');
}

// The option that links to this very page: the deal's own variant.
function magaluOwnVariant(doc, options) {
  const here = doc.defaultView.location;
  return (
    options.find(function (option) {
      const href = option.getAttribute('href');
      return href && new URL(href, here.href).pathname === here.pathname;
    }) || null
  );
}

// The product page works out shipping to the account's CEP after loading:
// "Enviar para ... Calcular" until then, "... Alterar" with the delivery
// ("Receba entre...") or "Produto esgotado!" after. Only then is the stock
// known: "Comprar agora" starts on even for a product out of stock.
function magaluShippingKnown(doc) {
  if (priceTestFindClickable(doc, /^enviar para\b.*\balterar$/i)) return true;
  return priceTestTextNodes(doc.body).some(function (node) {
    return /^\s*receba\b/i.test(node.nodeValue) && priceTestIsVisible(node.parentElement);
  });
}

// After many pages in a row the store answers every one with "Não é
// possível acessar a página (Erro 403)" for a minute or so.
function magaluForbidden(doc) {
  const text = priceTestText(doc.body);
  return /n[aã]o [eé] poss[ií]vel acessar a p[aá]gina/i.test(text) && /erro 403/i.test(text);
}

// A partner's product (magazinevoce.com.br/<partner>/<product>/p/<code>/...)
// on the store's own site, where the account is logged in; null for any other
// page.
function magaluStoreUrl(href) {
  const url = new URL(href);
  if (!/(^|\.)magazinevoce\.com\.br$/i.test(url.hostname)) return null;
  const parts = url.pathname.split('/');
  // ['', partner, product, 'p', code, ...]
  if (parts.length < 6 || parts[3] !== 'p' || !parts[2] || !parts[4]) return null;
  return 'https://www.magazineluiza.com.br/' + parts.slice(2).join('/') + url.search;
}

async function magaluCheckProduct(doc, input) {
  // Before anything else: the partner's site shows the account logged out.
  const store = magaluStoreUrl(doc.defaultView.location.href);
  if (store) {
    priceTestSoon(function () {
      doc.defaultView.location.assign(store);
    });
    return { ok: true, navigates: true, repeat: true };
  }
  const blocked = priceTestBlocker(doc);
  if (blocked) return blocked;
  if (magaluForbidden(doc)) return { ok: false, code: 'BLOCKED' };
  if (magaluOutOfStock(doc)) return { ok: false, code: 'OUT_OF_STOCK' };
  const buy = await priceTestWaitFor(function () {
    return priceTestFindClickable(doc, /comprar agora/i);
  }, input.timeoutMs);
  if (buy) {
    // The store works shipping out only once its box is on screen (a small
    // window, a long page): bring it into view, once.
    let scrolled = false;
    await priceTestWaitFor(function () {
      if (magaluOutOfStock(doc) || magaluShippingKnown(doc)) return true;
      const box = !scrolled && priceTestFindClickable(doc, /^enviar para\b/i);
      if (box && typeof box.scrollIntoView === 'function') {
        scrolled = true;
        box.scrollIntoView({ block: 'center' });
      }
      return false;
    }, Math.min(6000, input.timeoutMs));
    if (magaluOutOfStock(doc)) return { ok: false, code: 'OUT_OF_STOCK' };
    // A link to a product with variants but none of its own (a parent
    // product): go to the first variant on sale.
    const loose = magaluVariantGroups(doc).find(function (options) {
      return !magaluOwnVariant(doc, options);
    });
    const first = loose && loose.find(magaluOptionOnSale);
    if (!first) return { ok: true };
    priceTestClickSoon(first);
    return { ok: true, navigates: true };
  }
  if (magaluOutOfStock(doc)) return { ok: false, code: 'OUT_OF_STOCK' };
  return priceTestBlocker(doc) || priceTestMissing('Comprar agora');
}

async function magaluBuyNow(doc, input) {
  const blocked = priceTestBlocker(doc);
  if (blocked) return blocked;
  const buy = priceTestFindClickable(doc, /comprar agora/i);
  if (!buy) return magaluOutOfStock(doc) ? { ok: false, code: 'OUT_OF_STOCK' } : priceTestMissing('Comprar agora');
  // The page shows the deal's variant but wants it picked ("Selecione o
  // campo tamanho"): click it, which stays on the page.
  magaluVariantGroups(doc).forEach(function (options) {
    const own = magaluOwnVariant(doc, options);
    if (own && magaluOptionOnSale(own)) priceTestClick(own);
  });
  priceTestClickSoon(buy);
  // The review should list this product (see magaluReadTotals).
  const title = priceTestText(doc.querySelector('h1'));
  return title ? { ok: true, navigates: true, remember: { title: title } } : { ok: true, navigates: true };
}

// Some products offer an extended warranty ("Proteção") between "Comprar
// agora" and the delivery page: always "Agora não". Without the offer the
// delivery page shows up and the step passes untouched.
async function magaluSkipProtection(doc, input) {
  const blocked = priceTestBlocker(doc);
  if (blocked) return blocked;
  const seen = await priceTestWaitFor(function () {
    const decline = priceTestFindClickable(doc, /^agora n[aã]o$/i);
    if (decline) return { decline: decline };
    return magaluAddressOptions(doc).length || magaluShippingOptions(doc).length || magaluAmountRow(doc, /^(frete|entrega)\b/i) || magaluPixOption(doc)
      ? { decline: null }
      : null;
  }, input.timeoutMs);
  if (!seen || !seen.decline) return priceTestBlocker(doc) || { ok: true };
  priceTestClickSoon(seen.decline);
  return { ok: true, navigates: true };
}

// The saved addresses (sacola.../#/endereco): radios whose label shows a CEP.
function magaluAddressOptions(doc) {
  return priceTestRadios(doc).filter(function (option) {
    return /\bCEP\b/.test(option.text) && priceTestIsVisible(option.label);
  });
}

// The default address is the one card without "Tornar padrão".
function magaluDefaultAddress(doc) {
  return (
    magaluAddressOptions(doc).find(function (option) {
      const card = option.radio.parentElement || option.label;
      return !Array.from(card.querySelectorAll('button, a, [role="button"]')).some(function (el) {
        return /tornar padr[aã]o/i.test(priceTestLabelOf(el));
      });
    }) || null
  );
}

// Sometimes the checkout asks for the address before the delivery page, with
// none selected: always the account's default, then "Continuar". Only the
// radio and "Continuar" are clicked, never "Tornar padrão", "Editar" or
// "Excluir". When the delivery page comes straight away, the step passes.
async function magaluPickAddress(doc, input) {
  const blocked = priceTestBlocker(doc);
  if (blocked) return blocked;
  const page = await priceTestWaitFor(function () {
    if (magaluAddressOptions(doc).length) return 'addresses';
    return magaluShippingOptions(doc).length || magaluAmountRow(doc, /^(frete|entrega)\b/i) || magaluPixOption(doc) ? 'delivery' : null;
  }, input.timeoutMs);
  if (page !== 'addresses') return priceTestBlocker(doc) || { ok: true };
  const chosen = magaluDefaultAddress(doc);
  if (!chosen) return priceTestMissing('endereço padrão');
  if (!priceTestIsChosen(chosen.radio)) priceTestClick(chosen.radio);
  // "Continuar" turns on once an address is selected.
  const next = await priceTestWaitFor(function () {
    return priceTestFindClickable(doc, /^continuar$/i);
  }, input.timeoutMs);
  if (!next) return priceTestMissing('Continuar');
  priceTestClickSoon(next);
  return { ok: true, navigates: true };
}

// The smallest visible element whose text starts with the label and shows
// an amount or "Grátis" - a summary row like "Total R$ 1.299,00". The last
// one on the page when there are several: the summary comes last.
function magaluAmountRow(doc, label) {
  const row = magaluAmountRowElement(doc, label);
  return row ? priceTestText(row) : null;
}

function magaluAmountRowElement(doc, label) {
  const rows = Array.from(doc.body.querySelectorAll('*')).filter(function (el) {
    const text = priceTestText(el);
    return text.length <= 80 && label.test(text) && /R\$\s?[\d.]+,\d{2}|gr[aá]tis/i.test(text) && priceTestIsVisible(el);
  });
  const smallest = rows.filter(function (el) {
    return !rows.some(function (other) {
      return other !== el && el.contains(other);
    });
  });
  return smallest.length ? smallest[smallest.length - 1] : null;
}

// While the review recalculates, Magalu blurs the page behind a spinner.
function magaluPageBlurred(doc) {
  const view = doc.defaultView;
  return Array.from(doc.body.querySelectorAll('*')).some(function (el) {
    const style = view.getComputedStyle(el);
    return /blur\(/.test(style.filter + ' ' + (style.backdropFilter || '')) && priceTestIsVisible(el);
  });
}

// The review's values block: from "Produtos" down to "Total da sacola".
function magaluValuesBlock(doc) {
  const total = magaluAmountRowElement(doc, /^total\b/i);
  for (let box = total; box && box !== doc.body; box = box.parentElement) {
    const text = priceTestText(box);
    if (/produtos/i.test(text) && /frete/i.test(text)) return box;
  }
  return total;
}

// Where the values are on screen, once the page is clear, for the picture
// the service worker crops (runner.js). In CSS pixels, with a small margin.
async function magaluFrameTotals(doc, input) {
  const block = await priceTestWaitFor(function () {
    return magaluPageBlurred(doc) ? null : magaluValuesBlock(doc);
  }, input.timeoutMs);
  if (!block) return priceTestMissing('valores na tela');
  if (typeof block.scrollIntoView === 'function') block.scrollIntoView({ block: 'center' });
  await priceTestSettled(block, Math.min(2000, input.timeoutMs));
  const rect = block.getBoundingClientRect();
  const margin = 8;
  return {
    ok: true,
    area: {
      x: Math.max(0, Math.floor(rect.left - margin)),
      y: Math.max(0, Math.floor(rect.top - margin)),
      width: Math.ceil(rect.width + margin * 2),
      height: Math.ceil(rect.height + margin * 2),
      viewportWidth: doc.defaultView.innerWidth,
    },
  };
}

// Shipping choices: radios whose label shows a price or "Grátis", minus the
// payment ones. Store pickup ("Retire na loja") is marked: the test always
// ships to the account's default address, the one the page already shows.
function magaluShippingOptions(doc) {
  return priceTestRadios(doc)
    .filter(function (option) {
      return /gr[aá]tis|R\$\s?\d/i.test(option.text) && !/\bpix\b|cart[aã]o|boleto/i.test(option.text) && priceTestIsVisible(option.label);
    })
    .map(function (option) {
      option.cents = /gr[aá]tis/i.test(option.text) ? 0 : priceTestCents(option.text);
      option.pickup = /retir(e|ar|ada)\b/i.test(option.text);
      return option;
    });
}

async function magaluPickShipping(doc, input) {
  const blocked = priceTestBlocker(doc);
  if (blocked) return blocked;
  const found = await priceTestWaitFor(function () {
    const all = magaluShippingOptions(doc);
    if (all.length || magaluAmountRow(doc, /^(frete|entrega)\b/i)) return all;
    // Straight to the payment page, the delivery already set: the review
    // shows its shipping.
    return magaluPixOption(doc) ? 'payment' : null;
  }, input.timeoutMs);
  if (found === 'payment') return { ok: true };
  if (!found) return priceTestBlocker(doc) || priceTestMissing('opções de frete');
  const options = found.filter(function (option) {
    return !option.pickup;
  });
  if (found.length && !options.length) return priceTestMissing('entrega no endereço');
  if (options.length) {
    const cheapest = options.reduce(function (best, option) {
      return option.cents !== null && (best.cents === null || option.cents < best.cents) ? option : best;
    });
    if (!priceTestIsChosen(cheapest.radio)) priceTestClick(cheapest.radio);
  }
  const next = priceTestFindClickable(doc, /^(continuar|ir para (o )?pagamento|seguir para (o )?pagamento)$/i);
  if (!next) return { ok: true };
  priceTestClickSoon(next);
  return { ok: true, navigates: true };
}

function magaluCouponField(doc) {
  return (
    Array.from(doc.querySelectorAll('input:not([type]), input[type="text"], input[type="search"]')).find(function (field) {
      const hint = [field.placeholder, field.getAttribute('aria-label'), field.name, field.id].join(' ');
      return /cupom|coupon/i.test(hint) && priceTestIsVisible(field);
    }) || null
  );
}

// A message matching the pattern inside the coupon box (the smallest element
// holding the field and its button), so text elsewhere on the page
// ("Retirada na loja não disponível") doesn't count.
function magaluCouponMessage(field, button, pattern) {
  let box = field.parentElement;
  while (box && !box.contains(button)) box = box.parentElement;
  const scope = box || field.ownerDocument.body;
  const found = Array.from(scope.querySelectorAll('*')).find(function (el) {
    const text = priceTestText(el);
    return el.children.length === 0 && text.length <= 200 && pattern.test(text) && priceTestIsVisible(el);
  });
  return found ? priceTestText(found) : null;
}

// True when the text around the element (its parent or grandparent, a row
// like "Tem um código de cupom? [Inserir]") talks about coupons.
function magaluNearCoupon(el) {
  const near = [el.parentElement, el.parentElement && el.parentElement.parentElement];
  return near.some(function (box) {
    const text = priceTestText(box);
    return text.length <= 200 && /cupom/i.test(text);
  });
}

// The button that opens a collapsed coupon box: "Adicionar cupom", "Tenho um
// cupom"... or a bare "Inserir" in a row that mentions coupons ("Tem um código
// de cupom? Inserir"), but not "Remover cupom", and not a link that leaves the page.
function magaluCouponToggle(doc) {
  const pattern = /^(adicionar|inserir|usar|tenho( um)?|aplicar)? ?cupom( de desconto)?$/i;
  const bare = /^(inserir|adicionar)( cupom)?$/i;
  const candidates = doc.querySelectorAll('button, a, [role="button"]');
  return (
    Array.from(candidates).find(function (el) {
      const href = el.tagName === 'A' ? el.getAttribute('href') : null;
      if (href && href.charAt(0) !== '#' && !/^javascript:/i.test(href)) return false;
      if (el.disabled || !priceTestIsVisible(el)) return false;
      const label = priceTestLabelOf(el);
      return pattern.test(label) || (bare.test(label) && magaluNearCoupon(el));
    }) || null
  );
}

function magaluCouponRefusal() {
  return /inv[aá]lid|inativ|expirad|n[aã]o (é |foi )?(v[aá]lid|aplic|aceit|encontrad|dispon)|n[aã]o est(á|a|ar) (mais )?(ativo|dispon[ií]vel|v[aá]lido)|esgotad/i;
}

// The field the store marked invalid (aria-invalid), with the message it
// points at (aria-describedby): Magalu's own way of refusing a code.
function magaluCouponFlaggedMessage(field) {
  if (field.getAttribute('aria-invalid') !== 'true') return null;
  const ids = (field.getAttribute('aria-describedby') || '').split(/\s+/).filter(Boolean);
  const texts = ids
    .map(function (id) {
      const el = field.ownerDocument.getElementById(id);
      return el && priceTestIsVisible(el) ? priceTestText(el) : '';
    })
    .filter(Boolean);
  return texts.length ? texts.join(' ') : null;
}

async function magaluApplyCoupon(doc, input) {
  const blocked = priceTestBlocker(doc);
  if (blocked) return blocked;
  let field = magaluCouponField(doc);
  if (!field) {
    // The page may not take clicks yet right after loading: while no field
    // shows, click the opener again every couple of seconds, a few times.
    let clicks = 0;
    let lastClick = 0;
    const open = function () {
      const toggle = magaluCouponToggle(doc);
      if (!toggle) return;
      priceTestClick(toggle);
      clicks += 1;
      lastClick = Date.now();
    };
    open();
    field = await priceTestWaitFor(function () {
      const found = magaluCouponField(doc);
      if (!found && clicks < 6 && Date.now() - lastClick >= 2000) open();
      return found;
    }, input.timeoutMs);
  }
  if (!field) return priceTestMissing('campo de cupom');
  priceTestType(field, input.coupon);
  const apply = priceTestFindClickable(doc, /^aplicar( cupom)?$/i);
  if (!apply) return priceTestMissing('Aplicar cupom');
  priceTestClick(apply);
  const outcome = await priceTestWaitFor(function () {
    // The page may re-render the modal: look at the field and button as they
    // are now, not the ones captured before the click.
    const current = magaluCouponField(doc);
    if (current) {
      const flagged = magaluCouponFlaggedMessage(current);
      if (flagged) return { ok: false, code: 'COUPON_REJECTED', detail: { message: flagged } };
      const button = priceTestFindClickable(doc, /^aplicar( cupom)?$/i) || apply;
      const refused = magaluCouponMessage(current, button, magaluCouponRefusal());
      if (refused) return { ok: false, code: 'COUPON_REJECTED', detail: { message: refused } };
      if (magaluCouponMessage(current, button, /cupom aplicado|desconto aplicado|cupom adicionado/i)) return { ok: true };
      return null;
    }
    // No coupon field anywhere: the modal closed. Accepted, unless a refusal
    // shows elsewhere on the page (a toast outside the modal).
    const toast = priceTestTextNodes(doc.body).find(function (node) {
      return magaluCouponRefusal().test(node.nodeValue) && priceTestIsVisible(node.parentElement);
    });
    if (toast) return { ok: false, code: 'COUPON_REJECTED', detail: { message: priceTestText(toast.parentElement) } };
    return { ok: true };
  }, input.timeoutMs);
  return outcome || priceTestMissing('resposta do cupom');
}

// A refused coupon doesn't stop the test: close the coupon dialog ("Fechar")
// and go on to PIX, telling the refusal so the result can show the price
// without the coupon.
async function magaluTryCoupon(doc, input) {
  const result = await magaluApplyCoupon(doc, input);
  if (result.ok || result.code !== 'COUPON_REJECTED') return result;
  const field = magaluCouponField(doc);
  if (field) {
    const dialog = field.closest('[role="dialog"], [aria-modal="true"]') || doc.body;
    const close = Array.from(dialog.querySelectorAll('button, [role="button"]')).find(function (el) {
      const label = (el.getAttribute('aria-label') || priceTestText(el)).trim();
      return /^(fechar|close|×|x)$/i.test(label) && priceTestIsVisible(el);
    });
    if (!close) return priceTestMissing('Fechar cupom');
    priceTestClick(close);
    const closed = await priceTestWaitFor(function () {
      return !magaluCouponField(doc);
    }, input.timeoutMs);
    if (!closed) return priceTestMissing('Fechar cupom');
  }
  return { ok: true, couponRejected: result.detail.message };
}

// The PIX option: a radio, or (on Magalu's payment page) a list item, button
// or option whose visible text starts with "Pix". Other options ("Novo cartão
// de crédito", "Mastercard 0244") never match.
function magaluPixOption(doc) {
  const radio = priceTestRadios(doc).find(function (option) {
    return /^pix\b/i.test(option.text) && option.text.length <= 80 && priceTestIsVisible(option.label);
  });
  if (radio) return { el: radio.radio, radio: true };
  const item = Array.from(doc.querySelectorAll('li, button, label, [role="option"], [role="button"]')).find(function (el) {
    const text = priceTestText(el);
    return /^pix\b/i.test(text) && text.length <= 80 && !el.querySelector('input[type="radio"], [role="radio"]') && !el.disabled && priceTestIsVisible(el);
  });
  return item ? { el: item, radio: false } : null;
}

async function magaluSelectPix(doc, input) {
  const blocked = priceTestBlocker(doc);
  if (blocked) return blocked;
  const pix = await priceTestWaitFor(function () {
    return magaluPixOption(doc);
  }, input.timeoutMs);
  if (!pix) return priceTestBlocker(doc) || priceTestMissing('PIX');
  if (pix.radio) {
    if (!priceTestIsChosen(pix.el)) priceTestClick(pix.el);
    return { ok: true };
  }
  // Clicking the item takes the page to the review in the same document. A
  // click that lands too early is lost: either the page doesn't move (it was
  // re-rendering after the coupon dialog closed), or the review sends it back
  // to the payment page. Either way, find the item again and click once more.
  // The payment page keeps building for a moment after Pix shows (the
  // subtotal changes, then Pix's "Desconto de R$ ..."), and a click before
  // that bounces back from the review. Wait for Pix's discount, or for the
  // page to stop changing.
  await priceTestSettle(
    doc,
    function () {
      const option = magaluPixOption(doc);
      return !!option && /desconto/i.test(priceTestText(option.el));
    },
    1000,
    Math.min(5000, input.timeoutMs)
  );
  const settled = magaluPixOption(doc);
  const view = doc.defaultView;
  const from = view.location.href;
  let item = settled && !settled.radio ? settled.el : pix.el;
  for (let attempt = 0; attempt < 3 && item; attempt++) {
    priceTestClick(item);
    const left = await priceTestWaitFor(function () {
      return view.location.href !== from;
    }, Math.min(1500, input.timeoutMs));
    if (left) {
      const where = await priceTestWaitFor(function () {
        if (magaluReviewReady(doc)) return 'review';
        return view.location.href === from && magaluPixOption(doc) ? 'back' : null;
      }, Math.min(6000, input.timeoutMs));
      if (where === 'review' || (!where && view.location.href !== from)) return { ok: true };
    }
    const again = magaluPixOption(doc);
    item = again && !again.radio ? again.el : null;
  }
  return priceTestBlocker(doc) || priceTestMissing('revisão do pedido');
}

// The review page once it has taken the payment: "Alterar pagamento" and
// the payment block's "Valor total".
function magaluReviewReady(doc) {
  return !!priceTestFindClickable(doc, /^alterar pagamento$/i) && !!magaluAmountRow(doc, /^valor total\b/i);
}

// The review's rows (observed 2026-11-03): "Produtos (1): R$ 211,10",
// "Desconto: - R$ 42,22" (Pix), "Cupom: - R$ 50,00", "Frete: Grátis", then
// "Total do pedido". What the total should be from those rows, in cents, or
// null when there are no such rows to check against.
function magaluReviewSum(doc) {
  const products = priceTestCents(magaluAmountRow(doc, /^produtos\b/i));
  if (products === null) return null;
  const amount = function (label) {
    return priceTestCents(magaluAmountRow(doc, label)) || 0;
  };
  return products - amount(/^desconto\s*:/i) - amount(/^cupom\s*:/i) + amount(/^(frete|entrega)\b/i);
}

// How long the review's rows stay the same before the total counts, and how
// long a total that doesn't add up is given before the page is reloaded.
const MAGALU_REVIEW_STILL_MS = 1000;
const MAGALU_REVIEW_MISMATCH_MS = 6000;

async function magaluReadTotals(doc, input) {
  const blocked = priceTestBlocker(doc);
  if (blocked) return blocked;
  let rows = null;
  let rowsSince = 0;
  let wrongSince = 0;
  const found = await priceTestWaitFor(function () {
    const bag = magaluAmountRow(doc, /^total\b/i);
    if (!bag) return null;
    const sum = magaluReviewSum(doc);
    if (sum !== null) {
      const now = Date.now();
      // The review can show the coupon row while "Total do pedido" leaves it
      // out (observed for 18 s): the total counts once it adds up from the
      // rows above it.
      if (Math.abs(sum - priceTestCents(bag)) > 1) {
        rows = null;
        if (!wrongSince) wrongSince = now;
        return now - wrongSince >= Math.min(MAGALU_REVIEW_MISMATCH_MS, input.timeoutMs) ? { wrong: bag, sum: sum } : null;
      }
      wrongSince = 0;
      // Reloaded, the review first shows without the Pix discount row, and
      // that adds up too: the rows have to stay the same for a moment.
      const shown = priceTestText(magaluValuesBlock(doc) || doc.body);
      if (shown !== rows) {
        rows = shown;
        rowsSince = now;
        return null;
      }
      if (now - rowsSince < MAGALU_REVIEW_STILL_MS) return null;
    }
    // On the review page the bag total first shows without the Pix
    // discount: it counts once the payment block ("Valor total") agrees.
    if (!priceTestFindClickable(doc, /^alterar pagamento$/i)) return { total: bag };
    const paid = magaluAmountRow(doc, /^valor total\b/i);
    return paid && priceTestCents(paid) === priceTestCents(bag) ? { total: bag } : null;
  }, input.timeoutMs);
  if (found && found.wrong) {
    if (!input.magaluReviewReloaded) {
      priceTestSoon(function () {
        doc.defaultView.location.reload();
      });
      return { ok: true, navigates: true, repeat: true, remember: { magaluReviewReloaded: true } };
    }
    return {
      ok: false,
      code: 'STEP_FAILED',
      detail: {
        message:
          'O "Total do pedido" da Magalu (' + priceTestFormat(priceTestCents(found.wrong)) + ') não bate com os valores acima dele (' +
          priceTestFormat(found.sum) + '), nem depois de recarregar a página: confira na aba',
      },
    };
  }
  const total = found && found.total;
  if (!total) return priceTestBlocker(doc) || priceTestMissing('Total');
  // "Comprar agora" on some products leaves the buy-now order as it was: the
  // review ("Revise seu pedido") then lists the product bought before. The
  // review names it without what follows " - " (brand, model, color).
  const words = function (text) {
    return text.toLowerCase().replace(/\s+/g, ' ').trim();
  };
  const page = words(priceTestText(doc.body));
  const name = input.title ? words(input.title).split(' - ')[0] : '';
  if (name && /\brevise seu pedido\b/.test(page) && page.indexOf(name) < 0) {
    return { ok: false, code: 'OTHER_PRODUCT' };
  }
  return { ok: true, totalText: total, shippingText: magaluAmountRow(doc, /^(frete|entrega)\b/i) || '' };
}

// The steps pelandoPriceTestStep (page.js) runs here.
function pelandoPriceTestSteps() {
  return {
    checkProduct: magaluCheckProduct,
    buyNow: magaluBuyNow,
    skipProtection: magaluSkipProtection,
    pickAddress: magaluPickAddress,
    pickShipping: magaluPickShipping,
    applyCoupon: magaluTryCoupon,
    selectPix: magaluSelectPix,
    readTotals: magaluReadTotals,
    frameTotals: magaluFrameTotals,
  };
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = {
    magaluStoreUrl,
    magaluCheckProduct,
    magaluBuyNow,
    magaluSkipProtection,
    magaluPickAddress,
    magaluPickShipping,
    magaluApplyCoupon,
    magaluTryCoupon,
    magaluSelectPix,
    magaluReadTotals,
    magaluFrameTotals,
    pelandoPriceTestSteps,
  };
}
