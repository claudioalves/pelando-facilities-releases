// "Testar Promoção": the steps on Amazon's pages, injected after compare.js
// and page.js (which has the helpers and pelandoPriceTestStep). Product page
// → "Comprar agora" → sometimes a protection plan offer → a one-page
// checkout (/checkout/p/.../spc?isBuyNow=1) with delivery, payment and the
// order summary. The coupon and Pix are on its payment page (/pay), reached
// by "Alterar forma de pagamento" and left by "Use este método de
// pagamento". The checkout left behind puts the product in the cart: the
// cleanup deletes it there, by its ASIN.
//
// Elements are found by visible text and role, as on the other stores, with
// Amazon's stable names where its text is hidden (input names such as
// ppw-claimCode, the summary's list id).

// Amazon's own stops on top of the common ones: its captcha page ("Digite
// os caracteres") and its sign-in pages, which ask for the email first.
function amazonBlocker(doc) {
  const blocked = priceTestBlocker(doc);
  if (blocked) return blocked;
  if (doc.querySelector('form[action*="validateCaptcha"]')) return { ok: false, code: 'NEEDS_HUMAN' };
  if (/^\/(ap\/signin|ax\/claim)\b/i.test(doc.defaultView.location.pathname)) return { ok: false, code: 'SESSION_EXPIRED' };
  return null;
}

function amazonBuyNowButton(doc) {
  const button = doc.getElementById('buy-now-button');
  if (button && priceTestIsVisible(button)) return button;
  return priceTestFindClickable(doc, /^comprar agora$/i);
}

// The buy box's own "out of stock" sentences.
function amazonOutOfStock(doc) {
  const availability = doc.getElementById('availability') || doc.getElementById('outOfStock');
  return !!availability && /n[aã]o dispon[ií]vel|indispon[ií]vel|esgotado|fora de estoque/i.test(priceTestText(availability));
}

// Nobody holds the buy box ("Nenhuma opção de compra em destaque"): no
// "Comprar agora", only "Ver todas as opções de compra", the other sellers'
// list, at other prices.
function amazonNoFeaturedOffer(doc) {
  return priceTestIsVisible(doc.getElementById('buybox-see-all-buying-choices'));
}

// A Kindle eBook: only "Comprar agora com 1-clique", which orders on the
// spot with the saved card. No Pix, no checkout to read.
function amazonOneClickOnly(doc) {
  return priceTestIsVisible(doc.getElementById('one-click-button'));
}

// "Programe e Poupe" open: its buy box has no "Comprar agora".
function amazonSubscriptionOpen(doc) {
  const active = doc.querySelector('#buyBoxAccordion > .a-accordion-active');
  return !!active && /^sns/i.test(active.id);
}

// The deal's link names one size or color (/dp/<ASIN>, /gp/product/<ASIN>),
// yet Amazon may open the same product in another one. Its option on the
// size list, when the page shows another and it hasn't been picked yet;
// { gone: true } when the list no longer has it.
function amazonLinkedVariation(doc, input) {
  const match = /\/(?:dp|gp\/product)\/([A-Z0-9]{10})(?:[/?#]|$)/i.exec(String(input.url || ''));
  if (!match) return null;
  const asin = match[1].toUpperCase();
  const shown = doc.querySelector('input[name="ASIN"]');
  if (!shown || shown.value.toUpperCase() === asin || input.pickedAsin === asin) return null;
  const twister = doc.querySelector('#twister_feature_div, #twister, [id^="inline-twister"]');
  // Without a size list the link was only another name for this product.
  if (!twister) return null;
  const item = twister.querySelector('[data-asin="' + asin + '"]');
  if (!item) return { gone: true };
  const option = item.querySelector('input[type="submit"], button, [role="radio"]') || item;
  return { asin: asin, option: option };
}

// "Para comprar, selecione Tamanho": a variation still to choose. Its
// options are the twister's buttons; the sold-out ones are greyed out.
function amazonLooseVariation(doc) {
  const asks = priceTestTextNodes(doc.body).some(function (node) {
    return /para comprar, selecione/i.test(node.nodeValue) && priceTestIsVisible(node.parentElement);
  });
  if (!asks) return null;
  const twister = doc.querySelector('#twister_feature_div, #twister, [id^="inline-twister"]');
  if (!twister) return { options: [] };
  return {
    options: Array.from(twister.querySelectorAll('button, [role="radio"], [role="option"], input[type="submit"]')).filter(function (option) {
      const item = option.closest('li') || option;
      return (
        priceTestIsVisible(option) &&
        option.getAttribute('aria-disabled') !== 'true' &&
        !option.disabled &&
        !/unavailable|disabled/i.test(String(item.className))
      );
    }),
  };
}

// "Programe e Poupe" is a subscription: the test buys once ("Compra única",
// the buy box's first row).
function amazonBuyOnce(doc) {
  const active = doc.querySelector('#buyBoxAccordion > .a-accordion-active');
  if (!active || !/^sns/i.test(active.id)) return false;
  const once = doc.querySelector('#buyBoxAccordion > [id^="newAccordionRow"] [role="button"], #buyBoxAccordion > [id^="newAccordionRow"] .a-accordion-row');
  if (!once) return false;
  priceTestClick(once);
  return true;
}

// A product sold from a minimum quantity starts on "Selecionar", with
// "Comprar agora" disabled: the minimum, the first number on the list.
function amazonPickMinimum(doc) {
  const select = doc.getElementById('quantity');
  if (!select || select.value) return false;
  const minimum = Array.from(select.options).find(function (option) {
    return /^\d+$/.test(option.value);
  });
  if (!minimum) return false;
  select.value = minimum.value;
  select.dispatchEvent(new doc.defaultView.Event('change', { bubbles: true }));
  return true;
}

// A deal for several units ("Leve 2"): that many, unless the list starts
// higher (a minimum) or doesn't go that far.
function amazonPickUnits(doc, units) {
  const select = doc.getElementById('quantity');
  if (!select || !(units > 1) || Number(select.value) >= units) return false;
  const option = Array.from(select.options).find(function (option) {
    return option.value === String(units);
  });
  if (!option) return false;
  select.value = option.value;
  select.dispatchEvent(new doc.defaultView.Event('change', { bubbles: true }));
  return true;
}

// A minimum quantity over the stock ("Quantidade mínima: 4", 3 left): the
// list holds no number at all and "Comprar agora" stays off.
function amazonNoQuantity(doc) {
  const select = doc.getElementById('quantity');
  return (
    !!select &&
    !select.value &&
    !Array.from(select.options).some(function (option) {
      return /^\d+$/.test(option.value);
    })
  );
}

// A coupon the product page offers, part of the price a buyer sees. Amazon
// lays it out as a box with no text of its own: "Aplicar Cupom de 27%" sits
// beside it (couponText…) and "Cupom de 27% de desconto aplicado" (done…)
// stays hidden until Amazon takes the coupon. Some pages have a "Resgatar"
// button instead. A mission's "Inscreva-se" next to it is no discount.
// { el, name, done } or null; `done` only for the box.
function amazonPageCoupon(doc) {
  const box = doc.getElementById('promoPriceBlockMessage_feature_div') || doc.getElementById('vpcButton');
  if (!box) return null;
  let found = null;
  Array.from(box.querySelectorAll('input[type="checkbox"][id^="checkbox"]')).some(function (el) {
    const key = el.id.slice('checkbox'.length);
    const text = doc.getElementById('couponText' + key);
    const done = doc.getElementById('done' + key);
    const offer = text && !text.closest('.aok-hidden') && /^aplicar\s+(cupom de \d+\s*%)/i.exec(priceTestText(text));
    if (el.disabled || el.checked || el.closest('.aok-hidden') || !offer || !done) return false;
    found = { el: el, name: offer[1], done: done };
    return true;
  });
  if (found) return found;
  const redeem = Array.from(box.querySelectorAll('button, input[type="submit"], [role="button"]')).find(function (el) {
    return !el.disabled && /^(resgatar|aplicar( cupom)?)\b/i.test(priceTestLabelOf(el));
  });
  return redeem ? { el: redeem, name: null, done: null } : null;
}

async function amazonCheckProduct(doc, input) {
  const blocked = amazonBlocker(doc);
  if (blocked) return blocked;
  const seen = await priceTestWaitFor(function () {
    if (amazonOutOfStock(doc)) return 'out';
    if (amazonLooseVariation(doc)) return 'choose';
    if (amazonBuyNowButton(doc)) return 'buy';
    if (amazonSubscriptionOpen(doc)) return 'subscription';
    if (amazonNoFeaturedOffer(doc)) return 'nofeatured';
    if (amazonOneClickOnly(doc)) return 'digital';
    return null;
  }, input.timeoutMs);
  if (!seen) return amazonBlocker(doc) || priceTestMissing('Comprar agora');
  // Once: the size or color the deal links, when Amazon opened another.
  const linked = amazonLinkedVariation(doc, input);
  if (linked && linked.gone) return { ok: false, code: 'VARIATION_GONE' };
  if (linked) {
    priceTestClickSoon(linked.option);
    return { ok: true, navigates: true, repeat: true, remember: { pickedAsin: linked.asin } };
  }
  if (seen === 'out') return { ok: false, code: 'OUT_OF_STOCK' };
  if (seen === 'nofeatured') return { ok: false, code: 'NO_FEATURED_OFFER' };
  if (seen === 'digital') return { ok: false, code: 'DIGITAL_ONLY' };
  if (seen === 'choose') {
    const first = amazonLooseVariation(doc).options[0];
    if (!first) return { ok: false, code: 'OUT_OF_STOCK' };
    priceTestClickSoon(first);
    return { ok: true, navigates: true, repeat: true };
  }
  if (amazonBuyOnce(doc)) {
    // Never test the subscription's price in its place.
    const once = await priceTestWaitFor(function () {
      const active = doc.querySelector('#buyBoxAccordion > .a-accordion-active');
      return active && !/^sns/i.test(active.id) ? true : null;
    }, input.timeoutMs);
    if (!once) return priceTestMissing('Compra única');
    // "Comprar agora" comes with "Compra única".
    if (!(await priceTestWaitFor(function () {
      return amazonBuyNowButton(doc);
    }, input.timeoutMs))) {
      return priceTestMissing('Comprar agora');
    }
  }
  if (amazonNoQuantity(doc)) return { ok: false, code: 'OUT_OF_STOCK' };
  const minimum = amazonPickMinimum(doc);
  if (amazonPickUnits(doc, input.units) || minimum) {
    // "Comprar agora" turns on once Amazon takes the quantity.
    await priceTestWaitFor(function () {
      const buy = amazonBuyNowButton(doc);
      return buy && !/cursorDisabled/.test(String(buy.className)) ? true : null;
    }, input.timeoutMs);
  }
  const coupon = amazonPageCoupon(doc);
  if (!coupon) return { ok: true };
  priceTestClick(coupon.el);
  if (!coupon.done) return { ok: true };
  // "Comprar agora" before Amazon takes it would leave the coupon out.
  const taken = await priceTestWaitFor(function () {
    return coupon.done.classList.contains('aok-hidden') ? null : true;
  }, input.timeoutMs);
  return taken ? { ok: true, remember: { pageCoupon: coupon.name } } : { ok: true };
}

async function amazonBuyNow(doc, input) {
  const blocked = amazonBlocker(doc);
  if (blocked) return blocked;
  const buy = amazonBuyNowButton(doc);
  if (!buy) return amazonOutOfStock(doc) ? { ok: false, code: 'OUT_OF_STOCK' } : priceTestMissing('Comprar agora');
  // The product (or the variation picked) the cleanup takes out of the cart.
  const asin = doc.querySelector('input[name="ASIN"]');
  priceTestClickSoon(buy);
  const result = { ok: true, navigates: true };
  if (asin && asin.value) result.remember = { asin: asin.value };
  return result;
}

function amazonOpenCart(doc) {
  priceTestSoon(function () {
    doc.defaultView.location.assign('https://www.amazon.com.br/gp/cart/view.html');
  });
  return Promise.resolve({ ok: true, navigates: true });
}

// The "Excluir" of the product's row in the cart (not "Salvo para mais
// tarde", which is another list).
function amazonCartDelete(doc, asin) {
  const row = doc.querySelector('#sc-active-cart [data-asin="' + asin + '"]');
  return row ? row.querySelector('input[name^="submit.delete-active"], [data-action="delete-active"] input') : null;
}

async function amazonRemoveFromCart(doc, input) {
  const blocked = amazonBlocker(doc);
  if (blocked) return blocked;
  if (!input.asin) return priceTestMissing('código do produto');
  const ready = await priceTestWaitFor(function () {
    return doc.getElementById('sc-active-cart') ? true : null;
  }, input.timeoutMs);
  if (!ready) return priceTestMissing('carrinho');
  // Rows can show after the cart's box. Not there after a moment: nothing
  // to take out.
  const found = await priceTestWaitFor(function () {
    return amazonCartDelete(doc, input.asin);
  }, Math.min(3000, input.timeoutMs));
  if (!found) return { ok: true };
  let clicks = 0;
  let lastClick = 0;
  const gone = await priceTestWaitFor(function () {
    const current = amazonCartDelete(doc, input.asin);
    if (!current) return true;
    if (clicks < 4 && Date.now() - lastClick >= 2000) {
      priceTestClick(current);
      clicks += 1;
      lastClick = Date.now();
    }
    return false;
  }, input.timeoutMs);
  return gone ? { ok: true } : priceTestMissing('Excluir');
}

// The one-page checkout has shown up: its order summary, at its address.
// The checkout and the payment page swap without reloading, and the address
// can change before the page does: both must agree.
function amazonOnCheckout(doc) {
  return /\/spc\b/i.test(doc.defaultView.location.pathname) && !!amazonSummary(doc);
}

function amazonSummary(doc) {
  const table = doc.getElementById('subtotals-marketplace-table');
  return table && priceTestIsVisible(table) ? table : null;
}

// A protection plan offered after "Comprar agora" (a side sheet or a page):
// always "Não, obrigado", never the plan.
function amazonDeclineButton(doc) {
  const panes = doc.querySelectorAll('#attach-warranty-pane, #attach-warranty-display, [id*="attach" i][id*="warranty" i], [id*="Warranty"], [role="dialog"]');
  for (const pane of panes) {
    if (!priceTestIsVisible(pane)) continue;
    const decline = Array.from(pane.querySelectorAll('button, a, [role="button"], input[type="submit"], input[type="button"]')).find(function (el) {
      return priceTestIsVisible(el) && /^(n[aã]o,? obrigad[oa]|agora n[aã]o|continuar sem)/i.test(priceTestLabelOf(el));
    });
    if (decline) return decline;
  }
  return null;
}

// "Lamentamos, esse item não está disponível no seu endereço" (/itemselect):
// Amazon doesn't deliver it to the account's address.
function amazonUndeliverable(doc) {
  return priceTestTextNodes(doc.body).some(function (node) {
    return /n[aã]o est[aá] dispon[ií]vel no seu endere[cç]o/i.test(node.nodeValue) && priceTestIsVisible(node.parentElement);
  });
}

// An import (Amazon Global) asks for an ID for customs (/kyc) before the
// checkout: "Pular por enquanto", which saves nothing, then "Continuar".
function amazonCustomsSkip(doc) {
  return (
    Array.from(doc.querySelectorAll('input[type="radio"][name^="kyc"]')).find(function (radio) {
      return /^pular por enquanto/i.test(priceTestText(priceTestRadioLabel(doc, radio)));
    }) || null
  );
}

// An import's checkout first asks which address, with the account's own
// already chosen: "Entregar neste endereço", the one under the addresses
// (the summary on top has another, as on the customs step).
function amazonAddressContinue(doc) {
  const chosen = Array.from(doc.querySelectorAll('input[type="radio"][name="destinationSubmissionUrl"]')).some(priceTestIsChosen);
  if (!chosen) return null;
  const primary = doc.getElementById('checkout-primary-continue-button-id');
  return priceTestFindClickable(primary || doc, /^entregar neste endere[cç]o$/i);
}

// The ID's form has its own "Continuar"; the summary on top has another,
// which only brings the same page back. While the page loads it sets the
// options back to the ID on file and draws them anew: let it settle, then
// find the option anew and click again until it takes.
async function amazonSkipCustoms(doc, input) {
  await amazonSettled(doc, input);
  const chosen = await amazonClickUntil(
    function () {
      const current = amazonCustomsSkip(doc);
      return !!current && priceTestIsChosen(current);
    },
    function () {
      const current = amazonCustomsSkip(doc);
      if (current) priceTestClick(priceTestRadioLabel(doc, current));
    },
    input.timeoutMs
  );
  if (!chosen) return priceTestMissing('Pular por enquanto');
  const skip = amazonCustomsSkip(doc);
  const form = skip.closest('form') || doc;
  const go = await priceTestWaitFor(function () {
    return (
      Array.from(form.querySelectorAll('button, [role="button"], input[type="submit"], input[type="button"]')).find(function (el) {
        return !el.disabled && priceTestIsVisible(el) && /^continuar$/i.test(priceTestLabelOf(el));
      }) || null
    );
  }, input.timeoutMs);
  if (!go) return priceTestMissing('Continuar');
  priceTestClickSoon(go);
  return { ok: true, navigates: true, repeat: true };
}

// What comes between "Comprar agora" and the checkout: a protection plan, a
// customs ID, an item Amazon doesn't deliver.
async function amazonSkipProtection(doc, input) {
  const blocked = amazonBlocker(doc);
  if (blocked) return blocked;
  const seen = await priceTestWaitFor(function () {
    if (amazonUndeliverable(doc)) return { undeliverable: true };
    const skip = amazonCustomsSkip(doc);
    if (skip) return { skip: skip };
    const address = amazonAddressContinue(doc);
    if (address) return { decline: address };
    const decline = amazonDeclineButton(doc);
    if (decline) return { decline: decline };
    return amazonOnCheckout(doc) ? {} : null;
  }, input.timeoutMs);
  if (!seen) return amazonBlocker(doc) || priceTestMissing('checkout');
  if (seen.undeliverable) return { ok: false, code: 'OUT_OF_STOCK' };
  if (seen.skip) return amazonSkipCustoms(doc, input);
  if (!seen.decline) return { ok: true };
  priceTestClickSoon(seen.decline);
  return { ok: true, navigates: true, repeat: true };
}

// Delivery choices: radios whose row tells the price ("GRÁTIS", "R$ 9,90"),
// one group per shipment.
function amazonShippingOptions(doc) {
  return Array.from(doc.querySelectorAll('fieldset input[type="radio"]'))
    .map(function (radio) {
      const label = priceTestRadioLabel(doc, radio);
      const text = priceTestText(label);
      return { radio: radio, label: label, text: text, cents: /gr[aá]tis/i.test(text) ? 0 : priceTestCents(text) };
    })
    .filter(function (option) {
      return option.cents !== null && !option.radio.disabled;
    });
}

// Waits for the checkout to take a change: the page goes quiet for a moment.
function amazonSettled(doc, input) {
  return priceTestSettle(
    doc,
    function () {
      return false;
    },
    800,
    Math.min(4000, input.timeoutMs)
  );
}

async function amazonPickShipping(doc, input) {
  const blocked = amazonBlocker(doc);
  if (blocked) return blocked;
  const ready = await priceTestWaitFor(function () {
    return amazonOnCheckout(doc) ? true : null;
  }, input.timeoutMs);
  if (!ready) return amazonBlocker(doc) || priceTestMissing('checkout');
  const groups = {};
  amazonShippingOptions(doc).forEach(function (option) {
    const name = option.radio.name || '';
    if (!groups[name] || option.cents < groups[name].cents) groups[name] = option;
  });
  const wanted = Object.keys(groups).map(function (name) {
    return groups[name];
  });
  if (
    wanted.every(function (option) {
      return priceTestIsChosen(option.radio);
    })
  ) {
    return { ok: true };
  }
  wanted.forEach(function (option) {
    if (!priceTestIsChosen(option.radio)) priceTestClick(option.label);
  });
  const taken = await priceTestWaitFor(function () {
    return wanted.every(function (option) {
      return option.radio.isConnected ? priceTestIsChosen(option.radio) : true;
    })
      ? true
      : null;
  }, input.timeoutMs);
  if (!taken) return priceTestMissing('frete escolhido');
  await amazonSettled(doc, input);
  return { ok: true };
}

// The payment page, with its options and the coupon box, at its address.
function amazonOnPayPage(doc) {
  return /\/pay(select)?\b/i.test(doc.defaultView.location.pathname) && doc.querySelectorAll('input[name="ppw-instrumentRowSelection"]').length > 0;
}

// "Alterar forma de pagamento" on the checkout: to the payment page.
function amazonOpenPayPage(doc) {
  const link =
    doc.querySelector('a[aria-label="Alterar forma de pagamento"]') ||
    priceTestFindClickable(doc, /^usar um cupom de desconto/i) ||
    priceTestFindClickable(doc, /^pagando com\b/i);
  if (!link) return priceTestMissing('Alterar forma de pagamento');
  priceTestClickSoon(link);
  return { ok: true, navigates: true, repeat: true };
}

// "Pagando com Pix", the checkout's payment line.
function amazonPaying(doc) {
  const node = priceTestTextNodes(doc.body).find(function (text) {
    return /^\s*pagando com\b/i.test(text.nodeValue) && priceTestIsVisible(text.parentElement);
  });
  return node ? node.nodeValue.replace(/\s+/g, ' ').trim() : '';
}

function amazonPaysWithPix(doc) {
  return /^pagando com pix\b/i.test(amazonPaying(doc));
}

// The store's answer to a code: its refusal (a visible alert under the
// field, not the hidden template) or its "aplicou com sucesso".
function amazonCouponOutcome(doc) {
  const refusal = Array.from(doc.querySelectorAll('#pmts-claim-code-error-messages [role="alert"]')).find(function (alert) {
    return priceTestIsVisible(alert) && !/^placeholder$/i.test(priceTestText(alert));
  });
  if (refusal) return { ok: true, couponRejected: priceTestText(refusal) };
  const accepted = priceTestTextNodes(doc.body).some(function (node) {
    return /aplicou com sucesso|c[oó]digo promocional (foi )?aplicado/i.test(node.nodeValue) && priceTestIsVisible(node.parentElement);
  });
  return accepted ? { ok: true } : null;
}

async function amazonApplyCoupon(doc, input) {
  const blocked = amazonBlocker(doc);
  if (blocked) return blocked;
  if (!amazonOnPayPage(doc)) {
    const ready = await priceTestWaitFor(function () {
      return amazonOnCheckout(doc) || amazonOnPayPage(doc) ? true : null;
    }, input.timeoutMs);
    if (!ready) return amazonBlocker(doc) || priceTestMissing('checkout');
    if (!amazonOnPayPage(doc)) return amazonOpenPayPage(doc);
  }
  const field = doc.querySelector('input[name="ppw-claimCode"]');
  if (!field) return priceTestMissing('campo de cupom');
  priceTestType(field, input.coupon);
  const apply = doc.querySelector('input[name="ppw-claimCodeApplyPressed"]') || priceTestFindClickable(doc, /^aplicar$/i);
  if (!apply) return priceTestMissing('Aplicar cupom');
  priceTestClick(apply);
  const outcome = await priceTestWaitFor(function () {
    return amazonCouponOutcome(doc);
  }, input.timeoutMs);
  if (!outcome) return priceTestMissing('resposta do cupom');
  return outcome;
}

function amazonPixRadio(doc) {
  return doc.querySelector('input[name="ppw-instrumentRowSelection"][value*="paymentMethod=Pix" i]');
}

// A click that lands before the page is ready does nothing: click(), at most
// a few times a couple of seconds apart, until done() holds.
function amazonClickUntil(done, click, timeoutMs) {
  let tries = 0;
  let lastTry = 0;
  return priceTestWaitFor(function () {
    if (done()) return true;
    if (tries < 4 && Date.now() - lastTry >= 2500) {
      click();
      tries += 1;
      lastTry = Date.now();
      return done() || null;
    }
    return null;
  }, timeoutMs);
}

// Pix alone: on the checkout it goes on when it already pays with Pix;
// otherwise to the payment page, where Pix is chosen (on its label, the
// way a person does) and "Use este método de pagamento" goes back. Never a
// card, never the account's balance.
async function amazonSelectPix(doc, input) {
  const blocked = amazonBlocker(doc);
  if (blocked) return blocked;
  const where = await priceTestWaitFor(function () {
    if (amazonOnPayPage(doc)) return 'pay';
    return amazonOnCheckout(doc) && amazonPaying(doc) ? 'checkout' : null;
  }, input.timeoutMs);
  if (!where) return amazonBlocker(doc) || priceTestMissing('PIX');
  if (where === 'checkout') return amazonPaysWithPix(doc) ? { ok: true } : amazonOpenPayPage(doc);
  const pix = amazonPixRadio(doc);
  if (!pix) return priceTestMissing('PIX');
  const chosen = await amazonClickUntil(
    function () {
      const current = amazonPixRadio(doc);
      return !!current && priceTestIsChosen(current);
    },
    function () {
      const current = amazonPixRadio(doc);
      if (current) priceTestClick(priceTestRadioLabel(doc, current));
    },
    input.timeoutMs
  );
  if (!chosen) return amazonBlocker(doc) || priceTestMissing('PIX selecionado');
  const back = priceTestFindClickable(doc, /^use este m[eé]todo de pagamento$/i);
  if (!back) return priceTestMissing('Use este método de pagamento');
  priceTestClickSoon(back);
  return { ok: true, navigates: true, repeat: true };
}

// The summary row starting with the term ("Total do pedido:", "Frete:"):
// its amount.
function amazonSummaryAmount(summary, term) {
  const row = Array.from(summary.querySelectorAll('li')).find(function (li) {
    return term.test(priceTestText(li));
  });
  if (!row) return null;
  const cents = priceTestCents(priceTestText(row));
  return cents === null ? null : priceTestFormat(cents);
}

// Units in the order: the quantity steppers' numbers.
function amazonQuantity(doc) {
  return Array.from(doc.querySelectorAll('fieldset[name="checkout-quantity-stepper"]')).reduce(function (sum, stepper) {
    const number = priceTestTextNodes(stepper)
      .map(function (node) {
        return node.nodeValue.trim();
      })
      .find(function (text) {
        return /^\d+$/.test(text);
      });
    return sum + (number ? Number(number) : 0);
  }, 0);
}

function amazonValues(doc) {
  if (!amazonPaysWithPix(doc)) return null;
  const summary = amazonSummary(doc);
  if (!summary) return null;
  const total = amazonSummaryAmount(summary, /^total do pedido:/i);
  if (!total) return null;
  return { total: total, shipping: amazonSummaryAmount(summary, /^frete:/i) || '' };
}

// A discount row in the summary besides Pix's own ("Desconto método de
// pagamento", "Desc. forma pgto") and the "Descontos (2)" total above them.
function amazonCouponInSummary(summary, coupon) {
  const text = priceTestText(summary);
  if (text.toUpperCase().indexOf(String(coupon).toUpperCase()) !== -1) return true;
  return Array.from(summary.querySelectorAll('li')).some(function (li) {
    const row = priceTestText(li);
    return /-\s*R\$/.test(row) && !/^descontos\s*\(|m[eé]todo de pagamento|forma (de )?(pagamento|pgto)/i.test(row);
  });
}

async function amazonReadTotals(doc, input) {
  const blocked = amazonBlocker(doc);
  if (blocked) return blocked;
  await amazonSettled(doc, input);
  const found = await priceTestWaitFor(function () {
    return amazonValues(doc);
  }, input.timeoutMs);
  if (!found) return amazonBlocker(doc) || priceTestMissing(amazonPaysWithPix(doc) ? 'Total do pedido' : 'PIX selecionado');
  const result = { ok: true, totalText: found.total, shippingText: found.shipping };
  const quantity = amazonQuantity(doc);
  if (quantity > 1) result.quantity = quantity;
  // A coupon redeemed before (on the product page, or in an earlier test)
  // is refused when typed again, yet the order counts it: the summary lists
  // its code or its discount ("15% off em YoPRO").
  if (input.coupon && amazonCouponInSummary(amazonSummary(doc), input.coupon)) result.couponApplied = true;
  return result;
}

// Where the order summary is on screen, for the picture: its card, from the
// top down to "Total do pedido" and a little under it.
async function amazonFrameTotals(doc, input) {
  const summary = await priceTestWaitFor(function () {
    return amazonSummary(doc);
  }, input.timeoutMs);
  if (!summary) return priceTestMissing('valores na tela');
  const card = summary.closest('#subtotals, .a-cardui, .a-box') || summary;
  if (typeof card.scrollIntoView === 'function') card.scrollIntoView({ block: 'start' });
  await priceTestSettled(card, Math.min(2000, input.timeoutMs));
  const outer = card.getBoundingClientRect();
  const total = Array.from(summary.querySelectorAll('li')).find(function (li) {
    return /^total do pedido:/i.test(priceTestText(li));
  });
  const bottom = total ? Math.min(outer.bottom, total.getBoundingClientRect().bottom + 16) : outer.bottom;
  const margin = 8;
  return {
    ok: true,
    area: {
      x: Math.max(0, Math.floor(outer.left - margin)),
      y: Math.max(0, Math.floor(outer.top - margin)),
      width: Math.ceil(outer.width + margin * 2),
      height: Math.max(1, Math.ceil(bottom - outer.top + margin * 2)),
      viewportWidth: doc.defaultView.innerWidth,
    },
  };
}

// The steps pelandoPriceTestStep (page.js) runs here.
function pelandoPriceTestSteps() {
  return {
    checkProduct: amazonCheckProduct,
    buyNow: amazonBuyNow,
    skipProtection: amazonSkipProtection,
    pickShipping: amazonPickShipping,
    applyCoupon: amazonApplyCoupon,
    selectPix: amazonSelectPix,
    readTotals: amazonReadTotals,
    frameTotals: amazonFrameTotals,
    openCart: amazonOpenCart,
    removeFromCart: amazonRemoveFromCart,
  };
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = {
    amazonCheckProduct,
    amazonBuyNow,
    amazonSkipProtection,
    amazonPickShipping,
    amazonApplyCoupon,
    amazonSelectPix,
    amazonReadTotals,
    amazonFrameTotals,
    amazonOpenCart,
    amazonRemoveFromCart,
    pelandoPriceTestSteps,
  };
}
