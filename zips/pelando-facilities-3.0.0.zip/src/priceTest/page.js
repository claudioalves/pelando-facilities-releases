// "Testar Promoção": what every store's steps use on the store's pages -
// reading text, finding and clicking buttons, waiting for the page - and the
// entry point pelandoPriceTestStep. The service worker
// (src/priceTest/runner.js) injects compare.js, this file and the store's
// (stores/<store>.js) into the store's tab and calls pelandoPriceTestStep(step,
// input), once per step and again after every page change: only function
// declarations at the top level, since a second const/let would throw. Each
// step answers { ok: true, ... } or { ok: false, code, detail }. No step
// finishes the purchase: every click goes through priceTestForbidden.
//
// The stores' markup isn't ours and changes, so elements are found by their
// visible text and role, not by class.

// Text nodes under root, minus the ones no reader sees: script, style,
// noscript and template contents (JSON state, CSS, fallbacks).
function priceTestTextNodes(root) {
  const nodes = [];
  const walker = root.ownerDocument.createTreeWalker(root, NodeFilter.SHOW_TEXT);
  for (let node = walker.nextNode(); node; node = walker.nextNode()) {
    if (node.parentElement && node.parentElement.closest('script, style, noscript, template')) continue;
    nodes.push(node);
  }
  return nodes;
}

// Visible text, with separate text nodes joined by a space: a summary row
// written as <span>Total</span><span>R$ 1,00</span> reads "Total R$ 1,00".
function priceTestText(el) {
  if (!el) return '';
  return priceTestTextNodes(el)
    .map(function (node) {
      return node.nodeValue;
    })
    .join(' ')
    .replace(/\s+/g, ' ')
    .trim();
}

function priceTestIsVisible(el) {
  if (!el || !el.isConnected) return false;
  if (el.closest('[hidden], [aria-hidden="true"]')) return false;
  const view = el.ownerDocument.defaultView;
  for (let node = el; node && node.nodeType === 1; node = node.parentElement) {
    const style = view.getComputedStyle(node);
    if (style.display === 'none' || style.visibility === 'hidden') return false;
  }
  return true;
}

// Amazon's buttons are inputs with no text of their own, named by the span
// their aria-labelledby points at ("Use este método de pagamento").
function priceTestLabelOf(el) {
  const own = el.tagName === 'INPUT' ? el.value : priceTestText(el);
  const named = (el.getAttribute('aria-labelledby') || '')
    .split(/\s+/)
    .filter(Boolean)
    .map(function (id) {
      return priceTestText(el.ownerDocument.getElementById(id));
    })
    .join(' ');
  const label = el.tagName === 'INPUT' && named ? named : own || el.getAttribute('aria-label') || named;
  return (label || '').replace(/\s+/g, ' ').trim();
}

function priceTestFindClickable(doc, pattern) {
  const candidates = doc.querySelectorAll('button, a, [role="button"], input[type="submit"], input[type="button"]');
  return (
    Array.from(candidates).find(function (el) {
      return !el.disabled && priceTestIsVisible(el) && pattern.test(priceTestLabelOf(el));
    }) || null
  );
}

// Buttons that would place the order. "Pagar com Pix" is a payment option,
// not the order button, so any "Pagar" not followed by "com" is refused.
// Amazon's "Comprar agora com 1-clique" orders on the spot.
// The label, the aria-label, an input's value and the title are all
// checked: any one naming the order is enough.
function priceTestForbidden(el) {
  const forbidden =
    /finalizar|confirmar (o )?(pedido|compra|pagamento)|^confirmar$|concluir (o )?(pedido|compra)|^concluir$|fazer (o )?pedido|realizar (o )?pedido|efetuar (o )?pagamento|^pagar(?! com\b)|gerar (o )?(c[oó]digo )?pix|1-clique|one-click/i;
  const names = [priceTestLabelOf(el), el.getAttribute('aria-label'), el.tagName === 'INPUT' ? el.value : '', el.getAttribute('title')];
  return names.some(function (name) {
    return forbidden.test(String(name || '').replace(/\s+/g, ' ').trim());
  });
}

function priceTestClick(el) {
  if (priceTestForbidden(el)) throw new Error('Clique recusado: "' + priceTestLabelOf(el) + '"');
  el.click();
}

// The store's tab is a background tab, where Chrome runs timers about once a
// second at most. A message-channel task isn't held back like that.
function priceTestSoon(fn) {
  const channel = new MessageChannel();
  channel.port1.onmessage = function () {
    channel.port1.close();
    fn();
  };
  channel.port2.postMessage(0);
}

// For clicks that leave the page: the step answers before the page goes,
// or the answer is lost with it.
function priceTestClickSoon(el) {
  if (priceTestForbidden(el)) throw new Error('Clique recusado: "' + priceTestLabelOf(el) + '"');
  priceTestSoon(function () {
    el.click();
  });
}

// A check that runs while the page is being swapped (no body yet) finds
// nothing, rather than failing the step.
function priceTestTryFind(find) {
  try {
    return find();
  } catch (err) {
    return null;
  }
}

// Resolves with what find() returns once it's truthy, or null after
// timeoutMs. Pages fill in after their own requests, so steps wait: find()
// runs again on every change to the page, so a button is clicked the moment
// it shows (timers crawl in background tabs). Checked radios and typed
// values change no markup: a slow timer looks too.
function priceTestWaitFor(find, timeoutMs) {
  return new Promise(function (resolve) {
    const first = priceTestTryFind(find);
    if (first || timeoutMs <= 0) {
      resolve(first || null);
      return;
    }
    let finished = false;
    function finish(value) {
      if (finished) return;
      finished = true;
      observer.disconnect();
      clearInterval(fallback);
      clearTimeout(limit);
      resolve(value || null);
    }
    function check() {
      if (finished) return;
      const found = priceTestTryFind(find);
      if (found) finish(found);
    }
    const observer = new MutationObserver(check);
    observer.observe(document.documentElement, { childList: true, subtree: true, attributes: true, characterData: true });
    const fallback = setInterval(check, 250);
    const limit = setTimeout(function () {
      finish(priceTestTryFind(find));
    }, timeoutMs);
  });
}

// Resolves once ready() holds, or the page has not changed for quietMs, or
// after maxMs at most.
function priceTestSettle(doc, ready, quietMs, maxMs) {
  return new Promise(function (resolve) {
    if (maxMs <= 0 || priceTestTryFind(ready)) {
      resolve();
      return;
    }
    let finished = false;
    let quiet = setTimeout(done, quietMs);
    const limit = setTimeout(done, maxMs);
    const observer = new MutationObserver(function () {
      if (priceTestTryFind(ready)) {
        done();
        return;
      }
      clearTimeout(quiet);
      quiet = setTimeout(done, quietMs);
    });
    observer.observe(doc.documentElement, { childList: true, subtree: true, attributes: true, characterData: true });
    function done() {
      if (finished) return;
      finished = true;
      observer.disconnect();
      clearTimeout(quiet);
      clearTimeout(limit);
      resolve();
    }
  });
}

// Resolves true once the element has stayed put on screen for 300 ms (a
// store may scroll the page again right after the test scrolled it), or null
// after timeoutMs.
function priceTestSettled(el, timeoutMs) {
  let last = null;
  let since = 0;
  return priceTestWaitFor(function () {
    const rect = el.getBoundingClientRect();
    const place = [rect.left, rect.top, rect.width, rect.height].map(Math.round).join(',');
    const now = Date.now();
    if (place !== last) {
      last = place;
      since = now;
      return null;
    }
    return now - since >= 300 ? true : null;
  }, timeoutMs);
}

// What stops any step: a login form or login route (the session expired) or a captcha
// challenge (someone has to solve it). The invisible reCAPTCHA badge is no
// challenge; its challenge frame is "bframe".
function priceTestBlocker(doc) {
  const view = doc.defaultView;
  const href = view && view.location ? String(view.location.href) : '';
  if (/\/cliente\/login|[#/]login\b/i.test(href)) return { ok: false, code: 'SESSION_EXPIRED' };
  // The stores' own verification pages (Mercado Livre's /captcha/wall,
  // Shopee's /verify/captcha and /verify/traffic).
  const path = view && view.location ? String(view.location.pathname) : '';
  if (/^\/(captcha|verify)\//i.test(path)) return { ok: false, code: 'NEEDS_HUMAN' };
  const password = Array.from(doc.querySelectorAll('input[type="password"]')).some(priceTestIsVisible);
  if (password) return { ok: false, code: 'SESSION_EXPIRED' };
  const challenges = doc.querySelectorAll(
    'iframe[src*="recaptcha/api2/bframe"], iframe[src*="recaptcha/enterprise/bframe"], iframe[src*="hcaptcha"], iframe[title*="desafio" i], iframe[title*="challenge" i]'
  );
  if (Array.from(challenges).some(priceTestIsVisible)) return { ok: false, code: 'NEEDS_HUMAN' };
  return null;
}

function priceTestMissing(element) {
  return { ok: false, code: 'SELECTOR_NOT_FOUND', detail: { element: element } };
}

// The text describing a radio: a role="radio" element's own text, an input's
// <label> (wrapping or by `for`), or else its parent.
function priceTestRadioLabel(doc, radio) {
  if (radio.tagName !== 'INPUT') return radio;
  const wrapping = radio.closest('label');
  if (wrapping) return wrapping;
  const byFor = radio.id && Array.from(doc.querySelectorAll('label')).find(function (label) {
    return label.htmlFor === radio.id;
  });
  return byFor || radio.parentElement;
}

// A hidden input inside a role="radio" wrapper is the same option: only the
// wrapper counts.
function priceTestRadios(doc) {
  const radios = Array.from(doc.querySelectorAll('input[type="radio"], [role="radio"]')).filter(function (radio) {
    return radio.tagName !== 'INPUT' || !(radio.parentElement && radio.parentElement.closest('[role="radio"]'));
  });
  return radios.map(function (radio) {
    const label = priceTestRadioLabel(doc, radio);
    return { radio: radio, label: label, text: priceTestText(label) };
  });
}

function priceTestIsChosen(radio) {
  return radio.checked === true || radio.getAttribute('aria-checked') === 'true';
}

// Typing that a React page notices: its own value setter, then the events.
function priceTestType(field, value) {
  const setter = Object.getOwnPropertyDescriptor(field.ownerDocument.defaultView.HTMLInputElement.prototype, 'value').set;
  setter.call(field, value);
  field.dispatchEvent(new field.ownerDocument.defaultView.Event('input', { bubbles: true }));
  field.dispatchEvent(new field.ownerDocument.defaultView.Event('change', { bubbles: true }));
}

// What the service worker calls after injecting this file and the store's,
// which names its steps in pelandoPriceTestSteps().
function pelandoPriceTestStep(step, input) {
  const steps = pelandoPriceTestSteps();
  if (!steps[step]) return Promise.resolve({ ok: false, code: 'STEP_FAILED', detail: { message: 'Etapa desconhecida: ' + step } });
  // A step that leaves the page flags it, so the service worker can tell the
  // next page from this one (priceTestNewPageProbe in runner.js).
  window.pelandoPriceTestLeft = false;
  return Promise.resolve()
    .then(function () {
      return steps[step](document, input);
    })
    .then(function (result) {
      if (result && result.navigates) window.pelandoPriceTestLeft = true;
      return result;
    })
    .catch(function (err) {
      return { ok: false, code: 'STEP_FAILED', detail: { message: err.message } };
    });
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = {
    priceTestTextNodes,
    priceTestText,
    priceTestIsVisible,
    priceTestLabelOf,
    priceTestFindClickable,
    priceTestForbidden,
    priceTestClick,
    priceTestSoon,
    priceTestClickSoon,
    priceTestTryFind,
    priceTestWaitFor,
    priceTestSettle,
    priceTestSettled,
    priceTestBlocker,
    priceTestMissing,
    priceTestRadioLabel,
    priceTestRadios,
    priceTestIsChosen,
    priceTestType,
    pelandoPriceTestStep,
  };
}
