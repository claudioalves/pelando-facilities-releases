// On every page of Pelando's backoffice: links to the site's chat and to
// Pelando's "recentes", each opening a new tab. In the header they sit
// centered between the page's title and "Próximo" (the group of the country
// menu); on a page without that menu, fixed at the bottom, right of the
// sidebar (whose foot holds the user menu), in the sidebar's wrapper, which
// carries the sidebar's width for the CSS. The backoffice is a single-page
// app that re-renders freely: keep one set, and put it back when a page
// drops it.
const PELANDO_BO_QUICK_LINKS_CLASS = 'pelando-bo-quick-links';
const PELANDO_BO_QUICK_LINKS_HEADER_CLASS = 'pelando-bo-quick-links--header';
const PELANDO_BO_QUICK_LINKS = [
  { text: 'Chat', url: 'https://www.pelando.com.br/chat/' },
  { text: 'Pelando recentes', url: 'https://www.pelando.com.br/recentes' },
];

// The header's group pushed to the right: the country menu (with "Próximo"
// first in it) and the bell. Each country button sits in its own span inside
// the menu.
function findHeaderRightGroup(doc) {
  const current = doc.querySelector('header button[aria-current="true"][data-slot="tooltip-trigger"]');
  const menu = current && current.parentElement && current.parentElement.parentElement;
  const group = menu && menu.parentElement;
  return group && group.parentElement && group.closest('header') ? group : null;
}

function createBackofficeQuickLinks(doc) {
  const box = doc.createElement('nav');
  box.className = PELANDO_BO_QUICK_LINKS_CLASS;
  box.setAttribute('aria-label', 'Atalhos do Pelando');
  PELANDO_BO_QUICK_LINKS.forEach(function (item) {
    const link = doc.createElement('a');
    link.className = 'pelando-bo-quick-link';
    link.href = item.url;
    link.target = '_blank';
    link.rel = 'noopener noreferrer';
    link.textContent = item.text;
    box.appendChild(link);
  });
  return box;
}

function syncBackofficeQuickLinks(doc) {
  const box = doc.querySelector('.' + PELANDO_BO_QUICK_LINKS_CLASS) || createBackofficeQuickLinks(doc);
  const group = findHeaderRightGroup(doc);
  box.classList.toggle(PELANDO_BO_QUICK_LINKS_HEADER_CLASS, !!group);
  if (group) {
    if (box.nextElementSibling !== group) group.parentElement.insertBefore(box, group);
    return;
  }
  const home = doc.querySelector('[data-slot="sidebar-wrapper"]') || doc.body;
  if (box.parentElement !== home) home.appendChild(box);
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = { syncBackofficeQuickLinks };
}
