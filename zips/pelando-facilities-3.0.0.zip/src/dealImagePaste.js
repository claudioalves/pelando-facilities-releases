// "Colar imagem" on the backoffice deal page (/promocao/{id}): next to
// "Buscar do Crawler" in "Imagem da promoção", a button that takes the image
// copied (Win+Shift+S, Chrome's "Copiar imagem"), turns it into a JPG and
// hands it to the backoffice's own #image-picker, as "Procurar arquivo"
// does: the backoffice uploads it, shows it and puts its link in the form,
// and the deal only changes when the form is saved. Ctrl+V with the focus in
// that section does the same. On every backoffice: Pelando's and Promoninja's (the same app, in other languages).
const PELANDO_IMAGE_PASTE_CLASS = 'pelando-image-paste';

// The picker ("Procurar arquivo" clicks it), the row of "Substituir imagem
// por" buttons it sits in, and the card titled "Imagem da promoção".
function findDealImageSection(doc) {
  const picker = doc.getElementById('image-picker');
  if (!picker || picker.type !== 'file') return null;
  const row = picker.parentElement;
  if (!row) return null;
  // "Buscar do Crawler", "Fetch from Crawler": the word is the same in every
  // language of the backoffice.
  const crawler =
    Array.from(row.querySelectorAll('button')).find(function (button) {
      return /crawler/i.test(button.textContent);
    }) || null;
  // Up to the card with the section's title; without that title (the
  // backoffice changed it), the column the buttons are in, never the whole
  // page (Ctrl+V would be taken everywhere).
  let card = row;
  while (card && card !== doc.body && !/imagem da promo/i.test((card.querySelector('h1, h2, h3, h4') || {}).textContent || '')) {
    card = card.parentElement;
  }
  if (!card || card === doc.body) card = row.closest('.space-y-4') || row.parentElement;
  return { picker: picker, row: row, crawler: crawler, card: card };
}

function createDealImageButton(doc, model, className, text, title, onClick) {
  const button = doc.createElement('button');
  button.type = 'button';
  // The neighbours' look (the backoffice's secondary button).
  button.className = (model ? model.className + ' ' : '') + className;
  if (model && model.getAttribute('data-slot')) button.setAttribute('data-slot', model.getAttribute('data-slot'));
  button.textContent = text;
  button.title = title;
  button.addEventListener('click', onClick);
  return button;
}

function syncDealImagePasteButton(doc, deps) {
  const found = findDealImageSection(doc);
  if (!found) return;
  const model = found.crawler || found.row.querySelector('button');
  let button = found.row.querySelector('.' + PELANDO_IMAGE_PASTE_CLASS);
  if (!button) {
    button = createDealImageButton(doc, model, PELANDO_IMAGE_PASTE_CLASS, 'Colar imagem', 'Usa a imagem copiada (Win+Shift+S ou "Copiar imagem") como imagem da promoção', function () {
      pasteDealImage(doc, deps);
    });
    if (found.crawler) found.crawler.insertAdjacentElement('afterend', button);
    else found.row.appendChild(button);
  }
  const busy = !!(found.crawler && found.crawler.disabled);
  if (button.disabled !== busy) button.disabled = busy;
  // Focusable (a click in it gives it the focus) so Ctrl+V reaches it.
  if (!found.card.pelandoImagePaste) {
    found.card.pelandoImagePaste = true;
    if (!found.card.hasAttribute('tabindex')) found.card.setAttribute('tabindex', '-1');
    found.card.addEventListener('paste', function (event) {
      onDealImagePaste(doc, deps, event);
    });
  }
}

const DEAL_IMAGE_PASTE_TYPES = ['image/png', 'image/jpeg', 'image/webp'];

const DEAL_IMAGE_PASTE_MESSAGES = {
  'no-image': 'Não há imagem copiada. Tire um print (Win+Shift+S) ou use "Copiar imagem" e tente de novo',
  denied: 'O Chrome bloqueou a leitura do que foi copiado. Clique no cadeado da barra de endereço → Área de transferência → Permitir',
  'no-picker': 'Não achei o campo de imagem do backoffice: use "Procurar arquivo"',
  'bad-image': 'Não consegui abrir a imagem copiada',
};

const DEAL_IMAGE_PASTE_NOTICE_MS = 5000;

function dealImagePasteTwo(n) {
  return String(n).padStart(2, '0');
}

// colada-2026-11-01-14h32m05s.jpg, local time.
function dealImagePasteFileName(date) {
  return (
    'colada-' + date.getFullYear() + '-' + dealImagePasteTwo(date.getMonth() + 1) + '-' + dealImagePasteTwo(date.getDate()) +
    '-' + dealImagePasteTwo(date.getHours()) + 'h' + dealImagePasteTwo(date.getMinutes()) + 'm' + dealImagePasteTwo(date.getSeconds()) + 's.jpg'
  );
}

// Below the row of buttons (found by the picker, or by our button when the
// picker is gone), one at a time, gone after 5 s.
function showDealImagePasteNotice(doc, text) {
  const found = findDealImageSection(doc);
  const button = doc.querySelector('.' + PELANDO_IMAGE_PASTE_CLASS);
  const row = found ? found.row : button && button.parentElement;
  if (!row || !row.parentElement) return;
  let note = row.parentElement.querySelector('.pelando-image-paste-notice');
  if (!note) {
    note = doc.createElement('p');
    note.className = 'pelando-image-paste-notice';
    note.setAttribute('role', 'status');
    row.insertAdjacentElement('afterend', note);
  }
  note.textContent = text;
  clearTimeout(note.pelandoTimer);
  note.pelandoTimer = setTimeout(function () {
    note.remove();
  }, DEAL_IMAGE_PASTE_NOTICE_MS);
}

// The first image among what was copied (navigator.clipboard.read()'s items).
async function readDealImageFromClipboard(deps) {
  const items = await deps.readClipboard();
  for (const item of items || []) {
    const type = DEAL_IMAGE_PASTE_TYPES.find(function (wanted) {
      return item.types.indexOf(wanted) !== -1;
    });
    if (type) return item.getType(type);
  }
  return null;
}

// The copied image (or the one pasted, `blob`), as a JPG, into the
// backoffice's picker: its "change" starts the backoffice's upload. Answers
// what happened.
async function pasteDealImage(doc, deps, blob) {
  const use = Object.assign({}, pelandoDealImagePasteDeps, deps);
  if (!findDealImageSection(doc)) {
    showDealImagePasteNotice(doc, DEAL_IMAGE_PASTE_MESSAGES['no-picker']);
    return 'no-picker';
  }
  let image = blob || null;
  if (!image) {
    try {
      image = await readDealImageFromClipboard(use);
    } catch (err) {
      showDealImagePasteNotice(doc, DEAL_IMAGE_PASTE_MESSAGES.denied);
      return 'denied';
    }
  }
  if (!image) {
    showDealImagePasteNotice(doc, DEAL_IMAGE_PASTE_MESSAGES['no-image']);
    return 'no-image';
  }
  let jpeg;
  try {
    jpeg = await use.toJpeg(image);
  } catch (err) {
    showDealImagePasteNotice(doc, DEAL_IMAGE_PASTE_MESSAGES['bad-image']);
    return 'bad-image';
  }
  // The page may have re-rendered meanwhile: the picker of now.
  const found = findDealImageSection(doc);
  if (!found) {
    showDealImagePasteNotice(doc, DEAL_IMAGE_PASTE_MESSAGES['no-picker']);
    return 'no-picker';
  }
  const file = new File([jpeg], dealImagePasteFileName(use.now()), { type: 'image/jpeg' });
  use.setFiles(found.picker, file);
  found.picker.dispatchEvent(new Event('change', { bubbles: true }));
  return 'done';
}

// Ctrl+V with the focus in the image card: the paste event carries the
// image, so Chrome asks nothing. Text pastes go through untouched.
function onDealImagePaste(doc, deps, event) {
  const files = Array.from((event.clipboardData && event.clipboardData.files) || []);
  const image = files.find(function (file) {
    return DEAL_IMAGE_PASTE_TYPES.indexOf(file.type) !== -1;
  });
  if (!image) return;
  event.preventDefault();
  pasteDealImage(doc, deps, image);
}

// What the page really uses; tests pass their own.
const pelandoDealImagePasteDeps = {
  readClipboard: function () {
    return navigator.clipboard.read();
  },
  // White behind transparent parts (a JPG has no transparency), 0.92.
  toJpeg: async function (blob) {
    const bitmap = await createImageBitmap(blob);
    const canvas = document.createElement('canvas');
    canvas.width = bitmap.width;
    canvas.height = bitmap.height;
    const context = canvas.getContext('2d');
    context.fillStyle = '#ffffff';
    context.fillRect(0, 0, canvas.width, canvas.height);
    context.drawImage(bitmap, 0, 0);
    bitmap.close();
    return new Promise(function (resolve, reject) {
      canvas.toBlob(
        function (jpeg) {
          if (jpeg) resolve(jpeg);
          else reject(new Error('toBlob'));
        },
        'image/jpeg',
        0.92
      );
    });
  },
  setFiles: function (input, file) {
    const transfer = new DataTransfer();
    transfer.items.add(file);
    input.files = transfer.files;
  },
  now: function () {
    return new Date();
  },
};

if (typeof module !== 'undefined' && module.exports) {
  module.exports = {
    PELANDO_IMAGE_PASTE_CLASS,
    DEAL_IMAGE_PASTE_MESSAGES,
    findDealImageSection,
    syncDealImagePasteButton,
    dealImagePasteFileName,
    pasteDealImage,
    pelandoDealImagePasteDeps,
  };
}
