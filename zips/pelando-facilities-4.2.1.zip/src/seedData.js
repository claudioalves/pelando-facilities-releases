// The team's quick replies, shipped with every version: a fresh install gets
// all of them, and an existing one gets those it never had (applyNewSeeds
// never brings back one a moderator deleted). Exported from the chat's
// Exportar button (pelando-chat-ext-mensagens_v3.json, 2026-11-21).
const PELANDO_CHAT_EXT_SEED_THEMES = [
  {
    "id": "saudacoes",
    "nome": "Saudações",
    "palavrasChave": []
  },
  {
    "id": "sentimos-muito",
    "nome": "Sentimos muito",
    "palavrasChave": [
      "promocao",
      "promocoes",
      "comentario",
      "comentarios"
    ]
  },
  {
    "id": "exclusao-conta",
    "nome": "Exclusão de conta",
    "palavrasChave": [
      "excluir conta",
      "deletar conta",
      "cancelar conta"
    ]
  },
  {
    "id": "cashback",
    "nome": "Cashback",
    "palavrasChave": [
      "cashback",
      "saldo",
      "reembolso"
    ]
  },
  {
    "id": "plataforma-promocoes",
    "nome": "Plataforma e Promoções",
    "palavrasChave": [
      "cadastro",
      "postar",
      "cupom",
      "devolucao",
      "parceria"
    ]
  },
  {
    "id": "moderacao-conteudo",
    "nome": "Moderação de Conteúdo",
    "palavrasChave": [
      "autopromocao",
      "ofensivo",
      "golpe",
      "banimento"
    ]
  },
  {
    "id": "top-creators",
    "nome": "Top Creators",
    "palavrasChave": [
      "top creator",
      "top creators",
      "selo exclusivo"
    ]
  },
  {
    "id": "alertas-notificacoes",
    "nome": "Alertas e Notificações",
    "palavrasChave": [
      "alerta",
      "notificacao",
      "notificacoes",
      "marketing",
      "seguir"
    ]
  },
  {
    "id": "conta-login",
    "nome": "Conta e Login",
    "palavrasChave": [
      "senha",
      "login",
      "facebook",
      "recuperar conta"
    ]
  },
  {
    "id": "reprova-promocoes",
    "nome": "Reprova de promoções",
    "palavrasChave": []
  },
  {
    "id": "reprova-comentarios",
    "nome": "Reprova de comentários",
    "palavrasChave": []
  }
];

const PELANDO_CHAT_EXT_SEED_MESSAGES = [
  {
    "id": "greeting",
    "temaId": "saudacoes",
    "nome": "Salve {nome}, tudo bem?",
    "texto": "Salve {nome}, tudo bem?"
  },
  {
    "id": "promo-sing",
    "temaId": "sentimos-muito",
    "nome": "Promoção Singular - Antes de mais nada. Me desculpe se você se sentiu mal ao ver sua promoção deletada, não foi a intenção.",
    "texto": "Antes de mais nada. Me desculpe se você se sentiu mal ao ver sua promoção deletada, não foi a intenção."
  },
  {
    "id": "promo-plural",
    "temaId": "sentimos-muito",
    "nome": "Promoção Plural - Antes de mais nada. Me desculpe se você se sentiu mal ao ver suas promoções deletadas, não foi a intenção.",
    "texto": "Antes de mais nada. Me desculpe se você se sentiu mal ao ver suas promoções deletadas, não foi a intenção."
  },
  {
    "id": "coment-sing",
    "temaId": "sentimos-muito",
    "nome": "Comentário Singular - Antes de mais nada. Me desculpe se você se sentiu mal ao ver seu comentário deletado, não foi a intenção.",
    "texto": "Antes de mais nada. Me desculpe se você se sentiu mal ao ver seu comentário deletado, não foi a intenção."
  },
  {
    "id": "coment-plural",
    "temaId": "sentimos-muito",
    "nome": "Comentário Plural - Antes de mais nada. Me desculpe se você se sentiu mal ao ver seus comentários deletados, não foi a intenção.",
    "texto": "Antes de mais nada. Me desculpe se você se sentiu mal ao ver seus comentários deletados, não foi a intenção."
  },
  {
    "id": "excluir-conta",
    "temaId": "exclusao-conta",
    "nome": "Usuário quer excluir a conta",
    "texto": "Sinto muito que você queira excluir sua conta. Aconteceu algo que posso fazer para ajudar? Se ainda assim preferir prosseguir, você pode acessar o seu perfil e ir até as configurações para realizar o processo. Conte com a gente para o que precisar!"
  },
  {
    "id": "excluir-conta-caminho",
    "temaId": "exclusao-conta",
    "nome": "Excluir conta - caminho e e-mail não validado",
    "texto": "O caminho é Perfil > Configurações > Segurança > Excluir conta. Se o seu e-mail não estiver validado, não vai dar. Nesse caso, me chama no atendimento@pelando.com.br que eu faço manualmente."
  },
  {
    "id": "devolucao-loja-parceira",
    "temaId": "plataforma-promocoes",
    "nome": "Usuário quer devolução (compra em loja parceira)",
    "texto": "O Pelando não é uma loja e não vendemos produtos. Você pode nos informar em qual loja foi efetuada a compra? Podemos tentar conseguir o contato deles para você resolver diretamente."
  },
  {
    "id": "o-que-e-pelando",
    "temaId": "plataforma-promocoes",
    "nome": "O que é o Pelando (dúvida básica)",
    "texto": "O Pelando é uma rede social que ajuda as pessoas a encontrarem produtos em promoção. Não somos uma loja e não vendemos nenhum produto — apenas conectamos lojas seguras com pessoas interessadas em economizar. Como podemos te ajudar?"
  },
  {
    "id": "loja-nao-cadastrada",
    "temaId": "plataforma-promocoes",
    "nome": "Loja não cadastrada",
    "texto": "A loja que você enviou ainda não tem cadastro no Pelando. Nosso Time fará uma análise criteriosa — prezamos muito pela segurança dos usuários. Para uma loja ser aceita, ela precisa ter boa reputação no Reclame Aqui, Consumidor.gov ou Trustpilot."
  },
  {
    "id": "como-postar-promocao",
    "temaId": "plataforma-promocoes",
    "nome": "Como postar uma promoção",
    "texto": "Será um prazer compartilhar suas promoções com a comunidade! Acesse o pelando.com.br, faça seu cadastro e clique em 'Postar'. O Time de Comunidade vai conferir se está tudo certinho e, pronto, sua promoção estará no ar! Esperamos te ver no Pelando!"
  },
  {
    "id": "parceria-comercial",
    "temaId": "plataforma-promocoes",
    "nome": "Parceria comercial / empresa interessada",
    "texto": "Para assuntos de parcerias, entre em contato pelo e-mail: comercial@pelando.com.br. Um abraço!"
  },
  {
    "id": "autopromocao-identificada",
    "temaId": "moderacao-conteudo",
    "nome": "Autopromoção identificada",
    "texto": "Nossa equipe identificou múltiplas tentativas de autopromoção que podem comprometer a experiência da comunidade. Qualquer divulgação para ganho pessoal vai contra o Código de Conduta do Pelando e pode resultar em infrações ou banimento. Podemos contar com você para manter o espaço colaborativo?"
  },
  {
    "id": "primeira-promocao-elogio",
    "temaId": "moderacao-conteudo",
    "nome": "Primeira promoção aprovada — elogio",
    "texto": "Passando para dizer que você arrasou postando sua primeira promoção! Muitas pessoas conseguiram aproveitar e economizar. Qualquer dúvida, pode me chamar. Um abraço!"
  },
  {
    "id": "primeira-promocao-dicas",
    "temaId": "moderacao-conteudo",
    "nome": "Primeira promoção gelada — dicas",
    "texto": "Que legal que você fez a sua primeira publicação! Dicas para as próximas pegarem fogo: 1. Confira se o preço está realmente bom — use a busca do Pelando para ver o histórico. 2. Não deixe informações importantes de fora: foto, título, descrição, preço e cupom. 3. Conte com o Time Pelando no chat a qualquer momento!"
  },
  {
    "id": "bloquear-usuario",
    "temaId": "moderacao-conteudo",
    "nome": "Bloquear usuário",
    "texto": "Dá pra bloquear: entra na página do perfil do usuário e toca em Bloquear. Se o comentário for contra as regras, denuncia também nos '…' do comentário, que eu ajo mais rápido."
  },
  {
    "id": "promocao-suspeita",
    "temaId": "moderacao-conteudo",
    "nome": "Promoção suspeita ou produto falso",
    "texto": "Valeu pelo alerta! O que te fez achar que é de origem duvidosa, o vendedor ou o preço? O que a gente pode fazer pra evitar isso da próxima vez? Vou pedir pro time de análise olhar."
  },
  {
    "id": "top-creators-como-se-tornar",
    "temaId": "top-creators",
    "nome": "Como se tornar um Top Creator",
    "texto": "Só é possível ser um Top Creator via convite do Time Pelando. É importante manter-se ativo(a) na comunidade, criar conteúdo de qualidade, comentar, ajudar outros usuários e ter um bom comportamento seguindo nossas diretrizes. O Time está sempre analisando!"
  },
  {
    "id": "top-creators-o-que-e",
    "temaId": "top-creators",
    "nome": "O que é o programa Top Creators",
    "texto": "Os Tops Creators dá visibilidade a Pelandeiros que se preocupam com a comunidade e criam conteúdos incríveis — publicam as melhores promoções e cupons e ajudam outros usuários com comentários pertinentes. Eles recebem um SELO EXCLUSIVO ao lado do nickname."
  },
  {
    "id": "mtz5s4wbbsfjy7",
    "temaId": "saudacoes",
    "nome": "Em que posso ajudar?",
    "texto": "Em que posso ajudar?"
  },
  {
    "id": "mtyq2g4omycd6g",
    "temaId": "saudacoes",
    "nome": "te ajudo em algo mais?",
    "texto": "te ajudo em algo mais?"
  },
  {
    "id": "mtyt0j02vauw7d",
    "temaId": "saudacoes",
    "nome": "Abraço, qualquer coisa dá um toque.",
    "texto": "Abraço, qualquer coisa dá um toque."
  },
  {
    "id": "mtyyb7b70ub9sd",
    "temaId": "saudacoes",
    "nome": "Promoção renovada.",
    "texto": "Promoção renovada."
  },
  {
    "id": "mtzgfcwch6996j",
    "temaId": "cashback",
    "nome": "Cashback não rastreado 1",
    "texto": "Entendo sua frustração :( Quando o cashback não é rastreado, geralmente é porque o clique do Pelando não foi o último validado pela loja. Isso pode acontecer por cookies antigos, carrinho cheio, alteração de aba, adblock, cupom externo ou priorização da loja por outro afiliado. Dá para investigar direitinho. É só preencher aqui: https://ajuda.pelando.com.br/cashback/formulario."
  },
  {
    "id": "mtzgfrqu75qzvn",
    "temaId": "cashback",
    "nome": "Cashback não rastreado 2",
    "texto": "Quando o cashback não aparece, significa que a loja não atribuiu o pedido ao Pelando. Isso pode ser causado por cookies antigos, último clique vindo de outro canal, mudança de aba, carrinho cheio, adblock ou priorização automática da loja. Você pode enviar aqui para análise: https://ajuda.pelando.com.br/cashback/formulario."
  },
  {
    "id": "mtzgnv569swnmr",
    "temaId": "top-creators",
    "nome": "Os Top Creators são remunerados?",
    "texto": "Os Top Creators, apesar de não terem qualquer tipo de vínculo empregatício com o Pelando, possuem alguns benefícios exclusivos. Desta forma, conseguimos recompensá-los por toda a contribuição e ajuda que prestam à comunidade."
  },
  {
    "id": "mtzgrvv333inlo",
    "temaId": "cashback",
    "nome": "Cashback Cancelado 1",
    "texto": "Vi que seu cashback foi cancelado e imagino como isso é chato. Normalmente isso acontece quando a loja entende que o último clique não ficou com o Pelando. Lembrando que, em casos de devolução, troca ou cancelamento do pedido, o cashback é cancelado automaticamente. Se não foi esse o caso, dá pra contestar! Preenche aqui pra gente analisar com a loja: https://ajuda.pelando.com.br/cashback/formulario"
  },
  {
    "id": "mtzgt3y8tvy715",
    "temaId": "cashback",
    "nome": "Cashback Cancelado 2",
    "texto": "Entendo sua frustração. Quando o cashback é cancelado, significa que a loja não validou o rastreio ou identificou alguma regra da campanha. Em situações de devolução, troca ou cancelamento do pedido, o cashback é cancelado automaticamente. Se não foi o seu caso, envie os dados aqui para revisão: https://ajuda.pelando.com.br/cashback/formulario"
  },
  {
    "id": "mtzgth1opyheov",
    "temaId": "cashback",
    "nome": "Cashback Cancelado 3",
    "texto": "Vi que seu cashback não foi aprovado. Isso pode acontecer por regras da loja, rastreamento não validado ou também quando há devolução, troca ou cancelamento da compra. Se sua compra foi finalizada normalmente, abre uma solicitação aqui: https://ajuda.pelando.com.br/cashback/formulario Vamos encaminhar pra contestação."
  },
  {
    "id": "mtzguygbepzwp1",
    "temaId": "saudacoes",
    "nome": "Abraço, tamo junto!",
    "texto": "Abraço, tamo junto!"
  },
  {
    "id": "mu1dh0mkcbiqut",
    "temaId": "saudacoes",
    "nome": "Um momento, vou verificar.",
    "texto": "Um momento, vou verificar."
  },
  {
    "id": "mu4j20hlpon40k",
    "temaId": "saudacoes",
    "nome": "Disponha, grande abraço",
    "texto": "Disponha, grande abraço"
  },
  {
    "id": "reprova-03-pelando",
    "temaId": "reprova-promocoes",
    "nome": "Preço não promocional - Mensagem Pelando",
    "texto": "Obrigado por compartilhar a oferta. Não conseguimos aceitá-la porque, na conferência, o preço não parecia promocional ou não mostrava uma economia clara para a comunidade. Para aumentar a chance de aprovação, envie quando o valor estiver abaixo do preço normal ou inclua informações que comprovem o desconto, como preço final, cupom aplicado e condições da oferta."
  },
  {
    "id": "reprova-03-alternativa",
    "temaId": "reprova-promocoes",
    "nome": "Preço não promocional - Mensagem alternativa",
    "texto": "A gente comparou o preço com o histórico do produto no Pelando e nas lojas nas últimas semanas, e o valor não ficou abaixo do que costuma aparecer. Por isso, a publicação foi recusada. Se o preço cair, ou se existir uma condição que deixe o produto mais barato (cupom, Pix, app da loja), envie de novo explicando o passo a passo que a gente revisa."
  },
  {
    "id": "reprova-03-claudio-1",
    "temaId": "reprova-promocoes",
    "nome": "Preço não promocional - Mensagem Claudio 1",
    "texto": "O analista não conseguiu chegar num preço promocional, comparei com o histórico do produto aqui no Pelando e o valor não ficou abaixo do que costuma aparecer. Se tiver cupom, Pix ou app da loja que baixa o preço, consegue postar de novo com um print chegando no valor?"
  },
  {
    "id": "reprova-03-claudio-2",
    "temaId": "reprova-promocoes",
    "nome": "Preço não promocional - Mensagem Claudio 2",
    "texto": "Recusei porque o preço tava igual ou acima do que já rolou por aqui. Dá uma olhada no histórico pela busca do Pelando antes de postar. Se cair, cria um alerta de desejo com preço alvo que eu te aviso."
  },
  {
    "id": "reprova-03-claudio-3",
    "temaId": "reprova-promocoes",
    "nome": "Preço não promocional - Mensagem Claudio 3",
    "texto": "Na conferência o preço não pareceu promoção, por isso recusei. Se tiver algum passo pra chegar no valor que você viu (cupom, frete, forma de pagamento), posta de novo contando tudo na descrição que eu revejo."
  },
  {
    "id": "reprova-01-pelando",
    "temaId": "reprova-promocoes",
    "nome": "Autopromoção - Mensagem Pelando",
    "texto": "Obrigado por compartilhar sua publicação com a comunidade. Não conseguimos aceitá-la porque identificamos sinais de benefício pessoal, como vínculo com a loja, divulgação própria ou link de afiliado. Para ser aceita na próxima vez, envie uma oferta de forma neutra, sem ganho direto para você e com informações claras de preço, loja e desconto."
  },
  {
    "id": "reprova-01-alternativa",
    "temaId": "reprova-promocoes",
    "nome": "Autopromoção - Mensagem alternativa",
    "texto": "Sua publicação foi recusada porque encontramos sinais de vínculo comercial, como link de afiliado, divulgação da sua própria loja ou outro ganho direto para quem postou. No Pelando isso não é permitido, mesmo quando a oferta é boa. Se quiser compartilhar de novo, use o link direto da loja, sem afiliado, e conte para a galera o preço, a loja e o desconto."
  },
  {
    "id": "reprova-01-claudio-1",
    "temaId": "reprova-promocoes",
    "nome": "Autopromoção - Mensagem Claudio 1",
    "texto": "Recusei sua promoção porque achei sinais de autopromoção, tipo link de afiliado, loja própria ou algum ganho direto pra quem postou. Aqui no Pelando isso não rola, mesmo com promoção boa. Se quiser postar de novo, usa o link direto da loja, sem afiliado, que eu dou uma olhada."
  },
  {
    "id": "reprova-01-claudio-2",
    "temaId": "reprova-promocoes",
    "nome": "Autopromoção - Mensagem Claudio 2",
    "texto": "Tive que recusar essa porque o link ou a publicação tinha cara de divulgação própria (afiliado, loja sua ou indicação). A regra de autopromoção vale pra todo mundo. Manda de novo com o link limpo da loja e as infos de preço que passa tranquilo."
  },
  {
    "id": "reprova-01-claudio-3",
    "temaId": "reprova-promocoes",
    "nome": "Autopromoção - Mensagem Claudio 3",
    "texto": "Vi que a promoção tinha vínculo com quem postou, como link de afiliado ou divulgação da própria loja, por isso recusei. Pode continuar compartilhando, só sem ganho pessoal no meio. Qualquer dúvida sobre a regra, me chama no chat que te explico."
  },
  {
    "id": "reprova-05-pelando",
    "temaId": "reprova-promocoes",
    "nome": "Loja ou vendedor não liberado - Mensagem Pelando",
    "texto": "Obrigado por enviar sua publicação. Não conseguimos aceitá-la porque a loja, marketplace ou vendedor ainda não está liberado no Pelando ou não atende aos critérios de confiança usados para proteger a comunidade. Para ser aceita na próxima vez, envie uma oferta de uma loja ou vendedor já verificado, ou aguarde essa loja passar pela análise."
  },
  {
    "id": "reprova-05-alternativa",
    "temaId": "reprova-promocoes",
    "nome": "Loja ou vendedor não liberado - Mensagem alternativa",
    "texto": "A loja ou o vendedor dessa oferta ainda não está liberado no Pelando: pode estar em análise, sem cadastro ou sem cumprir nossos critérios de confiança. A gente faz essa checagem para proteger quem compra pelas promoções da comunidade. Se encontrar o mesmo produto em uma loja já cadastrada, ou no vendedor oficial dentro do marketplace, pode enviar de novo."
  },
  {
    "id": "reprova-05-claudio-1",
    "temaId": "reprova-promocoes",
    "nome": "Loja ou vendedor não liberado - Mensagem Claudio 1",
    "texto": "Recusei porque essa loja ou vendedor ainda não é liberado aqui no Pelando. A gente faz essa checagem pra proteger a galera. Se achar o mesmo produto numa loja já cadastrada, ou no vendedor oficial do marketplace, pode postar de novo."
  },
  {
    "id": "reprova-05-claudio-2",
    "temaId": "reprova-promocoes",
    "nome": "Loja ou vendedor não liberado - Mensagem Claudio 2",
    "texto": "A loja que você enviou ainda não tem cadastro no Pelando. Pra uma loja ser aceita, ela precisa ter boa reputação no Reclame Aqui, Consumidor.gov ou Trustpilot. Vou deixar ela pra análise, enquanto isso posta de uma loja já liberada."
  },
  {
    "id": "reprova-05-claudio-3",
    "temaId": "reprova-promocoes",
    "nome": "Loja ou vendedor não liberado - Mensagem Claudio 3",
    "texto": "Essa eu recusei porque o vendedor não passou nos nossos critérios de segurança. Não é nada contra você, é cuidado com quem compra pelas promoções. Se encontrar em loja confiável, manda que eu aprovo."
  },
  {
    "id": "reprova-04-pelando",
    "temaId": "reprova-promocoes",
    "nome": "Promoção duplicada - Mensagem Pelando",
    "texto": "Obrigado por contribuir com a comunidade. Não conseguimos aceitar essa publicação porque a mesma oferta já havia sido compartilhada. Fazemos isso para manter o feed organizado e concentrar as informações em um só lugar. Na próxima vez, confira se a promoção já está no Pelando antes de enviar ou compartilhe uma oferta diferente."
  },
  {
    "id": "reprova-04-alternativa",
    "temaId": "reprova-promocoes",
    "nome": "Promoção duplicada - Mensagem alternativa",
    "texto": "Essa mesma oferta já estava publicada no Pelando, então a gente recusou a sua para manter tudo reunido em um só lugar. Você pode comentar na publicação que já existe para somar informações, como um cupom novo ou outra cor disponível. Se o seu preço for melhor que o da publicação existente, envie de novo e avise na descrição que o valor caiu."
  },
  {
    "id": "reprova-04-claudio-1",
    "temaId": "reprova-promocoes",
    "nome": "Promoção duplicada - Mensagem Claudio 1",
    "texto": "Essa promoção já tava publicada aqui no Pelando, por isso recusei a sua, pra deixar tudo num lugar só. Se tiver algo a mais, tipo cupom novo ou outra cor, comenta lá na que já existe que ajuda a galera."
  },
  {
    "id": "reprova-04-claudio-2",
    "temaId": "reprova-promocoes",
    "nome": "Promoção duplicada - Mensagem Claudio 2",
    "texto": "Recusei porque já tinha uma publicação igual no ar. Antes de postar, dá uma busca rápida no Pelando. Se o seu preço for melhor que o da que já existe, posta de novo avisando na descrição que o valor caiu."
  },
  {
    "id": "reprova-04-claudio-3",
    "temaId": "reprova-promocoes",
    "nome": "Promoção duplicada - Mensagem Claudio 3",
    "texto": "Já tinha alguém postado essa mesma promoção antes de você, então tive que recusar como duplicada. Continua compartilhando que você manda bem, só confere antes se ela já não tá no feed."
  },
  {
    "id": "reprova-07-pelando",
    "temaId": "reprova-promocoes",
    "nome": "Spam ou excesso de publicações - Mensagem Pelando",
    "texto": "Obrigado pelas suas contribuições. Não conseguimos aceitar essa publicação porque identificamos muitas publicações iguais ou muito parecidas em pouco tempo, o que pode prejudicar a experiência da comunidade no feed. Para ser aceito na próxima vez, envie apenas as melhores ofertas, com informações completas, e evite publicar várias promoções semelhantes de uma só vez."
  },
  {
    "id": "reprova-07-alternativa",
    "temaId": "reprova-promocoes",
    "nome": "Spam ou excesso de publicações - Mensagem alternativa",
    "texto": "Recebemos várias publicações suas, iguais ou muito parecidas, em pouco tempo, e isso acaba enchendo o feed da comunidade. Por isso, algumas foram recusadas. Escolha as melhores ofertas e envie com calma, uma de cada vez e com todas as informações."
  },
  {
    "id": "reprova-07-claudio-1",
    "temaId": "reprova-promocoes",
    "nome": "Spam ou excesso de publicações - Mensagem Claudio 1",
    "texto": "Recebi várias publicações suas iguais ou bem parecidas em pouco tempo, e isso acaba enchendo o feed. Por isso recusei algumas. Escolhe as melhores e posta com calma, uma de cada vez e com as infos completas."
  },
  {
    "id": "reprova-07-claudio-2",
    "temaId": "reprova-promocoes",
    "nome": "Spam ou excesso de publicações - Mensagem Claudio 2",
    "texto": "Recusei essa porque entrou como excesso de publicações parecidas. Não tem problema postar bastante, mas cada promoção precisa ser diferente e valer a pena pra galera."
  },
  {
    "id": "reprova-07-claudio-3",
    "temaId": "reprova-promocoes",
    "nome": "Spam ou excesso de publicações - Mensagem Claudio 3",
    "texto": "Notei uma sequência de posts muito parecidos seus, então recusei pra não lotar o feed. Prefere mandar as que têm o melhor preço, com descrição completa, que a chance de bombar é bem maior."
  },
  {
    "id": "reprova-06-pelando",
    "temaId": "reprova-promocoes",
    "nome": "Informações insuficientes - Mensagem Pelando",
    "texto": "Obrigado por compartilhar sua publicação. Não conseguimos aceitá-la porque faltaram informações ou encontramos dados que não conseguimos validar com segurança. Para ser aceita na próxima vez, revise preço, loja, link, cupom, frete e condições da oferta, deixando tudo claro para a moderação e para a comunidade."
  },
  {
    "id": "reprova-06-alternativa",
    "temaId": "reprova-promocoes",
    "nome": "Informações insuficientes - Mensagem alternativa",
    "texto": "A gente tentou conferir essa promoção, mas não conseguiu chegar no preço ou nas condições que você informou ao abrir o link. Por isso, a publicação foi recusada por inconsistência nas informações. Se tiver algum passo para chegar nesse valor, como cupom, app da loja, frete ou forma de pagamento, envie de novo contando tudo na descrição que a gente revisa."
  },
  {
    "id": "reprova-06-claudio-1",
    "temaId": "reprova-promocoes",
    "nome": "Informações insuficientes - Mensagem Claudio 1",
    "texto": "Tentei conferir sua promoção, mas não consegui chegar no preço ou nas condições que você informou, por isso recusei. Se tiver algum passo (cupom, app, frete, forma de pagamento), posta de novo contando tudo na descrição que eu reviso."
  },
  {
    "id": "reprova-06-claudio-2",
    "temaId": "reprova-promocoes",
    "nome": "Informações insuficientes - Mensagem Claudio 2",
    "texto": "Recusei porque faltou informação pra validar com segurança. Confere preço, loja, link, cupom e frete antes de postar. Se puder, manda um print chegando no valor que facilita bastante."
  },
  {
    "id": "reprova-06-claudio-3",
    "temaId": "reprova-promocoes",
    "nome": "Informações insuficientes - Mensagem Claudio 3",
    "texto": "Não consegui fechar as informações da promoção na conferência, aí tive que recusar. Me manda no chat o print chegando no preço que eu vejo o que aconteceu."
  },
  {
    "id": "reprova-02-pelando",
    "temaId": "reprova-promocoes",
    "nome": "Conteúdo sem oferta clara - Mensagem Pelando",
    "texto": "Obrigado por enviar sua publicação. Não conseguimos aceitá-la porque não identificamos uma promoção válida ou um benefício claro de economia para a comunidade. Para ser aceita na próxima vez, informe uma oferta ativa com loja, preço, desconto ou cupom, link direto e condições de uso bem claras."
  },
  {
    "id": "reprova-02-alternativa",
    "temaId": "reprova-promocoes",
    "nome": "Conteúdo sem oferta clara - Mensagem alternativa",
    "texto": "A gente olhou sua publicação, mas não encontrou uma vantagem real para a comunidade, como desconto, cupom ou preço abaixo do normal. Produtos com preço cheio, lançamentos ou divulgações não entram como promoção. Se houver uma oferta ativa, envie de novo com o link direto, o preço final e as condições para chegar nele."
  },
  {
    "id": "reprova-02-claudio-1",
    "temaId": "reprova-promocoes",
    "nome": "Conteúdo sem oferta clara - Mensagem Claudio 1",
    "texto": "Recusei porque não achei uma promoção de verdade ali: sem desconto, sem cupom e sem preço abaixo do normal. Preço cheio, lançamento ou divulgação não entram como promoção. Se tiver uma condição que deixa mais barato, posta de novo explicando o passo a passo."
  },
  {
    "id": "reprova-02-claudio-2",
    "temaId": "reprova-promocoes",
    "nome": "Conteúdo sem oferta clara - Mensagem Claudio 2",
    "texto": "Olhei sua publicação, mas não encontrei vantagem clara pra galera, então tive que recusar. Pra passar, precisa ter link direto, preço final e o que faz ela ser promoção (cupom, desconto, Pix...)."
  },
  {
    "id": "reprova-02-claudio-3",
    "temaId": "reprova-promocoes",
    "nome": "Conteúdo sem oferta clara - Mensagem Claudio 3",
    "texto": "Essa eu recusei porque não ficou claro onde estava a economia. Se tiver cupom, preço no Pix ou alguma condição especial, coloca na descrição e manda de novo que eu reviso."
  },
  {
    "id": "reprova-c01-pelando",
    "temaId": "reprova-comentarios",
    "nome": "Divulgação de plataforma concorrente - Mensagem Pelando",
    "texto": "Removemos seu comentário porque ele direcionava a comunidade para uma plataforma concorrente ou para uma vantagem fora do Pelando. Para manter a comunidade sustentável e organizada, não permitimos esse tipo de divulgação nos comentários."
  },
  {
    "id": "reprova-c01-alternativa",
    "temaId": "reprova-comentarios",
    "nome": "Divulgação de plataforma concorrente - Mensagem alternativa",
    "texto": "Seu comentário foi removido porque indicava outra plataforma de promoções ou uma vantagem fora do Pelando. Esse tipo de divulgação não é permitido nos comentários, porque é o que mantém a comunidade sustentável. Se quiser ajudar a galera, compartilhe a dica aqui mesmo, com o link da loja."
  },
  {
    "id": "reprova-c01-claudio-1",
    "temaId": "reprova-comentarios",
    "nome": "Divulgação de plataforma concorrente - Mensagem Claudio 1",
    "texto": "Removi seu comentário porque ele indicava outra plataforma de promoções. Aceitamos várias lojas, inclusive sem parceria, o problema é citar concorrente. Se quiser ajudar a galera, compartilha a dica aqui mesmo, com o link da loja."
  },
  {
    "id": "reprova-c01-claudio-2",
    "temaId": "reprova-comentarios",
    "nome": "Divulgação de plataforma concorrente - Mensagem Claudio 2",
    "texto": "Apaguei o comentário porque mencionava um concorrente. Pode (e deve) comentar que achou mais barato em loja oficial, só não cita outro site ou grupo de promoções."
  },
  {
    "id": "reprova-c01-claudio-3",
    "temaId": "reprova-comentarios",
    "nome": "Divulgação de plataforma concorrente - Mensagem Claudio 3",
    "texto": "Tive que remover porque o comentário levava pra outra plataforma de promoções. Não é pra esconder preço menor, é regra pra manter o Pelando de pé e gratuito."
  },
  {
    "id": "reprova-c07-pelando",
    "temaId": "reprova-comentarios",
    "nome": "Conteúdo ofensivo - Mensagem Pelando",
    "texto": "Removemos seu comentário porque ele continha ofensa, ataque pessoal ou linguagem que prejudica o ambiente da comunidade. Queremos manter o Pelando um espaço respeitoso, leve e útil para todo mundo."
  },
  {
    "id": "reprova-c07-alternativa",
    "temaId": "reprova-comentarios",
    "nome": "Conteúdo ofensivo - Mensagem alternativa",
    "texto": "Seu comentário foi removido porque tinha ofensa, ataque pessoal ou linguagem que pesa o clima da conversa. Pode discordar à vontade, mas sempre com respeito. Se quiser, comente de novo com outras palavras."
  },
  {
    "id": "reprova-c07-claudio-1",
    "temaId": "reprova-comentarios",
    "nome": "Conteúdo ofensivo - Mensagem Claudio 1",
    "texto": "Removi seu comentário porque tinha ofensa ou ataque pessoal. Pode discordar à vontade, mas sempre com respeito. Se quiser, comenta de novo com outras palavras."
  },
  {
    "id": "reprova-c07-claudio-2",
    "temaId": "reprova-comentarios",
    "nome": "Conteúdo ofensivo - Mensagem Claudio 2",
    "texto": "Apaguei o comentário pelo tom ofensivo. Bora manter o clima bom por aqui."
  },
  {
    "id": "reprova-c07-claudio-3",
    "temaId": "reprova-comentarios",
    "nome": "Conteúdo ofensivo - Mensagem Claudio 3",
    "texto": "Tive que remover porque o comentário passou do ponto. Sua opinião é bem-vinda, só sem ofender ninguém."
  },
  {
    "id": "reprova-12-pelando",
    "temaId": "reprova-promocoes",
    "nome": "Link inválido ou encurtado - Mensagem Pelando",
    "texto": "Obrigado por compartilhar a publicação. Não conseguimos aceitá-la porque o link enviado não permite conferir a oferta com segurança, seja por estar encurtado, quebrado ou com destino pouco claro. Para ser aceita na próxima vez, envie o link completo e direto da loja ou produto."
  },
  {
    "id": "reprova-12-alternativa",
    "temaId": "reprova-promocoes",
    "nome": "Link inválido ou encurtado - Mensagem alternativa",
    "texto": "Não conseguimos abrir ou conferir o destino do link que você enviou: ele estava encurtado, quebrado ou levava para uma página que não era a da oferta. Para a segurança da comunidade, só aceitamos links que mostram claramente para onde vão. Envie de novo com o link completo, direto da página do produto na loja."
  },
  {
    "id": "reprova-12-claudio-1",
    "temaId": "reprova-promocoes",
    "nome": "Link inválido ou encurtado - Mensagem Claudio 1",
    "texto": "Recusei porque o link tava encurtado, quebrado ou levava pra outra página. Por segurança só aceito link que mostra claramente pra onde vai. Posta de novo com o link completo, direto da página do produto."
  },
  {
    "id": "reprova-12-claudio-2",
    "temaId": "reprova-promocoes",
    "nome": "Link inválido ou encurtado - Mensagem Claudio 2",
    "texto": "Não consegui abrir o destino do seu link, então tive que recusar. Copia o endereço completo da loja (sem encurtador) e manda de novo."
  },
  {
    "id": "reprova-12-claudio-3",
    "temaId": "reprova-promocoes",
    "nome": "Link inválido ou encurtado - Mensagem Claudio 3",
    "texto": "Link encurtado ou redirecionador pode esconder o destino real, por isso recusei. Usa o link direto da loja que eu aprovo rapidinho."
  },
  {
    "id": "reprova-09-pelando",
    "temaId": "reprova-promocoes",
    "nome": "Discussão fora do formato - Mensagem Pelando",
    "texto": "Obrigado por participar da comunidade. Não conseguimos aceitar essa publicação como discussão porque o tema não ficou claro ou não se encaixa nesse formato. Para ser aceita na próxima vez, escreva uma pergunta, experiência ou comparação objetiva, com contexto suficiente para outras pessoas conseguirem ajudar."
  },
  {
    "id": "reprova-09-alternativa",
    "temaId": "reprova-promocoes",
    "nome": "Discussão fora do formato - Mensagem alternativa",
    "texto": "Sua publicação foi enviada como discussão, mas não ficou claro qual é a pergunta ou o tema da conversa. Discussões funcionam melhor quando trazem uma dúvida, uma experiência ou uma comparação, com contexto para a galera responder. Se quiser, reescreva nesse formato e envie de novo. Se for uma oferta, publique como promoção."
  },
  {
    "id": "reprova-09-claudio-1",
    "temaId": "reprova-promocoes",
    "nome": "Discussão fora do formato - Mensagem Claudio 1",
    "texto": "Sua publicação entrou como discussão, mas não ficou claro qual era a pergunta ou o tema, por isso recusei. Discussão funciona melhor com uma dúvida, experiência ou comparação. Se for promoção, posta como promoção."
  },
  {
    "id": "reprova-09-claudio-2",
    "temaId": "reprova-promocoes",
    "nome": "Discussão fora do formato - Mensagem Claudio 2",
    "texto": "Recusei porque a discussão ficou sem contexto pra galera conseguir responder. Reescreve com a pergunta bem clara e um pouco do seu caso que eu aprovo."
  },
  {
    "id": "reprova-09-claudio-3",
    "temaId": "reprova-promocoes",
    "nome": "Discussão fora do formato - Mensagem Claudio 3",
    "texto": "Essa eu recusei por estar fora do formato de discussão. Se quiser opinião da comunidade sobre um produto, conta o que você tá procurando e as opções que tá pensando."
  },
  {
    "id": "reprova-11-pelando",
    "temaId": "reprova-promocoes",
    "nome": "Oferta encerrada ou indisponível - Mensagem Pelando",
    "texto": "Obrigado por enviar a oferta. Não conseguimos aceitá-la porque, no momento da conferência, a promoção já estava encerrada, indisponível ou não chegava mais ao preço informado. Se ela voltar a funcionar, envie novamente com link, preço final e condições atualizadas."
  },
  {
    "id": "reprova-11-alternativa",
    "temaId": "reprova-promocoes",
    "nome": "Oferta encerrada ou indisponível - Mensagem alternativa",
    "texto": "Quando a gente abriu o link para conferir, a promoção já tinha acabado, o produto estava sem estoque ou o preço não era mais o informado. Por isso, a publicação foi recusada. Se a oferta voltar, envie de novo com o link e o preço atualizados."
  },
  {
    "id": "reprova-11-claudio-1",
    "temaId": "reprova-promocoes",
    "nome": "Oferta encerrada ou indisponível - Mensagem Claudio 1",
    "texto": "Quando abri o link, a promoção já tinha acabado ou o preço não era mais o informado, por isso recusei. Se voltar, posta de novo com link e preço atualizados."
  },
  {
    "id": "reprova-11-claudio-2",
    "temaId": "reprova-promocoes",
    "nome": "Oferta encerrada ou indisponível - Mensagem Claudio 2",
    "texto": "Recusei porque o produto já tava sem estoque ou com outro preço na conferência. Essas promoções acabam rápido mesmo. Cria um alerta de desejo que quando aparecer de novo eu te aviso."
  },
  {
    "id": "reprova-11-claudio-3",
    "temaId": "reprova-promocoes",
    "nome": "Oferta encerrada ou indisponível - Mensagem Claudio 3",
    "texto": "Essa já tinha encerrado quando eu fui conferir, então tive que recusar. Se ainda estiver funcionando pra você, me manda um print no chat que eu vejo se pode ser regional."
  },
  {
    "id": "reprova-c05-pelando",
    "temaId": "reprova-comentarios",
    "nome": "Link inválido ou encurtado - Mensagem Pelando",
    "texto": "Removemos seu comentário porque ele continha um link encurtado ou redirecionador. Esses links podem esconder o destino real e trazer riscos para a comunidade. Quando permitido, envie o link completo e verificável."
  },
  {
    "id": "reprova-c05-alternativa",
    "temaId": "reprova-comentarios",
    "nome": "Link inválido ou encurtado - Mensagem alternativa",
    "texto": "Seu comentário foi removido porque tinha um link encurtado ou que redireciona para outro lugar, e esse tipo de link pode esconder o destino real. Se o link for útil para a conversa, comente de novo com o endereço completo, que mostre para onde vai."
  },
  {
    "id": "reprova-c05-claudio-1",
    "temaId": "reprova-comentarios",
    "nome": "Link inválido ou encurtado - Mensagem Claudio 1",
    "texto": "Removi seu comentário porque tinha link encurtado ou redirecionador, que pode esconder o destino real. Se o link for útil, comenta de novo com o endereço completo."
  },
  {
    "id": "reprova-c05-claudio-2",
    "temaId": "reprova-comentarios",
    "nome": "Link inválido ou encurtado - Mensagem Claudio 2",
    "texto": "Apaguei por causa do link encurtado. Usa o link direto da loja que fica tudo certo."
  },
  {
    "id": "reprova-c05-claudio-3",
    "temaId": "reprova-comentarios",
    "nome": "Link inválido ou encurtado - Mensagem Claudio 3",
    "texto": "Tive que remover porque não dava pra ver pra onde o link levava. Por segurança, só deixo link completo e verificável."
  },
  {
    "id": "reprova-c12-pelando",
    "temaId": "reprova-comentarios",
    "nome": "Conteúdo político - Mensagem Pelando",
    "texto": "Ocultamos ou removemos seu comentário porque ele desviava a conversa para discussão política fora do foco da comunidade. O Pelando é um espaço voltado a promoções, compras e economia."
  },
  {
    "id": "reprova-c12-alternativa",
    "temaId": "reprova-comentarios",
    "nome": "Conteúdo político - Mensagem alternativa",
    "texto": "Seu comentário foi ocultado ou removido porque levava a conversa para política, e no Pelando combinamos de deixar esse assunto de fora para evitar brigas. Pode continuar comentando sobre a oferta, o produto ou a sua experiência de compra."
  },
  {
    "id": "reprova-c12-claudio-1",
    "temaId": "reprova-comentarios",
    "nome": "Conteúdo político - Mensagem Claudio 1",
    "texto": "Ocultei seu comentário porque levava a conversa pra política, e aqui a gente deixa esse assunto de fora pra evitar briga. Pode continuar comentando sobre a promoção e o produto."
  },
  {
    "id": "reprova-c12-claudio-2",
    "temaId": "reprova-comentarios",
    "nome": "Conteúdo político - Mensagem Claudio 2",
    "texto": "Removi o comentário por ser político. O Pelando é fórum de promoção, não de debate. Comenta sobre o produto que fica tudo certo."
  },
  {
    "id": "reprova-c12-claudio-3",
    "temaId": "reprova-comentarios",
    "nome": "Conteúdo político - Mensagem Claudio 3",
    "texto": "Tive que ocultar o comentário porque fugia pra política. Não é nada pessoal, vale pra todo mundo."
  },
  {
    "id": "reprova-c11-pelando",
    "temaId": "reprova-comentarios",
    "nome": "Spam ou excesso de comentários - Mensagem Pelando",
    "texto": "Removemos seu comentário porque ele fazia parte de um padrão de spam, repetição ou flood. Comentários repetidos, automatizados ou em excesso atrapalham a conversa e a experiência da comunidade."
  },
  {
    "id": "reprova-c11-alternativa",
    "temaId": "reprova-comentarios",
    "nome": "Spam ou excesso de comentários - Mensagem alternativa",
    "texto": "Seu comentário foi removido porque fazia parte de uma sequência de comentários repetidos ou em excesso, e isso atrapalha a conversa. Se tiver algo a acrescentar, deixe um comentário só, com a informação completa."
  },
  {
    "id": "reprova-c11-claudio-1",
    "temaId": "reprova-comentarios",
    "nome": "Spam ou excesso de comentários - Mensagem Claudio 1",
    "texto": "Removi seu comentário porque fazia parte de uma sequência de comentários repetidos, e isso atrapalha a conversa. Se tiver algo a acrescentar, deixa um comentário só, com a info completa."
  },
  {
    "id": "reprova-c11-claudio-2",
    "temaId": "reprova-comentarios",
    "nome": "Spam ou excesso de comentários - Mensagem Claudio 2",
    "texto": "Apaguei por flood. Um comentário bem completo ajuda mais a galera do que vários iguais."
  },
  {
    "id": "reprova-c11-claudio-3",
    "temaId": "reprova-comentarios",
    "nome": "Spam ou excesso de comentários - Mensagem Claudio 3",
    "texto": "Tive que remover porque o comentário tava repetido várias vezes. Pode comentar de novo, só uma vez."
  },
  {
    "id": "reprova-c02-pelando",
    "temaId": "reprova-comentarios",
    "nome": "Contato externo não permitido - Mensagem Pelando",
    "texto": "Removemos seu comentário porque ele convidava ou direcionava pessoas para contato fora do Pelando, como WhatsApp, Telegram, Instagram, Discord, e-mail, telefone, direct ou grupos externos. Essa regra ajuda a proteger a comunidade contra golpes e abordagens indevidas."
  },
  {
    "id": "reprova-c02-alternativa",
    "temaId": "reprova-comentarios",
    "nome": "Contato externo não permitido - Mensagem alternativa",
    "texto": "Seu comentário foi removido porque chamava pessoas para conversar fora do Pelando, como WhatsApp, Telegram, Instagram, Discord, e-mail ou grupos. Esse tipo de contato é muito usado em golpes, por isso não é permitido. Se quiser ajudar alguém, responda por aqui mesmo, nos comentários."
  },
  {
    "id": "reprova-c02-claudio-1",
    "temaId": "reprova-comentarios",
    "nome": "Contato externo não permitido - Mensagem Claudio 1",
    "texto": "Removi seu comentário porque chamava a galera pra conversar fora do Pelando, tipo WhatsApp, Telegram, Instagram ou grupo. Esse tipo de contato é muito usado em golpe. Se quiser ajudar alguém, responde por aqui mesmo."
  },
  {
    "id": "reprova-c02-claudio-2",
    "temaId": "reprova-comentarios",
    "nome": "Contato externo não permitido - Mensagem Claudio 2",
    "texto": "Apaguei o comentário por ter contato externo. É pra proteger a galera. Qualquer coisa, pode continuar a conversa nos comentários."
  },
  {
    "id": "reprova-c02-claudio-3",
    "temaId": "reprova-comentarios",
    "nome": "Contato externo não permitido - Mensagem Claudio 3",
    "texto": "Tive que remover porque tinha número, perfil ou grupo externo no comentário. Comenta de novo sem essa parte que fica tudo certo."
  },
  {
    "id": "reprova-10-pelando",
    "temaId": "reprova-promocoes",
    "nome": "Divulgação de plataforma concorrente - Mensagem Pelando",
    "texto": "Obrigado por compartilhar sua publicação. Não conseguimos aceitá-la porque ela divulga ou direciona para uma plataforma concorrente, o que não é permitido no Pelando. Para ser aceita na próxima vez, envie a oferta diretamente, sem menções, convites ou links para outros serviços de promoções."
  },
  {
    "id": "reprova-10-alternativa",
    "temaId": "reprova-promocoes",
    "nome": "Divulgação de plataforma concorrente - Mensagem alternativa",
    "texto": "Sua publicação menciona ou leva para outra plataforma de promoções, e esse tipo de divulgação não é permitido no Pelando, porque é o que mantém a comunidade sustentável. Se a oferta for boa, envie de novo com o link direto da loja, sem citar outros sites, grupos ou canais de promoção."
  },
  {
    "id": "reprova-10-claudio-1",
    "temaId": "reprova-promocoes",
    "nome": "Divulgação de plataforma concorrente - Mensagem Claudio 1",
    "texto": "Recusei porque a publicação mencionava ou levava pra outra plataforma de promoções, e isso não é permitido aqui. Se a promoção for boa, posta de novo só com o link direto da loja, sem citar outros sites, grupos ou canais."
  },
  {
    "id": "reprova-10-claudio-2",
    "temaId": "reprova-promocoes",
    "nome": "Divulgação de plataforma concorrente - Mensagem Claudio 2",
    "texto": "Tive que recusar por divulgação de concorrente. Aceitamos várias lojas, o problema é só citar outro site ou grupo de promoções. Tira essa parte e manda de novo."
  },
  {
    "id": "reprova-10-claudio-3",
    "temaId": "reprova-promocoes",
    "nome": "Divulgação de plataforma concorrente - Mensagem Claudio 3",
    "texto": "Sua publicação direcionava pra outro serviço de promoções, por isso recusei. É o que mantém o Pelando de pé e gratuito pra galera. Manda a promoção direto da loja que passa."
  },
  {
    "id": "reprova-r01-pelando",
    "temaId": "reprova-promocoes",
    "nome": "Review sem conteúdo - Mensagem Pelando",
    "texto": "Obrigado por compartilhar seu review com a comunidade. Não conseguimos aceitá-lo porque ele não apresenta uma análise, experiência de uso, opinião ou informações que ajudem outros usuários. Apenas imagens ou vídeos do produto, especialmente materiais da própria loja ou fabricante, não são suficientes para caracterizar um review. Para aumentar a chance de aprovação, conte sua experiência, destaque pontos positivos e negativos, faça comparações ou compartilhe informações que realmente agreguem valor para a comunidade."
  },
  {
    "id": "reprova-r01-alternativa",
    "temaId": "reprova-promocoes",
    "nome": "Review sem conteúdo - Mensagem alternativa",
    "texto": "Sua publicação foi enviada como review, mas trazia só fotos ou vídeos do produto, sem contar como foi a sua experiência. Um review precisa de opinião própria: o que você achou, pontos positivos e negativos, comparações. Se quiser, reescreva contando sua experiência e envie de novo. Se era uma oferta, publique como promoção."
  },
  {
    "id": "reprova-r01-claudio-1",
    "temaId": "reprova-promocoes",
    "nome": "Review sem conteúdo - Mensagem Claudio 1",
    "texto": "Sua publicação entrou como review, mas tinha só fotos ou vídeos do produto, sem contar sua experiência, por isso recusei. Review precisa da sua opinião: o que achou, pontos positivos e negativos. Reescreve contando e manda de novo."
  },
  {
    "id": "reprova-r01-claudio-2",
    "temaId": "reprova-promocoes",
    "nome": "Review sem conteúdo - Mensagem Claudio 2",
    "texto": "Recusei porque o review não tinha análise sua, só material da loja. Conta como foi usar o produto que a galera adora esse tipo de conteúdo."
  },
  {
    "id": "reprova-r01-claudio-3",
    "temaId": "reprova-promocoes",
    "nome": "Review sem conteúdo - Mensagem Claudio 3",
    "texto": "Essa eu recusei porque faltou a parte mais importante do review: a sua experiência. Se era promoção, posta como promoção."
  },
  {
    "id": "reprova-13-pelando",
    "temaId": "reprova-promocoes",
    "nome": "Cupom inválido ou expirado - Mensagem Pelando",
    "texto": "Obrigado por enviar o cupom. Não conseguimos aceitá-lo porque o código não funcionou, estava expirado ou não levou ao benefício informado durante a conferência. Para ser aceito na próxima vez, teste o cupom antes de publicar e informe as condições de uso, como valor mínimo, app, categoria, validade ou usuários elegíveis."
  },
  {
    "id": "reprova-13-alternativa",
    "temaId": "reprova-promocoes",
    "nome": "Cupom inválido ou expirado - Mensagem alternativa",
    "texto": "A gente testou o cupom na conferência, mas ele não funcionou, estava expirado ou não deu o desconto informado. Por isso, a publicação foi recusada. Se o cupom tiver alguma regra, como valor mínimo, primeira compra, uso só no app ou categoria específica, envie de novo explicando que a gente testa outra vez."
  },
  {
    "id": "reprova-13-claudio-1",
    "temaId": "reprova-promocoes",
    "nome": "Cupom inválido ou expirado - Mensagem Claudio 1",
    "texto": "Testei o cupom na conferência e ele não funcionou, já tinha expirado ou não deu o desconto informado, por isso recusei. Se o cupom tiver alguma regra (valor mínimo, primeira compra, só no app), posta de novo explicando que eu testo outra vez."
  },
  {
    "id": "reprova-13-claudio-2",
    "temaId": "reprova-promocoes",
    "nome": "Cupom inválido ou expirado - Mensagem Claudio 2",
    "texto": "Recusei porque o código não aplicou aqui. Às vezes é regional ou só pra algumas contas: se funcionou pra você, me manda um print no chat que eu vejo."
  },
  {
    "id": "reprova-13-claudio-3",
    "temaId": "reprova-promocoes",
    "nome": "Cupom inválido ou expirado - Mensagem Claudio 3",
    "texto": "O cupom já tinha encerrado quando fui conferir, por isso recusei. Esses cupons acabam rapidinho mesmo. Testa antes de postar e coloca as condições de uso na descrição."
  },
  {
    "id": "reprova-16-pelando",
    "temaId": "reprova-promocoes",
    "nome": "Produto ou categoria não permitido - Mensagem Pelando",
    "texto": "Obrigado por enviar sua publicação. Não conseguimos aceitá-la porque esse produto ou categoria não atende aos critérios atuais do Pelando. Para aumentar a chance de aprovação na próxima vez, envie itens permitidos, de lojas confiáveis, com oferta clara e informações completas."
  },
  {
    "id": "reprova-16-alternativa",
    "temaId": "reprova-promocoes",
    "nome": "Produto ou categoria não permitido - Mensagem alternativa",
    "texto": "Esse produto ou categoria não está entre os que aceitamos hoje no Pelando, mesmo com desconto. Por isso, a publicação foi recusada. Você pode continuar compartilhando outras ofertas, de itens permitidos e lojas confiáveis."
  },
  {
    "id": "reprova-16-claudio-1",
    "temaId": "reprova-promocoes",
    "nome": "Produto ou categoria não permitido - Mensagem Claudio 1",
    "texto": "Recusei porque esse produto ou categoria não está entre os que aceitamos hoje no Pelando, mesmo com desconto. Pode continuar compartilhando outras promoções de itens permitidos."
  },
  {
    "id": "reprova-16-claudio-2",
    "temaId": "reprova-promocoes",
    "nome": "Produto ou categoria não permitido - Mensagem Claudio 2",
    "texto": "Essa categoria não entra aqui no Pelando, por isso recusei. Não é nada com você, é regra geral da plataforma."
  },
  {
    "id": "reprova-16-claudio-3",
    "temaId": "reprova-promocoes",
    "nome": "Produto ou categoria não permitido - Mensagem Claudio 3",
    "texto": "Tive que recusar porque o item não é permitido aqui. Se tiver dúvida sobre o que pode ou não postar, me chama no chat."
  },
  {
    "id": "reprova-c03-pelando",
    "temaId": "reprova-comentarios",
    "nome": "Autopromoção - Mensagem Pelando",
    "texto": "Removemos seu comentário porque ele parecia divulgar algo com benefício próprio, como loja, canal, serviço, venda recorrente, cupom próprio, comissão ou indicação. No Pelando, as contribuições precisam ser genuínas e úteis para a comunidade."
  },
  {
    "id": "reprova-c03-alternativa",
    "temaId": "reprova-comentarios",
    "nome": "Autopromoção - Mensagem alternativa",
    "texto": "Seu comentário foi removido porque parecia divulgar algo seu, como loja, canal, serviço ou venda, com benefício próprio. Nos comentários, a ideia é trocar dicas e experiências de forma genuína. Pode continuar participando, só sem divulgação própria."
  },
  {
    "id": "reprova-c03-claudio-1",
    "temaId": "reprova-comentarios",
    "nome": "Autopromoção - Mensagem Claudio 1",
    "texto": "Removi seu comentário porque parecia divulgar algo seu, tipo loja, canal, serviço ou venda. Nos comentários a ideia é trocar dica e experiência de forma genuína."
  },
  {
    "id": "reprova-c03-claudio-2",
    "temaId": "reprova-comentarios",
    "nome": "Autopromoção - Mensagem Claudio 2",
    "texto": "Apaguei por autopromoção. Pode continuar participando à vontade, só sem divulgar coisa própria."
  },
  {
    "id": "reprova-c03-claudio-3",
    "temaId": "reprova-comentarios",
    "nome": "Autopromoção - Mensagem Claudio 3",
    "texto": "Tive que remover o comentário porque tinha divulgação com benefício próprio. Se tiver uma dica útil sobre a promoção, comenta de novo sem essa parte."
  },
  {
    "id": "reprova-c16-pelando",
    "temaId": "reprova-comentarios",
    "nome": "Comentário fora do contexto - Mensagem Pelando",
    "texto": "Removemos seu comentário porque ele estava fora do contexto da conversa e não contribuía para a discussão da promoção. Tente manter os comentários relacionados à oferta, ao produto ou à experiência de compra."
  },
  {
    "id": "reprova-c16-alternativa",
    "temaId": "reprova-comentarios",
    "nome": "Comentário fora do contexto - Mensagem alternativa",
    "texto": "Seu comentário foi removido porque não tinha relação com a oferta nem ajudava na conversa. Os comentários funcionam melhor quando falam do produto, da loja ou da experiência de compra."
  },
  {
    "id": "reprova-c16-claudio-1",
    "temaId": "reprova-comentarios",
    "nome": "Comentário fora do contexto - Mensagem Claudio 1",
    "texto": "Removi seu comentário porque não tinha relação com a promoção nem ajudava na conversa. Os comentários funcionam melhor falando do produto, da loja ou da experiência de compra."
  },
  {
    "id": "reprova-c16-claudio-2",
    "temaId": "reprova-comentarios",
    "nome": "Comentário fora do contexto - Mensagem Claudio 2",
    "texto": "Apaguei por estar fora do contexto. Pode comentar de novo falando da promoção."
  },
  {
    "id": "reprova-c16-claudio-3",
    "temaId": "reprova-comentarios",
    "nome": "Comentário fora do contexto - Mensagem Claudio 3",
    "texto": "Tive que remover o comentário porque fugiu do assunto da promoção. Bora manter a conversa útil pra galera."
  },
  {
    "id": "reprova-23-pelando",
    "temaId": "reprova-promocoes",
    "nome": "Conteúdo ofensivo - Mensagem Pelando",
    "texto": "Obrigado por participar da comunidade. Não conseguimos aceitar essa publicação porque ela contém linguagem ou abordagem que pode ser ofensiva ou desrespeitosa. Para ser aceita na próxima vez, reescreva o conteúdo com tom respeitoso e foco em ajudar a comunidade."
  },
  {
    "id": "reprova-23-alternativa",
    "temaId": "reprova-promocoes",
    "nome": "Conteúdo ofensivo - Mensagem alternativa",
    "texto": "Sua publicação tinha linguagem ou tom que pode ofender outras pessoas, e por isso a gente recusou. Queremos que o Pelando seja um espaço respeitoso para todo mundo. Se quiser, reescreva o conteúdo com outras palavras e envie de novo."
  },
  {
    "id": "reprova-23-claudio-1",
    "temaId": "reprova-promocoes",
    "nome": "Conteúdo ofensivo - Mensagem Claudio 1",
    "texto": "Recusei porque a publicação tinha linguagem ou tom que pode ofender outras pessoas. Quero o Pelando um lugar tranquilo pra todo mundo. Reescreve com outras palavras e manda de novo."
  },
  {
    "id": "reprova-23-claudio-2",
    "temaId": "reprova-promocoes",
    "nome": "Conteúdo ofensivo - Mensagem Claudio 2",
    "texto": "Essa eu recusei pelo tom ofensivo. A promoção pode até ser boa, só precisa ser postada com respeito."
  },
  {
    "id": "reprova-23-claudio-3",
    "temaId": "reprova-promocoes",
    "nome": "Conteúdo ofensivo - Mensagem Claudio 3",
    "texto": "Tive que recusar por conteúdo ofensivo. Pode continuar compartilhando, só ajusta a forma de escrever."
  },
  {
    "id": "reprova-08-pelando",
    "temaId": "reprova-promocoes",
    "nome": "Verificação de segurança - Mensagem Pelando",
    "texto": "Obrigado por enviar sua publicação. Não conseguimos aceitá-la porque encontramos sinais que impediram uma validação segura da oferta. Para tentar novamente, revise o conteúdo, use um link direto e confiável, informe preço e condições com clareza e evite qualquer vínculo, repetição ou padrão que possa parecer artificial."
  },
  {
    "id": "reprova-08-alternativa",
    "temaId": "reprova-promocoes",
    "nome": "Verificação de segurança - Mensagem alternativa",
    "texto": "Na conferência, essa publicação mostrou sinais que a gente não conseguiu validar com segurança, como link com destino estranho, padrão repetido ou vínculo que não ficou claro. Para proteger a comunidade de golpes, preferimos recusar. Se a oferta for legítima, envie de novo com o link direto da loja e as informações completas de preço e condições."
  },
  {
    "id": "reprova-08-claudio-1",
    "temaId": "reprova-promocoes",
    "nome": "Verificação de segurança - Mensagem Claudio 1",
    "texto": "Recusei porque a publicação mostrou sinais que eu não consegui validar com segurança, tipo link com destino estranho ou padrão repetido. Prefiro pecar pelo cuidado pra proteger a galera de golpe. Se a promoção for legítima, manda de novo com o link direto da loja."
  },
  {
    "id": "reprova-08-claudio-2",
    "temaId": "reprova-promocoes",
    "nome": "Verificação de segurança - Mensagem Claudio 2",
    "texto": "Na conferência essa promoção acendeu um alerta de segurança, por isso recusei. Se achar que foi engano, me chama no chat que eu olho com calma."
  },
  {
    "id": "reprova-08-claudio-3",
    "temaId": "reprova-promocoes",
    "nome": "Verificação de segurança - Mensagem Claudio 3",
    "texto": "Tive que recusar por segurança: alguns sinais da publicação não bateram. Posta de novo usando link direto da loja, com preço e condições claros, que eu reviso."
  },
  {
    "id": "reprova-c14-pelando",
    "temaId": "reprova-comentarios",
    "nome": "Negociação entre usuários - Mensagem Pelando",
    "texto": "Removemos seu comentário porque ele tentava negociar compra, venda ou troca diretamente com outros usuários. Para proteger a comunidade, esse tipo de negociação não deve acontecer nos comentários."
  },
  {
    "id": "reprova-c14-alternativa",
    "temaId": "reprova-comentarios",
    "nome": "Negociação entre usuários - Mensagem alternativa",
    "texto": "Seu comentário foi removido porque tentava comprar, vender ou trocar algo diretamente com outros usuários. Essas negociações não têm nenhuma proteção e abrem espaço para golpes, por isso não são permitidas nos comentários."
  },
  {
    "id": "reprova-c14-claudio-1",
    "temaId": "reprova-comentarios",
    "nome": "Negociação entre usuários - Mensagem Claudio 1",
    "texto": "Removi seu comentário porque tentava comprar, vender ou trocar algo direto com outro usuário. Essas negociações não têm proteção nenhuma e abrem espaço pra golpe."
  },
  {
    "id": "reprova-c14-claudio-2",
    "temaId": "reprova-comentarios",
    "nome": "Negociação entre usuários - Mensagem Claudio 2",
    "texto": "Apaguei por negociação entre usuários. Pra proteger a galera, isso não pode rolar nos comentários."
  },
  {
    "id": "reprova-c14-claudio-3",
    "temaId": "reprova-comentarios",
    "nome": "Negociação entre usuários - Mensagem Claudio 3",
    "texto": "Tive que remover porque o comentário oferecia venda ou troca. Se tiver um produto à venda, compartilha só promoções de lojas confiáveis aqui."
  },
  {
    "id": "reprova-15-pelando",
    "temaId": "reprova-promocoes",
    "nome": "Categoria com critérios específicos - Mensagem Pelando",
    "texto": "Obrigado por enviar sua publicação. Não conseguimos aceitá-la porque essa categoria tem critérios extras de aprovação e, neste caso, eles não foram atendidos. Para ser aceita na próxima vez, envie detalhes que comprovem a relevância da oferta, validade, abrangência, funcionamento e benefício real para a comunidade."
  },
  {
    "id": "reprova-15-alternativa",
    "temaId": "reprova-promocoes",
    "nome": "Categoria com critérios específicos - Mensagem alternativa",
    "texto": "Algumas categorias, como ebooks, cursos, workshops, bugs de preço e ofertas de loja física, têm critérios extras para entrar no Pelando, e essa publicação não atendeu a eles. A gente costuma aprovar quando o benefício é real, vale para muita gente e tem chance de ser honrado pela loja. Se a sua oferta cumpre esses pontos, envie de novo mostrando a validade, a abrangência e a economia."
  },
  {
    "id": "reprova-15-claudio-1",
    "temaId": "reprova-promocoes",
    "nome": "Categoria com critérios específicos - Mensagem Claudio 1",
    "texto": "Essa categoria tem critérios extras pra entrar no Pelando (ebook, curso, bug de preço, loja física...), e essa publicação não atendeu, por isso recusei. Aprovo quando o benefício é real, vale pra muita gente e a loja tem chance de honrar."
  },
  {
    "id": "reprova-15-claudio-2",
    "temaId": "reprova-promocoes",
    "nome": "Categoria com critérios específicos - Mensagem Claudio 2",
    "texto": "Recusei porque, nessa categoria, preciso de mais detalhes pra aprovar: validade, abrangência e economia de verdade. Se a sua promoção cumpre isso, posta de novo mostrando esses pontos."
  },
  {
    "id": "reprova-15-claudio-3",
    "temaId": "reprova-promocoes",
    "nome": "Categoria com critérios específicos - Mensagem Claudio 3",
    "texto": "Tive que recusar porque não bateu com os critérios específicos dessa categoria. Se tiver dúvida sobre o que entra, me chama no chat que te explico."
  },
  {
    "id": "reprova-c04-pelando",
    "temaId": "reprova-comentarios",
    "nome": "Código ou afiliado pessoal - Mensagem Pelando",
    "texto": "Removemos seu comentário porque ele continha código, indicação ou link que poderia gerar benefício pessoal para quem compartilhou. Para preservar a confiança da comunidade, não permitimos divulgação de indicação, afiliado ou comissão pessoal."
  },
  {
    "id": "reprova-c04-alternativa",
    "temaId": "reprova-comentarios",
    "nome": "Código ou afiliado pessoal - Mensagem alternativa",
    "texto": "Seu comentário foi removido porque tinha código de indicação, cupom pessoal ou link de afiliado, que gera benefício para quem compartilha. Isso não é permitido no Pelando, para manter a confiança da comunidade. Se souber de um cupom público da loja, pode comentar sem problemas."
  },
  {
    "id": "reprova-c04-claudio-1",
    "temaId": "reprova-comentarios",
    "nome": "Código ou afiliado pessoal - Mensagem Claudio 1",
    "texto": "Removi seu comentário porque tinha código de indicação, cupom pessoal ou link de afiliado. Isso gera ganho pra quem compartilha e não é permitido aqui. Se souber de cupom público da loja, pode comentar tranquilo."
  },
  {
    "id": "reprova-c04-claudio-2",
    "temaId": "reprova-comentarios",
    "nome": "Código ou afiliado pessoal - Mensagem Claudio 2",
    "texto": "Apaguei por ter link ou código pessoal. A regra de autopromoção vale pros comentários também."
  },
  {
    "id": "reprova-c04-claudio-3",
    "temaId": "reprova-comentarios",
    "nome": "Código ou afiliado pessoal - Mensagem Claudio 3",
    "texto": "Tive que remover porque o comentário tinha indicação com benefício pessoal. Cupom aberto pra todo mundo pode, código seu não."
  },
  {
    "id": "reprova-c06-pelando",
    "temaId": "reprova-comentarios",
    "nome": "Verificação de segurança - Mensagem Pelando",
    "texto": "Removemos seu comentário porque ele continha um link ou domínio com sinais de risco, como site falso, tentativa de golpe, phishing ou endereço que imita uma loja conhecida. Fazemos isso para proteger a comunidade."
  },
  {
    "id": "reprova-c06-alternativa",
    "temaId": "reprova-comentarios",
    "nome": "Verificação de segurança - Mensagem alternativa",
    "texto": "Seu comentário foi removido porque tinha um link ou site com sinais de risco, como página falsa, tentativa de golpe ou endereço parecido com o de uma loja conhecida. A gente faz isso para proteger a comunidade. Se achar que foi um engano, fale com o nosso suporte."
  },
  {
    "id": "reprova-c06-claudio-1",
    "temaId": "reprova-comentarios",
    "nome": "Verificação de segurança - Mensagem Claudio 1",
    "texto": "Removi seu comentário porque tinha um link com sinais de risco, tipo site falso ou endereço parecido com loja conhecida. Faço isso pra proteger a galera. Se achar que foi engano, me chama no chat."
  },
  {
    "id": "reprova-c06-claudio-2",
    "temaId": "reprova-comentarios",
    "nome": "Verificação de segurança - Mensagem Claudio 2",
    "texto": "Apaguei por segurança: o link parecia golpe. Se é um site que você confia, me manda no chat que eu verifico."
  },
  {
    "id": "reprova-c06-claudio-3",
    "temaId": "reprova-comentarios",
    "nome": "Verificação de segurança - Mensagem Claudio 3",
    "texto": "Tive que remover o comentário por causa de um domínio suspeito. Melhor pecar pelo cuidado com a comunidade."
  },
  {
    "id": "reprova-c17-pelando",
    "temaId": "reprova-comentarios",
    "nome": "Outro motivo informado pela moderação - Mensagem Pelando",
    "texto": "Removemos seu comentário por um motivo específico avaliado pela moderação. Consulte a observação enviada junto com esta decisão para entender melhor o caso."
  },
  {
    "id": "reprova-c17-alternativa",
    "temaId": "reprova-comentarios",
    "nome": "Outro motivo informado pela moderação - Mensagem alternativa",
    "texto": "Seu comentário foi removido por um motivo específico, avaliado caso a caso pela moderação. Se quiser entender melhor o que aconteceu, fale com o nosso suporte que a gente explica."
  },
  {
    "id": "reprova-c17-claudio-1",
    "temaId": "reprova-comentarios",
    "nome": "Outro motivo informado pela moderação - Mensagem Claudio 1",
    "texto": "Removi seu comentário por um motivo específico, avaliado caso a caso. Se quiser entender melhor o que aconteceu, me chama no chat que eu te explico."
  },
  {
    "id": "reprova-c17-claudio-2",
    "temaId": "reprova-comentarios",
    "nome": "Outro motivo informado pela moderação - Mensagem Claudio 2",
    "texto": "Apaguei o comentário depois de analisar o caso. Se achar que foi engano, me chama no chat que eu olho de novo."
  },
  {
    "id": "reprova-c17-claudio-3",
    "temaId": "reprova-comentarios",
    "nome": "Outro motivo informado pela moderação - Mensagem Claudio 3",
    "texto": "Tive que remover seu comentário por um motivo pontual. Me chama no chat que eu te passo os detalhes."
  },
  {
    "id": "reprova-19-pelando",
    "temaId": "reprova-promocoes",
    "nome": "Contato externo não permitido - Mensagem Pelando",
    "texto": "Obrigado por enviar sua publicação. Não conseguimos aceitá-la porque ela direciona para contato externo, como WhatsApp, Telegram, e-mail ou rede social. Para proteger a comunidade, envie a oferta com link direto da loja e sem canais externos de contato."
  },
  {
    "id": "reprova-19-alternativa",
    "temaId": "reprova-promocoes",
    "nome": "Contato externo não permitido - Mensagem alternativa",
    "texto": "Sua publicação leva para contato fora do Pelando, como WhatsApp, Telegram, e-mail ou redes sociais. Esse tipo de contato é um dos caminhos mais usados em golpes, por isso não é permitido. Se quiser compartilhar a oferta, envie de novo só com o link direto da loja."
  },
  {
    "id": "reprova-19-claudio-1",
    "temaId": "reprova-promocoes",
    "nome": "Contato externo não permitido - Mensagem Claudio 1",
    "texto": "Recusei porque a publicação levava pra contato fora do Pelando, tipo WhatsApp, Telegram, e-mail ou rede social. Esse é um dos caminhos mais usados em golpe. Posta de novo só com o link direto da loja."
  },
  {
    "id": "reprova-19-claudio-2",
    "temaId": "reprova-promocoes",
    "nome": "Contato externo não permitido - Mensagem Claudio 2",
    "texto": "Tive que recusar por ter contato externo na publicação. Tira o número, grupo ou perfil e manda de novo com o link da loja."
  },
  {
    "id": "reprova-19-claudio-3",
    "temaId": "reprova-promocoes",
    "nome": "Contato externo não permitido - Mensagem Claudio 3",
    "texto": "Essa eu recusei porque direcionava pra fora do Pelando. É pra proteger a galera de golpe. Se quiser compartilhar a promoção, usa só o link da loja."
  },
  {
    "id": "reprova-14-pelando",
    "temaId": "reprova-promocoes",
    "nome": "Discussão duplicada - Mensagem Pelando",
    "texto": "Obrigado por participar da comunidade. Não conseguimos aceitar essa discussão porque já existe um tópico igual ou muito parecido em andamento. Para ajudar a concentrar as respostas, participe da discussão existente ou reenvie apenas se tiver um novo ponto de vista ou informação relevante."
  },
  {
    "id": "reprova-14-alternativa",
    "temaId": "reprova-promocoes",
    "nome": "Discussão duplicada - Mensagem alternativa",
    "texto": "Já existe uma discussão aberta sobre esse mesmo tema, então a gente recusou a sua para concentrar as respostas em um só lugar. Você pode participar da discussão que já existe e deixar sua opinião ou experiência por lá. Se tiver um ponto de vista bem diferente, pode abrir uma nova explicando o que muda."
  },
  {
    "id": "reprova-14-claudio-1",
    "temaId": "reprova-promocoes",
    "nome": "Discussão duplicada - Mensagem Claudio 1",
    "texto": "Já tem uma discussão aberta sobre esse tema, então recusei a sua pra concentrar as respostas num lugar só. Participa da que já existe e deixa sua experiência por lá."
  },
  {
    "id": "reprova-14-claudio-2",
    "temaId": "reprova-promocoes",
    "nome": "Discussão duplicada - Mensagem Claudio 2",
    "texto": "Recusei como duplicada porque o assunto já tá sendo discutido. Se o seu ponto for bem diferente, abre uma nova explicando o que muda."
  },
  {
    "id": "reprova-14-claudio-3",
    "temaId": "reprova-promocoes",
    "nome": "Discussão duplicada - Mensagem Claudio 3",
    "texto": "Essa discussão já existia, por isso recusei. Comenta lá na original que a galera vê e te responde mais rápido."
  },
  {
    "id": "reprova-18-pelando",
    "temaId": "reprova-promocoes",
    "nome": "Produto usado - Mensagem Pelando",
    "texto": "Obrigado por compartilhar sua publicação. Não conseguimos aceitá-la porque o Pelando não aceita ofertas de produtos usados. Para ser aceita na próxima vez, envie um produto novo, reembalado ou open box, com essa condição informada de forma clara e com link de uma loja confiável."
  },
  {
    "id": "reprova-18-alternativa",
    "temaId": "reprova-promocoes",
    "nome": "Produto usado - Mensagem alternativa",
    "texto": "Pelas informações da oferta, o produto é usado, e no Pelando só aceitamos itens novos, reembalados ou open box, informados com clareza. Isso porque não temos como garantir o estado de um produto usado. Se encontrar o mesmo item novo ou open box em uma loja confiável, pode enviar."
  },
  {
    "id": "reprova-18-claudio-1",
    "temaId": "reprova-promocoes",
    "nome": "Produto usado - Mensagem Claudio 1",
    "texto": "Recusei porque o produto é usado, e aqui no Pelando só aceito item novo, reembalado ou open box (informado com clareza). Não tenho como garantir o estado de um usado. Se achar novo ou open box em loja confiável, pode postar."
  },
  {
    "id": "reprova-18-claudio-2",
    "temaId": "reprova-promocoes",
    "nome": "Produto usado - Mensagem Claudio 2",
    "texto": "Essa eu recusei por ser produto usado. Se for open box ou reembalado, deixa isso claro no título e na descrição e manda de novo."
  },
  {
    "id": "reprova-18-claudio-3",
    "temaId": "reprova-promocoes",
    "nome": "Produto usado - Mensagem Claudio 3",
    "texto": "Produto usado não entra no Pelando, por isso recusei. Cria um alerta de desejo com preço alvo que quando aparecer novo nessa faixa eu te aviso."
  },
  {
    "id": "reprova-c13-pelando",
    "temaId": "reprova-comentarios",
    "nome": "Produto ou serviço ilegal - Mensagem Pelando",
    "texto": "Removemos seu comentário porque ele mencionava, recomendava ou direcionava para pirataria, IPTV ilegal, crack, torrent, desbloqueio ou outro serviço ilegal. Não permitimos esse tipo de conteúdo no Pelando."
  },
  {
    "id": "reprova-c13-alternativa",
    "temaId": "reprova-comentarios",
    "nome": "Produto ou serviço ilegal - Mensagem alternativa",
    "texto": "Seu comentário foi removido porque mencionava ou indicava pirataria, IPTV irregular, crack, torrent, desbloqueio ou outro serviço ilegal. Esse tipo de conteúdo não é permitido no Pelando."
  },
  {
    "id": "reprova-c13-claudio-1",
    "temaId": "reprova-comentarios",
    "nome": "Produto ou serviço ilegal - Mensagem Claudio 1",
    "texto": "Removi seu comentário porque mencionava ou indicava pirataria, IPTV irregular, crack, torrent ou serviço ilegal. Isso não é permitido no Pelando."
  },
  {
    "id": "reprova-c13-claudio-2",
    "temaId": "reprova-comentarios",
    "nome": "Produto ou serviço ilegal - Mensagem Claudio 2",
    "texto": "Apaguei por indicar serviço ilegal. Pode continuar comentando sobre a promoção normalmente."
  },
  {
    "id": "reprova-c13-claudio-3",
    "temaId": "reprova-comentarios",
    "nome": "Produto ou serviço ilegal - Mensagem Claudio 3",
    "texto": "Tive que remover porque o comentário falava de conteúdo pirata ou irregular. Esse tipo de coisa não entra aqui."
  },
  {
    "id": "reprova-20-pelando",
    "temaId": "reprova-promocoes",
    "nome": "Conteúdo político - Mensagem Pelando",
    "texto": "Obrigado por compartilhar sua publicação. Não conseguimos aceitá-la porque ela abre espaço para discussão política, assunto que fica fora do foco do Pelando. Para ser aceita na próxima vez, envie uma oferta com informações objetivas de preço, loja, desconto e condições, sem posicionamento político."
  },
  {
    "id": "reprova-20-alternativa",
    "temaId": "reprova-promocoes",
    "nome": "Conteúdo político - Mensagem alternativa",
    "texto": "Sua publicação abria espaço para discussão política, e no Pelando combinamos de deixar esse assunto de fora para evitar brigas e manter o foco em economia. Se a oferta for boa, envie de novo só com as informações do produto: preço, loja, desconto e condições."
  },
  {
    "id": "reprova-20-claudio-1",
    "temaId": "reprova-promocoes",
    "nome": "Conteúdo político - Mensagem Claudio 1",
    "texto": "Recusei porque a publicação abria espaço pra discussão política, e aqui a gente deixa esse assunto de fora pra evitar briga. Se a promoção for boa, posta de novo só com produto, preço, loja e condições."
  },
  {
    "id": "reprova-20-claudio-2",
    "temaId": "reprova-promocoes",
    "nome": "Conteúdo político - Mensagem Claudio 2",
    "texto": "Essa eu recusei por conteúdo político. O Pelando é pra falar de promoção e economia. Tira essa parte e manda de novo."
  },
  {
    "id": "reprova-20-claudio-3",
    "temaId": "reprova-promocoes",
    "nome": "Conteúdo político - Mensagem Claudio 3",
    "texto": "Tive que recusar porque tinha posicionamento político no meio. Sem problema nenhum postar a promoção, só deixa a política de fora."
  },
  {
    "id": "reprova-17-pelando",
    "temaId": "reprova-promocoes",
    "nome": "Conteúdo provocativo ou sem contribuição - Mensagem Pelando",
    "texto": "Obrigado por participar da comunidade. Não conseguimos aceitar essa publicação porque ela não contribui para um ambiente útil, respeitoso e colaborativo. Para ser aceita na próxima vez, envie uma oferta ou comentário com informações reais, tom respeitoso e foco em ajudar outras pessoas a economizar."
  },
  {
    "id": "reprova-17-alternativa",
    "temaId": "reprova-promocoes",
    "nome": "Conteúdo provocativo ou sem contribuição - Mensagem alternativa",
    "texto": "Essa publicação parecia mais uma provocação ou brincadeira do que uma contribuição para a comunidade, e esse tipo de conteúdo costuma gerar discórdia. Por isso, a gente recusou. Aqui o foco é ajudar a galera a economizar: se tiver uma oferta ou informação útil, pode enviar de novo."
  },
  {
    "id": "reprova-17-claudio-1",
    "temaId": "reprova-promocoes",
    "nome": "Conteúdo provocativo ou sem contribuição - Mensagem Claudio 1",
    "texto": "Recusei porque a publicação parecia mais provocação ou brincadeira do que uma contribuição pra galera. Aqui o foco é ajudar a economizar: se tiver uma promoção ou info útil, manda de novo."
  },
  {
    "id": "reprova-17-claudio-2",
    "temaId": "reprova-promocoes",
    "nome": "Conteúdo provocativo ou sem contribuição - Mensagem Claudio 2",
    "texto": "Essa eu recusei porque não ajudava ninguém a economizar e podia gerar briga. Bora manter o clima bom por aqui."
  },
  {
    "id": "reprova-17-claudio-3",
    "temaId": "reprova-promocoes",
    "nome": "Conteúdo provocativo ou sem contribuição - Mensagem Claudio 3",
    "texto": "Tive que recusar por ser conteúdo provocativo ou sem contribuição. Pode continuar participando, só com foco em promoção, produto e experiência de compra."
  },
  {
    "id": "reprova-21-pelando",
    "temaId": "reprova-promocoes",
    "nome": "Produto ou serviço ilegal - Mensagem Pelando",
    "texto": "Obrigado por enviar sua publicação. Não conseguimos aceitá-la porque ela envolve produto ou serviço ilegal, irregular ou não permitido, como pirataria, IPTV irregular ou similares. Para ser aceita na próxima vez, compartilhe apenas ofertas legais, verificáveis e de lojas ou serviços autorizados."
  },
  {
    "id": "reprova-21-alternativa",
    "temaId": "reprova-promocoes",
    "nome": "Produto ou serviço ilegal - Mensagem alternativa",
    "texto": "Sua publicação envolve um produto ou serviço ilegal ou irregular, como pirataria, IPTV não autorizado ou VPN usada de forma indevida. Esse tipo de conteúdo não é permitido no Pelando, mesmo com desconto. Continue compartilhando ofertas legais, de lojas e serviços autorizados."
  },
  {
    "id": "reprova-21-claudio-1",
    "temaId": "reprova-promocoes",
    "nome": "Produto ou serviço ilegal - Mensagem Claudio 1",
    "texto": "Recusei porque a publicação envolvia produto ou serviço ilegal ou irregular, tipo pirataria ou IPTV não autorizado. Isso não entra no Pelando, mesmo com desconto."
  },
  {
    "id": "reprova-21-claudio-2",
    "temaId": "reprova-promocoes",
    "nome": "Produto ou serviço ilegal - Mensagem Claudio 2",
    "texto": "Essa eu recusei por ser serviço irregular. Continua compartilhando promoções de lojas e serviços autorizados que eu aprovo."
  },
  {
    "id": "reprova-21-claudio-3",
    "temaId": "reprova-promocoes",
    "nome": "Produto ou serviço ilegal - Mensagem Claudio 3",
    "texto": "Tive que recusar porque esse tipo de produto ou serviço não é legal, e aqui no Pelando não aceitamos de jeito nenhum."
  },
  {
    "id": "reprova-22-pelando",
    "temaId": "reprova-promocoes",
    "nome": "Promoção ainda não ativa - Mensagem Pelando",
    "texto": "Obrigado por compartilhar a oferta. Não conseguimos aceitá-la porque a promoção ainda não estava ativa no momento da análise. Para ser aceita na próxima vez, envie quando o desconto já estiver funcionando e inclua link, preço final, cupom se houver e condições da campanha."
  },
  {
    "id": "reprova-22-alternativa",
    "temaId": "reprova-promocoes",
    "nome": "Promoção ainda não ativa - Mensagem alternativa",
    "texto": "Quando a gente conferiu, a promoção ainda não tinha começado, então a comunidade não conseguiria aproveitar naquele momento. Por isso, a publicação foi recusada. Assim que o desconto estiver valendo, envie de novo com o link, o preço final e o cupom, se houver."
  },
  {
    "id": "reprova-22-claudio-1",
    "temaId": "reprova-promocoes",
    "nome": "Promoção ainda não ativa - Mensagem Claudio 1",
    "texto": "Quando conferi, a promoção ainda não tinha começado, então a galera não conseguiria aproveitar, por isso recusei. Assim que estiver valendo, posta de novo com link, preço final e cupom."
  },
  {
    "id": "reprova-22-claudio-2",
    "temaId": "reprova-promocoes",
    "nome": "Promoção ainda não ativa - Mensagem Claudio 2",
    "texto": "Recusei porque a promoção ainda não tava ativa. Fica de olho no horário que libera e manda assim que começar, que eu aprovo."
  },
  {
    "id": "reprova-22-claudio-3",
    "temaId": "reprova-promocoes",
    "nome": "Promoção ainda não ativa - Mensagem Claudio 3",
    "texto": "Essa eu recusei porque ainda não dava pra comprar no preço anunciado. Quando abrir, posta de novo que tem tudo pra bombar."
  },
  {
    "id": "reprova-26-pelando",
    "temaId": "reprova-promocoes",
    "nome": "Tentativa de contornar regras - Mensagem Pelando",
    "texto": "Obrigado por enviar sua publicação. Não conseguimos aceitá-la porque identificamos uma tentativa de contornar regras do Pelando, da loja ou da própria oferta. Para ser aceita na próxima vez, compartilhe apenas condições oficiais, links diretos e formas de compra permitidas."
  },
  {
    "id": "reprova-26-alternativa",
    "temaId": "reprova-promocoes",
    "nome": "Tentativa de contornar regras - Mensagem alternativa",
    "texto": "A gente identificou nessa publicação uma forma de contornar regras do Pelando, da loja ou da própria oferta, como brechas ou condições que não são oficiais. Por isso, ela foi recusada. Envie apenas ofertas com condições oficiais, que qualquer pessoa da comunidade consiga usar."
  },
  {
    "id": "reprova-26-claudio-1",
    "temaId": "reprova-promocoes",
    "nome": "Tentativa de contornar regras - Mensagem Claudio 1",
    "texto": "Recusei porque a publicação usava uma forma de contornar regra do Pelando, da loja ou da própria promoção, tipo brecha ou condição não oficial. Posta só promoção com condição oficial, que qualquer pessoa consiga usar."
  },
  {
    "id": "reprova-26-claudio-2",
    "temaId": "reprova-promocoes",
    "nome": "Tentativa de contornar regras - Mensagem Claudio 2",
    "texto": "Essa eu recusei porque dependia de uma brecha que não é oficial da loja. Isso costuma dar problema pra quem compra."
  },
  {
    "id": "reprova-26-claudio-3",
    "temaId": "reprova-promocoes",
    "nome": "Tentativa de contornar regras - Mensagem Claudio 3",
    "texto": "Tive que recusar por tentativa de contornar as regras. Se achar que foi engano, me chama no chat que eu olho de novo."
  },
  {
    "id": "reprova-c10-pelando",
    "temaId": "reprova-comentarios",
    "nome": "Conteúdo adulto ou impróprio - Mensagem Pelando",
    "texto": "Removemos seu comentário porque ele continha conteúdo adulto, sexual ou impróprio para a comunidade. Mantemos esse tipo de conteúdo fora do Pelando para preservar um ambiente seguro e adequado para todos."
  },
  {
    "id": "reprova-c10-alternativa",
    "temaId": "reprova-comentarios",
    "nome": "Conteúdo adulto ou impróprio - Mensagem alternativa",
    "texto": "Seu comentário foi removido porque tinha conteúdo adulto, sexual ou impróprio para a comunidade. Queremos manter o Pelando adequado para todo mundo que participa."
  },
  {
    "id": "reprova-c10-claudio-1",
    "temaId": "reprova-comentarios",
    "nome": "Conteúdo adulto ou impróprio - Mensagem Claudio 1",
    "texto": "Removi seu comentário porque tinha conteúdo adulto ou impróprio. Quero manter o Pelando adequado pra todo mundo que participa."
  },
  {
    "id": "reprova-c10-claudio-2",
    "temaId": "reprova-comentarios",
    "nome": "Conteúdo adulto ou impróprio - Mensagem Claudio 2",
    "texto": "Apaguei por conteúdo impróprio. Pode continuar comentando sobre a promoção normalmente."
  },
  {
    "id": "reprova-c10-claudio-3",
    "temaId": "reprova-comentarios",
    "nome": "Conteúdo adulto ou impróprio - Mensagem Claudio 3",
    "texto": "Tive que remover o comentário por ser conteúdo adulto. Bora manter o foco no produto e na promoção."
  },
  {
    "id": "reprova-c08-pelando",
    "temaId": "reprova-comentarios",
    "nome": "Ameaça ou constrangimento - Mensagem Pelando",
    "texto": "Removemos seu comentário porque ele poderia ameaçar, intimidar, constranger ou assediar outra pessoa. Esse tipo de abordagem não é permitido, pois queremos que todos se sintam seguros para participar."
  },
  {
    "id": "reprova-c08-alternativa",
    "temaId": "reprova-comentarios",
    "nome": "Ameaça ou constrangimento - Mensagem alternativa",
    "texto": "Seu comentário foi removido porque podia ameaçar, intimidar, constranger ou assediar outra pessoa. Esse tipo de abordagem não é permitido no Pelando. A gente quer que todo mundo se sinta seguro para participar."
  },
  {
    "id": "reprova-c08-claudio-1",
    "temaId": "reprova-comentarios",
    "nome": "Ameaça ou constrangimento - Mensagem Claudio 1",
    "texto": "Removi seu comentário porque podia ameaçar, intimidar ou constranger outra pessoa. Isso não é permitido aqui, quero que todo mundo se sinta seguro pra participar."
  },
  {
    "id": "reprova-c08-claudio-2",
    "temaId": "reprova-comentarios",
    "nome": "Ameaça ou constrangimento - Mensagem Claudio 2",
    "texto": "Apaguei por ameaça ou constrangimento. Se tiver algum problema com outro usuário, usa a opção de denunciar ou me chama no chat que eu vejo."
  },
  {
    "id": "reprova-c08-claudio-3",
    "temaId": "reprova-comentarios",
    "nome": "Ameaça ou constrangimento - Mensagem Claudio 3",
    "texto": "Tive que remover o comentário por constranger outro usuário. Pode continuar participando, sempre com respeito."
  },
  {
    "id": "reprova-25-pelando",
    "temaId": "reprova-promocoes",
    "nome": "Conta em análise - Mensagem Pelando",
    "texto": "Obrigado por enviar sua publicação. No momento, não conseguimos aceitá-la porque sua conta está passando por uma análise de segurança. Para os próximos envios, acompanhe os canais de suporte e garanta que suas publicações tenham link direto, loja confiável, preço claro e estejam alinhadas às regras da comunidade."
  },
  {
    "id": "reprova-25-alternativa",
    "temaId": "reprova-promocoes",
    "nome": "Conta em análise - Mensagem alternativa",
    "texto": "Sua conta está passando por uma revisão de segurança, e por isso suas publicações estão pausadas por enquanto. Isso não quer dizer que a oferta era ruim: é uma checagem que a gente faz para proteger a comunidade. Se tiver dúvidas, fale com o nosso suporte pelos canais oficiais."
  },
  {
    "id": "reprova-25-claudio-1",
    "temaId": "reprova-promocoes",
    "nome": "Conta em análise - Mensagem Claudio 1",
    "texto": "Sua conta tá passando por uma revisão de segurança, por isso suas publicações estão pausadas por enquanto. Não quer dizer que a promoção era ruim, é uma checagem pra proteger a comunidade. Se tiver dúvida, me chama no atendimento@pelando.com.br."
  },
  {
    "id": "reprova-25-claudio-2",
    "temaId": "reprova-promocoes",
    "nome": "Conta em análise - Mensagem Claudio 2",
    "texto": "Recusei porque sua conta está em análise no momento. Assim que a revisão terminar, as publicações voltam ao normal."
  },
  {
    "id": "reprova-25-claudio-3",
    "temaId": "reprova-promocoes",
    "nome": "Conta em análise - Mensagem Claudio 3",
    "texto": "Suas publicações estão segurando por uma análise da conta, é procedimento de segurança. Qualquer dúvida, me chama no chat que eu te explico."
  },
  {
    "id": "reprova-c09-pelando",
    "temaId": "reprova-comentarios",
    "nome": "Discurso de ódio ou discriminação - Mensagem Pelando",
    "texto": "Removemos seu comentário porque ele continha discurso de ódio, racismo ou discriminação contra pessoas ou grupos. Esse tipo de conteúdo não é permitido no Pelando."
  },
  {
    "id": "reprova-c09-alternativa",
    "temaId": "reprova-comentarios",
    "nome": "Discurso de ódio ou discriminação - Mensagem alternativa",
    "texto": "Seu comentário foi removido porque tinha discurso de ódio, racismo ou discriminação contra pessoas ou grupos. Esse tipo de conteúdo não é aceito no Pelando em nenhuma situação."
  },
  {
    "id": "reprova-c09-claudio-1",
    "temaId": "reprova-comentarios",
    "nome": "Discurso de ódio ou discriminação - Mensagem Claudio 1",
    "texto": "Removi seu comentário porque tinha discurso de ódio ou discriminação. Isso não é aceito no Pelando em nenhuma situação."
  },
  {
    "id": "reprova-c09-claudio-2",
    "temaId": "reprova-comentarios",
    "nome": "Discurso de ódio ou discriminação - Mensagem Claudio 2",
    "texto": "Apaguei o comentário por conteúdo discriminatório. Aqui é espaço pra todo mundo."
  },
  {
    "id": "reprova-c09-claudio-3",
    "temaId": "reprova-comentarios",
    "nome": "Discurso de ódio ou discriminação - Mensagem Claudio 3",
    "texto": "Tive que remover porque o comentário atacava pessoas ou grupos. Esse tipo de conteúdo não tem espaço no Pelando."
  },
  {
    "id": "reprova-c15-pelando",
    "temaId": "reprova-comentarios",
    "nome": "Chamada indevida para moderação ou suporte - Mensagem Pelando",
    "texto": "Seu comentário foi tratado porque usava a conversa para acionar moderação ou suporte fora do fluxo correto. Quando precisar de ajuda, use os canais indicados na plataforma para que o time consiga acompanhar melhor."
  },
  {
    "id": "reprova-c15-alternativa",
    "temaId": "reprova-comentarios",
    "nome": "Chamada indevida para moderação ou suporte - Mensagem alternativa",
    "texto": "Seu comentário foi tratado porque usava a conversa da promoção para chamar a moderação ou o suporte, e por ali o time não consegue acompanhar direito. Para pedir ajuda ou avisar sobre algum problema, use a opção de reportar ou os canais de suporte da plataforma."
  },
  {
    "id": "reprova-c15-claudio-1",
    "temaId": "reprova-comentarios",
    "nome": "Chamada indevida para moderação ou suporte - Mensagem Claudio 1",
    "texto": "Removi seu comentário porque usava a conversa da promoção pra chamar a análise ou o suporte, e por ali eu não consigo acompanhar direito. Pra avisar algum problema, usa a opção de denunciar ou me chama no chat."
  },
  {
    "id": "reprova-c15-claudio-2",
    "temaId": "reprova-comentarios",
    "nome": "Chamada indevida para moderação ou suporte - Mensagem Claudio 2",
    "texto": "Apaguei o comentário porque o pedido de ajuda se perde nos comentários. Me chama no chat ou no atendimento@pelando.com.br que eu resolvo com você."
  },
  {
    "id": "reprova-c15-claudio-3",
    "temaId": "reprova-comentarios",
    "nome": "Chamada indevida para moderação ou suporte - Mensagem Claudio 3",
    "texto": "Tive que remover porque os comentários são pra falar da promoção. Se precisar de mim, me chama no chat do Pelando, @craudio."
  },
  {
    "id": "reprova-24-pelando",
    "temaId": "reprova-promocoes",
    "nome": "Ameaça ou constrangimento - Mensagem Pelando",
    "texto": "Obrigado por participar da comunidade. Não conseguimos aceitar essa publicação porque ela pode ameaçar, constranger ou expor outra pessoa. Para continuar contribuindo, mantenha as interações respeitosas e envie conteúdos focados em ofertas, dúvidas ou experiências úteis para a comunidade."
  },
  {
    "id": "reprova-24-alternativa",
    "temaId": "reprova-promocoes",
    "nome": "Ameaça ou constrangimento - Mensagem alternativa",
    "texto": "Sua publicação podia ameaçar, constranger ou expor outra pessoa, e esse tipo de conteúdo não é permitido no Pelando. A gente quer que todo mundo se sinta seguro para participar. Continue contribuindo com ofertas, dúvidas e experiências, sempre com respeito."
  },
  {
    "id": "reprova-24-claudio-1",
    "temaId": "reprova-promocoes",
    "nome": "Ameaça ou constrangimento - Mensagem Claudio 1",
    "texto": "Recusei porque a publicação podia ameaçar, constranger ou expor outra pessoa, e isso não é permitido aqui. Quero que todo mundo se sinta seguro pra participar."
  },
  {
    "id": "reprova-24-claudio-2",
    "temaId": "reprova-promocoes",
    "nome": "Ameaça ou constrangimento - Mensagem Claudio 2",
    "texto": "Essa eu recusei por expor ou constranger alguém. Se tiver algum problema com outro usuário, me chama no chat ou usa a opção de denunciar que eu vejo."
  },
  {
    "id": "reprova-24-claudio-3",
    "temaId": "reprova-promocoes",
    "nome": "Ameaça ou constrangimento - Mensagem Claudio 3",
    "texto": "Tive que recusar por conter ameaça ou constrangimento. Continua contribuindo com promoções e experiências, sempre com respeito."
  },
  {
    "id": "reprova-27-pelando",
    "temaId": "reprova-promocoes",
    "nome": "Lista de cupons - Mensagem Pelando",
    "texto": "Obrigado por compartilhar os cupons. Não conseguimos aceitar essa publicação porque ela reúne vários cupons em uma única página, sem uma oferta específica para a comunidade avaliar. Para ser aceita na próxima vez, envie um cupom individual, com loja, benefício, validade e condições de uso bem claras."
  },
  {
    "id": "reprova-27-alternativa",
    "temaId": "reprova-promocoes",
    "nome": "Lista de cupons - Mensagem alternativa",
    "texto": "Sua publicação reunia vários cupons em uma página só, sem uma oferta específica para a comunidade avaliar, e assim fica difícil para a galera saber o que vale a pena. Envie cada cupom separado, com a loja, o desconto, a validade e as regras de uso."
  },
  {
    "id": "reprova-27-claudio-1",
    "temaId": "reprova-promocoes",
    "nome": "Lista de cupons - Mensagem Claudio 1",
    "texto": "Recusei porque a publicação juntava vários cupons numa página só, sem uma promoção específica pra galera avaliar. Posta cada cupom separado, com loja, desconto, validade e regras de uso."
  },
  {
    "id": "reprova-27-claudio-2",
    "temaId": "reprova-promocoes",
    "nome": "Lista de cupons - Mensagem Claudio 2",
    "texto": "Lista de cupons não entra como promoção, por isso recusei. Separa o melhor cupom e posta ele sozinho, com as condições na descrição."
  },
  {
    "id": "reprova-27-claudio-3",
    "temaId": "reprova-promocoes",
    "nome": "Lista de cupons - Mensagem Claudio 3",
    "texto": "Essa eu recusei por ser lista de cupons. Cupom avulso com regra clara tem muito mais chance de aprovar e esquentar."
  },
  {
    "id": "mv1qwp81244nme",
    "temaId": "plataforma-promocoes",
    "nome": "Explicando o que é autopromoção e Pelando",
    "texto": "o Pelando é uma rede social focada em compartilhar descontos de forma voluntária, então não temos nenhum tipo de ganho financeiro para quem publica. Sobre os links de afiliados, eles não são permitidos pela nossa regra de autopromoção e o nosso sistema sempre muda a tag dos links postados para a nossa. Qualquer outra dúvida, me chama que te explico."
  },
  {
    "id": "grupo-de-3-1",
    "temaId": "plataforma-promocoes",
    "nome": "Grupo de 3 - Como postar e links nos comentários 1",
    "texto": "Sobre Grupo de 3, dá uma olhada nesse link que explica como postar aqui no Pelando: https://www.pelando.com.br/t/guia-pratico-como-postar-promocoes-de-grupos-do-aliexpress-sem-erro-b402?cid=9db2d4f3-00a7-4886-b24a-f7dfd97d372d\nNão enviem links de grupo de 3 em comentários de promoções que não são grupo de 3."
  },
  {
    "id": "grupo-de-3-2",
    "temaId": "plataforma-promocoes",
    "nome": "Grupo de 3 - Como postar e links nos comentários 2",
    "texto": "Pra postar Grupo de 3 do AliExpress sem erro, preparei esse guia: https://www.pelando.com.br/t/guia-pratico-como-postar-promocoes-de-grupos-do-aliexpress-sem-erro-b402?cid=9db2d4f3-00a7-4886-b24a-f7dfd97d372d\nSó um pedido: link de Grupo de 3 vai só em promoção de Grupo de 3. Em comentário de outras promoções eu vou remover, beleza?"
  },
  {
    "id": "grupo-de-3-3",
    "temaId": "plataforma-promocoes",
    "nome": "Grupo de 3 - Como postar e links nos comentários 3",
    "texto": "Grupo de 3 tem um jeito certo de postar aqui no Pelando, tá tudo nesse guia: https://www.pelando.com.br/t/guia-pratico-como-postar-promocoes-de-grupos-do-aliexpress-sem-erro-b402?cid=9db2d4f3-00a7-4886-b24a-f7dfd97d372d\nE lembrando: não manda link de Grupo de 3 nos comentários de promoções que não são de Grupo de 3, que atrapalha a galera. Os links às vezes só abrem no app do AliExpress, então testa pelo celular."
  },
  {
    "id": "mv8ic1av6uk7kb",
    "temaId": "plataforma-promocoes",
    "nome": "Indique um amigo",
    "texto": "A aba de indicação pode não aparecer no painel principal de cashback porque a recompensa funciona com uma regra específica. O valor de R$ 5,00 da indicação só é aprovado e liberado no seu saldo depois que o seu amigo indicado faz uma compra pelo Pelando, acumula o valor mínimo de R$ 20,00 e conclui o resgate para a conta bancária dele. Assim que ele finalizar esse processo, o valor entra para você. Se precisar que eu confira o status do seu amigo, pode me avisar por aqui."
  },
  {
    "id": "cupom-acabou",
    "temaId": "plataforma-promocoes",
    "nome": "Cupom ou promoção acabou",
    "texto": "Esse cupom já encerrou, eles acabam rapidinho mesmo. Cria um alerta de desejo desse produto que, quando aparecer de novo, eu te aviso na hora."
  },
  {
    "id": "seguir-perfil-nao-notifica",
    "temaId": "alertas-notificacoes",
    "nome": "Seguir perfil não notifica",
    "texto": "Seguir uma pessoa não manda notificação das postagens dela. O que funciona é criar um alerta de desejo do produto que você quer."
  },
  {
    "id": "parar-notificacoes-marketing",
    "temaId": "alertas-notificacoes",
    "nome": "Parar notificações de marketing",
    "texto": "Vai em Configurações > aba Notificações > Comunicações e desativa Marketing. Os seus alertas continuam chegando normal. Se persistir, me avisa."
  },
  {
    "id": "alerta-atrasado",
    "temaId": "alertas-notificacoes",
    "nome": "Alerta atrasado",
    "texto": "Olhei aqui os logs de disparo, e o seu alerta saiu em [X] min depois da aprovação. Você abriu logo que chegou? Se tiver um print, me manda que eu levo pro time."
  },
  {
    "id": "recuperar-senha",
    "temaId": "conta-login",
    "nome": "Recuperar senha - e-mail não chega",
    "texto": "Busca pelo assunto 'Pelando - Recuperar senha' e olha também o spam. Se mesmo assim não chegar, me chama no atendimento@pelando.com.br."
  },
  {
    "id": "login-facebook",
    "temaId": "conta-login",
    "nome": "Login pelo Facebook descontinuado",
    "texto": "O login pelo Facebook foi descontinuado, mas a sua conta e o seu histórico continuam salvos. Me manda o seu nickname e um e-mail sem conta no Pelando pelo atendimento@pelando.com.br que eu faço a vinculação."
  }
];

if (typeof module !== 'undefined' && module.exports) {
  module.exports = { PELANDO_CHAT_EXT_SEED_THEMES, PELANDO_CHAT_EXT_SEED_MESSAGES };
}
