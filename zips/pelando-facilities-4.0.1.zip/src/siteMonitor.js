// "Monitor dos sites": a panel at the end of the backoffice's promotions
// moderation list telling whether Pelando and each Promoninja site open. The service
// worker fetches the sites (checkMonitoredSite in background.js); the panel
// only asks and shows. It checks once per visit, after the page has loaded,
// and again on "Testar de novo".
const PELANDO_SITE_MONITOR_CLASS = 'pelando-site-monitor';
const PELANDO_SITE_MONITOR_PATH = '/moderar-promocoes';
// Each site's recent deals page (Promoninja's is its home), and how it shows
// prices.
const PELANDO_SITE_MONITOR_SITES = [
  { flag: '🇧🇷', url: 'https://www.pelando.com.br/recentes', currency: 'BRL', locale: 'pt-BR' },
  { flag: '🇺🇸', url: 'https://www.promoninja.com/', currency: 'USD', locale: 'en-US' },
  { flag: '🇬🇧', url: 'https://www.promoninja.co.uk/', currency: 'GBP', locale: 'en-GB' },
  { flag: '🇫🇷', url: 'https://www.promoninja.fr/', currency: 'EUR', locale: 'fr-FR' },
  { flag: '🇪🇸', url: 'https://www.promoninja.es/', currency: 'EUR', locale: 'es-ES' },
  { flag: '🇩🇪', url: 'https://www.promoninja.de/', currency: 'EUR', locale: 'de-DE' },
  { flag: '🇲🇽', url: 'https://www.promoninja.com.mx/', currency: 'MXN', locale: 'es-MX' },
];

// How often to check, in minutes: chosen in the chat's settings (storage.js
// writes the same key, with the same limits).
const PELANDO_SITE_MONITOR_MINUTES_KEY = 'siteMonitorMinutes';
const PELANDO_SITE_MONITOR_MINUTES = { default: 5, min: 1, max: 120 };
// A newest deal at least this old is shown in red.
const PELANDO_SITE_MONITOR_LATE_MS = 2 * 60 * 60 * 1000;
// The last run, shared by every backoffice tab: one opened before the
// interval is up shows it instead of checking again.
const PELANDO_SITE_MONITOR_LAST_RUN_KEY = 'siteMonitorLastRun';

function siteMonitorMinutes(value) {
  const minutes = Math.round(Number(value));
  if (!Number.isFinite(minutes)) return PELANDO_SITE_MONITOR_MINUTES.default;
  return Math.min(Math.max(minutes, PELANDO_SITE_MONITOR_MINUTES.min), PELANDO_SITE_MONITOR_MINUTES.max);
}

// Where the interval and the last run live; storage trouble means the
// default interval and no saved run.
const chromeSiteMonitorStore = {
  readMinutes: async function () {
    try {
      const stored = await chrome.storage.sync.get(PELANDO_SITE_MONITOR_MINUTES_KEY);
      const value = stored[PELANDO_SITE_MONITOR_MINUTES_KEY];
      return value === undefined ? PELANDO_SITE_MONITOR_MINUTES.default : siteMonitorMinutes(value);
    } catch (err) {
      return PELANDO_SITE_MONITOR_MINUTES.default;
    }
  },
  readLastRun: async function () {
    try {
      const stored = await chrome.storage.local.get(PELANDO_SITE_MONITOR_LAST_RUN_KEY);
      return stored[PELANDO_SITE_MONITOR_LAST_RUN_KEY] || null;
    } catch (err) {
      return null;
    }
  },
  saveLastRun: async function (run) {
    try {
      await chrome.storage.local.set({ [PELANDO_SITE_MONITOR_LAST_RUN_KEY]: run });
    } catch (err) {
      // Not saving only means the next page load checks again.
    }
  },
};

// What the panel shows, kept across the page's re-renders and tab changes.
let siteMonitorState = null;

function resetSiteMonitor() {
  if (siteMonitorState && siteMonitorState.timer) clearTimeout(siteMonitorState.timer);
  siteMonitorState = {
    started: false,
    running: false,
    results: {},
    testedAt: null,
    nextAt: null,
    timer: null,
    check: null,
    store: chromeSiteMonitorStore,
    shown: '',
  };
}
resetSiteMonitor();

// Asks the service worker; a missing answer counts as an error.
function checkSiteViaWorker(url) {
  return new Promise(function (resolve) {
    try {
      chrome.runtime.sendMessage({ type: 'PELANDO_SITE_CHECK', url: url }, function (response) {
        if (chrome.runtime.lastError || !response || !response.data) {
          resolve({ ok: false, reason: 'sem resposta da extensão' });
          return;
        }
        resolve(response.data);
      });
    } catch (err) {
      resolve({ ok: false, reason: 'sem resposta da extensão' });
    }
  });
}

function siteMonitorSeconds(ms) {
  return (ms / 1000).toFixed(1).replace('.', ',') + ' s';
}

function siteMonitorStatus(result) {
  if (!result) return { kind: 'pending', text: 'testando...' };
  if (result.ok) return { kind: 'ok', text: 'OK · ' + siteMonitorSeconds(result.ms || 0) };
  return { kind: 'error', text: 'Erro · ' + (result.reason || 'não abriu') };
}

// "há 10 min", "há 2 h", "há 3 dias" since the deal went live.
function siteMonitorAgo(iso, now) {
  const minutes = Math.floor((now - Date.parse(iso)) / 60000);
  if (!(minutes >= 1)) return 'agora';
  if (minutes < 60) return 'há ' + minutes + ' min';
  const hours = Math.floor(minutes / 60);
  if (hours < 48) return 'há ' + hours + ' h';
  return 'há ' + Math.floor(hours / 24) + ' dias';
}

function siteMonitorPrice(site, price) {
  if (typeof price !== 'number' || price <= 0) return 'sem preço';
  return new Intl.NumberFormat(site.locale, { style: 'currency', currency: site.currency }).format(price);
}

// The second line of a site that opened: its newest deal, or that none was
// found on the page.
function siteMonitorLatestLine(doc, site, result) {
  const line = siteMonitorElement(doc, 'div', 'pelando-site-monitor-latest');
  if (!result.latest) {
    line.textContent = 'última promoção: não encontrada';
    return line;
  }
  const title = siteMonitorElement(doc, 'span', 'pelando-site-monitor-latest-title', result.latest.title);
  title.title = result.latest.title;
  const now = Date.now();
  const ago = siteMonitorElement(doc, 'span', 'pelando-site-monitor-latest-ago', siteMonitorAgo(result.latest.approvedAt, now));
  // A site this long without a new deal deserves a look.
  if (now - Date.parse(result.latest.approvedAt) >= PELANDO_SITE_MONITOR_LATE_MS) {
    ago.classList.add('pelando-site-monitor-latest-ago--late');
  }
  line.append(
    ago,
    ' · ',
    title,
    ' · ',
    siteMonitorElement(doc, 'span', 'pelando-site-monitor-latest-price', siteMonitorPrice(site, result.latest.price))
  );
  return line;
}

function siteMonitorElement(doc, tag, className, text) {
  const el = doc.createElement(tag);
  if (className) el.className = className;
  if (text !== undefined) el.textContent = text;
  return el;
}

// Redraws the panel only when what it shows changed: the page's
// MutationObserver calls back on every change, ours included.
function renderSiteMonitor(doc, panel) {
  const state = siteMonitorState;
  const shown = JSON.stringify([state.results, state.testedAt, state.nextAt, state.running]);
  if (panel.dataset.shown === shown && panel.childNodes.length) return;
  panel.dataset.shown = shown;

  const header = siteMonitorElement(doc, 'div', 'pelando-site-monitor-header');
  header.appendChild(siteMonitorElement(doc, 'strong', 'pelando-site-monitor-title', 'Monitor dos sites'));
  header.appendChild(siteMonitorElement(doc, 'span', 'pelando-site-monitor-hint', 'O Pelando e os sites do Promoninja abrem?'));

  const list = siteMonitorElement(doc, 'ul', 'pelando-site-monitor-list');
  PELANDO_SITE_MONITOR_SITES.forEach(function (site) {
    const result = state.results[site.url];
    const status = siteMonitorStatus(result);
    const row = siteMonitorElement(doc, 'li', 'pelando-site-monitor-row');
    const main = siteMonitorElement(doc, 'div', 'pelando-site-monitor-row-main');
    main.appendChild(siteMonitorElement(doc, 'span', 'pelando-site-monitor-flag', site.flag));
    const link = siteMonitorElement(doc, 'a', 'pelando-site-monitor-site', new URL(site.url).hostname.replace(/^www\./, ''));
    link.href = site.url;
    link.target = '_blank';
    link.rel = 'noopener noreferrer';
    main.appendChild(link);
    main.appendChild(siteMonitorElement(doc, 'span', 'pelando-site-monitor-status pelando-site-monitor-status--' + status.kind, status.text));
    row.appendChild(main);
    if (result && result.ok) row.appendChild(siteMonitorLatestLine(doc, site, result));
    list.appendChild(row);
  });

  const footer = siteMonitorElement(doc, 'div', 'pelando-site-monitor-footer');
  const clock = { hour: '2-digit', minute: '2-digit' };
  let when = state.testedAt ? 'Testado às ' + state.testedAt.toLocaleTimeString('pt-BR', clock) : 'Testando...';
  if (state.testedAt && state.nextAt) when += ' · próximo às ' + state.nextAt.toLocaleTimeString('pt-BR', clock);
  footer.appendChild(siteMonitorElement(doc, 'span', 'pelando-site-monitor-when', when));
  const retry = siteMonitorElement(doc, 'button', 'pelando-site-monitor-retry', 'Testar de novo');
  retry.type = 'button';
  retry.disabled = state.running;
  retry.addEventListener('click', function () {
    if (!siteMonitorState.running) runSiteMonitor(doc, siteMonitorState.check);
  });
  footer.appendChild(retry);

  panel.replaceChildren(header, list, footer);
}

function renderSiteMonitorNow(doc) {
  const panel = doc.querySelector('.' + PELANDO_SITE_MONITOR_CLASS);
  if (panel) renderSiteMonitor(doc, panel);
}

// Shows a run (this tab's or a saved one) and plans the next check for when
// the interval is up.
async function showSiteMonitorRun(doc, state, run) {
  state.results = run.results || {};
  state.testedAt = new Date(run.testedAt);
  const minutes = await state.store.readMinutes();
  if (siteMonitorState !== state) return;
  state.nextAt = new Date(state.testedAt.getTime() + minutes * 60000);
  if (state.timer) clearTimeout(state.timer);
  state.timer = setTimeout(function () {
    state.timer = null;
    refreshSiteMonitor(doc, state);
  }, Math.max(0, state.nextAt.getTime() - Date.now()));
  renderSiteMonitorNow(doc);
}

// The saved run while it's newer than the interval (this or another tab's),
// a new check otherwise.
async function refreshSiteMonitor(doc, state) {
  const minutes = await state.store.readMinutes();
  const lastRun = await state.store.readLastRun();
  if (siteMonitorState !== state || state.running) return;
  const age = lastRun ? Date.now() - Date.parse(lastRun.testedAt) : Infinity;
  if (age >= 0 && age < minutes * 60000) {
    await showSiteMonitorRun(doc, state, lastRun);
    return;
  }
  await runSiteMonitor(doc, state.check);
}

async function runSiteMonitor(doc, check) {
  const state = siteMonitorState;
  if (state.timer) clearTimeout(state.timer);
  state.timer = null;
  state.running = true;
  state.results = {};
  state.testedAt = null;
  state.nextAt = null;
  renderSiteMonitorNow(doc);
  await Promise.all(
    PELANDO_SITE_MONITOR_SITES.map(async function (site) {
      let result;
      try {
        result = await check(site.url);
      } catch (err) {
        result = null;
      }
      if (siteMonitorState !== state) return;
      state.results[site.url] = result || { ok: false, reason: 'sem resposta' };
      renderSiteMonitorNow(doc);
    })
  );
  if (siteMonitorState !== state) return;
  state.running = false;
  const run = { testedAt: new Date().toISOString(), results: state.results };
  await state.store.saveLastRun(run);
  if (siteMonitorState !== state) return;
  await showSiteMonitorRun(doc, state, run);
}

// Keeps the panel at the end of the active tab of the promotions moderation
// page (the cards, or the "nothing to moderate" notice, come before it) and,
// once the page has finished loading, shows the last run or checks. `store`
// replaces chrome.storage in the tests.
function syncSiteMonitor(doc, pathname, check, store) {
  let panel = doc.querySelector('.' + PELANDO_SITE_MONITOR_CLASS);
  if (pathname !== PELANDO_SITE_MONITOR_PATH) {
    if (panel) panel.remove();
    // Coming back is another visit, with a fresh check.
    if (siteMonitorState.started) resetSiteMonitor();
    return;
  }
  const tab = doc.querySelector('[data-slot="tabs-content"][data-state="active"]');
  if (!tab) return;
  if (!panel) {
    panel = siteMonitorElement(doc, 'section', PELANDO_SITE_MONITOR_CLASS);
    panel.setAttribute('aria-label', 'Monitor dos sites');
  }
  if (tab.lastElementChild !== panel) tab.appendChild(panel);
  siteMonitorState.check = check;
  if (store) siteMonitorState.store = store;
  renderSiteMonitor(doc, panel);
  if (!siteMonitorState.started && doc.readyState === 'complete') {
    siteMonitorState.started = true;
    refreshSiteMonitor(doc, siteMonitorState);
  }
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = {
    syncSiteMonitor,
    resetSiteMonitor,
    checkSiteViaWorker,
    siteMonitorMinutes,
    PELANDO_SITE_MONITOR_SITES,
    PELANDO_SITE_MONITOR_MINUTES,
  };
}
