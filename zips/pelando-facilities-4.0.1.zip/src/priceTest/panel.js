// "Testar Promoção" on the backoffice deal page: asks the service worker to
// check the deal's price at the store's checkout (src/priceTest/runner.js) and
// shows how it goes below the button. Only on deals of a store the test
// knows: Magalu, Mercado Livre, Amazon, KaBuM!, Centauro and AliExpress.
const PELANDO_PRICE_TEST_CLASS = 'pelando-price-test';

// The stores in PRICE_TEST_STORES (runner.js, in the service worker).
const PRICE_TEST_SUPPORTED_STORES = ['magalu', 'mercadolivre', 'amazon', 'kabum', 'centauro', 'aliexpress'];

// How many units the deal's price is for: "[Leve 2/ Cada R$ 12] Cotonetes"
// for R$ 24 is 2. A kit ("Kit c/ 2") is one listing, so 1.
function priceTestDealUnits(title) {
  const match = /\bleve\s*(\d{1,2})\b/i.exec(String(title || ''));
  const units = match ? Number(match[1]) : 1;
  return units > 1 ? units : 1;
}

// What the test needs from the backoffice deal.
function priceTestRequestFromDeal(deal) {
  const request = {
    dealId: deal.id,
    store: storeBrandFor(deal),
    url: deal.sourceUrl || deal.redirectUrl || null,
    price: typeof deal.price === 'number' ? deal.price : null,
    coupon: deal.couponCode || null,
  };
  const units = priceTestDealUnits(deal.title);
  if (units > 1) request.units = units;
  // AliExpress coins deals ("[Moedas R$5824] ...", "(Moedas R$ 11) ...").
  if (/\bmoedas\b/i.test(String(deal.title || ''))) request.coins = true;
  return request;
}

// If the service worker dies mid-test nothing more arrives: after this long
// without a message the panel says so instead of hanging. Longer after a
// request for a person (a captcha is solved at human speed).
const PELANDO_PRICE_TEST_SILENCE_MS = 30000;
const PELANDO_PRICE_TEST_HUMAN_SILENCE_MS = 75000;

function priceTestDisarm(status) {
  if (status.pelandoCancelWatchdog) status.pelandoCancelWatchdog();
  status.pelandoCancelWatchdog = null;
}

function priceTestArm(status, ms, deps) {
  priceTestDisarm(status);
  status.pelandoCancelWatchdog = deps.setTimer(function () {
    status.pelandoCancelWatchdog = null;
    renderPriceTestStatus(status, { type: 'priceTest:error', message: 'O teste parou de responder. Tente de novo.' }, deps);
  }, ms);
}

function renderPriceTestStatus(status, message, deps) {
  const kinds = { 'priceTest:progress': 'running', 'priceTest:needsHuman': 'attention', 'priceTest:error': 'error' };
  const results = { validated: 'ok', slightly: 'slight' };
  const kind = message.type === 'priceTest:result' ? results[message.status] || 'diverges' : kinds[message.type] || 'running';
  status.hidden = false;
  status.className = PELANDO_PRICE_TEST_CLASS + '-status ' + PELANDO_PRICE_TEST_CLASS + '-status--' + kind;
  status.textContent = '';
  (message.lines || [message.label || message.message]).forEach(function (text) {
    const line = status.ownerDocument.createElement('div');
    // In a result, the deal's price and the tested one stand out in the
    // result's color: green kept, yellow under 5% off, red 5% or more.
    const price = message.type === 'priceTest:result' && /^(Valor da promoção|Valor do teste \(sem frete\)): (.+)$/.exec(text);
    if (price) {
      const value = status.ownerDocument.createElement('strong');
      value.className = PELANDO_PRICE_TEST_CLASS + '-price ' + PELANDO_PRICE_TEST_CLASS + '-price--' + kind;
      value.textContent = price[2];
      line.append(price[1] + ': ', value);
    } else {
      line.textContent = text;
    }
    status.appendChild(line);
  });
  // Where the time went, step by step (runner.js).
  if (message.timings) {
    const timings = status.ownerDocument.createElement('div');
    timings.className = PELANDO_PRICE_TEST_CLASS + '-timings';
    timings.textContent = message.timings;
    status.appendChild(timings);
  }
  // The review's values as the test saw them, last and full width; larger
  // on click. Only the image the service worker took (a JPEG data URL).
  if (message.screenshot && /^data:image\/jpeg;base64,/.test(message.screenshot)) {
    const shot = status.ownerDocument.createElement('img');
    shot.className = PELANDO_PRICE_TEST_CLASS + '-screenshot';
    shot.src = message.screenshot;
    shot.alt = 'Valores do pedido na loja, com o total no PIX';
    shot.title = 'Clique para ampliar';
    shot.addEventListener('click', function () {
      shot.classList.toggle(PELANDO_PRICE_TEST_CLASS + '-screenshot--zoomed');
    });
    status.appendChild(shot);
    status.appendChild(createAddImageButton(status.ownerDocument, message.screenshot, deps));
  }
  if (message.tabId && (kind === 'error' || kind === 'attention')) {
    const focus = status.ownerDocument.createElement('button');
    focus.type = 'button';
    focus.className = PELANDO_PRICE_TEST_CLASS + '-focus';
    focus.textContent = 'Ver aba';
    focus.addEventListener('click', function () {
      deps.focusTab(message.tabId);
    });
    status.appendChild(focus);
  }
}

// Under the picture: puts it in the deal's "Descrição curta", on a line of
// its own after the text. The deal still has to be saved.
function createAddImageButton(doc, dataUrl, deps) {
  const button = doc.createElement('button');
  button.type = 'button';
  button.className = PELANDO_PRICE_TEST_CLASS + '-add-image';
  button.textContent = 'Adicionar imagem na descrição';
  button.addEventListener('click', function () {
    if (button.disabled) return;
    button.disabled = true;
    button.textContent = 'Adicionando imagem…';
    let adding;
    try {
      adding = Promise.resolve(deps.addImageToDescription(dataUrl));
    } catch (err) {
      adding = Promise.reject(err);
    }
    adding.then(
        function () {
          button.textContent = 'Imagem adicionada na descrição';
        },
        function (err) {
          button.disabled = false;
          button.textContent = err.message + '. Tentar de novo';
        }
      );
  });
  return button;
}

// The backoffice's text fields each hold a toolbar, whose image button opens
// a hidden file picker, and a Quill editor: those of "Descrição curta".
function priceTestDescriptionField(doc) {
  const item = Array.from(doc.querySelectorAll('[data-slot="form-item"]')).find(function (el) {
    return Array.from(el.querySelectorAll('label')).some(function (label) {
      return /^descri[cç][aã]o curta$/i.test((label.textContent || '').trim());
    });
  });
  const editor = item && item.querySelector('.ql-editor');
  const input = item && item.querySelector('input[type="file"]');
  return editor && input ? { editor: editor, input: input } : null;
}

// Does what a person does: caret at the end of the text, a new line, then
// the picture through the image button's file picker. The backoffice
// uploads it (api-bo .../media) and puts it in the editor at the caret.
function priceTestAddImageToDescription(doc, dataUrl) {
  const field = priceTestDescriptionField(doc);
  if (!field) return Promise.reject(new Error('Não achei o campo "Descrição curta"'));
  const view = doc.defaultView;
  const imagesBefore = field.editor.querySelectorAll('img').length;
  return view
    .fetch(dataUrl)
    .then(function (response) {
      return response.blob();
    })
    .then(function (blob) {
      const editor = field.editor;
      editor.focus();
      const range = doc.createRange();
      range.selectNodeContents(editor);
      range.collapse(false);
      const selection = view.getSelection();
      selection.removeAllRanges();
      selection.addRange(range);
      // An empty editor needs no new line.
      if (!editor.classList.contains('ql-blank')) doc.execCommand('insertParagraph');
      const transfer = new view.DataTransfer();
      transfer.items.add(new view.File([blob], 'teste-de-preco.jpg', { type: 'image/jpeg' }));
      field.input.files = transfer.files;
      field.input.dispatchEvent(new view.Event('change', { bubbles: true }));
      return priceTestUntil(function () {
        return field.editor.querySelectorAll('img').length > imagesBefore;
      }, 20000);
    })
    .then(function (added) {
      if (!added) throw new Error('A imagem não subiu');
      return true;
    });
}

// Resolves true once done() holds, or false after timeoutMs.
function priceTestUntil(done, timeoutMs) {
  return new Promise(function (resolve) {
    const started = Date.now();
    const timer = setInterval(function () {
      if (done()) {
        clearInterval(timer);
        resolve(true);
      } else if (Date.now() - started > timeoutMs) {
        clearInterval(timer);
        resolve(false);
      }
    }, 200);
  });
}

// The moderation summary (src/summary): a failure there leaves the box be.
function priceTestPublish(deps, dealId, message) {
  try {
    deps.publish(dealId, message);
  } catch (err) {
    console.warn('[pelando-chat-ext] resumo da moderação falhou:', err);
  }
}

function createPriceTestBox(doc, dealId, deps) {
  const box = doc.createElement('div');
  box.className = PELANDO_PRICE_TEST_CLASS;
  box.dataset.dealId = dealId;
  // Shown once the deal turns out to be from a store the test knows.
  box.hidden = true;
  const button = doc.createElement('button');
  button.type = 'button';
  button.className = PELANDO_PRICE_TEST_CLASS + '-button';
  button.textContent = 'Testar Promoção';
  button.disabled = true;
  const status = doc.createElement('div');
  status.className = PELANDO_PRICE_TEST_CLASS + '-status';
  status.hidden = true;
  box.append(button, status);

  // Only to show the button: the test itself uses the deal as saved at the
  // click (the usual flow is fix the price, save, test). Unreadable deals
  // and other stores keep it hidden.
  deps.fetchDeal(dealId).then(
    function (deal) {
      if (PRICE_TEST_SUPPORTED_STORES.indexOf(priceTestRequestFromDeal(deal).store) === -1) return;
      box.hidden = false;
      button.disabled = false;
      // The moderation summary shows "Teste: não rodado" until a message comes.
      priceTestPublish(deps, dealId, null);
    },
    function () {}
  );
  button.addEventListener('click', function () {
    if (button.disabled) return;
    renderPriceTestStatus(status, { type: 'priceTest:progress', label: 'Lendo a promoção…' }, deps);
    priceTestArm(status, PELANDO_PRICE_TEST_SILENCE_MS, deps);
    deps.fetchDeal(dealId)
      .then(function (deal) {
        return deps.start(priceTestRequestFromDeal(deal));
      })
      .then(function (response) {
        if (response && response.started === false && response.dealId !== dealId) {
          priceTestDisarm(status);
          renderPriceTestStatus(
            status,
            { type: 'priceTest:needsHuman', message: 'Outro teste em andamento em outra promoção. Aguarde terminar.' },
            deps
          );
        }
      })
      .catch(function (err) {
        priceTestDisarm(status);
        renderPriceTestStatus(status, { type: 'priceTest:error', message: err.message }, deps);
      });
  });
  return box;
}

// The form field of the deal's title: the form-item holding a label that
// starts with "Título".
function priceTestTitleField(doc) {
  return (
    Array.from(doc.querySelectorAll('[data-slot="form-item"]')).find(function (item) {
      return Array.from(item.querySelectorAll('label')).some(function (label) {
        return /^t[ií]tulo/i.test((label.textContent || '').trim());
      });
    }) || null
  );
}

// "Testar Promoção" shows only for whoever turned it on in the chat's settings
// (priceTestEnabled in chrome.storage.sync, written by storage.js). Off until
// the stored value is true.
let pelandoPriceTestEnabled = false;

function priceTestIsEnabled() {
  return pelandoPriceTestEnabled;
}

// Reads the switch and follows its changes, so an open backoffice page takes
// it without a reload; onChange runs after each change.
function watchPriceTestEnabled(onChange) {
  function apply(value) {
    const enabled = value === true;
    if (enabled === pelandoPriceTestEnabled) return;
    pelandoPriceTestEnabled = enabled;
    onChange();
  }
  chrome.storage.sync.get('priceTestEnabled').then(
    function (stored) {
      apply(stored && stored.priceTestEnabled);
    },
    function () {
      // Unreadable: stays off.
    }
  );
  chrome.storage.onChanged.addListener(function (changes, area) {
    if (area === 'sync' && changes.priceTestEnabled) apply(changes.priceTestEnabled.newValue);
  });
}

// Right below the deal's title field (or the moderation summary right under
// it); without it, right below "Justificar ao usuário" when that's on the
// page, floating with it while it floats, and otherwise floating in the
// corner (that button was turned off on 2026-11-13). The backoffice is a single-page app: keep one box, for the
// deal in the URL. None while the switch is off; turned off on an open page,
// the box goes and the summary drops its "Teste" line.
function syncPriceTestButton(doc, pathname, deps) {
  const dealId = backofficeDealIdFromPath(pathname);
  let box = doc.querySelector('.' + PELANDO_PRICE_TEST_CLASS);
  if (box && box.dataset.dealId !== dealId) {
    box.remove();
    box = null;
  }
  if (!deps.enabled()) {
    if (box) box.remove();
    // Also a deal tested before the switch went off and opened again now.
    // Forgetting nothing is quiet.
    if (dealId) {
      try {
        deps.forget(dealId);
      } catch (err) {
        console.warn('[pelando-chat-ext] resumo da moderação falhou:', err);
      }
    }
    return;
  }
  if (!dealId) return;
  // Preferred spot: right below the deal's title field.
  const title = priceTestTitleField(doc);
  if (title) {
    if (!box) box = createPriceTestBox(doc, dealId, deps);
    if (box.classList.contains(PELANDO_PRICE_TEST_CLASS + '--floating')) box.classList.remove(PELANDO_PRICE_TEST_CLASS + '--floating');
    if (box.style.gridColumn) box.style.gridColumn = '';
    // Below the moderation summary when it sits right below the title
    // (title → summary → this box → Keepa card).
    const summary = title.nextElementSibling;
    const anchor = summary && summary.classList.contains('pelando-summary') ? summary : title;
    if (anchor.nextElementSibling !== box) anchor.insertAdjacentElement('afterend', box);
    return;
  }
  // Fallback: right below "Justificar ao usuário", floating with it.
  const justify = doc.querySelector('.' + PELANDO_BO_JUSTIFY_BUTTON_CLASS);
  if (!box) box = createPriceTestBox(doc, dealId, deps);
  if (!justify) {
    box.classList.add(PELANDO_PRICE_TEST_CLASS + '--floating');
    box.style.gridColumn = '';
    if (box.parentElement !== doc.body) doc.body.appendChild(box);
    return;
  }
  box.classList.toggle(PELANDO_PRICE_TEST_CLASS + '--floating', justify.classList.contains(PELANDO_BO_JUSTIFY_FLOATING_CLASS));
  box.style.gridColumn = justify.style.gridColumn;
  if (justify.nextElementSibling !== box) justify.insertAdjacentElement('afterend', box);
}

function priceTestHandleMessage(doc, message, deps) {
  const box = doc.querySelector('.' + PELANDO_PRICE_TEST_CLASS);
  const status = doc.querySelector('.' + PELANDO_PRICE_TEST_CLASS + '-status');
  // The service worker runs one test for the whole browser: show only this
  // page's deal.
  if (!box || !status || message.dealId !== box.dataset.dealId) return;
  renderPriceTestStatus(status, message, deps);
  if (message.type === 'priceTest:progress') priceTestArm(status, PELANDO_PRICE_TEST_SILENCE_MS, deps);
  else if (message.type === 'priceTest:needsHuman') priceTestArm(status, PELANDO_PRICE_TEST_HUMAN_SILENCE_MS, deps);
  else priceTestDisarm(status);
  priceTestPublish(deps, message.dealId, message);
}

// The service worker reports to the tab that asked (chrome.tabs.sendMessage).
function listenForPriceTestMessages(doc, deps) {
  chrome.runtime.onMessage.addListener(function (message) {
    if (message && typeof message.type === 'string' && message.type.indexOf('priceTest:') === 0) {
      priceTestHandleMessage(doc, message, deps);
    }
  });
}

const pelandoPriceTestDeps = {
  fetchDeal: function (dealId) {
    return fetchDealById(dealId);
  },
  start: function (request) {
    return sendExtensionMessage({ type: 'priceTest:start', request: request });
  },
  setTimer: function (fn, ms) {
    const id = setTimeout(fn, ms);
    return function () {
      clearTimeout(id);
    };
  },
  focusTab: function (tabId) {
    return sendExtensionMessage({ type: 'priceTest:focus', tabId: tabId }).catch(function () {
      // The tab is gone; nothing to show.
    });
  },
  addImageToDescription: function (dataUrl) {
    return priceTestAddImageToDescription(document, dataUrl);
  },
  publish: function (dealId, message) {
    publishSummarySignal(dealId, summarySignalFromPriceTest(message));
  },
  enabled: priceTestIsEnabled,
  forget: function (dealId) {
    summaryForgetSignal(dealId, 'test');
  },
};

if (typeof module !== 'undefined' && module.exports) {
  module.exports = {
    PRICE_TEST_SUPPORTED_STORES,
    priceTestDealUnits,
    priceTestRequestFromDeal,
    syncPriceTestButton,
    priceTestHandleMessage,
    listenForPriceTestMessages,
    priceTestIsEnabled,
    watchPriceTestEnabled,
    priceTestDescriptionField,
    priceTestTitleField,
  };
}
