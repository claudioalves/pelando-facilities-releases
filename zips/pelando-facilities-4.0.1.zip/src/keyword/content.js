(function () {
'use strict';

const isNode = typeof module !== 'undefined' && module.exports;
const selectors = isNode ? require('./selectors.js') : self.PelandoKW;
const cards = isNode ? require('./cards.js') : self.PelandoKW;

const INJECTED_ATTR = 'data-pelando-kw-injected';
const COMPETITOR_SEARCH_WORDS = 2;
let hasWarnedMissingField = false;

function injectButtons(doc, handlers, buttons) {
  const sourceField = selectors.findSourceUrlField(doc);
  if (!sourceField) {
    if (!hasWarnedMissingField) {
      console.debug('[pelando-keyword-inject] campo "Link original" não encontrado; botões não injetados.');
      hasWarnedMissingField = true;
    }
    return false;
  }
  hasWarnedMissingField = false;

  const wrapper = sourceField.closest('[data-slot="form-item"]') || sourceField.parentElement;
  if (wrapper.querySelector(`[${INJECTED_ATTR}]`)) return false;

  const getTitle = () => {
    const titleField = selectors.findTitleInput(doc);
    return titleField ? titleField.value : '';
  };
  // A loja sai do "Link original" (o domínio dela); a imagem, do "Link da imagem".
  const getDeal = () => {
    const priceField = selectors.findPriceInput(doc);
    const imageField = selectors.findImageInput(doc);
    const deal = { price: priceField ? priceField.value : '', store: sourceField.value || '' };
    if (imageField && imageField.value) deal.image = imageField.value;
    return deal;
  };
  const container = cards.buildIconButtons(doc, handlers, getTitle, buttons, getDeal);
  container.setAttribute(INJECTED_ATTR, 'true');
  wrapper.appendChild(container);
  return true;
}

function startObserver(doc, handlers) {
  const observer = new MutationObserver(() => injectButtons(doc, handlers));
  observer.observe(doc.body, { childList: true, subtree: true });
  injectButtons(doc, handlers);
  return observer;
}

// Handlers recebem o título da promoção (do formulário ou do card clicado).
function createHandlers(kw, panel, openTab, competitor) {
  // Os exemplos do moderador vêm antes: em empate de similaridade, vencem o catálogo.
  async function keywordsFor(title) {
    const examples = [...(await kw.getExamples()), ...(kw.MODERATOR_EXAMPLES || []), ...(kw.CATALOG_EXAMPLES || [])];
    return kw.extractKeywords(title || '', examples);
  }

  async function search(title, templateKey, destino) {
    try {
      const keywords = await keywordsFor(title);
      if (keywords.length === 0) {
        console.error('[pelando-keyword-inject] nenhuma palavra-chave extraída; busca cancelada para evitar abrir uma aba vazia.');
        return;
      }
      const config = await kw.getConfig();
      openTab(kw.buildSearchUrl(config[templateKey], keywords));
    } catch (error) {
      console.error(`[pelando-keyword-inject] falha ao buscar no ${destino}:`, error);
    }
  }

  // Título, preço, loja e imagem ficam guardados para a aba do concorrente
  // destacar o card que é a mesma promoção. `mode`: 'product' ou 'recent'.
  async function openCompetitor(title, deal, mode, urlFor) {
    try {
      const text = String(title || '').replace(/\s+/g, ' ').trim();
      const url = text && urlFor(text);
      if (!url) {
        console.error(`[pelando-keyword-inject] promoção sem título; busca no ${competitor.name} cancelada.`);
        return;
      }
      try {
        const remembered = { title: text, price: (deal && deal.price) || '', store: (deal && deal.store) || '' };
        if (deal && deal.image) remembered.image = deal.image;
        await kw.rememberCompetitorSearch(url, remembered, mode);
      } catch (error) {
        console.warn('[pelando-keyword-inject] não deu pra guardar a promoção para destacar no concorrente:', error);
      }
      openTab(url);
    } catch (error) {
      console.error(`[pelando-keyword-inject] falha ao buscar no ${competitor.name}:`, error);
    }
  }

  // A busca pelo produto usa só as primeiras palavras do título.
  function searchCompetitor(title, deal) {
    return openCompetitor(title, deal, 'product', (text) => {
      const words = kw.firstWords(text, COMPETITOR_SEARCH_WORDS);
      return words.length > 0 ? kw.buildSearchUrl(competitor.urlTemplate, words) : null;
    });
  }

  // A dos recentes abre a página das promoções mais novas do concorrente.
  function searchCompetitorRecent(title, deal) {
    return openCompetitor(title, deal, 'recent', () => competitor.recentUrl);
  }

  return {
    onCompetitor: searchCompetitor,
    onCompetitorRecent: searchCompetitorRecent,
    onPelando: (title) => search(title, 'pelandoUrlTemplate', 'Pelando'),
    onGoogleShopping: (title) => search(title, 'googleShoppingUrlTemplate', 'Google Shopping'),
    onConfig: async (title) => {
      try {
        const keywords = await keywordsFor(title);
        await panel.open({ title: title || '', keywords });
      } catch (error) {
        console.error('[pelando-keyword-inject] falha ao abrir o painel de configurações:', error);
      }
    },
  };
}

// Pelando's backoffice searches Pelando and Google Shopping and adds keywords
// itself, on the cards and in the deal's Links: the buttons were turned off
// there on 2026-11-13 (the code stays, for going back). Pelando's site and
// the Promoninja ones keep theirs.
const RETIRED_HOSTS = ['bo.pelando.com.br'];

function bootstrap(doc = document, location = window.location) {
  const hostname = location && location.hostname;
  if (RETIRED_HOSTS.includes(hostname)) return null;
  const kw = self.PelandoKW;
  const adapter = cards.adapterFor(hostname);
  if (!adapter) return null;
  // O formulário com "Link original" só existe no backoffice.
  const withForm = adapter === cards.ADAPTERS.backoffice;
  const openTab = (url) => window.open(url, '_blank');

  // Promoninja: só o botão do concorrente do país (a Argentina não tem um).
  if (kw.isInternational(hostname)) {
    const competitor = kw.competitorFor(hostname);
    if (!competitor) return null;
    const handlers = createHandlers(kw, null, openTab, competitor);
    const buttons = cards.competitorButtons(competitor);
    return cards.observeBody(doc, () => {
      cards.injectCardButtons(doc, adapter, handlers, buttons);
      if (withForm) injectButtons(doc, handlers, buttons);
    });
  }

  const panel = kw.createPanel(doc, {
    getExamples: kw.getExamples,
    addExample: kw.addExample,
    updateExample: kw.updateExample,
    deleteExample: kw.deleteExample,
    importExamples: kw.importExamples,
    getConfig: kw.getConfig,
    setConfig: kw.setConfig,
    extraCategories: kw.STANDARD_CATEGORIES,
  });
  doc.body.appendChild(panel.root);

  const handlers = createHandlers(kw, panel, openTab);
  return cards.observeBody(doc, () => {
    cards.injectCardButtons(doc, adapter, handlers);
    if (withForm) injectButtons(doc, handlers);
  });
}

const api = { injectButtons, startObserver, createHandlers, bootstrap };

if (isNode) {
  module.exports = api;
} else {
  self.PelandoKW = self.PelandoKW || {};
  Object.assign(self.PelandoKW, api);
}

if (!isNode) {
  // Starts only for a Pelando account (see src/access.js).
  self.pelandoWhenAllowed(() => bootstrap(document, window.location));
}

})();
