// The backoffice's "Reportadas" tabs list each report as
// "<reason> - <nickname of who reported>". With the option on (set in the
// chat's manage mode), "duplicada" in the reason, the nicknames from the
// spreadsheet (reportHighlightNicknames.js) and the age of deals 2 days or
// older reported as expired stand out.
const PELANDO_REPORT_SETTING_KEY = 'reportHighlightEnabled';
const PELANDO_REPORT_HIDDEN_CLASS = 'pelando-report-hidden';
const PELANDO_REPORT_REASON_CLASS = 'pelando-report-reason';
const PELANDO_REPORT_DUPLICATE_CLASS = 'pelando-report-duplicate';
const PELANDO_REPORT_NICKNAME_CLASS = 'pelando-report-nickname';
const PELANDO_REPORT_AGE_CLASS = 'pelando-report-age';
const PELANDO_REPORT_DUPLICATE_WORD = /duplicad[ao]s?/i;
const PELANDO_REPORT_EXPIRED_WORD = /expirad[ao]/i;
const PELANDO_REPORT_OLD_AGE_DAYS = 2;
// The card's age badge ("1 min", "23 h", "2 dias") has this icon.
const PELANDO_REPORT_AGE_ICON = 'svg.lucide-calendar-clock';
const PELANDO_REPORT_AGE_UNITS = [
  { pattern: /^min/, days: 0 },
  { pattern: /^h/, days: 1 / 24 },
  { pattern: /^dias?$/, days: 1 },
  { pattern: /^sem/, days: 7 },
  { pattern: /^(m[eê]s|meses)$/, days: 30 },
  { pattern: /^anos?$/, days: 365 },
];

function normalizeReportNickname(nickname) {
  return nickname
    .trim()
    .replace(/^@+/, '')
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase();
}

// Each report: its reason <span>, then a "-" <span>, then the link to the
// user who reported it.
function findReportEntries(root) {
  const entries = [];
  root.querySelectorAll('a[href^="/usuario/"]').forEach(function (nickname) {
    const dash = nickname.previousElementSibling;
    if (!dash || dash.tagName !== 'SPAN' || dash.textContent.trim() !== '-') return;
    let reason = dash.previousElementSibling;
    // Our highlighted copy sits between the page's reason and the dash.
    if (reason && reason.classList.contains(PELANDO_REPORT_REASON_CLASS)) reason = reason.previousElementSibling;
    if (!reason || reason.tagName !== 'SPAN') return;
    entries.push({ reason: reason, nickname: nickname });
  });
  return entries;
}

// The age a card's badge shows, in days; null when it isn't one.
function reportAgeInDays(text) {
  const match = text.trim().toLowerCase().match(/^(\d+)\s*([a-zêç]+)$/);
  if (!match) return null;
  const unit = PELANDO_REPORT_AGE_UNITS.find(function (u) {
    return u.pattern.test(match[2]);
  });
  return unit ? Number(match[1]) * unit.days : null;
}

// The age badge of the card a report is on: the closest block around the
// report that has one.
function findReportAgeBadge(report) {
  for (let block = report.parentElement; block; block = block.parentElement) {
    const icon = block.querySelector(PELANDO_REPORT_AGE_ICON);
    if (icon) return icon.closest('[data-slot="badge"]') || icon.parentElement;
  }
  return null;
}

function removeReportClass(element, className) {
  element.classList.remove(className);
  if (element.classList.length === 0) element.removeAttribute('class');
}

function highlightedReasonCopy(text, match) {
  const copy = document.createElement('span');
  copy.className = PELANDO_REPORT_REASON_CLASS;
  copy.dataset.source = text;
  const word = document.createElement('span');
  word.className = PELANDO_REPORT_DUPLICATE_CLASS;
  word.textContent = match[0];
  copy.append(text.slice(0, match.index), word, text.slice(match.index + match[0].length));
  return copy;
}

// The page (React) owns the reason's text, so it's left as is and hidden
// behind a highlighted copy; the copy is redone if the page changes the text.
function syncDuplicateReason(reason) {
  const text = reason.textContent;
  const match = text.match(PELANDO_REPORT_DUPLICATE_WORD);
  const copy = reason.nextElementSibling && reason.nextElementSibling.classList.contains(PELANDO_REPORT_REASON_CLASS)
    ? reason.nextElementSibling
    : null;
  if (copy && match && copy.dataset.source === text) return;
  if (copy) copy.remove();
  if (!match) {
    if (reason.classList.contains(PELANDO_REPORT_HIDDEN_CLASS)) removeReportClass(reason, PELANDO_REPORT_HIDDEN_CLASS);
    return;
  }
  reason.classList.add(PELANDO_REPORT_HIDDEN_CLASS);
  reason.after(highlightedReasonCopy(text, match));
}

// Only touches what differs, so running it on its own changes settles.
function applyReportHighlight(root, nicknames) {
  const oldExpiredAges = new Set();
  findReportEntries(root).forEach(function (entry) {
    if (PELANDO_REPORT_EXPIRED_WORD.test(entry.reason.textContent)) {
      const badge = findReportAgeBadge(entry.nickname);
      const age = badge && reportAgeInDays(badge.textContent);
      if (age !== null && age >= PELANDO_REPORT_OLD_AGE_DAYS) oldExpiredAges.add(badge);
    }
    syncDuplicateReason(entry.reason);
    const listed = nicknames.has(normalizeReportNickname(entry.nickname.textContent));
    const marked = entry.nickname.classList.contains(PELANDO_REPORT_NICKNAME_CLASS);
    if (listed && !marked) entry.nickname.classList.add(PELANDO_REPORT_NICKNAME_CLASS);
    if (!listed && marked) removeReportClass(entry.nickname, PELANDO_REPORT_NICKNAME_CLASS);
  });
  root.querySelectorAll('.' + PELANDO_REPORT_AGE_CLASS).forEach(function (badge) {
    if (!oldExpiredAges.has(badge)) removeReportClass(badge, PELANDO_REPORT_AGE_CLASS);
  });
  oldExpiredAges.forEach(function (badge) {
    if (!badge.classList.contains(PELANDO_REPORT_AGE_CLASS)) badge.classList.add(PELANDO_REPORT_AGE_CLASS);
  });
}

function clearReportHighlight(root) {
  root.querySelectorAll('.' + PELANDO_REPORT_REASON_CLASS).forEach(function (copy) {
    copy.remove();
  });
  root.querySelectorAll('.' + PELANDO_REPORT_HIDDEN_CLASS).forEach(function (reason) {
    removeReportClass(reason, PELANDO_REPORT_HIDDEN_CLASS);
  });
  root.querySelectorAll('.' + PELANDO_REPORT_NICKNAME_CLASS).forEach(function (nickname) {
    removeReportClass(nickname, PELANDO_REPORT_NICKNAME_CLASS);
  });
  root.querySelectorAll('.' + PELANDO_REPORT_AGE_CLASS).forEach(function (badge) {
    removeReportClass(badge, PELANDO_REPORT_AGE_CLASS);
  });
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = { normalizeReportNickname, findReportEntries, applyReportHighlight, clearReportHighlight, reportAgeInDays };
} else {
  // Starts only for a Pelando account (see access.js).
  pelandoWhenAllowed(function () {
    const nicknames = new Set(PELANDO_REPORT_HIGHLIGHT_NICKNAMES.map(normalizeReportNickname));
    let enabled = false;
    let scheduled = false;

    // The backoffice is a single-page app that loads the reports after the
    // page; re-check on DOM changes, batched to one pass per frame.
    function scheduleSync() {
      if (scheduled) return;
      scheduled = true;
      requestAnimationFrame(function () {
        scheduled = false;
        if (enabled) applyReportHighlight(document.body, nicknames);
      });
    }

    function setEnabled(value) {
      enabled = value === true;
      if (enabled) scheduleSync();
      else clearReportHighlight(document.body);
    }

    new MutationObserver(scheduleSync).observe(document.body, { childList: true, subtree: true, characterData: true });

    chrome.storage.sync.get(PELANDO_REPORT_SETTING_KEY).then(
      function (result) {
        setEnabled(result[PELANDO_REPORT_SETTING_KEY]);
      },
      function () {
        // Without the setting the page stays as it is.
      }
    );
    // Turned on or off in the chat: follow it without a reload.
    chrome.storage.onChanged.addListener(function (changes, area) {
      if (area === 'sync' && PELANDO_REPORT_SETTING_KEY in changes) setEnabled(changes[PELANDO_REPORT_SETTING_KEY].newValue);
    });
  });
}
