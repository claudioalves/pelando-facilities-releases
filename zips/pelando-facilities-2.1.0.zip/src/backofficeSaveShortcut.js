const PELANDO_BO_SAVE_SHORTCUT_CLASS = 'pelando-bo-save-shortcut';
// One copy floats in the bottom right corner; another sits above the "Ações"
// card's Aprovar / Reprovar buttons.
const PELANDO_BO_SAVE_FLOATING_CLASS = PELANDO_BO_SAVE_SHORTCUT_CLASS + '--floating';
const PELANDO_BO_SAVE_ACTIONS_CLASS = PELANDO_BO_SAVE_SHORTCUT_CLASS + '--actions';
// Pelando's backoffice is in Portuguese; Promoninja's in Spanish (Spain and
// Argentina) or English (the others).
const PELANDO_BO_DECISION_BUTTON_TEXTS = ['aprovar', 'reprovar', 'aprobar', 'rechazar', 'approve', 'reject'];
// The deal page's submit button at the bottom of the form reads "Salvar
// alterações" ("Guardar cambios", "Save changes"), and "Salvando..."
// ("Guardando...", "Saving...", disabled) while it saves.
const PELANDO_BO_SAVE_TEXTS = ['salvar alterações', 'salvando...', 'guardar cambios', 'guardando...', 'save changes', 'saving...'];

function saveShortcutText(el) {
  return (el.textContent || '').replace(/\s+/g, ' ').trim().toLowerCase();
}

function findSaveShortcutButtonByText(doc, text) {
  const candidates = doc.querySelectorAll('button, a, [role="button"]');
  for (let i = 0; i < candidates.length; i++) {
    const el = candidates[i];
    if (el.classList.contains(PELANDO_BO_SAVE_SHORTCUT_CLASS)) continue;
    if (saveShortcutText(el) === text) return el;
  }
  return null;
}

function findSaveButton(doc) {
  const buttons = doc.querySelectorAll('button[type="submit"]');
  for (let i = 0; i < buttons.length; i++) {
    const button = buttons[i];
    if (button.classList.contains(PELANDO_BO_SAVE_SHORTCUT_CLASS)) continue;
    if (PELANDO_BO_SAVE_TEXTS.includes(saveShortcutText(button))) return button;
  }
  return null;
}

function createSaveShortcut(doc, placementClass) {
  const shortcut = doc.createElement('button');
  shortcut.type = 'button';
  shortcut.dataset.placement = placementClass;
  // Clicking the page's own button keeps its form validation and saving flow.
  shortcut.addEventListener('click', function () {
    const original = findSaveButton(doc);
    if (original && !original.disabled) original.click();
  });
  return shortcut;
}

// Makes the shortcut look exactly like the original: its classes (the page's
// own styles) and content (text, and the spinner while saving). Only our
// class, which floats it, is added.
function copySaveButtonLook(shortcut, original) {
  const look = original.className + '|' + original.innerHTML;
  if (shortcut.dataset.look !== look) {
    shortcut.dataset.look = look;
    shortcut.className = [original.className, PELANDO_BO_SAVE_SHORTCUT_CLASS, shortcut.dataset.placement]
      .filter(Boolean)
      .join(' ');
    shortcut.replaceChildren.apply(
      shortcut,
      Array.prototype.map.call(original.childNodes, function (node) {
        return node.cloneNode(true);
      })
    );
  }
  shortcut.disabled = original.disabled;
}

// The first Aprovar / Reprovar button of the "Ações" card, or the row holding
// it when the card lays them out side by side, so the copy goes above them.
function findDecisionButtonsAnchor(doc) {
  let button = null;
  for (let i = 0; i < PELANDO_BO_DECISION_BUTTON_TEXTS.length && !button; i++) {
    button = findSaveShortcutButtonByText(doc, PELANDO_BO_DECISION_BUTTON_TEXTS[i]);
  }
  if (!button || !button.parentElement) return null;
  const parent = button.parentElement;
  const style = getComputedStyle(parent);
  const sideBySide = /grid/.test(style.display) || (/flex/.test(style.display) && !/column/.test(style.flexDirection));
  return sideBySide && parent !== doc.body ? parent : button;
}

function syncSaveShortcut(doc, original, placementClass, place) {
  let shortcut = doc.querySelector('.' + placementClass);
  if (!original) {
    if (shortcut) shortcut.remove();
    return;
  }
  if (!shortcut) {
    shortcut = createSaveShortcut(doc, placementClass);
  }
  copySaveButtonLook(shortcut, original);
  if (!place(shortcut)) shortcut.remove();
}

// Copies of the page's "Salvar alterações" - one floating in the top right
// corner, one above Aprovar / Reprovar - so saving doesn't need scrolling to
// the bottom. They follow the original's look and disabled state, and go
// away with it.
function syncBackofficeSaveShortcut(doc) {
  const original = findSaveButton(doc);
  syncSaveShortcut(doc, original, PELANDO_BO_SAVE_FLOATING_CLASS, function (shortcut) {
    if (shortcut.parentElement !== doc.body) doc.body.appendChild(shortcut);
    return true;
  });
  syncSaveShortcut(doc, original, PELANDO_BO_SAVE_ACTIONS_CLASS, function (shortcut) {
    const anchor = findDecisionButtonsAnchor(doc);
    if (!anchor) return false;
    if (anchor.previousElementSibling !== shortcut) anchor.insertAdjacentElement('beforebegin', shortcut);
    return true;
  });
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = { syncBackofficeSaveShortcut };
}
