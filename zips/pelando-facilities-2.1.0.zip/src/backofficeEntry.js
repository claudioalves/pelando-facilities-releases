// Starts only for a Pelando account (see access.js).
pelandoWhenAllowed(function () {
  let scheduled = false;

  // The backoffice is a single-page app and opens its dialogs on demand, so
  // re-check on DOM changes, batched to one pass per frame.
  function scheduleSync() {
    if (scheduled) return;
    scheduled = true;
    requestAnimationFrame(function () {
      scheduled = false;
      syncBackofficeJustifyButton(document, window.location.pathname);
      sortBackofficeReasonLists(document.body);
      syncDiscussionAiButton(document, {
        copyText: (text) => navigator.clipboard.writeText(text),
        openTab: (url) => window.open(url, '_blank', 'noopener,noreferrer'),
      });
    });
  }

  const observer = new MutationObserver(scheduleSync);
  observer.observe(document.body, { childList: true, subtree: true });

  scheduleSync();
});
