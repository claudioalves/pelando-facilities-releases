(function () {
'use strict';

// Promoninja -> concorrente: os botões do ladrão guardam título, preço e loja
// da nossa promoção e abrem, no concorrente, a busca pelo produto ou a página
// das promoções mais novas; nessa aba, este arquivo destaca o card que é a
// mesma promoção - e nenhum, se não houver certeza.

const STORAGE_KEY = 'pelandoCompetitorMatches';
// Uma busca aberta há mais tempo que isso não é mais destacada.
const MAX_AGE_MS = 30 * 60 * 1000;
const MATCH_CLASS = 'pelando-competitor-match';
const BADGE_CLASS = 'pelando-competitor-match-badge';

// Peso de cada sinal na nota.
const WEIGHTS = { title: 0.6, price: 0.25, store: 0.15 };
// Abaixo disso nenhum card é destacado.
const MIN_TITLE_SIMILARITY = 0.5;
const MIN_SCORE = 0.65;
// Loja e preço são obrigatórios dos dois lados: a loja tem que ser a mesma e o
// preço, o mesmo ou quase (arredondado). Sem um deles, nada é destacado.
const MAX_PRICE_DIFFERENCE = 0.05;
// A promoção copiada é recente: na busca pelo produto ela está entre os
// primeiros resultados; mais abaixo só há promoções antigas parecidas.
const PRODUCT_SEARCH_RESULTS = 7;
// Quantos cards cada tipo de busca olha (a dos recentes, a página toda).
const RESULT_LIMITS = { product: PRODUCT_SEARCH_RESULTS, recent: Infinity };

// Hotukdeals, dealabs, chollometro e mydealz são da mesma plataforma (Pepper).
// Nos cards expirados o título vira <span> e o preço perde a classe thread-price.
const PEPPER = {
  cards: 'article.thread',
  title: ['.thread-title a', '.thread-link', '.thread-title'],
  price: ['.thread-price', 'span.size--all-xl'],
  store: ['a[data-t="merchantLink"]'],
};

const SLICKDEALS = {
  cards: '.dealCardListView__wrapper',
  title: ['.dealCardListView__title'],
  price: ['.dealCardListView__finalPrice'],
  store: ['.dealCardListView__store'],
};

const SITES = {
  'hotukdeals.com': PEPPER,
  'dealabs.com': PEPPER,
  'chollometro.com': PEPPER,
  'mydealz.de': PEPPER,
  'slickdeals.net': SLICKDEALS,
};

const FREE_WORDS = /^(free|gratis|gratuit|gratuito|kostenlos|grátis)\b/i;

function normalizeText(text) {
  return String(text || '')
    .normalize('NFD')
    .replace(/[̀-ͯ]/g, '')
    .toLowerCase();
}

// As primeiras `count` palavras do título, sem etiquetas entre colchetes
// ("[Reconditionné]") nem pontuação solta.
function firstWords(title, count) {
  return String(title || '')
    .replace(/\[[^\]]*\]/g, ' ')
    .split(/\s+/)
    .map((word) => word.replace(/^[^\p{L}\p{N}]+|[^\p{L}\p{N}]+$/gu, ''))
    .filter((word) => /[\p{L}\p{N}]/u.test(word))
    .slice(0, count);
}

// "£7.95", "179,99€", "1.299,00 €", "$1,299.99", "R$ 9,84" -> número; "Free" -> 0.
function parsePrice(text) {
  const value = String(text || '').trim();
  if (FREE_WORDS.test(value)) return 0;
  const match = value.match(/\d[\d.,\s]*/);
  if (!match) return null;
  let number = match[0].replace(/\s/g, '').replace(/[.,]$/, '');
  const lastDot = number.lastIndexOf('.');
  const lastComma = number.lastIndexOf(',');
  if (lastDot !== -1 && lastComma !== -1) {
    const decimal = lastDot > lastComma ? '.' : ',';
    const thousands = decimal === '.' ? ',' : '.';
    number = number.split(thousands).join('').replace(decimal, '.');
  } else if (lastDot !== -1 || lastComma !== -1) {
    const separator = lastDot !== -1 ? '.' : ',';
    const parts = number.split(separator);
    // Três dígitos depois do separador (ou vários separadores) = milhar.
    const isThousands = parts.length > 2 || parts[parts.length - 1].length === 3;
    number = isThousands ? parts.join('') : parts.join('.');
  }
  const parsed = Number.parseFloat(number);
  return Number.isFinite(parsed) ? parsed : null;
}

// Nome comparável da loja, a partir do nome ("Media Markt") ou de um link
// ("https://www.amazon.co.uk/..." e "Amazon.es" -> "amazon").
function storeKey(store) {
  let text = String(store || '').trim();
  if (!text) return '';
  if (/^https?:\/\//i.test(text)) {
    try {
      text = new URL(text).hostname;
    } catch (error) {
      return '';
    }
  }
  if (!/\s/.test(text) && text.includes('.')) {
    text = text.replace(/^www\./i, '').split('.')[0];
  }
  return normalizeText(text).replace(/[^a-z0-9]/g, '');
}

function titleTokens(title) {
  return new Set(normalizeText(title).split(/[^a-z0-9]+/).filter(Boolean));
}

// Dice entre as palavras dos dois títulos: 1 = mesmas palavras.
function titleSimilarity(a, b) {
  const left = titleTokens(a);
  const right = titleTokens(b);
  if (left.size === 0 || right.size === 0) return 0;
  let shared = 0;
  left.forEach((token) => {
    if (right.has(token)) shared += 1;
  });
  return (2 * shared) / (left.size + right.size);
}

function priceSimilarity(a, b) {
  if (a === b) return 1;
  return Math.max(0, 1 - Math.abs(a - b) / Math.max(a, b));
}

function siteFor(hostname) {
  return SITES[String(hostname || '').replace(/^www\./, '')] || null;
}

// Liga a busca que abrimos à página em que ela cai (o slickdeals acrescenta parâmetros).
function matchKey(url) {
  try {
    const parsed = new URL(url);
    const query = (parsed.searchParams.get('q') || '').toLowerCase().replace(/\s+/g, ' ').trim();
    return `${parsed.hostname.replace(/^www\./, '')}|${query}`;
  } catch (error) {
    return '';
  }
}

function firstText(card, selectors, read) {
  for (const selector of selectors) {
    for (const element of card.querySelectorAll(selector)) {
      const value = read(element);
      if (value !== null && value !== '') return value;
    }
  }
  return null;
}

function cleanText(element) {
  return element.textContent.replace(/\s+/g, ' ').trim();
}

function readCards(doc, site) {
  return [...doc.querySelectorAll(site.cards)].map((element) => ({
    element,
    title: firstText(element, site.title, (el) => (el.getAttribute('title') || cleanText(el)).trim()) || '',
    price: firstText(element, site.price, (el) => parsePrice(cleanText(el))),
    store: firstText(element, site.store, cleanText) || '',
  }));
}

function dealPrice(deal) {
  const price = typeof deal.price === 'string' ? parsePrice(deal.price) : deal.price;
  return price === undefined ? null : price;
}

// `mismatch`: falta preço ou loja de um dos lados, a loja é outra ou o preço
// está longe - não é a mesma promoção.
function scoreCard(card, deal) {
  const title = titleSimilarity(card.title, deal.title);
  const price = dealPrice(deal);
  const cardStore = storeKey(card.store);
  const dealStore = storeKey(deal.store);
  if (card.price === null || price === null || !cardStore || cardStore !== dealStore) {
    return { title, score: 0, mismatch: true };
  }
  const priceScore = priceSimilarity(card.price, price);
  const score = WEIGHTS.title * title + WEIGHTS.price * priceScore + WEIGHTS.store;
  return { title, score, mismatch: priceScore < 1 - MAX_PRICE_DIFFERENCE };
}

// O card mais parecido com a promoção ({ title, price, store }) entre os
// `limit` primeiros, ou null.
function pickBest(cards, deal, limit = Infinity) {
  let best = null;
  for (const card of cards.slice(0, limit)) {
    if (!card.title) continue;
    const { title, score, mismatch } = scoreCard(card, deal);
    if (mismatch || title < MIN_TITLE_SIMILARITY || score < MIN_SCORE) continue;
    if (!best || score > best.score) best = { card, score };
  }
  return best;
}

// Marca o card mais parecido (e só ele). Devolve o card marcado ou null.
function highlightBest(doc, site, deal, limit) {
  const best = pickBest(readCards(doc, site), deal, limit);
  if (!best) return null;
  const element = best.card.element;
  if (element.classList.contains(MATCH_CLASS)) return best.card;
  doc.querySelectorAll(`.${MATCH_CLASS}`).forEach((old) => old.classList.remove(MATCH_CLASS));
  doc.querySelectorAll(`.${BADGE_CLASS}`).forEach((old) => old.remove());
  element.classList.add(MATCH_CLASS);
  const badge = doc.createElement('div');
  badge.className = BADGE_CLASS;
  badge.textContent = `Mais parecida com a promoção (${Math.round(best.score * 100)}%)`;
  element.insertBefore(badge, element.firstChild);
  return best.card;
}

// `mode`: 'product' (a busca pelo produto) ou 'recent' (as promoções mais novas).
async function saveCompetitorMatch(storage, url, deal, now = Date.now(), mode = 'product') {
  const stored = (await storage.get(STORAGE_KEY))[STORAGE_KEY] || {};
  const kept = {};
  Object.entries(stored).forEach(([key, entry]) => {
    if (entry && now - entry.at <= MAX_AGE_MS) kept[key] = entry;
  });
  kept[matchKey(url)] = {
    at: now,
    mode,
    deal: { title: deal.title || '', price: dealPrice(deal), store: deal.store || '' },
  };
  await storage.set({ [STORAGE_KEY]: kept });
}

// { deal, mode } guardados para a página, ou null.
async function loadCompetitorMatch(storage, url, now = Date.now()) {
  const stored = (await storage.get(STORAGE_KEY))[STORAGE_KEY] || {};
  const entry = stored[matchKey(url)];
  if (!entry || now - entry.at > MAX_AGE_MS) return null;
  return { deal: entry.deal, mode: entry.mode || 'product' };
}

// Usado pelos botões do ladrão (content.js).
function rememberCompetitorSearch(url, deal, mode) {
  return saveCompetitorMatch(chrome.storage.local, url, deal, Date.now(), mode);
}

const OBSERVE_DELAY_MS = 200;
// Os cards chegam aos poucos (hidratação, rolagem); depois disso para de observar.
const OBSERVE_FOR_MS = 60 * 1000;

async function bootstrapSearchPage(doc, location) {
  const site = siteFor(location.hostname);
  if (!site) return;
  const match = await loadCompetitorMatch(chrome.storage.local, location.href);
  if (!match) return;
  const limit = RESULT_LIMITS[match.mode] || PRODUCT_SEARCH_RESULTS;

  let scrolled = false;
  const run = () => {
    const card = highlightBest(doc, site, match.deal, limit);
    if (card && !scrolled && typeof card.element.scrollIntoView === 'function') {
      scrolled = true;
      card.element.scrollIntoView({ block: 'center', behavior: 'smooth' });
    }
  };
  let scheduled = false;
  const observer = new MutationObserver(() => {
    if (scheduled) return;
    scheduled = true;
    setTimeout(() => {
      scheduled = false;
      run();
    }, OBSERVE_DELAY_MS);
  });
  observer.observe(doc.body, { childList: true, subtree: true });
  setTimeout(() => observer.disconnect(), OBSERVE_FOR_MS);
  run();
}

const api = {
  firstWords,
  parsePrice,
  storeKey,
  titleSimilarity,
  matchKey,
  siteFor,
  readCards,
  pickBest,
  highlightBest,
  saveCompetitorMatch,
  loadCompetitorMatch,
  rememberCompetitorSearch,
  PRODUCT_SEARCH_RESULTS,
};

const isNode = typeof module !== 'undefined' && module.exports;

if (isNode) {
  module.exports = api;
} else {
  self.PelandoKW = self.PelandoKW || {};
  Object.assign(self.PelandoKW, api);
  // Só age nas páginas de busca dos concorrentes, para uma conta Pelando (src/access.js).
  const location = typeof window !== 'undefined' ? window.location : null;
  if (location && siteFor(location.hostname)) {
    self.pelandoWhenAllowed(() => bootstrapSearchPage(document, location));
  }
}

})();
