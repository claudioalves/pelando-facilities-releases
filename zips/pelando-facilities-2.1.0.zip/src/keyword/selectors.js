(function () {
'use strict';

function findTitleInput(root = document) {
  return root.querySelector('input[name="title"]');
}

function findPriceInput(root = document) {
  return root.querySelector('input[name="price"]');
}

function findSourceUrlField(root = document) {
  return root.querySelector('textarea[name="sourceUrl"]');
}

const api = { findTitleInput, findPriceInput, findSourceUrlField };

if (typeof module !== 'undefined' && module.exports) {
  module.exports = api;
} else {
  self.PelandoKW = self.PelandoKW || {};
  Object.assign(self.PelandoKW, api);
}

})();
