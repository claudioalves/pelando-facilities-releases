// Starts only for a Pelando account (see access.js).
pelandoWhenAllowed(function () {
  let scheduled = false;

  // What every backoffice gets, Pelando's and Promoninja's. They're
  // single-page apps that update the country counts live, so re-check on DOM
  // changes, batched to one pass per frame.
  function scheduleSync() {
    if (scheduled) return;
    scheduled = true;
    requestAnimationFrame(function () {
      scheduled = false;
      syncNextCountryButton(document);
      syncBackofficeSaveShortcut(document);
    });
  }

  const observer = new MutationObserver(scheduleSync);
  observer.observe(document.body, { childList: true, subtree: true, characterData: true, attributes: true, attributeFilter: ['aria-label'] });

  scheduleSync();
});
