const PELANDO_ACTION_BUTTON_CLASS = 'pelando-action-button';
const PELANDO_BO_API_MESSAGE = 'PELANDO_BO_API';
const PELANDO_OPEN_TAB_MESSAGE = 'PELANDO_OPEN_TAB';
const PELANDO_OPEN_CHAT_MESSAGE = 'PELANDO_OPEN_CHAT';
// The backoffice's status for a rejected deal: rejecting removes it.
const PELANDO_REJECTED_DEAL_STATUSES = ['deleted', 'rejected'];

// The deal slug is the last segment of /d/<slug> or /t/<slug>, on either the
// public site or the backoffice (both use the same paths).
function dealSlugFromUrl(href) {
  let url;
  try {
    url = new URL(href);
  } catch (err) {
    return null;
  }
  const match = url.pathname.match(/^\/(d|t)\/([^/]+)/);
  return match ? match[2] : null;
}

function sendExtensionMessage(message) {
  return new Promise(function (resolve, reject) {
    chrome.runtime.sendMessage(message, function (response) {
      if (chrome.runtime.lastError) {
        reject(new Error('A extensão foi atualizada. Recarregue a página e tente de novo.'));
        return;
      }
      if (!response || response.error) {
        reject(new Error(response ? response.error : 'Sem resposta da extensão.'));
        return;
      }
      resolve(response.data);
    });
  });
}

// Backoffice API calls go through the service worker: it holds the moderator's
// backoffice session and isn't subject to the page's CORS rules.
function callBackoffice(method, path, body) {
  return sendExtensionMessage({ type: PELANDO_BO_API_MESSAGE, method: method, path: path, body: body });
}

// The slug lookup only reliably carries the deal id (the backoffice uses it
// just to redirect), so the full deal - status, store link - comes from the
// id lookup, which wraps it as { deal, filtersApplied, reports }.
async function fetchDealBySlug(slug) {
  const found = await callBackoffice('GET', '/deals/slug/' + encodeURIComponent(slug));
  if (!found || !found.id) throw new Error('Promoção não encontrada no backoffice.');
  return fetchDealById(found.id);
}

async function fetchDealById(id) {
  const details = await callBackoffice('GET', '/deals/' + encodeURIComponent(id));
  const deal = (details && details.deal) || details;
  if (!deal || !deal.id) throw new Error('Promoção não encontrada no backoffice.');
  return deal;
}

function isDealRejected(deal) {
  return PELANDO_REJECTED_DEAL_STATUSES.includes(deal && deal.status);
}

// The backoffice deal page's "Conversar" button chats with `deal.author.id`;
// `deal.user` can be someone else, so it's only a fallback.
function dealOwnerId(deal) {
  if (deal.author && deal.author.id) return deal.author.id;
  if (deal.authorId) return deal.authorId;
  const owner = deal.user || deal.owner || deal.creator || deal.createdBy;
  return (owner && owner.id) || deal.userId || deal.ownerId || null;
}

function dealRejectionReasonList(deal) {
  const list = deal.deletionReasons || deal.rejectionReasons || deal.reasons || [];
  return Array.isArray(list) ? list : [];
}

function normalizeReasonLabel(text) {
  return typeof text === 'string' ? text.trim().toLowerCase() : '';
}

// Names a reason goes by: the backoffice shows `bannerTitle || title` in its
// "motivo de deleção encontrado" box, and the sheet calls the banner title
// `summary`.
function reasonLabelsOf(reason) {
  return [reason.title, reason.bannerTitle, reason.summary].map(normalizeReasonLabel).filter(Boolean);
}

// Ids of the reasons the deal was rejected with, when the payload carries them.
function dealRejectionReasonIds(deal) {
  return dealRejectionReasonList(deal)
    .map(function (r) {
      if (typeof r === 'string') return r;
      return r && (r.id || r.deletionReasonId || (r.deletionReason && r.deletionReason.id));
    })
    .filter(Boolean);
}

let deletionReasonsRequest = null;

function fetchDeletionReasons() {
  if (!deletionReasonsRequest) {
    deletionReasonsRequest = callBackoffice('GET', '/deletion-reasons').catch(function (err) {
      deletionReasonsRequest = null;
      throw err;
    });
  }
  return deletionReasonsRequest;
}

function showActionToast(text, isError) {
  const toast = document.createElement('div');
  toast.className = 'pelando-action-toast' + (isError ? ' pelando-action-toast--error' : '');
  toast.textContent = text;
  document.body.appendChild(toast);
  setTimeout(function () {
    toast.remove();
  }, 4000);
}

// Builds an empty dialog and returns its parts; `close` removes it from the page.
function createDialog(titleText, descriptionText) {
  const overlay = document.createElement('div');
  overlay.className = 'pelando-action-overlay';
  const dialog = document.createElement('div');
  dialog.className = 'pelando-action-dialog';
  dialog.setAttribute('role', 'dialog');
  dialog.setAttribute('aria-modal', 'true');

  const title = document.createElement('h2');
  title.className = 'pelando-action-dialog-title';
  title.textContent = titleText;
  const description = document.createElement('p');
  description.className = 'pelando-action-dialog-description';
  description.textContent = descriptionText;
  const body = document.createElement('div');
  const footer = document.createElement('div');
  footer.className = 'pelando-action-dialog-footer';

  dialog.append(title, description, body, footer);
  overlay.appendChild(dialog);
  document.body.appendChild(overlay);

  let onClose = function () {};
  function onKeyDown(event) {
    if (event.key === 'Escape') close();
  }
  function close() {
    document.removeEventListener('keydown', onKeyDown, true);
    overlay.remove();
    onClose();
  }
  overlay.addEventListener('click', function (event) {
    if (event.target === overlay) close();
  });
  document.addEventListener('keydown', onKeyDown, true);

  return {
    overlay: overlay,
    body: body,
    footer: footer,
    close: close,
    onClose: function (fn) {
      onClose = fn;
    },
  };
}

function createDialogButton(label, variant) {
  const button = document.createElement('button');
  button.type = 'button';
  button.className = 'pelando-action-dialog-button pelando-action-dialog-button--' + variant;
  button.textContent = label;
  return button;
}

// Resolves true when the moderator confirms, false when they cancel.
function openConfirmDialog(options) {
  return new Promise(function (resolve) {
    const dialog = createDialog(options.title, options.description);
    let confirmed = false;
    dialog.onClose(function () {
      resolve(confirmed);
    });
    const cancel = createDialogButton('Cancelar', 'outline');
    const confirm = createDialogButton(options.confirmLabel, 'primary');
    cancel.addEventListener('click', dialog.close);
    confirm.addEventListener('click', function () {
      confirmed = true;
      dialog.close();
    });
    dialog.footer.append(cancel, confirm);
    confirm.focus();
  });
}

// Mirrors the backoffice's rejection dialog: a searchable list of reasons with
// multi-select. Resolves with the chosen reasons, or null when cancelled.
function openReasonsDialog(dealTitle, reasons) {
  return new Promise(function (resolve) {
    const dialog = createDialog(
      'Reprovar promoção',
      'Escolha o motivo para reprovar a promoção “' + dealTitle + '”.'
    );
    const selected = [];
    let result = null;
    dialog.onClose(function () {
      resolve(result);
    });

    const search = document.createElement('input');
    search.type = 'search';
    search.className = 'pelando-action-reasons-search';
    search.placeholder = 'Buscar motivo...';
    const list = document.createElement('div');
    list.className = 'pelando-action-reasons-list';
    const chips = document.createElement('div');
    chips.className = 'pelando-action-reasons-chips';
    dialog.body.append(search, list, chips);

    const cancel = createDialogButton('Cancelar', 'outline');
    const confirm = createDialogButton('Reprovar', 'danger');
    dialog.footer.append(cancel, confirm);

    const checkboxes = new Map();

    function isSelected(reason) {
      return selected.some(function (r) {
        return r.id === reason.id;
      });
    }

    function toggle(reason) {
      const index = selected.findIndex(function (r) {
        return r.id === reason.id;
      });
      if (index === -1) selected.push(reason);
      else selected.splice(index, 1);
      render();
    }

    function render() {
      checkboxes.forEach(function (checkbox, id) {
        checkbox.checked = selected.some(function (r) {
          return r.id === id;
        });
      });
      chips.replaceChildren();
      selected.forEach(function (reason) {
        const chip = document.createElement('span');
        chip.className = 'pelando-action-reasons-chip';
        chip.textContent = reason.title;
        const remove = document.createElement('button');
        remove.type = 'button';
        remove.textContent = '×';
        remove.setAttribute('aria-label', 'Remover ' + reason.title);
        remove.addEventListener('click', function () {
          toggle(reason);
        });
        chip.appendChild(remove);
        chips.appendChild(chip);
      });
      confirm.disabled = selected.length === 0;
      confirm.textContent = selected.length ? 'Reprovar (' + selected.length + ')' : 'Reprovar';
    }

    reasons.forEach(function (reason) {
      const item = document.createElement('label');
      item.className = 'pelando-action-reasons-item';
      const checkbox = document.createElement('input');
      checkbox.type = 'checkbox';
      checkbox.checked = isSelected(reason);
      checkbox.addEventListener('change', function () {
        toggle(reason);
      });
      const text = document.createElement('span');
      text.textContent = reason.title;
      item.append(checkbox, text);
      item.dataset.search = reason.title.toLowerCase();
      checkboxes.set(reason.id, checkbox);
      list.appendChild(item);
    });

    search.addEventListener('input', function () {
      const query = search.value.trim().toLowerCase();
      list.querySelectorAll('.pelando-action-reasons-item').forEach(function (item) {
        item.hidden = query !== '' && !item.dataset.search.includes(query);
      });
    });

    cancel.addEventListener('click', dialog.close);
    confirm.addEventListener('click', function () {
      if (selected.length === 0) return;
      result = selected.slice();
      dialog.close();
    });

    render();
    search.focus();
  });
}


function createReasonVersionOption(name, value, label, text, checked, onChange) {
  const option = document.createElement('label');
  option.className = 'pelando-action-justify-option';
  const radio = document.createElement('input');
  radio.type = 'radio';
  radio.name = name;
  radio.value = value;
  radio.checked = checked;
  radio.addEventListener('change', onChange);
  const content = document.createElement('span');
  const heading = document.createElement('strong');
  heading.textContent = label;
  const body = document.createElement('span');
  body.className = 'pelando-action-justify-text';
  body.textContent = text;
  content.append(heading, body);
  option.append(radio, content);
  return option;
}

// Shows the registered messages for the deal's rejection reason(s) so the
// moderator picks which one to send. Only when the reason couldn't be found
// does it also list every reason to pick from. Resolves with the text to
// send, or null when cancelled.
function openJustifyDialog(dealTitle, reasons, preselectedIds) {
  return new Promise(function (resolve) {
    const selected = reasons.filter(function (r) {
      return preselectedIds.includes(r.id);
    });
    const reasonKnown = selected.length > 0;
    const dialog = createDialog(
      'Justificar ao usuário',
      reasonKnown
        ? 'Escolha a mensagem para o dono de “' + dealTitle + '”. O chat abre com o texto pronto, sem enviar.'
        : 'Não achei o motivo da reprova de “' +
            dealTitle +
            '”. Escolha o motivo e a mensagem. O chat abre com o texto pronto, sem enviar.'
    );
    dialog.body.className = 'pelando-action-dialog-body';
    const versions = new Map();
    let result = null;
    dialog.onClose(function () {
      resolve(result);
    });

    const search = document.createElement('input');
    search.type = 'search';
    search.className = 'pelando-action-reasons-search';
    search.placeholder = 'Buscar motivo...';
    const list = document.createElement('div');
    list.className = 'pelando-action-reasons-list';
    const messages = document.createElement('div');
    messages.className = 'pelando-action-justify-messages';
    if (reasonKnown) dialog.body.append(messages);
    else dialog.body.append(search, list, messages);

    const cancel = createDialogButton('Cancelar', 'outline');
    const confirm = createDialogButton('Abrir chat', 'primary');
    dialog.footer.append(cancel, confirm);

    function renderMessages() {
      messages.replaceChildren();
      selected.forEach(function (reason) {
        const block = document.createElement('div');
        block.className = 'pelando-action-justify-reason';
        const title = document.createElement('div');
        title.className = 'pelando-action-justify-reason-title';
        title.textContent = reason.title;
        const name = 'pelando-justify-' + reason.id;
        const current = versions.get(reason.id) || 0;
        function choose(value) {
          return function () {
            versions.set(reason.id, value);
          };
        }
        block.appendChild(title);
        reasonReplies(reason).forEach(function (text, index) {
          block.appendChild(
            createReasonVersionOption(name, String(index), replyLabel(index), text, current === index, choose(index))
          );
        });
        messages.appendChild(block);
      });
      confirm.disabled = selected.length === 0;
    }

    reasons.forEach(function (reason) {
      const item = document.createElement('label');
      item.className = 'pelando-action-reasons-item';
      const checkbox = document.createElement('input');
      checkbox.type = 'checkbox';
      checkbox.checked = selected.includes(reason);
      checkbox.addEventListener('change', function () {
        const index = selected.indexOf(reason);
        if (index === -1) selected.push(reason);
        else selected.splice(index, 1);
        renderMessages();
      });
      const text = document.createElement('span');
      text.textContent = reason.title;
      item.append(checkbox, text);
      item.dataset.search = reason.title.toLowerCase();
      list.appendChild(item);
    });

    search.addEventListener('input', function () {
      const query = search.value.trim().toLowerCase();
      list.querySelectorAll('.pelando-action-reasons-item').forEach(function (item) {
        item.hidden = query !== '' && !item.dataset.search.includes(query);
      });
    });

    cancel.addEventListener('click', dialog.close);
    confirm.addEventListener('click', function () {
      if (selected.length === 0) return;
      result = selected
        .map(function (reason) {
          return reasonReplies(reason)[versions.get(reason.id) || 0];
        })
        .join('\n\n');
      dialog.close();
    });

    renderMessages();
    (reasonKnown ? confirm : search).focus();
  });
}

// The reasons the deal was rejected with, with the messages to offer: the
// sheet's (with the moderator's edits) for reasons found by id, title or
// banner title in the payload's `deletionReasons` or on the page
// (`extraReasonIds`); a reason missing from the sheet offers the message the
// backoffice itself has for it (`description`).
function resolveDealReasons(deal, reasons, extraReasonIds) {
  const found = [];
  function add(reason) {
    if (reason && !found.includes(reason)) found.push(reason);
  }
  dealRejectionReasonList(deal).forEach(function (item, index) {
    const entry = item && item.deletionReason ? item.deletionReason : item;
    const id = typeof entry === 'string' ? entry : entry && (entry.id || item.deletionReasonId);
    const labels = entry && typeof entry === 'object' ? reasonLabelsOf(entry) : [];
    const known = reasons.find(function (r) {
      return (
        r.id === id ||
        reasonLabelsOf(r).some(function (label) {
          return labels.includes(label);
        })
      );
    });
    if (known) {
      add(known);
    } else if (entry && typeof entry === 'object' && entry.description) {
      add({
        id: id || 'backoffice-' + index,
        title: entry.bannerTitle || entry.title || 'Motivo da reprova',
        messages: [entry.description],
      });
    }
  });
  (extraReasonIds || []).forEach(function (id) {
    add(
      reasons.find(function (r) {
        return r.id === id;
      })
    );
  });
  return found;
}

// Opens the chat with the deal's owner, text left pending for the chat tab.
async function openChatWithOwner(ownerId, text) {
  const chat = await callBackoffice('POST', '/chats/', { memberId: ownerId });
  if (!chat || !chat.id) throw new Error('O backoffice não devolveu a conversa com o usuário.');
  await sendExtensionMessage({ type: PELANDO_OPEN_CHAT_MESSAGE, chatId: chat.id, text: text });
}

// `openChat(ownerId, text)` can replace how the chat is opened (the
// backoffice page uses its own "Conversar" button).
async function justifyDeal(deal, extraReasonIds, openChat) {
  if (!isDealRejected(deal)) {
    showActionToast('Só dá pra justificar promoções reprovadas.', true);
    return;
  }
  const ownerId = dealOwnerId(deal);
  if (!ownerId) throw new Error('Não encontrei o dono da promoção no backoffice.');
  const reasons = await getDealReasonMessages();
  const dealReasons = resolveDealReasons(deal, reasons, extraReasonIds);
  if (dealReasons.length === 0) {
    console.warn('[pelando-chat-ext] motivo da reprova não identificado', {
      deletionReasons: dealRejectionReasonList(deal),
      pageReasonIds: extraReasonIds || [],
    });
  }
  const text = dealReasons.length
    ? await openJustifyDialog(
        deal.title,
        dealReasons,
        dealReasons.map(function (r) {
          return r.id;
        })
      )
    : await openJustifyDialog(deal.title, reasons, []);
  if (!text) return;
  await (openChat || openChatWithOwner)(ownerId, text);
}

async function expireDeal(deal) {
  if (deal.status === 'expired') {
    showActionToast('Essa promoção já está expirada.');
    return;
  }
  const confirmed = await openConfirmDialog({
    title: 'Expirar promoção',
    description: 'Tem certeza que deseja marcar a promoção “' + deal.title + '” como expirada?',
    confirmLabel: 'Expirar',
  });
  if (!confirmed) return;
  await callBackoffice('PUT', '/deals/' + deal.id + '/expire');
  showActionToast('Promoção marcada como expirada.');
}

async function rejectDeal(deal) {
  if (deal.status === 'deleted') {
    showActionToast('Essa promoção já foi removida.');
    return;
  }
  const reasons = (await fetchDeletionReasons()) || [];
  // Most used reasons first, when rejectionReasons.js is loaded.
  const ordered = typeof sortReasonsByUsage === 'function' ? sortReasonsByUsage(reasons) : reasons;
  const chosen = await openReasonsDialog(deal.title, ordered);
  if (!chosen) return;
  await callBackoffice('PUT', '/deals/' + deal.id + '/reject', {
    reasons: chosen.map(function (r) {
      return r.id;
    }),
  });
  showActionToast('Promoção reprovada.');
}

async function openDealStore(deal) {
  const storeUrl = deal.redirectUrl || deal.sourceUrl;
  if (!storeUrl) {
    showActionToast('Essa promoção não tem link da loja.', true);
    return;
  }
  // Opened by the service worker: the tab is created after async work, which
  // the page's popup blocker would otherwise stop.
  await sendExtensionMessage({ type: PELANDO_OPEN_TAB_MESSAGE, url: storeUrl });
}

const PELANDO_DEAL_ACTIONS = [
  { key: 'expire', label: 'Expirar', loadingLabel: 'Expirando...', run: expireDeal },
  { key: 'reject', label: 'Reprovar', loadingLabel: 'Carregando...', run: rejectDeal },
  { key: 'store', label: 'Loja', loadingLabel: 'Abrindo...', run: openDealStore },
  // Only on the deal's own page: it's enabled only for rejected deals, which
  // takes a lookup that lists with many cards shouldn't make on load. And
  // only on Pelando: the chat it opens and its messages are Pelando's.
  { key: 'justify', label: 'Justificar ao usuário', loadingLabel: 'Carregando...', run: justifyDeal, dealPageOnly: true, pelandoOnly: true },
];

const PELANDO_JUSTIFY_DISABLED_HINT = 'Disponível só para promoções reprovadas';

// After a click: a deal just seen not to be rejected disables the button
// again; otherwise (rejected, or the lookup failed) it stays usable.
function disableJustifyUnlessRejected(button, deal) {
  const notRejected = !!deal && !isDealRejected(deal);
  button.disabled = notRejected;
  button.title = notRejected ? PELANDO_JUSTIFY_DISABLED_HINT : '';
}

// Keeps the button disabled until the deal turns out to be rejected; if the
// lookup fails it's left enabled so a click can report why.
function enableWhenRejected(button, loadDeal) {
  button.disabled = true;
  button.title = PELANDO_JUSTIFY_DISABLED_HINT;
  return loadDeal().then(
    function (deal) {
      const rejected = isDealRejected(deal);
      button.disabled = !rejected;
      button.title = rejected ? '' : PELANDO_JUSTIFY_DISABLED_HINT;
    },
    function () {
      button.disabled = false;
      button.title = '';
    }
  );
}

async function runDealAction(action, slug, button) {
  if (button.disabled) return;
  button.disabled = true;
  button.textContent = action.loadingLabel;
  let deal = null;
  try {
    deal = await fetchDealBySlug(slug);
    await action.run(deal);
  } catch (err) {
    showActionToast(err.message || 'Não foi possível concluir a ação.', true);
  } finally {
    button.textContent = action.label;
    if (action.key === 'justify') disableJustifyUnlessRejected(button, deal);
    else button.disabled = false;
  }
}

// Stores whose colors the Loja button takes, recognized by the store link's
// host or, failing that, by the store's name in the backoffice. Other stores
// keep the button's default look.
const PELANDO_STORE_BRANDS = [
  { key: 'mercadolivre', hosts: /(^|\.)(mercadolivre|mercadolibre)\.com/, names: /mercado ?livre/ },
  { key: 'amazon', hosts: /(^|\.)(amazon\.com|amzn\.to)/, names: /amazon/ },
  { key: 'shopee', hosts: /(^|\.)shopee\.com/, names: /shopee/ },
  { key: 'americanas', hosts: /(^|\.)americanas\.com/, names: /americanas/ },
  { key: 'kabum', hosts: /(^|\.)kabum\.com/, names: /kabum/ },
  { key: 'magalu', hosts: /(^|\.)(magazineluiza|magalu|magazinevoce)\.com/, names: /magazine ?luiza|magalu/ },
  { key: 'steam', hosts: /(^|\.)(steampowered|steamcommunity)\.com/, names: /steam/ },
  { key: 'epic', hosts: /(^|\.)epicgames\.com/, names: /epic ?games|^epic$/ },
  { key: 'terabyte', hosts: /(^|\.)terabyteshop\.com/, names: /terabyte/ },
  { key: 'aliexpress', hosts: /(^|\.)aliexpress\.(com|us)/, names: /ali ?express/ },
];

function hostOf(url) {
  try {
    return new URL(url).hostname.toLowerCase();
  } catch (err) {
    return '';
  }
}

// The brand key for the deal's store, or null for any other store.
function storeBrandFor(deal) {
  if (!deal) return null;
  const hosts = [deal.sourceUrl, deal.redirectUrl, deal.url, deal.link].map(hostOf).filter(Boolean);
  const name = String((deal.store && deal.store.name) || deal.storeName || '')
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase();
  const brand = PELANDO_STORE_BRANDS.find(function (b) {
    return hosts.some(function (host) {
      return b.hosts.test(host);
    });
  }) || PELANDO_STORE_BRANDS.find(function (b) {
    return name && b.names.test(name);
  });
  return brand ? brand.key : null;
}

function paintStoreButton(button, deal) {
  const brand = storeBrandFor(deal);
  if (brand) button.classList.add(PELANDO_ACTION_BUTTON_CLASS + '--store-' + brand);
}

// Deals looked up when their buttons are made (to paint Loja and to enable
// Justificar), shared by the buttons of one deal and fetched at most two at a
// time, so a long list doesn't send a burst of requests to the backoffice.
const PELANDO_STORE_LOOKUP_CONCURRENCY = 2;
const storeLookups = new Map();
const storeLookupQueue = [];
let storeLookupsRunning = 0;

function runNextStoreLookup() {
  if (storeLookupsRunning >= PELANDO_STORE_LOOKUP_CONCURRENCY || storeLookupQueue.length === 0) return;
  const next = storeLookupQueue.shift();
  storeLookupsRunning += 1;
  fetchDealBySlug(next.slug)
    .then(next.resolve, function (err) {
      storeLookups.delete(next.slug);
      next.reject(err);
    })
    .finally(function () {
      storeLookupsRunning -= 1;
      runNextStoreLookup();
    });
}

function lookUpDealForStore(slug) {
  if (!storeLookups.has(slug)) {
    storeLookups.set(
      slug,
      new Promise(function (resolve, reject) {
        storeLookupQueue.push({ slug: slug, resolve: resolve, reject: reject });
        runNextStoreLookup();
      })
    );
  }
  return storeLookups.get(slug);
}

// Paints the Loja button once it scrolls into view.
function paintStoreButtonWhenVisible(button, slug) {
  if (typeof IntersectionObserver !== 'function') return;
  const observer = new IntersectionObserver(function (entries) {
    if (!entries.some(function (entry) { return entry.isIntersecting; })) return;
    observer.disconnect();
    lookUpDealForStore(slug).then(function (deal) {
      paintStoreButton(button, deal);
    }, function () {});
  });
  observer.observe(button);
}

// Buttons for the backoffice actions on one deal, placed next to its Editar
// button. The deal is looked up only when a button is clicked, so lists with
// many cards don't hit the backoffice on load. `options.dealPage` adds the
// actions meant for the deal's own page.
function createDealActionButtons(dealUrl, options) {
  const slug = dealSlugFromUrl(dealUrl);
  if (!slug) return [];
  const dealPage = !!(options && options.dealPage);
  const onPelando = /(^|\.)pelando\.com\.br$/.test(hostOf(dealUrl));
  const actions = PELANDO_DEAL_ACTIONS.filter(function (action) {
    return (dealPage || !action.dealPageOnly) && (onPelando || !action.pelandoOnly);
  });
  return actions.map(function (action) {
    const button = document.createElement('button');
    button.type = 'button';
    button.className = PELANDO_ACTION_BUTTON_CLASS + ' ' + PELANDO_ACTION_BUTTON_CLASS + '--' + action.key;
    button.textContent = action.label;
    button.addEventListener('click', function (event) {
      // Cards navigate on click; keep the click to the button.
      event.preventDefault();
      event.stopPropagation();
      runDealAction(action, slug, button);
    });
    if (action.key === 'justify') {
      enableWhenRejected(button, function () {
        return lookUpDealForStore(slug);
      });
    }
    if (action.key === 'store') {
      // The deal's own page already looks the deal up for Justificar.
      if (dealPage) lookUpDealForStore(slug).then(function (deal) { paintStoreButton(button, deal); }, function () {});
      else paintStoreButtonWhenVisible(button, slug);
    }
    return button;
  });
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = {
    dealSlugFromUrl,
    createDealActionButtons,
    fetchDealById,
    isDealRejected,
    dealOwnerId,
    dealRejectionReasonIds,
    resolveDealReasons,
    openJustifyDialog,
    justifyDeal,
    openChatWithOwner,
    enableWhenRejected,
    disableJustifyUnlessRejected,
    storeBrandFor,
    paintStoreButton,
    openConfirmDialog,
    openReasonsDialog,
    runDealAction,
    PELANDO_DEAL_ACTIONS,
  };
}
