// Shows whether this Chrome profile's account can use the extension, and how
// to unlock it when it can't (see checkAccess in background.js).
function renderAccess(doc, access) {
  const status = doc.getElementById('status');
  const title = doc.getElementById('status-title');
  const text = doc.getElementById('status-text');
  const button = doc.getElementById('open-accounts');
  const hint = doc.getElementById('hint');

  if (access.allowed) {
    status.classList.add('ok');
    title.textContent = 'Liberada';
    text.textContent = 'Conectado como ' + access.email + '.';
    button.hidden = true;
    hint.hidden = true;
    doc.getElementById('open-backup').hidden = false;
    return;
  }
  status.classList.remove('ok');
  title.textContent = 'Bloqueada';
  text.textContent = access.email
    ? 'O Chrome está conectado como ' + access.email + ', que não é uma conta @pelando.com.br.'
    : 'O Chrome não está conectado a nenhuma conta.';
  button.hidden = false;
  hint.hidden = false;
  doc.getElementById('open-backup').hidden = true;
}

if (typeof document !== 'undefined' && document.getElementById('status')) {
  chrome.runtime.sendMessage({ type: 'PELANDO_ACCESS' }, function (response) {
    const access = response && response.data ? response.data : { allowed: false, email: '' };
    renderAccess(document, access);
  });
  document.getElementById('open-accounts').addEventListener('click', function () {
    chrome.tabs.create({ url: 'chrome://settings/people' });
  });
  document.getElementById('open-backup').addEventListener('click', function () {
    chrome.runtime.openOptionsPage();
  });
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = { renderAccess };
}
