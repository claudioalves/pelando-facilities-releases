function findChatInputField() {
  return document.querySelector('div.chat-input-field');
}

function findChatInputImageButton(container) {
  const root = container || document;
  return root.querySelector('button.chat-input-image-button:not(.pelando-chat-ext-injected)');
}

function findChatInputTextarea() {
  return document.querySelector('textarea.chat-input-text');
}

function findContactName() {
  const el = document.querySelector('span.chat-header-name');
  return el ? el.textContent.trim() : '';
}

function findMessagesList() {
  return document.querySelector('div.chat-messages-list');
}

function hasOwnMessage(messagesListEl) {
  if (!messagesListEl) return false;
  return messagesListEl.querySelector('div.message-group.message-own') !== null;
}

function findLastContactMessageText(messagesListEl) {
  if (!messagesListEl) return '';
  const contactGroups = messagesListEl.querySelectorAll('div.message-group.message-other');
  if (contactGroups.length === 0) return '';
  return contactGroups[contactGroups.length - 1].textContent.trim();
}

// One entry per message bubble, in conversation order.
function getConversationEntries(messagesListEl) {
  if (!messagesListEl) return [];
  const entries = [];
  messagesListEl.querySelectorAll('div.message-group').forEach((group) => {
    const isOwn = group.classList.contains('message-own');
    group.querySelectorAll('div.message-bubble .message-content').forEach((bubble) => {
      const texto = bubble.textContent.trim();
      if (texto) entries.push({ isOwn, texto });
    });
  });
  return entries;
}

// Bounding box (viewport CSS pixels) enclosing the header, messages and
// input area of the chat panel, so a screenshot can be cropped to just the
// chat itself instead of the whole tab.
function getChatPanelBounds() {
  const header = document.querySelector('div.chat-header-row');
  const messages = document.querySelector('div.chat-messages-section');
  const input = document.querySelector('div.chat-input-area');
  const rects = [header, messages, input].filter(Boolean).map((el) => el.getBoundingClientRect());
  if (rects.length === 0) return null;

  const left = Math.min(...rects.map((r) => r.left));
  const top = Math.min(...rects.map((r) => r.top));
  const right = Math.max(...rects.map((r) => r.right));
  const bottom = Math.max(...rects.map((r) => r.bottom));
  return { left, top, width: right - left, height: bottom - top };
}

function findExistingInjectedButton(container) {
  return container ? container.querySelector('.pelando-chat-ext-button') : null;
}

function findExistingQuickAddButton(container) {
  return container ? container.querySelector('.pelando-chat-ext-quickadd-button') : null;
}

function countContactMessages(messagesListEl) {
  if (!messagesListEl) return 0;
  return messagesListEl.querySelectorAll('div.message-group.message-other').length;
}

function findHeaderChatCount() {
  return document.getElementById('chat-count');
}

function getHeaderUnreadCount() {
  const el = findHeaderChatCount();
  if (!el || el.style.display === 'none') return 0;
  const parsed = parseInt((el.textContent || '').trim(), 10);
  return isNaN(parsed) ? 0 : parsed;
}

function getSidebarUnreadTotal() {
  const badges = document.querySelectorAll('.chat-list-item-badge .badge-text');
  let total = 0;
  badges.forEach(function (badge) {
    const parsed = parseInt((badge.textContent || '').trim(), 10);
    if (!isNaN(parsed)) {
      total += parsed;
    }
  });
  return total;
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = {
    findChatInputField,
    findChatInputImageButton,
    findChatInputTextarea,
    findContactName,
    findMessagesList,
    hasOwnMessage,
    findLastContactMessageText,
    getConversationEntries,
    getChatPanelBounds,
    findExistingInjectedButton,
    findExistingQuickAddButton,
    countContactMessages,
    findHeaderChatCount,
    getHeaderUnreadCount,
    getSidebarUnreadTotal,
  };
}
