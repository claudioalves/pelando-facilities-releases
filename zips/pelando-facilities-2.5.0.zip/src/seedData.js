const PELANDO_CHAT_EXT_SEED_THEMES = [
  { id: 'saudacoes', nome: 'Saudações', palavrasChave: [] },
  {
    id: 'sentimos-muito',
    nome: 'Sentimos muito',
    palavrasChave: ['promocao', 'promocoes', 'comentario', 'comentarios'],
  },
  {
    id: 'exclusao-conta',
    nome: 'Exclusão de conta',
    palavrasChave: ['excluir conta', 'deletar conta', 'cancelar conta'],
  },
  { id: 'cashback', nome: 'Cashback', palavrasChave: ['cashback', 'saldo', 'reembolso'] },
  {
    id: 'plataforma-promocoes',
    nome: 'Plataforma e Promoções',
    palavrasChave: ['cadastro', 'postar', 'cupom', 'devolucao', 'parceria'],
  },
  {
    id: 'moderacao-conteudo',
    nome: 'Moderação de Conteúdo',
    palavrasChave: ['autopromocao', 'ofensivo', 'golpe', 'banimento'],
  },
  {
    id: 'top-creators',
    nome: 'Top Creators',
    palavrasChave: ['top creator', 'top creators', 'selo exclusivo'],
  },
];

const PELANDO_CHAT_EXT_SEED_MESSAGES = [
  {
    id: 'greeting',
    temaId: 'saudacoes',
    nome: 'Salve {nome}, tudo bem?',
    texto: 'Salve {nome}, tudo bem?',
  },
  {
    id: 'promo-sing',
    temaId: 'sentimos-muito',
    nome: 'Promoção Singular - Antes de mais nada. Me desculpe se você se sentiu mal ao ver sua promoção deletada, não foi a intenção.',
    texto: 'Antes de mais nada. Me desculpe se você se sentiu mal ao ver sua promoção deletada, não foi a intenção.',
  },
  {
    id: 'promo-plural',
    temaId: 'sentimos-muito',
    nome: 'Promoção Plural - Antes de mais nada. Me desculpe se você se sentiu mal ao ver suas promoções deletadas, não foi a intenção.',
    texto: 'Antes de mais nada. Me desculpe se você se sentiu mal ao ver suas promoções deletadas, não foi a intenção.',
  },
  {
    id: 'coment-sing',
    temaId: 'sentimos-muito',
    nome: 'Comentário Singular - Antes de mais nada. Me desculpe se você se sentiu mal ao ver seu comentário deletado, não foi a intenção.',
    texto: 'Antes de mais nada. Me desculpe se você se sentiu mal ao ver seu comentário deletado, não foi a intenção.',
  },
  {
    id: 'coment-plural',
    temaId: 'sentimos-muito',
    nome: 'Comentário Plural - Antes de mais nada. Me desculpe se você se sentiu mal ao ver seus comentários deletados, não foi a intenção.',
    texto: 'Antes de mais nada. Me desculpe se você se sentiu mal ao ver seus comentários deletados, não foi a intenção.',
  },
  {
    id: 'excluir-conta',
    temaId: 'exclusao-conta',
    nome: 'Usuário quer excluir a conta',
    texto:
      'Sinto muito que você queira excluir sua conta. Aconteceu algo que posso fazer para ajudar? Se ainda assim preferir prosseguir, você pode acessar o seu perfil e ir até as configurações para realizar o processo. Conte com a gente para o que precisar!',
  },
  {
    id: 'o-que-e-pelando',
    temaId: 'plataforma-promocoes',
    nome: 'O que é o Pelando (dúvida básica)',
    texto:
      'O Pelando é uma rede social que ajuda as pessoas a encontrarem produtos em promoção. Não somos uma loja e não vendemos nenhum produto — apenas conectamos lojas seguras com pessoas interessadas em economizar. Como podemos te ajudar?',
  },
  {
    id: 'como-postar-promocao',
    temaId: 'plataforma-promocoes',
    nome: 'Como postar uma promoção',
    texto:
      "Será um prazer compartilhar suas promoções com a comunidade! Acesse o pelando.com.br, faça seu cadastro e clique em 'Postar'. O Time de Comunidade vai conferir se está tudo certinho e, pronto, sua promoção estará no ar! Esperamos te ver no Pelando!",
  },
  {
    id: 'loja-nao-cadastrada',
    temaId: 'plataforma-promocoes',
    nome: 'Loja não cadastrada',
    texto:
      'A loja que você enviou ainda não tem cadastro no Pelando. Nosso Time fará uma análise criteriosa — prezamos muito pela segurança dos usuários. Para uma loja ser aceita, ela precisa ter boa reputação no Reclame Aqui, Consumidor.gov ou Trustpilot.',
  },
  {
    id: 'devolucao-loja-parceira',
    temaId: 'plataforma-promocoes',
    nome: 'Usuário quer devolução (compra em loja parceira)',
    texto:
      'O Pelando não é uma loja e não vendemos produtos. Você pode nos informar em qual loja foi efetuada a compra? Podemos tentar conseguir o contato deles para você resolver diretamente.',
  },
  {
    id: 'parceria-comercial',
    temaId: 'plataforma-promocoes',
    nome: 'Parceria comercial / empresa interessada',
    texto: 'Para assuntos de parcerias, entre em contato pelo e-mail: comercial@pelandolabs.com.br. Um abraço!',
  },
  {
    id: 'autopromocao-identificada',
    temaId: 'moderacao-conteudo',
    nome: 'Autopromoção identificada',
    texto:
      'Nossa equipe identificou múltiplas tentativas de autopromoção que podem comprometer a experiência da comunidade. Qualquer divulgação para ganho pessoal vai contra o Código de Conduta do Pelando e pode resultar em infrações ou banimento. Podemos contar com você para manter o espaço colaborativo?',
  },
  {
    id: 'primeira-promocao-elogio',
    temaId: 'moderacao-conteudo',
    nome: 'Primeira promoção aprovada — elogio',
    texto:
      'Passando para dizer que você arrasou postando sua primeira promoção! Muitas pessoas conseguiram aproveitar e economizar. Qualquer dúvida, pode me chamar. Um abraço!',
  },
  {
    id: 'primeira-promocao-dicas',
    temaId: 'moderacao-conteudo',
    nome: 'Primeira promoção gelada — dicas',
    texto:
      'Que legal que você fez a sua primeira publicação! Dicas para as próximas pegarem fogo: 1. Confira se o preço está realmente bom — use a busca do Pelando para ver o histórico. 2. Não deixe informações importantes de fora: foto, título, descrição, preço e cupom. 3. Conte com o Time Pelando no chat a qualquer momento!',
  },
  {
    id: 'top-creators-o-que-e',
    temaId: 'top-creators',
    nome: 'O que é o programa Top Creators',
    texto:
      'O Top Creators dá visibilidade a Pelandeiros que se preocupam com a comunidade e criam conteúdos incríveis — publicam as melhores promoções e cupons e ajudam outros usuários com comentários pertinentes. Eles recebem um SELO EXCLUSIVO ao lado do nickname.',
  },
  {
    id: 'top-creators-como-se-tornar',
    temaId: 'top-creators',
    nome: 'Como se tornar um Top Creator',
    texto:
      'Só é possível via convite do Time Pelando. É importante manter-se ativo(a) na comunidade, criar conteúdo de qualidade, comentar, ajudar outros usuários e ter um bom comportamento seguindo nossas diretrizes. O Time está sempre analisando!',
  },
  {
    id: 'mtyq2g4omycd6g',
    temaId: 'saudacoes',
    nome: 'te ajudo em algo mais?',
    texto: 'te ajudo em algo mais?',
  },
  {
    id: 'mtyt0j02vauw7d',
    temaId: 'saudacoes',
    nome: 'Abraço, qualquer coisa dá um toque.',
    texto: 'Abraço, qualquer coisa dá um toque.',
  },
  {
    id: 'mtyyb7b70ub9sd',
    temaId: 'saudacoes',
    nome: 'Promoção renovada.',
    texto: 'Promoção renovada.',
  },
  {
    id: 'mtz5s4wbbsfjy7',
    temaId: 'saudacoes',
    nome: 'Em que posso ajudar?',
    texto: 'Em que posso ajudar?',
  },
  {
    id: 'mtzgfcwch6996j',
    temaId: 'cashback',
    nome: 'Cashback não rastreado 1',
    texto:
      'Entendo sua frustração :( Quando o cashback não é rastreado, geralmente é porque o clique do Pelando não foi o último validado pela loja. Isso pode acontecer por cookies antigos, carrinho cheio, alteração de aba, adblock, cupom externo ou priorização da loja por outro afiliado. Dá para investigar direitinho. É só preencher aqui: https://ajuda.pelando.com.br/cashback/formulario.',
  },
  {
    id: 'mtzgfrqu75qzvn',
    temaId: 'cashback',
    nome: 'Cashback não rastreado 2',
    texto:
      'Quando o cashback não aparece, significa que a loja não atribuiu o pedido ao Pelando. Isso pode ser causado por cookies antigos, último clique vindo de outro canal, mudança de aba, carrinho cheio, adblock ou priorização automática da loja. Você pode enviar aqui para análise: https://ajuda.pelando.com.br/cashback/formulario.',
  },
  {
    id: 'mtzgnv569swnmr',
    temaId: 'top-creators',
    nome: 'Os Top Creators são remunerados?',
    texto:
      'Os Top Creators, apesar de não terem qualquer tipo de vínculo empregatício com o Pelando, possuem alguns benefícios exclusivos. Desta forma, conseguimos recompensá-los por toda a contribuição e ajuda que prestam à comunidade.',
  },
  {
    id: 'mtzgrvv333inlo',
    temaId: 'cashback',
    nome: 'Cashback Cancelado 1',
    texto:
      'Vi que seu cashback foi cancelado e imagino como isso é chato. Normalmente isso acontece quando a loja entende que o último clique não ficou com o Pelando. Lembrando que, em casos de devolução, troca ou cancelamento do pedido, o cashback é cancelado automaticamente. Se não foi esse o caso, dá pra contestar! Preenche aqui pra gente analisar com a loja: https://ajuda.pelando.com.br/cashback/formulario',
  },
  {
    id: 'mtzgt3y8tvy715',
    temaId: 'cashback',
    nome: 'Cashback Cancelado 2',
    texto:
      'Entendo sua frustração. Quando o cashback é cancelado, significa que a loja não validou o rastreio ou identificou alguma regra da campanha. Em situações de devolução, troca ou cancelamento do pedido, o cashback é cancelado automaticamente. Se não foi o seu caso, envie os dados aqui para revisão: https://ajuda.pelando.com.br/cashback/formulario',
  },
  {
    id: 'mtzgth1opyheov',
    temaId: 'cashback',
    nome: 'Cashback Cancelado 3',
    texto:
      'Vi que seu cashback não foi aprovado. Isso pode acontecer por regras da loja, rastreamento não validado ou também quando há devolução, troca ou cancelamento da compra. Se sua compra foi finalizada normalmente, abre uma solicitação aqui: https://ajuda.pelando.com.br/cashback/formulario Vamos encaminhar pra contestação.',
  },
  {
    id: 'mtzguygbepzwp1',
    temaId: 'saudacoes',
    nome: 'Abraço, tamo junto!',
    texto: 'Abraço, tamo junto!',
  },
];

if (typeof module !== 'undefined' && module.exports) {
  module.exports = { PELANDO_CHAT_EXT_SEED_THEMES, PELANDO_CHAT_EXT_SEED_MESSAGES };
}
