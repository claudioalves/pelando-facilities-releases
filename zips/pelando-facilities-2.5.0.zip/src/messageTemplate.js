const PELANDO_CHAT_EXT_GREETING_TEMPLATE = 'Salve {nome}, tudo bem?';

function fillTemplate(template, name) {
  const safeName = name || '';
  return template.split('{nome}').join(safeName);
}

function fillGreeting(name) {
  return fillTemplate(PELANDO_CHAT_EXT_GREETING_TEMPLATE, name);
}

// How many entries to include before the greeting itself, to capture the
// contact's message(s) that prompted it (the greeting is usually a reply,
// not the opening line).
const PELANDO_CHAT_EXT_TRANSCRIPT_CONTEXT_BEFORE = 2;

// There's no timestamp or session marker in the chat DOM, so "the last
// interaction" is inferred from content: the extension always autofills the
// standard greeting as the first message of a fresh conversation (see
// handleButtonClick), so the last own message matching it marks where the
// most recent atendimento began. No match found means we can't tell them
// apart, so the whole conversation is kept.
function findLastInteractionStart(entries, greetingText, contextBefore) {
  const before =
    typeof contextBefore === 'number' ? contextBefore : PELANDO_CHAT_EXT_TRANSCRIPT_CONTEXT_BEFORE;
  for (let i = entries.length - 1; i >= 0; i--) {
    if (entries[i].isOwn && entries[i].texto === greetingText) {
      return Math.max(0, i - before);
    }
  }
  return 0;
}

// One line per entry, in order: "{quem} disse: {texto}". Own entries are
// attributed to "Moderador"; the rest to `contactName`.
function formatConversationTranscript(entries, contactName) {
  const speakerFallback = contactName || 'Contato';
  return entries.map((e) => (e.isOwn ? 'Moderador' : speakerFallback) + ' disse: ' + e.texto);
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = {
    fillTemplate,
    fillGreeting,
    PELANDO_CHAT_EXT_GREETING_TEMPLATE,
    PELANDO_CHAT_EXT_TRANSCRIPT_CONTEXT_BEFORE,
    findLastInteractionStart,
    formatConversationTranscript,
  };
}
