// A version's zip, as downloaded from the releases repository: checked
// against the sha256 in versions.json, unpacked in memory, and refused unless
// it is a Pelando Facilities of the chosen version with files only where the
// extension keeps them (manifest.json, src/, icons/).
var UPDATER_EXTENSION_NAME = 'Pelando Facilities';

async function updaterSha256Hex(bytes) {
  const digest = await crypto.subtle.digest('SHA-256', bytes);
  return Array.from(new Uint8Array(digest), function (byte) {
    return byte.toString(16).padStart(2, '0');
  }).join('');
}

function updaterIsReleasePath(path) {
  if (path === 'manifest.json') return true;
  if (!/^(src|icons)\//.test(path) || /[\\:]/.test(path)) return false;
  return path.split('/').every(function (part) {
    return part !== '..' && part !== '.';
  });
}

// path → bytes of the package's files. Throws with a message the page shows.
async function verifyRelease(bytes, entry, unzip) {
  if ((await updaterSha256Hex(bytes)) !== String(entry.sha256).toLowerCase()) {
    throw new Error('Arquivo corrompido ou alterado, instalação cancelada.');
  }
  let entries;
  try {
    entries = unzip(bytes);
  } catch (err) {
    throw new Error('O arquivo baixado não é um zip válido.');
  }
  const files = {};
  Object.keys(entries).forEach(function (path) {
    if (path.endsWith('/')) return;
    if (!updaterIsReleasePath(path)) {
      throw new Error('O pacote tem um arquivo fora do lugar: ' + path + '. Instalação cancelada.');
    }
    files[path] = entries[path];
  });
  let manifest = null;
  try {
    manifest = JSON.parse(new TextDecoder().decode(files['manifest.json']));
  } catch (err) {
    manifest = null;
  }
  if (!manifest || manifest.name !== UPDATER_EXTENSION_NAME) {
    throw new Error('O pacote não é da Pelando Facilities. Instalação cancelada.');
  }
  if (manifest.version !== entry.version) {
    throw new Error('O pacote é da versão ' + manifest.version + ', não da ' + entry.version + '. Instalação cancelada.');
  }
  return files;
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = { UPDATER_EXTENSION_NAME, updaterSha256Hex, updaterIsReleasePath, verifyRelease };
}
