// The extension's own folder on disk (the one loaded with "Carregar sem
// compactação"), reached through the File System Access API. The updater
// writes a version's files into it; only manifest.json, src/ and icons/ are
// ever read, written or removed.
var UPDATER_FOLDER_DIRS = ['src', 'icons'];

function updaterPathParts(path) {
  return path.split('/').filter(Boolean);
}

async function updaterDirFor(root, parts, create) {
  let dir = root;
  for (const name of parts) dir = await dir.getDirectoryHandle(name, { create: create });
  return dir;
}

async function updaterReadFile(root, path) {
  const parts = updaterPathParts(path);
  const dir = await updaterDirFor(root, parts.slice(0, -1), false);
  const handle = await dir.getFileHandle(parts[parts.length - 1]);
  const file = await handle.getFile();
  return new Uint8Array(await file.arrayBuffer());
}

async function updaterWriteFile(root, path, bytes) {
  const parts = updaterPathParts(path);
  const dir = await updaterDirFor(root, parts.slice(0, -1), true);
  const handle = await dir.getFileHandle(parts[parts.length - 1], { create: true });
  const writable = await handle.createWritable();
  try {
    await writable.write(bytes);
  } catch (err) {
    if (writable.abort) await writable.abort();
    throw err;
  }
  await writable.close();
}

// A file that isn't there is already removed.
async function updaterRemoveFile(root, path) {
  const parts = updaterPathParts(path);
  try {
    const dir = await updaterDirFor(root, parts.slice(0, -1), false);
    await dir.removeEntry(parts[parts.length - 1]);
  } catch (err) {
    if (err.name !== 'NotFoundError') throw err;
  }
}

// Throws unless `root` holds the extension now running: same name, same version.
async function checkExtensionFolder(root, name, version) {
  let manifest = null;
  try {
    manifest = JSON.parse(new TextDecoder().decode(await updaterReadFile(root, 'manifest.json')));
  } catch (err) {
    manifest = null;
  }
  if (!manifest || manifest.name !== name || manifest.version !== version) {
    throw new Error('Essa não é a pasta da extensão instalada.');
  }
}

async function updaterListFiles(dir, prefix, out) {
  for await (const entry of dir.values()) {
    const path = prefix + entry.name;
    if (entry.kind === 'directory') await updaterListFiles(entry, path + '/', out);
    else out.push(path);
  }
  return out;
}

// path → bytes of manifest.json and every file under src/ and icons/.
async function snapshotFolder(root) {
  const snapshot = { 'manifest.json': await updaterReadFile(root, 'manifest.json') };
  for (const name of UPDATER_FOLDER_DIRS) {
    let dir = null;
    try {
      dir = await root.getDirectoryHandle(name);
    } catch (err) {
      continue;
    }
    for (const path of await updaterListFiles(dir, name + '/', [])) snapshot[path] = await updaterReadFile(root, path);
  }
  return snapshot;
}

function updaterManifestLast(paths) {
  const rest = paths.filter(function (path) {
    return path !== 'manifest.json';
  });
  return paths.indexOf('manifest.json') >= 0 ? rest.concat(['manifest.json']) : rest;
}

// Writes `files` (manifest.json last, so a half-written folder still loads as
// the old version) and removes what `before` had that `files` doesn't.
async function updaterReplaceFiles(root, files, before) {
  for (const path of updaterManifestLast(Object.keys(files))) await updaterWriteFile(root, path, files[path]);
  for (const path of Object.keys(before)) {
    if (!(path in files)) await updaterRemoveFile(root, path);
  }
}

// Makes the folder hold `files`. On any error it puts `snapshot` back and
// rethrows, with `err.restored` telling whether that worked.
async function applyFiles(root, files, snapshot) {
  try {
    await updaterReplaceFiles(root, files, snapshot);
  } catch (err) {
    let restored = true;
    try {
      await updaterReplaceFiles(root, snapshot, files);
    } catch (restoreErr) {
      restored = false;
    }
    err.restored = restored;
    throw err;
  }
}

// The folder to write to: the one saved before (asking again for write
// access, which needs the click that started the install) or one the user
// picks. Saved only once it is checked.
async function openExtensionFolder(options) {
  let dir = options.saved;
  if (dir) {
    if ((await dir.requestPermission({ mode: 'readwrite' })) !== 'granted') {
      throw new Error('Sem permissão para gravar na pasta da extensão.');
    }
  } else {
    try {
      dir = await options.pick();
    } catch (err) {
      if (err.name === 'AbortError') throw new Error('Nenhuma pasta escolhida.');
      throw err;
    }
  }
  await checkExtensionFolder(dir, options.name, options.version);
  await options.save(dir);
  return dir;
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = { checkExtensionFolder, snapshotFolder, applyFiles, openExtensionFolder };
}
