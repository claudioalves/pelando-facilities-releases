// Tells the team's usage sheet (scripts/usage-sheet) who uses the extension
// and in which version: once a day, and right after each update or rollback.
// Only a Pelando account's email and the version go out. Events that can't be
// sent wait in a short queue for the next time; nothing is shown to the user.
// The sheet's web app address; while empty, nothing is sent.
var UPDATER_USAGE_URL = 'https://script.google.com/macros/s/AKfycbyUNhGtcAJXGg6qfdhVmWtANT4n8X4oAGO04akSS5_1U4kjw6bQzUY-Otu4pUvXUqtyBg/exec';
var UPDATER_USAGE_QUEUE_KEY = 'usageQueue';
var UPDATER_USAGE_QUEUE_MAX = 20;
// Each report waits for the previous one, so two overlapping calls never read the same queue.
var updaterUsageChain = Promise.resolve();

function usageEvent(email, version, event, from, now) {
  return { email: email, version: version, event: event, from: from || '', at: now.toISOString() };
}

function sendUsage(event, from, deps) {
  const run = updaterUsageChain.then(function () {
    return updaterSendUsageNow(event, from, deps);
  });
  updaterUsageChain = run.catch(function () {});
  return run;
}

async function updaterSendUsageNow(event, from, deps) {
  const email = String(deps.email || '').trim().toLowerCase();
  if (!deps.url || !/@pelando\.com\.br$/.test(email)) return;
  const stored = (await deps.storage.local.get(UPDATER_USAGE_QUEUE_KEY))[UPDATER_USAGE_QUEUE_KEY];
  const queue = (Array.isArray(stored) ? stored : [])
    .concat([usageEvent(email, deps.installed, event, from, deps.now)])
    .slice(-UPDATER_USAGE_QUEUE_MAX);
  const left = [];
  for (const item of queue) {
    if (left.length) {
      left.push(item);
      continue;
    }
    try {
      const response = await deps.fetch(deps.url, {
        method: 'POST',
        headers: { 'Content-Type': 'text/plain;charset=utf-8' },
        body: JSON.stringify(item),
      });
      if (!response.ok) left.push(item);
    } catch (err) {
      left.push(item);
    }
  }
  await deps.storage.local.set({ [UPDATER_USAGE_QUEUE_KEY]: left });
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = { UPDATER_USAGE_QUEUE_KEY, usageEvent, sendUsage };
}
