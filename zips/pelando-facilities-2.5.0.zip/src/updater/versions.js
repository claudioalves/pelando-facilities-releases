// The list of released versions (versions.json in the public releases
// repository) and what the updater decides from it: which version to point
// to, and whether a choice is an update or a rollback. Loaded by the settings
// page, the popup and the service worker.
var UPDATER_RELEASES_PREFIX = 'https://raw.githubusercontent.com/claudioalves/pelando-facilities-releases/';
var UPDATER_VERSIONS_URL = UPDATER_RELEASES_PREFIX + 'main/versions.json';
var UPDATER_CHECK_ERROR = 'Não foi possível verificar agora.';
// chrome.storage.local: the last check's result, and the version a reload
// started by the updater should come back as.
var UPDATER_STATE_KEY = 'updaterState';
var UPDATER_PENDING_KEY = 'updaterPending';

function updaterVersionParts(version) {
  return String(version)
    .split('.')
    .map(function (part) {
      return parseInt(part, 10) || 0;
    });
}

function compareVersions(a, b) {
  const x = updaterVersionParts(a);
  const y = updaterVersionParts(b);
  for (let i = 0; i < Math.max(x.length, y.length); i++) {
    const diff = (x[i] || 0) - (y[i] || 0);
    if (diff) return diff > 0 ? 1 : -1;
  }
  return 0;
}

// The zip must come from the releases repository itself. Dot segments and
// percent-encoded dots are refused, since fetch resolves them and could reach
// another repository under the same host.
function updaterIsReleaseUrl(url) {
  if (typeof url !== 'string' || url.indexOf(UPDATER_RELEASES_PREFIX) !== 0) return false;
  if (url.indexOf('..') !== -1 || url.toLowerCase().indexOf('%2e') !== -1) return false;
  try {
    const parsed = new URL(url);
    return (
      parsed.protocol === 'https:' &&
      parsed.host === 'raw.githubusercontent.com' &&
      parsed.pathname.indexOf('/claudioalves/pelando-facilities-releases/') === 0
    );
  } catch (error) {
    return false;
  }
}

function updaterIsReleaseEntry(entry) {
  return (
    !!entry &&
    typeof entry === 'object' &&
    typeof entry.version === 'string' &&
    /^\d+(\.\d+){1,3}$/.test(entry.version) &&
    updaterIsReleaseUrl(entry.url) &&
    typeof entry.sha256 === 'string' &&
    /^[0-9a-f]{64}$/i.test(entry.sha256)
  );
}

function updaterText(value) {
  return typeof value === 'string' ? value : '';
}

// { recommended, versions } with the usable entries, newest first. Throws
// UPDATER_CHECK_ERROR for a file this version doesn't understand.
function parseVersionsFile(data) {
  if (!data || typeof data !== 'object' || data.format !== 1 || !Array.isArray(data.versions)) {
    throw new Error(UPDATER_CHECK_ERROR);
  }
  const versions = data.versions
    .filter(updaterIsReleaseEntry)
    .map(function (entry) {
      return {
        version: entry.version,
        date: updaterText(entry.date),
        notes: updaterText(entry.notes),
        url: entry.url,
        sha256: entry.sha256.toLowerCase(),
        minUpdaterVersion: updaterText(entry.minUpdaterVersion),
      };
    })
    .sort(function (a, b) {
      return compareVersions(b.version, a.version);
    });
  const listed = versions.some(function (entry) {
    return entry.version === data.recommended;
  });
  return { recommended: listed ? data.recommended : '', versions: versions };
}

// The recommended version's entry while another version is installed (newer
// or older: pointing back is how a bad version is rolled back for everyone).
function updateNotice(installed, state) {
  if (!state || !state.recommended || state.recommended === installed) return null;
  return (
    (state.versions || []).find(function (entry) {
      return entry.version === state.recommended;
    }) || null
  );
}

// What the install button does for `target`. `confirm` is the question asked
// first, or '' to go straight ahead.
function installAction(installed, target) {
  if (target.version === installed) return { kind: 'same', label: 'Instalar esta versão', confirm: '' };
  const manual = target.minUpdaterVersion
    ? ''
    : ' A versão ' +
      target.version +
      ' não tem o atualizador: para sair dela depois, a troca será manual (baixar o zip e descompactar por cima da mesma pasta).';
  if (compareVersions(target.version, installed) < 0) {
    return {
      kind: 'rollback',
      label: 'Voltar para ' + target.version,
      confirm: 'Voltar da versão ' + installed + ' para a ' + target.version + '?' + manual,
    };
  }
  return {
    kind: 'install',
    label: 'Instalar esta versão',
    confirm: manual ? 'Instalar a versão ' + target.version + '?' + manual : '',
  };
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = {
    UPDATER_RELEASES_PREFIX,
    UPDATER_VERSIONS_URL,
    UPDATER_CHECK_ERROR,
    UPDATER_STATE_KEY,
    UPDATER_PENDING_KEY,
    compareVersions,
    parseVersionsFile,
    updateNotice,
    installAction,
  };
}
