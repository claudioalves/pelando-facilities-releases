// The "Atualizações" card of the settings page: the installed and the
// recommended version, the install or rollback of a chosen version into the
// extension's folder (install.js), the data backups taken before each one,
// and the manual way (zip + steps) when writing to the folder isn't possible.
var UPDATER_FOLDER_KEY = 'extensionFolder';

function updaterDate(iso) {
  const date = new Date(iso);
  return iso && !isNaN(date) ? date.toLocaleString('pt-BR', { dateStyle: 'short', timeStyle: 'short' }) : '';
}

// The version <select>: every listed version; the recommended one chosen, or
// the installed one when nothing is recommended.
function updaterVersionOptions(installed, state) {
  const versions = (state && state.versions) || [];
  const recommended = (state && state.recommended) || '';
  const listed = function (version) {
    return versions.some(function (entry) {
      return entry.version === version;
    });
  };
  const selected = listed(recommended) ? recommended : listed(installed) ? installed : versions.length ? versions[0].version : '';
  return versions.map(function (entry) {
    const tags = [];
    if (entry.version === recommended) tags.push('recomendada');
    if (entry.version === installed) tags.push('instalada');
    return {
      value: entry.version,
      label: entry.version + (entry.date ? ' · ' + entry.date : '') + (tags.length ? ' (' + tags.join(', ') + ')' : ''),
      selected: entry.version === selected,
    };
  });
}

// What to say about the reload the updater started, once it happened.
function updaterOutcome(pending) {
  if (!pending || !pending.result) return null;
  if (pending.result === 'ok') {
    return { kind: 'ok', text: 'Atualizado para ' + pending.to + '. Recarregue as abas do backoffice e do chat.' };
  }
  return {
    kind: 'error',
    text: 'A extensão não ficou na versão ' + pending.to + '. Faça a troca à mão com o passo a passo abaixo.',
  };
}

function updaterShow(el, text, kind) {
  el.textContent = text;
  el.className = 'status ' + kind;
  el.hidden = false;
}

function updaterAskCheck() {
  return new Promise(function (resolve) {
    chrome.runtime.sendMessage({ type: 'PELANDO_UPDATER_CHECK' }, function (response) {
      resolve(response && response.data ? response.data : null);
    });
  });
}

function updaterPickFolder() {
  if (typeof window.showDirectoryPicker !== 'function') {
    return Promise.reject(new Error('Este Chrome não deixa escolher a pasta da extensão.'));
  }
  return window.showDirectoryPicker({ id: 'pelando-facilities', mode: 'readwrite' });
}

async function startUpdater(doc) {
  const el = function (id) {
    return doc.getElementById(id);
  };
  const installed = chrome.runtime.getManifest().version;
  const db = await openUpdaterDb(indexedDB);
  let state = (await chrome.storage.local.get(UPDATER_STATE_KEY))[UPDATER_STATE_KEY] || null;
  let waitingConfirm = null;
  let installing = false;
  el('updater-installed').textContent = installed;

  function findEntry(version) {
    return (
      ((state && state.versions) || []).find(function (entry) {
        return entry.version === version;
      }) || null
    );
  }

  function showManual(entry) {
    if (!entry) return;
    el('updater-manual-zip').href = entry.url;
    el('updater-manual').hidden = false;
  }

  function renderChoice() {
    const entry = findEntry(el('updater-select').value);
    const button = el('updater-install');
    el('updater-confirm').hidden = true;
    waitingConfirm = null;
    if (!entry) {
      button.disabled = true;
      el('updater-version-notes').textContent = '';
      return;
    }
    const action = installAction(installed, entry);
    button.textContent = action.label;
    button.disabled = installing || action.kind === 'same';
    el('updater-version-notes').textContent = entry.notes;
  }

  function render() {
    const notice = updateNotice(installed, state);
    el('updater-notice').hidden = !notice;
    if (notice) {
      el('updater-notice-title').textContent =
        'Nova versão recomendada: ' + notice.version + (notice.date ? ' (' + notice.date + ')' : '');
      el('updater-notice-notes').textContent = notice.notes;
    }
    const select = el('updater-select');
    select.replaceChildren();
    updaterVersionOptions(installed, state).forEach(function (option) {
      const item = doc.createElement('option');
      item.value = option.value;
      item.textContent = option.label;
      item.selected = option.selected;
      select.appendChild(item);
    });
    const last = state ? updaterDate(state.checkedAt) : '';
    el('updater-last-check').textContent =
      (last ? 'Última verificação: ' + last + '.' : 'Ainda não verificado.') + (state && state.error ? ' ' + state.error : '');
    renderChoice();
  }

  async function renderFolder() {
    const folder = await updaterDbGet(db, 'handles', UPDATER_FOLDER_KEY);
    el('updater-folder').hidden = !folder;
    if (folder) el('updater-folder-name').textContent = folder.name;
  }

  async function renderBackups() {
    const list = el('updater-backup-list');
    const backups = await listUpdateBackups(db);
    list.replaceChildren();
    el('updater-backups').hidden = backups.length === 0;
    backups.forEach(function (item) {
      const button = doc.createElement('button');
      button.type = 'button';
      button.textContent = 'Restaurar dados de antes da atualização para ' + item.to + ' (' + updaterDate(item.savedAt) + ')';
      button.addEventListener('click', async function () {
        const question =
          'Os dados de agora (mensagens, temas, respostas dos motivos e configurações) serão substituídos pelos de ' +
          updaterDate(item.savedAt) +
          '. Continuar?';
        if (!window.confirm(question)) return;
        try {
          await restoreUpdateBackup(db, item.id, function (data) {
            return restoreBackup(chrome.storage, data);
          });
          await ensureGreetingProtected();
          updaterShow(el('updater-status'), 'Dados restaurados. Recarregue as abas do chat, do Pelando e do backoffice.', 'ok');
        } catch (err) {
          updaterShow(el('updater-status'), 'Não deu para restaurar: ' + err.message, 'error');
        }
      });
      list.appendChild(button);
    });
  }

  async function getFolder() {
    return openExtensionFolder({
      saved: await updaterDbGet(db, 'handles', UPDATER_FOLDER_KEY),
      pick: updaterPickFolder,
      save: function (dir) {
        return updaterDbPut(db, 'handles', dir, UPDATER_FOLDER_KEY);
      },
      name: UPDATER_EXTENSION_NAME,
      version: installed,
    });
  }

  // Runs inside the click that started it: asking for the folder needs it.
  async function install(entry) {
    const status = el('updater-status');
    installing = true;
    el('updater-install').disabled = true;
    el('updater-manual').hidden = true;
    updaterShow(status, 'Instalando a versão ' + entry.version + '…', 'ok');
    try {
      await installRelease(entry, {
        getFolder: getFolder,
        download: function (url) {
          return downloadRelease(url, function (u, init) {
            return fetch(u, init);
          });
        },
        verify: function (bytes, target) {
          return verifyRelease(bytes, target, fflate.unzipSync);
        },
        saveBackup: async function (from, to) {
          await saveUpdateBackup(db, await collectBackup(chrome.storage, {}), from, to, new Date());
        },
        storage: chrome.storage,
        installed: installed,
        now: new Date(),
        reload: function () {
          chrome.runtime.reload();
        },
      });
    } catch (err) {
      installing = false;
      updaterShow(status, err.message, 'error');
      showManual(entry);
      renderChoice();
      await renderFolder();
      await renderBackups();
    }
  }

  const pending = (await chrome.storage.local.get(UPDATER_PENDING_KEY))[UPDATER_PENDING_KEY];
  const outcome = updaterOutcome(pending);
  if (outcome) {
    updaterShow(el('updater-outcome'), outcome.text, outcome.kind);
    if (outcome.kind === 'error') showManual(findEntry(pending.to));
    await chrome.storage.local.remove(UPDATER_PENDING_KEY);
  }

  el('updater-select').addEventListener('change', renderChoice);

  el('updater-install').addEventListener('click', function () {
    const entry = findEntry(el('updater-select').value);
    if (!entry) return;
    const action = installAction(installed, entry);
    if (!action.confirm) {
      install(entry);
      return;
    }
    waitingConfirm = entry;
    el('updater-confirm-text').textContent = action.confirm;
    el('updater-confirm').hidden = false;
  });

  el('updater-confirm-yes').addEventListener('click', function () {
    const entry = waitingConfirm;
    waitingConfirm = null;
    el('updater-confirm').hidden = true;
    if (entry) install(entry);
  });

  el('updater-confirm-no').addEventListener('click', function () {
    waitingConfirm = null;
    el('updater-confirm').hidden = true;
  });

  el('updater-check').addEventListener('click', async function () {
    const button = this;
    button.disabled = true;
    const next = await updaterAskCheck();
    if (next) state = next;
    render();
    button.disabled = false;
  });

  el('updater-folder-change').addEventListener('click', async function () {
    try {
      const dir = await updaterPickFolder();
      await checkExtensionFolder(dir, UPDATER_EXTENSION_NAME, installed);
      await updaterDbPut(db, 'handles', dir, UPDATER_FOLDER_KEY);
      await renderFolder();
      updaterShow(el('updater-status'), 'Pasta da extensão trocada.', 'ok');
    } catch (err) {
      if (err.name !== 'AbortError') updaterShow(el('updater-status'), err.message, 'error');
    }
  });

  el('updater-manual-steps-toggle').addEventListener('click', function () {
    el('updater-manual-steps').hidden = !el('updater-manual-steps').hidden;
  });

  render();
  await renderFolder();
  await renderBackups();
  if (!state) {
    const next = await updaterAskCheck();
    if (next) {
      state = next;
      render();
    }
  }
}

if (typeof document !== 'undefined' && document.getElementById('updater')) {
  startUpdater(document);
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = { updaterVersionOptions, updaterOutcome };
}
