// The service worker's side of the updater: the daily check and usage
// report, and what happens right after the extension changes version (by
// the updater or by hand).
async function runUpdaterCheck(deps) {
  const state = await checkForUpdates(deps);
  await showUpdateBadge(deps.action, deps.installed, state);
  return state;
}

async function runDailyUpdater(deps) {
  await runUpdaterCheck(deps);
  await sendUsage('active', '', deps);
}

// Returns whether the updater was waiting for this reload; the settings page
// then shows how it went (`result` in updaterPending). A reload into the same
// version (during development) reports nothing.
async function handleVersionChange(previousVersion, deps) {
  let pending = (await deps.storage.local.get(UPDATER_PENDING_KEY))[UPDATER_PENDING_KEY];
  // A pending entry from an older reload (e.g. a rollback to a version with no
  // updater code left it behind) is not about this one.
  if (pending && pending.from !== previousVersion) {
    await deps.storage.local.remove(UPDATER_PENDING_KEY);
    pending = null;
  }
  if (pending) {
    const result = pending.to === deps.installed ? 'ok' : 'mismatch';
    await deps.storage.local.set({ [UPDATER_PENDING_KEY]: Object.assign({}, pending, { result: result }) });
  }
  if (previousVersion && previousVersion !== deps.installed) {
    const event = compareVersions(deps.installed, previousVersion) < 0 ? 'rolledBack' : 'updated';
    await sendUsage(event, previousVersion, deps);
  }
  const state = (await deps.storage.local.get(UPDATER_STATE_KEY))[UPDATER_STATE_KEY];
  await showUpdateBadge(deps.action, deps.installed, state);
  return !!pending;
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = { runUpdaterCheck, runDailyUpdater, handleVersionChange };
}
