// The look at versions.json, once a day and from the "Buscar atualizações"
// button. Its result is kept in chrome.storage.local for the settings page
// and the popup; a failed look keeps the last good list. While the
// recommended version isn't installed, the toolbar icon shows a "1".
var UPDATER_ALARM_NAME = 'pelando-updater-daily';
var UPDATER_BADGE_COLOR = '#dc143c';

async function checkForUpdates(deps) {
  const stored = (await deps.storage.local.get(UPDATER_STATE_KEY))[UPDATER_STATE_KEY] || {
    recommended: '',
    versions: [],
    checkedAt: '',
  };
  let state;
  try {
    const response = await deps.fetch(UPDATER_VERSIONS_URL, { cache: 'no-store' });
    if (!response.ok) throw new Error(UPDATER_CHECK_ERROR);
    const parsed = parseVersionsFile(await response.json());
    state = { recommended: parsed.recommended, versions: parsed.versions, checkedAt: deps.now.toISOString(), error: '' };
  } catch (err) {
    state = Object.assign({}, stored, { error: UPDATER_CHECK_ERROR, failedAt: deps.now.toISOString() });
  }
  await deps.storage.local.set({ [UPDATER_STATE_KEY]: state });
  return state;
}

function updaterBadgeText(installed, state) {
  return updateNotice(installed, state) ? '1' : '';
}

async function showUpdateBadge(action, installed, state) {
  await action.setBadgeBackgroundColor({ color: UPDATER_BADGE_COLOR });
  await action.setBadgeText({ text: updaterBadgeText(installed, state) });
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = { UPDATER_ALARM_NAME, checkForUpdates, updaterBadgeText, showUpdateBadge };
}
