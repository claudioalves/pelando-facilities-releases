// The updater's IndexedDB: the extension folder's handle (chrome.storage
// can't hold it) and the data backups taken before each update. Like
// chrome.storage, it belongs to the extension's ID, which the updater keeps
// by always writing to the same folder.
var UPDATER_DB_NAME = 'pelando-facilities-updater';

function openUpdaterDb(idb) {
  return new Promise(function (resolve, reject) {
    const request = idb.open(UPDATER_DB_NAME, 1);
    request.onupgradeneeded = function () {
      const db = request.result;
      db.createObjectStore('handles');
      db.createObjectStore('backups', { keyPath: 'id', autoIncrement: true });
    };
    request.onsuccess = function () {
      resolve(request.result);
    };
    request.onerror = function () {
      reject(request.error);
    };
  });
}

// Runs one request in its own transaction; resolves when it is committed.
function updaterDbRequest(db, store, mode, run) {
  return new Promise(function (resolve, reject) {
    const tx = db.transaction(store, mode);
    const request = run(tx.objectStore(store));
    tx.oncomplete = function () {
      resolve(request.result);
    };
    tx.onerror = tx.onabort = function () {
      reject(tx.error);
    };
  });
}

function updaterDbGet(db, store, key) {
  return updaterDbRequest(db, store, 'readonly', function (s) {
    return s.get(key);
  });
}

function updaterDbPut(db, store, value, key) {
  return updaterDbRequest(db, store, 'readwrite', function (s) {
    return key === undefined ? s.put(value) : s.put(value, key);
  });
}

function updaterDbGetAll(db, store) {
  return updaterDbRequest(db, store, 'readonly', function (s) {
    return s.getAll();
  });
}

function updaterDbDelete(db, store, key) {
  return updaterDbRequest(db, store, 'readwrite', function (s) {
    return s.delete(key);
  });
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = { openUpdaterDb, updaterDbGet, updaterDbPut, updaterDbGetAll, updaterDbDelete };
}
