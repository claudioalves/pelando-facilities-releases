// A copy of the extension's data (collectBackup in backup.js) taken before
// each update or rollback, so the settings page can put it back. The 3 most
// recent are kept.
var UPDATER_BACKUPS_KEPT = 3;

function updaterNewestFirst(items) {
  return items.sort(function (a, b) {
    return b.id - a.id;
  });
}

async function saveUpdateBackup(db, backup, from, to, now) {
  const id = await updaterDbPut(db, 'backups', { from: from, to: to, savedAt: now.toISOString(), backup: backup });
  const old = updaterNewestFirst(await updaterDbGetAll(db, 'backups')).slice(UPDATER_BACKUPS_KEPT);
  for (const item of old) await updaterDbDelete(db, 'backups', item.id);
  return id;
}

async function listUpdateBackups(db) {
  return updaterNewestFirst(await updaterDbGetAll(db, 'backups'));
}

// `restore` puts a backup into chrome.storage (restoreBackup in backup.js).
async function restoreUpdateBackup(db, id, restore) {
  const item = await updaterDbGet(db, 'backups', id);
  if (!item) throw new Error('Esse backup não existe mais.');
  await restore(item.backup);
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = { saveUpdateBackup, listUpdateBackups, restoreUpdateBackup };
}
