// Installing (or going back to) one version, in the order of the spec's
// section 3: the folder, the download, the package check and the data backup
// all come before anything on disk changes. Any error is thrown with a
// message the page shows next to the manual way (zip + steps).
async function downloadRelease(url, fetchFn) {
  let response;
  try {
    response = await fetchFn(url, { cache: 'no-store' });
  } catch (err) {
    throw new Error('Não deu para baixar a versão. Verifique sua conexão.');
  }
  if (!response.ok) throw new Error('Não deu para baixar a versão (erro ' + response.status + ').');
  return new Uint8Array(await response.arrayBuffer());
}

async function installRelease(entry, deps) {
  const folder = await deps.getFolder();
  const bytes = await deps.download(entry.url);
  const files = await deps.verify(bytes, entry);
  await deps.saveBackup(deps.installed, entry.version);
  const snapshot = await snapshotFolder(folder);
  try {
    await applyFiles(folder, files, snapshot);
  } catch (err) {
    throw new Error(
      err.restored
        ? 'Não deu para gravar a nova versão; a pasta voltou ao que era. ' + err.message
        : 'A pasta pode ter ficado incompleta; siga o passo a passo.'
    );
  }
  await deps.storage.local.set({
    [UPDATER_PENDING_KEY]: { from: deps.installed, to: entry.version, at: deps.now.toISOString() },
  });
  deps.reload();
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = { downloadRelease, installRelease };
}
