const PELANDO_BO_JUSTIFY_BUTTON_CLASS = 'pelando-bo-justify-button';
// Fewer matches than this isn't the reasons list: a title that happens to
// match one, or the chips of the reasons picked so far.
const PELANDO_BO_MIN_REASON_ITEMS = 5;

// The backoffice deal page is /promocao/<deal id>.
function backofficeDealIdFromPath(pathname) {
  const match = pathname.match(/^\/promocao\/([0-9a-f-]{36})(?:\/|$)/i);
  return match ? match[1] : null;
}

const PELANDO_BO_JUSTIFY_FLOATING_CLASS = PELANDO_BO_JUSTIFY_BUTTON_CLASS + '--floating';
const PELANDO_BO_MERGE_BUTTON_TEXT = 'mesclar promoção';
// Longest text the page's rejection reason can be embedded in (e.g.
// "Motivo: Autopromoção"); longer text is the deal's own content.
const PELANDO_BO_MAX_REASON_TEXT_LENGTH = 120;

// Text nodes of the page itself: not our dialogs nor the page's own open ones
// (the reject dialog lists every reason).
function pageTextNodes(root) {
  const nodes = [];
  const walker = root.ownerDocument.createTreeWalker(root, NodeFilter.SHOW_TEXT);
  for (let node = walker.nextNode(); node; node = walker.nextNode()) {
    const parent = node.parentElement;
    if (!parent || parent.closest('.pelando-action-overlay, [role="dialog"], dialog, script, style')) continue;
    nodes.push(node);
  }
  return nodes;
}

const PELANDO_BO_DELETION_BOX_HEADER = /motivos? de dele[cç][aã]o encontrad/i;

// The deal page's "N motivo(s) de deleção encontrado(s)!" box: the smallest
// ancestor of its header that also holds the reasons below it.
function findDeletionReasonBox(root) {
  const header = pageTextNodes(root).find(function (node) {
    return PELANDO_BO_DELETION_BOX_HEADER.test(node.nodeValue);
  });
  if (!header) return null;
  const headerText = normalizeReasonTitle(header.nodeValue);
  let box = header.parentElement;
  while (box && box !== root && normalizeReasonTitle(box.textContent) === headerText) {
    box = box.parentElement;
  }
  return box;
}

// Each reason can show on the page by its name or, as the deletion box does,
// by its internal summary ("Pirataria, IPTV irregular, VPN indevida ou
// similares").
function reasonLabels(reason) {
  return [reason.title, reason.summary].filter(Boolean).map(normalizeReasonTitle);
}

// Deal reasons the backoffice page shows for the deal. Read from the deletion
// box when there is one - exact lines first, then text containing a label -
// and otherwise from short text anywhere on the page matching a label exactly.
function findReasonIdsOnPage(root) {
  const reasons = reasonCatalog().filter(function (r) {
    return r.type !== PELANDO_REASON_COMMENT_TYPE;
  });
  const box = findDeletionReasonBox(root);
  const texts = pageTextNodes(box || root)
    .map(function (node) {
      return normalizeReasonTitle(node.nodeValue);
    })
    .filter(function (text) {
      return text && text.length <= PELANDO_BO_MAX_REASON_TEXT_LENGTH;
    });
  function matching(test) {
    return reasons
      .filter(function (r) {
        return reasonLabels(r).some(function (label) {
          return texts.some(function (text) {
            return test(text, label);
          });
        });
      })
      .map(function (r) {
        return r.id;
      });
  }
  const exact = matching(function (text, label) {
    return text === label;
  });
  if (exact.length || !box) return exact;
  return matching(function (text, label) {
    return text.includes(label);
  });
}

function findMergeButton(doc) {
  return findButtonByText(doc, PELANDO_BO_MERGE_BUTTON_TEXT);
}

function findButtonByText(doc, text) {
  const candidates = doc.querySelectorAll('button, a, [role="button"]');
  for (let i = 0; i < candidates.length; i++) {
    const el = candidates[i];
    if (el.classList.contains(PELANDO_BO_JUSTIFY_BUTTON_CLASS)) continue;
    if (normalizeReasonTitle(el.textContent) === text) return el;
  }
  return null;
}

// Opens the chat through the page's own "Conversar" button (the user card),
// exactly as a moderator would; the text is left for whichever chat tab opens
// next. Without that button, falls back to opening the chat directly.
async function openChatViaConversarButton(ownerId, text) {
  const conversar = findButtonByText(document, 'conversar');
  if (!conversar) return openChatWithOwner(ownerId, text);
  await chrome.storage.local.set({ pendingChatMessage: { chatId: null, text: text, createdAt: Date.now() } });
  conversar.click();
}

function createBackofficeJustifyButton(dealId) {
  const button = document.createElement('button');
  button.type = 'button';
  button.className = PELANDO_BO_JUSTIFY_BUTTON_CLASS;
  button.dataset.dealId = dealId;
  button.textContent = 'Justificar ao usuário';
  button.addEventListener('click', async function () {
    if (button.disabled) return;
    button.disabled = true;
    button.textContent = 'Carregando...';
    let deal = null;
    try {
      const pageReasonIds = findReasonIdsOnPage(document.body);
      deal = await fetchDealById(dealId);
      await justifyDeal(deal, pageReasonIds, openChatViaConversarButton);
    } catch (err) {
      showActionToast(err.message || 'Não foi possível concluir a ação.', true);
    } finally {
      button.textContent = 'Justificar ao usuário';
      disableJustifyUnlessRejected(button, deal);
    }
  });
  enableWhenRejected(button, function () {
    return fetchDealById(dealId);
  });
  return button;
}

// Right below "Mesclar promoção"; when the page lays its buttons out in a row,
// below that whole row. Floating in the corner until that button shows up.
function placeBackofficeJustifyButton(doc, button) {
  const merge = findMergeButton(doc);
  if (!merge) {
    button.classList.add(PELANDO_BO_JUSTIFY_FLOATING_CLASS);
    if (button.parentElement !== doc.body) doc.body.appendChild(button);
    return;
  }
  let anchor = merge;
  const parent = merge.parentElement;
  if (parent && parent !== doc.body) {
    const style = getComputedStyle(parent);
    if (/flex/.test(style.display) && !/column/.test(style.flexDirection)) anchor = parent;
  }
  button.classList.remove(PELANDO_BO_JUSTIFY_FLOATING_CLASS);
  // The "Ações" block is a grid where Mesclar spans the full row; take a full
  // row of our own too.
  const container = anchor.parentElement;
  const inGrid = !!container && /grid/.test(getComputedStyle(container).display);
  button.style.gridColumn = inGrid ? '1 / -1' : '';
  if (anchor.nextElementSibling !== button) anchor.insertAdjacentElement('afterend', button);
}

// The backoffice is a single-page app: keep exactly one button, for the deal
// in the current URL.
function syncBackofficeJustifyButton(doc, pathname) {
  const dealId = backofficeDealIdFromPath(pathname);
  let button = doc.querySelector('.' + PELANDO_BO_JUSTIFY_BUTTON_CLASS);
  if (button && button.dataset.dealId !== dealId) {
    button.remove();
    button = null;
  }
  if (!dealId) return;
  if (!button) button = createBackofficeJustifyButton(dealId);
  placeBackofficeJustifyButton(doc, button);
}

// Uses of each reason title, the way the backoffice's own list shows them.
function backofficeReasonUses() {
  const uses = new Map();
  reasonUsesByTitle().forEach(function (entry, key) {
    uses.set(key, entry.uses);
  });
  return uses;
}

// Reorders the backoffice's own rejection reasons list, most used first.
// Its markup isn't ours, so the list is found by its text: elements reading
// exactly a known reason title, grouped under the parent they share. They're
// reordered with CSS `order` rather than by moving nodes, so the page's own
// rendering keeps working.
function sortBackofficeReasonLists(root) {
  const uses = backofficeReasonUses();
  const matches = [];
  const walker = root.ownerDocument.createTreeWalker(root, NodeFilter.SHOW_TEXT);
  for (let node = walker.nextNode(); node; node = walker.nextNode()) {
    const key = normalizeReasonTitle(node.nodeValue);
    if (key && uses.has(key) && node.parentElement) {
      matches.push({ element: node.parentElement, uses: uses.get(key) });
    }
  }
  if (matches.length < PELANDO_BO_MIN_REASON_ITEMS) return;

  // Each match's item is its highest ancestor that holds no other match; the
  // item's parent is the list.
  const lists = new Map();
  matches.forEach(function (match) {
    let item = match.element;
    while (
      item.parentElement &&
      item.parentElement !== root &&
      !matches.some(function (other) {
        return other !== match && item.parentElement.contains(other.element);
      })
    ) {
      item = item.parentElement;
    }
    const list = item.parentElement;
    if (!list) return;
    if (!lists.has(list)) lists.set(list, []);
    lists.get(list).push({ item: item, uses: match.uses });
  });

  lists.forEach(function (items, list) {
    if (items.length < PELANDO_BO_MIN_REASON_ITEMS) return;
    // Our own dialogs are already in order.
    if (list.closest('.pelando-action-overlay')) return;
    const display = getComputedStyle(list).display;
    if (!/flex|grid/.test(display)) {
      list.style.display = 'flex';
      list.style.flexDirection = 'column';
    }
    items
      .slice()
      .sort(function (a, b) {
        return b.uses - a.uses;
      })
      .forEach(function (entry, index) {
        const order = String(index + 1);
        if (entry.item.style.order !== order) entry.item.style.order = order;
      });
  });
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = {
    backofficeDealIdFromPath,
    findReasonIdsOnPage,
    openChatViaConversarButton,
    syncBackofficeJustifyButton,
    sortBackofficeReasonLists,
  };
}
