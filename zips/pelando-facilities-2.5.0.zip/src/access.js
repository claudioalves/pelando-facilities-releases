// Loaded first on every page: the rest of the extension starts only when the
// Chrome profile is signed in with a Pelando account (see checkAccess in
// background.js). Otherwise nothing of the extension shows up, apart from a
// short notice explaining how to unlock it, once per tab.
//
// Pages that load two groups of the extension's scripts (the Pelando site, the
// backoffice) run this file twice in the same realm, so it only uses `var` and
// function declarations, which may repeat, and asks for access once.
var PELANDO_ACCESS_NOTICE_KEY = 'pelandoFacilitiesAccessNoticeShown';

function requestPelandoAccess() {
  return new Promise(function (resolve) {
    try {
      chrome.runtime.sendMessage({ type: 'PELANDO_ACCESS' }, function (response) {
        if (chrome.runtime.lastError || !response || response.error || !response.data) {
          resolve({ allowed: false, email: '' });
          return;
        }
        resolve(response.data);
      });
    } catch (err) {
      resolve({ allowed: false, email: '' });
    }
  });
}

var pelandoAccess = typeof pelandoAccess !== 'undefined' && pelandoAccess ? pelandoAccess : requestPelandoAccess();

function showPelandoAccessNotice(email) {
  try {
    if (sessionStorage.getItem(PELANDO_ACCESS_NOTICE_KEY)) return;
    sessionStorage.setItem(PELANDO_ACCESS_NOTICE_KEY, '1');
  } catch (err) {
    // Without sessionStorage the notice may show again on the next page.
  }
  const notice = document.createElement('div');
  notice.className = 'pelando-access-notice';
  notice.setAttribute('role', 'status');
  const title = document.createElement('strong');
  title.textContent = 'Pelando Facilities está bloqueada';
  const text = document.createElement('span');
  text.textContent = email
    ? 'O Chrome está conectado como ' + email + '. Entre no Chrome com sua conta @pelando.com.br para usar a extensão.'
    : 'Entre no Chrome com sua conta @pelando.com.br para usar a extensão.';
  const close = document.createElement('button');
  close.type = 'button';
  close.textContent = '×';
  close.setAttribute('aria-label', 'Fechar aviso');
  close.addEventListener('click', function () {
    notice.remove();
  });
  notice.append(title, text, close);
  // Styled here: it shows on pages whose own CSS groups differ.
  notice.style.cssText =
    'position:fixed;left:16px;bottom:16px;z-index:2147483647;max-width:380px;display:grid;' +
    'grid-template-columns:1fr auto;gap:4px 12px;padding:12px 14px;border-radius:8px;' +
    'background:#1f1f24;color:#fff;font:14px/1.4 system-ui,-apple-system,"Segoe UI",sans-serif;' +
    'box-shadow:0 6px 20px rgba(0,0,0,.3);border-left:4px solid #dc143c;';
  title.style.cssText = 'grid-column:1;';
  text.style.cssText = 'grid-column:1;color:#d8d8de;';
  close.style.cssText =
    'grid-column:2;grid-row:1 / span 2;align-self:start;border:0;background:none;color:#fff;' +
    'font-size:18px;line-height:1;cursor:pointer;';
  document.body.appendChild(notice);
  setTimeout(function () {
    notice.remove();
  }, 12000);
}

// Runs `start` only for a Pelando account.
function pelandoWhenAllowed(start) {
  pelandoAccess.then(function (access) {
    if (access.allowed) {
      start();
      return;
    }
    showPelandoAccessNotice(access.email);
  });
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = { requestPelandoAccess, pelandoWhenAllowed, showPelandoAccessNotice };
}
