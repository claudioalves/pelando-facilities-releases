// "Reportar ao usuário" on the backoffice's own reasons dialog: the one its
// Rejeitar and Excluir buttons open for deals and coupons, on the moderation
// queues' cards and on the deal page. With the box on, once the backoffice
// has rejected the deal, Justificar opens with the reasons picked there.
// The dialog isn't ours, so it's told by its description text; the comment
// version of the same dialog reads "este comentário" and is left alone.
const PELANDO_BO_DECISION_DESCRIPTION = /você está (rejeitando|excluindo) a promoção/i;
const PELANDO_BO_DECISION_TOGGLE_CLASS = 'pelando-action-report-toggle';
// How long to wait for the backoffice to save the rejection after the
// dialog's confirm button: it closes the dialog first, then calls its API.
const PELANDO_BO_DECISION_POLL = { attempts: 15, delayMs: 1000 };
const PELANDO_BO_DECISION_NOT_CONFIRMED =
  'Não deu para confirmar a reprovação a tempo. Use "Justificar ao usuário" na página da promoção.';

// The deal the last click on the page (outside a dialog) pointed at: the
// queues' dialogs don't say which card opened them.
let lastBackofficeDecisionRef = null;

function findBackofficeDecisionDialogs(doc) {
  return Array.prototype.filter.call(doc.querySelectorAll('[role="dialog"]'), function (dialog) {
    const description = dialog.querySelector('[data-slot="dialog-description"]');
    return !!description && PELANDO_BO_DECISION_DESCRIPTION.test(description.textContent);
  });
}

// The dialog names the deal as “title”.
function backofficeDecisionDealTitle(dialog) {
  const description = dialog.querySelector('[data-slot="dialog-description"]');
  const match = description && description.textContent.match(/“([^”]*)”/);
  return match ? match[1].trim() : '';
}

function selectedDecisionReasonTitles(dialog) {
  return Array.prototype.filter
    .call(dialog.querySelectorAll('[data-slot="command-item"]'), function (item) {
      const box = item.querySelector('[data-slot="checkbox"]');
      return !!box && box.getAttribute('data-state') === 'checked';
    })
    // The checkbox holds only its check mark (a span with an icon), so the
    // item's text is the reason's title.
    .map(function (item) {
      return item.textContent.trim();
    })
    .filter(Boolean);
}

// Deals a block links to: its backoffice page, or its page on Pelando.
function dealRefsIn(el) {
  const ids = new Set();
  const slugs = new Set();
  el.querySelectorAll('a[href]').forEach(function (link) {
    const href = link.getAttribute('href');
    let url;
    try {
      url = new URL(href, 'https://bo.pelando.com.br');
    } catch (err) {
      return;
    }
    const id = /(^|\.)bo\.pelando\.com\.br$/.test(url.hostname) ? backofficeDealIdFromPath(url.pathname) : null;
    if (id) ids.add(id);
    else if (/(^|\.)pelando\.com\.br$/.test(url.hostname)) {
      const slug = dealSlugFromUrl(url.href);
      if (slug) slugs.add(slug);
    }
  });
  return { ids: Array.from(ids), slugs: Array.from(slugs) };
}

// The deal of the closest block around `el` that links to one; null when
// that block links to several (it isn't a single card).
function dealRefNear(el) {
  for (let node = el && el.parentElement; node && node !== node.ownerDocument.body; node = node.parentElement) {
    const refs = dealRefsIn(node);
    if (refs.ids.length > 1 || (!refs.ids.length && refs.slugs.length > 1)) return null;
    if (refs.ids.length === 1) return { id: refs.ids[0] };
    if (refs.slugs.length === 1) return { slug: refs.slugs[0] };
  }
  return null;
}

// Meant for a capture click listener on the document.
function rememberBackofficeDecisionClick(event) {
  const target = event.target;
  if (!target || !target.closest || target.closest('[role="dialog"]')) return;
  const ref = dealRefNear(target);
  if (ref) lastBackofficeDecisionRef = ref;
}

// The deal page names its deal in the address; elsewhere, the clicked card.
function currentBackofficeDecisionRef() {
  const id = backofficeDealIdFromPath(window.location.pathname);
  return id ? { id: id } : lastBackofficeDecisionRef;
}

function decisionFooter(dialog) {
  const footer = dialog.querySelector('[data-slot="dialog-footer"]');
  if (footer) return footer;
  const buttons = dialog.querySelectorAll('button');
  return buttons.length ? buttons[buttons.length - 1].parentElement : null;
}

// The confirm button is the footer's last one (Cancelar comes first).
function decisionConfirmButton(footer) {
  const buttons = footer.querySelectorAll('button');
  return buttons.length ? buttons[buttons.length - 1] : null;
}

function waitMs(ms) {
  return new Promise(function (resolve) {
    setTimeout(resolve, ms);
  });
}

async function waitForDealDecision(dealId) {
  for (let i = 0; i < PELANDO_BO_DECISION_POLL.attempts; i++) {
    await waitMs(PELANDO_BO_DECISION_POLL.delayMs);
    try {
      const deal = await fetchDealById(dealId);
      if (isDealRejected(deal)) return deal;
    } catch (err) {
      // A failed lookup is tried again until the attempts run out.
    }
  }
  return null;
}

// The backoffice's own reasons for the picked titles, so a reason the sheet
// lacks still carries its text; just the title when the list can't load.
async function backofficeReasonsByTitle(titles) {
  let known = [];
  try {
    known = (await fetchDeletionReasons()) || [];
  } catch (err) {
    known = [];
  }
  return titles.map(function (title) {
    const key = normalizeReasonTitle(title);
    return (
      known.find(function (r) {
        return normalizeReasonTitle(r.title) === key;
      }) || { title: title }
    );
  });
}

async function reportBackofficeDecision(ref, dealTitle, reasonTitles) {
  try {
    if (!ref) throw new Error('Não identifiquei a promoção reprovada. Use "Justificar ao usuário" na página da promoção.');
    const dealId = ref.id || (await fetchDealBySlug(ref.slug)).id;
    const deal = await waitForDealDecision(dealId);
    if (!deal) {
      showActionToast(PELANDO_BO_DECISION_NOT_CONFIRMED, true);
      return;
    }
    if (dealTitle && normalizeReasonTitle(deal.title) !== normalizeReasonTitle(dealTitle)) {
      throw new Error('A promoção reprovada não é a que a extensão encontrou. Use "Justificar ao usuário" na página da promoção.');
    }
    // Without the dialog's picks, the reasons the backoffice saved on the deal.
    const reasons = reasonTitles.length ? await backofficeReasonsByTitle(reasonTitles) : dealRejectionReasonList(deal);
    await reportRejectionToUser(deal, reasons);
  } catch (err) {
    showActionToast(err.message || PELANDO_BO_DECISION_NOT_CONFIRMED, true);
  }
}

function addDecisionToggle(dialog) {
  const footer = decisionFooter(dialog);
  if (!footer || footer.querySelector('.' + PELANDO_BO_DECISION_TOGGLE_CLASS)) return;
  const ref = currentBackofficeDecisionRef();
  const dealTitle = backofficeDecisionDealTitle(dialog);

  const label = document.createElement('label');
  label.className = PELANDO_BO_DECISION_TOGGLE_CLASS + ' ' + PELANDO_BO_DECISION_TOGGLE_CLASS + '--backoffice';
  const box = document.createElement('input');
  box.type = 'checkbox';
  const text = document.createElement('span');
  text.textContent = 'Reportar ao usuário';
  label.append(box, text);
  footer.insertBefore(label, footer.firstChild);

  let touched = false;
  box.addEventListener('change', function () {
    touched = true;
  });
  readRejectReportChoice().then(function (value) {
    if (!touched) box.checked = value;
  });

  // Capture, so the dialog is still there to read before the page's own
  // handler closes it. Once per dialog: a double click mustn't report twice.
  let confirmed = false;
  footer.addEventListener(
    'click',
    function (event) {
      const button = event.target.closest && event.target.closest('button');
      if (!button || button !== decisionConfirmButton(footer) || button.disabled || confirmed) return;
      confirmed = true;
      const report = box.checked;
      const reasonTitles = selectedDecisionReasonTitles(dialog);
      saveRejectReportChoice(report);
      if (report) reportBackofficeDecision(ref, dealTitle, reasonTitles);
    },
    true
  );
}

function syncBackofficeRejectReport(doc) {
  findBackofficeDecisionDialogs(doc).forEach(addDecisionToggle);
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = {
    findBackofficeDecisionDialogs,
    backofficeDecisionDealTitle,
    selectedDecisionReasonTitles,
    dealRefNear,
    rememberBackofficeDecisionClick,
    syncBackofficeRejectReport,
    PELANDO_BO_DECISION_POLL,
  };
}
