// The "Backup entre perfis" page: exports this profile's data to a file and
// restores a file into it (see backup.js). Only for a Pelando account, like
// the rest of the extension.
const SUMMARY_LABELS = [
  ['themes', 'Temas'],
  ['messages', 'Mensagens'],
  ['reasonEdits', 'Motivos editados'],
  ['keywordExamples', 'Exemplos de palavras-chave'],
];

function renderSummary(list, summary) {
  list.replaceChildren();
  SUMMARY_LABELS.forEach(function ([key, label]) {
    const item = document.createElement('div');
    const dt = document.createElement('dt');
    dt.textContent = label;
    const dd = document.createElement('dd');
    dd.textContent = String(summary[key]);
    item.append(dt, dd);
    list.appendChild(item);
  });
}

function showStatus(el, text, kind) {
  el.textContent = text;
  el.className = 'status ' + kind;
  el.hidden = false;
}

function formatDate(iso) {
  const date = new Date(iso);
  return isNaN(date) ? iso : date.toLocaleString('pt-BR', { dateStyle: 'short', timeStyle: 'short' });
}

function askAccess() {
  return new Promise(function (resolve) {
    chrome.runtime.sendMessage({ type: 'PELANDO_ACCESS' }, function (response) {
      resolve(response && response.data ? response.data : { allowed: false, email: '' });
    });
  });
}

async function refreshCurrent() {
  const sync = await chrome.storage.sync.get(null);
  const local = await chrome.storage.local.get(null);
  renderSummary(document.getElementById('current-summary'), summarizeData(sync, local));
}

function downloadBackup(backup) {
  const blob = new Blob([JSON.stringify(backup, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = backupFileName(backup.account, new Date(backup.exportedAt));
  document.body.appendChild(link);
  link.click();
  link.remove();
  setTimeout(function () {
    URL.revokeObjectURL(url);
  }, 1000);
}

async function start() {
  const access = await askAccess();
  const accountEl = document.getElementById('account');
  if (!access.allowed) {
    const blocked = document.getElementById('blocked');
    blocked.textContent = access.email
      ? 'O Chrome está conectado como ' + access.email + '. Entre no Chrome com sua conta @pelando.com.br para usar o backup.'
      : 'Entre no Chrome com sua conta @pelando.com.br para usar o backup.';
    blocked.hidden = false;
    accountEl.textContent = 'Bloqueado neste perfil.';
    document.getElementById('export').disabled = true;
    document.getElementById('import-file').disabled = true;
    return;
  }
  accountEl.innerHTML = '';
  accountEl.append('Conta do Chrome: ');
  const strong = document.createElement('strong');
  strong.textContent = access.email;
  accountEl.appendChild(strong);
  await refreshCurrent();

  document.getElementById('export').addEventListener('click', async function () {
    const status = document.getElementById('export-status');
    try {
      const backup = await collectBackup(chrome.storage, { account: access.email });
      downloadBackup(backup);
      showStatus(status, 'Backup baixado. Leve o arquivo para o outro perfil e use Importar tudo.', 'ok');
    } catch (err) {
      showStatus(status, 'Não deu para exportar: ' + err.message, 'error');
    }
  });

  let pending = null;
  const preview = document.getElementById('preview');
  const fileInput = document.getElementById('import-file');
  const importStatus = document.getElementById('import-status');

  fileInput.addEventListener('change', async function () {
    importStatus.hidden = true;
    preview.hidden = true;
    pending = null;
    const file = fileInput.files && fileInput.files[0];
    if (!file) return;
    try {
      const data = JSON.parse(await file.text());
      validateBackup(data);
      pending = data;
      document.getElementById('preview-account').textContent =
        'Backup de ' + (data.account || 'conta desconhecida') + ', exportado em ' + formatDate(data.exportedAt) + ':';
      renderSummary(document.getElementById('preview-summary'), summarizeData(data.sync, data.local));
      preview.hidden = false;
    } catch (err) {
      const message = err instanceof SyntaxError ? 'Esse arquivo não é um backup válido (JSON com erro).' : err.message;
      showStatus(importStatus, message, 'error');
    } finally {
      fileInput.value = '';
    }
  });

  document.getElementById('cancel-import').addEventListener('click', function () {
    pending = null;
    preview.hidden = true;
  });

  document.getElementById('confirm-import').addEventListener('click', async function () {
    if (!pending) return;
    const button = this;
    button.disabled = true;
    try {
      await restoreBackup(chrome.storage, pending);
      await ensureGreetingProtected();
      pending = null;
      preview.hidden = true;
      await refreshCurrent();
      showStatus(importStatus, 'Pronto: este perfil ficou igual ao backup. Atualize as abas do chat, do Pelando e do backoffice.', 'ok');
    } catch (err) {
      showStatus(importStatus, 'Não deu para importar, e os dados deste perfil continuam como estavam: ' + err.message, 'error');
    } finally {
      button.disabled = false;
    }
  });
}

if (typeof document !== 'undefined' && document.getElementById('export')) {
  start();
}
