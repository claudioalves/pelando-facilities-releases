// Moderators can reword the messages sent to the user for each rejection
// reason; their edits live in sync storage, one key per reason, on top of the
// sheet's text in rejectionReasonsData.js.
const PELANDO_REASON_MESSAGE_KEY_PREFIX = 'reasonMessage:';
const PELANDO_REASON_COMMENT_TYPE = 'Comentário';

function reasonCatalog() {
  return typeof PELANDO_REJECTION_REASONS !== 'undefined' ? PELANDO_REJECTION_REASONS : [];
}

function normalizeReasonTitle(title) {
  return (title || '').trim().toLowerCase();
}

// Deals are rejected with deal reasons; when a title exists both as a deal and
// a comment reason, the deal one is the one whose usage counts here.
function reasonUsesByTitle() {
  const byTitle = new Map();
  reasonCatalog().forEach(function (reason) {
    const key = normalizeReasonTitle(reason.title);
    const existing = byTitle.get(key);
    const isComment = reason.type === PELANDO_REASON_COMMENT_TYPE;
    if (!existing || (existing.isComment && !isComment)) {
      byTitle.set(key, { uses: reason.uses, isComment: isComment });
    }
  });
  return byTitle;
}

// Total uses for a backoffice reason ({ id, title }): matched by id, falling
// back to the title; reasons missing from the sheet count as never used.
function reasonUses(reason, usesByTitle) {
  const known = reasonCatalog().find(function (r) {
    return r.id === reason.id;
  });
  if (known) return known.uses;
  const byTitle = (usesByTitle || reasonUsesByTitle()).get(normalizeReasonTitle(reason.title));
  return byTitle ? byTitle.uses : 0;
}

// Most used first; ties keep the order they came in.
function sortReasonsByUsage(reasons) {
  const usesByTitle = reasonUsesByTitle();
  return reasons
    .map(function (reason, index) {
      return { reason: reason, index: index, uses: reasonUses(reason, usesByTitle) };
    })
    .sort(function (a, b) {
      return b.uses - a.uses || a.index - b.index;
    })
    .map(function (entry) {
      return entry.reason;
    });
}

// Sheet reasons that can be used to reject a deal or discussion, with the
// moderator's edited messages applied, most used first.
async function getDealReasonMessages() {
  const reasons = reasonCatalog().filter(function (r) {
    return r.type !== PELANDO_REASON_COMMENT_TYPE;
  });
  return applyReasonMessageEdits(reasons);
}

async function getAllReasonMessages() {
  return applyReasonMessageEdits(reasonCatalog());
}

async function applyReasonMessageEdits(reasons) {
  const keys = reasons.map(function (r) {
    return PELANDO_REASON_MESSAGE_KEY_PREFIX + r.id;
  });
  const stored = keys.length ? await chrome.storage.sync.get(keys) : {};
  return sortReasonsByUsage(reasons).map(function (reason) {
    const edit = stored[PELANDO_REASON_MESSAGE_KEY_PREFIX + reason.id];
    const messages = editedMessages(edit) || [reason.principal, reason.alternativa].filter(Boolean);
    return { ...reason, messages: messages, edited: !!edit };
  });
}

// The replies a moderator saved for a reason; edits saved before replies
// could be added hold just the two fixed ones.
function editedMessages(edit) {
  if (!edit) return null;
  if (Array.isArray(edit.messages)) {
    const messages = edit.messages.filter(Boolean);
    return messages.length ? messages : null;
  }
  const legacy = [edit.principal, edit.alternativa].filter(Boolean);
  return legacy.length ? legacy : null;
}

// Saves the reason's replies, in order; the first is the one offered first.
async function saveReasonMessage(id, changes) {
  await chrome.storage.sync.set({
    [PELANDO_REASON_MESSAGE_KEY_PREFIX + id]: { messages: changes.messages.filter(Boolean) },
  });
}

// A reason's replies to pick from: the moderator's list, or the sheet's main
// message and alternative.
function reasonReplies(reason) {
  if (Array.isArray(reason.messages)) return reason.messages.filter(Boolean);
  return [reason.principal, reason.alternativa].filter(Boolean);
}

// The sheet's two messages keep their names; replies the moderator added
// are numbered after them.
function replyLabel(index) {
  if (index === 0) return 'Mensagem 1';
  if (index === 1) return 'Alternativa';
  return 'Resposta ' + (index + 1);
}

async function resetReasonMessage(id) {
  await chrome.storage.sync.remove(PELANDO_REASON_MESSAGE_KEY_PREFIX + id);
}

// The sheet's messages also ship as regular quick replies: a theme for deal
// (and discussion/review) reasons and one for comment reasons. Their ids are
// stable, so applyNewSeeds adds them once to existing installs and never
// brings back one a moderator deleted. No keywords: they'd compete with
// "Sentimos muito" for the same messages and leave neither suggested.
const PELANDO_REASON_SEED_THEMES = [
  { id: 'reprova-promocoes', nome: 'Reprova de promoções', palavrasChave: [] },
  { id: 'reprova-comentarios', nome: 'Reprova de comentários', palavrasChave: [] },
];

function reasonSeedThemeId(reason) {
  return reason.type === PELANDO_REASON_COMMENT_TYPE ? 'reprova-comentarios' : 'reprova-promocoes';
}

// "<Motivo> - Mensagem Pelando" and "<Motivo> - Mensagem alternativa" for
// each reason, most used first.
function buildReasonSeedMessages(reasons) {
  const messages = [];
  sortReasonsByUsage(reasons).forEach(function (reason) {
    const idBase = 'reprova-' + reason.code.toLowerCase();
    const temaId = reasonSeedThemeId(reason);
    if (reason.principal) {
      messages.push({ id: idBase + '-pelando', temaId: temaId, nome: reason.title + ' - Mensagem Pelando', texto: reason.principal });
    }
    if (reason.alternativa) {
      messages.push({
        id: idBase + '-alternativa',
        temaId: temaId,
        nome: reason.title + ' - Mensagem alternativa',
        texto: reason.alternativa,
      });
    }
  });
  return messages;
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = {
    PELANDO_REASON_SEED_THEMES,
    buildReasonSeedMessages,
    PELANDO_REASON_COMMENT_TYPE,
    reasonCatalog,
    normalizeReasonTitle,
    reasonUsesByTitle,
    sortReasonsByUsage,
    reasonUses,
    getDealReasonMessages,
    getAllReasonMessages,
    saveReasonMessage,
    resetReasonMessage,
    reasonReplies,
    replyLabel,
  };
}
