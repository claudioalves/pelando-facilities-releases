// Starts only for a Pelando account (see access.js).
pelandoWhenAllowed(function () {
  let scheduled = false;

  // One feature failing on some page must not keep the others from running.
  function runSync(name, sync) {
    try {
      sync();
    } catch (err) {
      console.warn('[pelando-chat-ext] ' + name + ' falhou:', err);
    }
  }

  // What every backoffice gets, Pelando's and Promoninja's. They're
  // single-page apps that update the country counts live, so re-check on DOM
  // changes, batched to one pass per frame.
  function scheduleSync() {
    if (scheduled) return;
    scheduled = true;
    requestAnimationFrame(function () {
      scheduled = false;
      runSync('syncNextCountryButton', function () {
        syncNextCountryButton(document);
      });
      runSync('syncBackofficeSaveShortcut', function () {
        syncBackofficeSaveShortcut(document);
      });
      runSync('syncSiteMonitor', function () {
        syncSiteMonitor(document, window.location.pathname, checkSiteViaWorker);
      });
    });
  }

  // The site monitor starts once the page has loaded, even if nothing
  // changes on the page after that.
  if (document.readyState !== 'complete') window.addEventListener('load', scheduleSync);

  const observer = new MutationObserver(scheduleSync);
  observer.observe(document.body, { childList: true, subtree: true, characterData: true, attributes: true, attributeFilter: ['aria-label'] });

  scheduleSync();
});
