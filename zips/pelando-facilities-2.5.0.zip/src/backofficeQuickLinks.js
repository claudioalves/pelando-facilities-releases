// On every page of Pelando's backoffice: links to the site's chat and to
// Pelando's "recentes", fixed at the bottom, right of the sidebar (whose foot
// holds the user menu), each opening a new tab. They live in the sidebar's
// wrapper, which carries the sidebar's width for the CSS. The backoffice is a
// single-page app that re-renders freely: keep one set, and put it back
// when a page drops it.
const PELANDO_BO_QUICK_LINKS_CLASS = 'pelando-bo-quick-links';
const PELANDO_BO_QUICK_LINKS = [
  { text: 'Chat', url: 'https://www.pelando.com.br/chat/' },
  { text: 'Pelando recentes', url: 'https://www.pelando.com.br/recentes' },
];

function syncBackofficeQuickLinks(doc) {
  const home = doc.querySelector('[data-slot="sidebar-wrapper"]') || doc.body;
  const current = doc.querySelector('.' + PELANDO_BO_QUICK_LINKS_CLASS);
  if (current) {
    if (current.parentElement !== home) home.appendChild(current);
    return;
  }
  const box = doc.createElement('nav');
  box.className = PELANDO_BO_QUICK_LINKS_CLASS;
  box.setAttribute('aria-label', 'Atalhos do Pelando');
  PELANDO_BO_QUICK_LINKS.forEach(function (item) {
    const link = doc.createElement('a');
    link.className = 'pelando-bo-quick-link';
    link.href = item.url;
    link.target = '_blank';
    link.rel = 'noopener noreferrer';
    link.textContent = item.text;
    box.appendChild(link);
  });
  home.appendChild(box);
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = { syncBackofficeQuickLinks };
}
