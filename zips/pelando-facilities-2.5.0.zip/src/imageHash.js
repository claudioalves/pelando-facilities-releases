// Fingerprint of a picture (a difference hash), to tell whether a competitor's
// card shows the same photo as our deal. Runs in the service worker, which can
// download pictures from any site; the pages can't read cross-site pictures.
//
// The picture is shrunk to 17x16 in gray and each pixel is compared with the
// one on its right: 256 bits that survive resizing and recompression. Half of
// the bits match by chance between unrelated pictures, so the similarity
// counts from there: 0% for unrelated (or opposite) pictures, 100% for the
// same one.
const PELANDO_IMAGE_HASH_SIZE = 16;
// Shrinking straight to 17x16 lets fine patterns (dithering, text) alias into
// different hashes for two sizes of the same picture: it's decoded 4x larger
// and each 4x4 block averaged instead.
const PELANDO_IMAGE_HASH_OVERSAMPLE = 4;
// Pictures already hashed in this service worker's life, by address.
const PELANDO_IMAGE_HASH_CACHE_LIMIT = 300;
const pelandoImageHashCache = new Map();

// Gray levels (0..255) of RGBA pixels, transparent ones laid over white.
function grayFromRgba(data, width, height) {
  const gray = new Float64Array(width * height);
  for (let i = 0; i < width * height; i++) {
    const alpha = data[i * 4 + 3] / 255;
    const luma = 0.299 * data[i * 4] + 0.587 * data[i * 4 + 1] + 0.114 * data[i * 4 + 2];
    gray[i] = luma * alpha + 255 * (1 - alpha);
  }
  return gray;
}

// The gray picture shrunk by `factor`, each pixel the average of its block.
function averageBlocks(gray, width, height, factor) {
  const outWidth = Math.floor(width / factor);
  const outHeight = Math.floor(height / factor);
  const out = new Float64Array(outWidth * outHeight);
  for (let y = 0; y < outHeight; y++) {
    for (let x = 0; x < outWidth; x++) {
      let sum = 0;
      for (let dy = 0; dy < factor; dy++) {
        for (let dx = 0; dx < factor; dx++) sum += gray[(y * factor + dy) * width + x * factor + dx];
      }
      out[y * outWidth + x] = sum / (factor * factor);
    }
  }
  return out;
}

// Hex string of (width - 1) x height bits: is each pixel brighter than the
// next one in its row?
function differenceHash(gray, width, height) {
  let hex = '';
  let nibble = 0;
  let bits = 0;
  for (let y = 0; y < height; y++) {
    for (let x = 0; x < width - 1; x++) {
      nibble = (nibble << 1) | (gray[y * width + x] > gray[y * width + x + 1] ? 1 : 0);
      bits++;
      if (bits === 4) {
        hex += nibble.toString(16);
        nibble = 0;
        bits = 0;
      }
    }
  }
  return hex;
}

// 0..1, or null when either picture has no fingerprint.
function imageHashSimilarity(a, b) {
  if (!a || !b || a.length !== b.length) return null;
  let different = 0;
  for (let i = 0; i < a.length; i++) {
    let xor = parseInt(a[i], 16) ^ parseInt(b[i], 16);
    while (xor) {
      different += xor & 1;
      xor >>= 1;
    }
  }
  const total = a.length * 4;
  return Math.max(0, 1 - (2 * different) / total);
}

// RGBA pixels of the picture shrunk to width x height.
async function decodeImageWithCanvas(blob, width, height) {
  const bitmap = await createImageBitmap(blob);
  const canvas = new OffscreenCanvas(width, height);
  const context = canvas.getContext('2d');
  context.imageSmoothingQuality = 'high';
  context.drawImage(bitmap, 0, 0, width, height);
  if (typeof bitmap.close === 'function') bitmap.close();
  return context.getImageData(0, 0, width, height).data;
}

// The fingerprint of the picture at `url`, or null when it can't be had.
// `deps` replaces the download and the decoding in the tests.
async function hashImageUrl(url, deps) {
  const fetchImage = (deps && deps.fetchImage) || fetch;
  const decode = (deps && deps.decode) || decodeImageWithCanvas;
  if (!/^https?:\/\//i.test(String(url || ''))) return null;
  try {
    const response = await fetchImage(url);
    if (!response || !response.ok) return null;
    const blob = await response.blob();
    const width = PELANDO_IMAGE_HASH_SIZE + 1;
    const height = PELANDO_IMAGE_HASH_SIZE;
    const factor = PELANDO_IMAGE_HASH_OVERSAMPLE;
    const data = await decode(blob, width * factor, height * factor);
    const gray = averageBlocks(grayFromRgba(data, width * factor, height * factor), width * factor, height * factor, factor);
    return differenceHash(gray, width, height);
  } catch (err) {
    return null;
  }
}

// hashImageUrl, once per address.
function cachedImageHash(url) {
  if (!pelandoImageHashCache.has(url)) {
    if (pelandoImageHashCache.size >= PELANDO_IMAGE_HASH_CACHE_LIMIT) {
      pelandoImageHashCache.delete(pelandoImageHashCache.keys().next().value);
    }
    pelandoImageHashCache.set(url, hashImageUrl(url));
  }
  return pelandoImageHashCache.get(url);
}

// 0..1 between the pictures at `a` and `b`, or null when either can't be had.
async function compareImageUrls(a, b, hash) {
  const hashOf = hash || cachedImageHash;
  const [left, right] = await Promise.all([hashOf(a), hashOf(b)]);
  return imageHashSimilarity(left, right);
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = {
    PELANDO_IMAGE_HASH_SIZE,
    grayFromRgba,
    differenceHash,
    imageHashSimilarity,
    hashImageUrl,
    cachedImageHash,
    compareImageUrls,
  };
}
