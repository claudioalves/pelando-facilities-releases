// Windows has no flag emojis: "🇧🇷" shows as the letters "BR". This font has
// only the flags (the Twemoji ones, from country-flag-emoji-polyfill), so
// every other character keeps the page's own font.
const FLAG_FONT_NAME = 'Twemoji Country Flags';
const FLAG_FONT_FILE = 'src/fonts/TwemojiCountryFlags.woff2';
// The regional indicator letters flags are made of, plus the black flag and
// tag characters of the UK nations' flags.
const FLAG_FONT_RANGE = 'U+1F1E6-1F1FF, U+1F3F4, U+E0062-E0063, U+E0065, U+E0067, U+E006C, U+E006E, U+E0073-E0074, U+E0077, U+E007F';

function flagFontFamily(pageFamily) {
  const quoted = '"' + FLAG_FONT_NAME + '"';
  if (pageFamily.includes(FLAG_FONT_NAME)) return pageFamily;
  return quoted + ', ' + (pageFamily.trim() || 'system-ui, sans-serif');
}

// Elements inherit the body's font. The page may set it with a class, which
// would win over a plain `body` rule.
function applyFlagFont(doc) {
  let style = doc.querySelector('style[data-pelando-flag-font]');
  if (!style) {
    style = doc.createElement('style');
    style.dataset.pelandoFlagFont = '';
    doc.head.appendChild(style);
  }
  const family = flagFontFamily(getComputedStyle(doc.body).fontFamily);
  const css = 'body { font-family: ' + family + ' !important; }';
  if (style.textContent !== css) style.textContent = css;
}

// Loaded from the extension's own file into the page's fonts: unlike a
// stylesheet pointing at it, that isn't subject to the page's CSP.
async function loadFlagFont(doc) {
  const response = await fetch(chrome.runtime.getURL(FLAG_FONT_FILE));
  const face = new FontFace(FLAG_FONT_NAME, await response.arrayBuffer(), { unicodeRange: FLAG_FONT_RANGE });
  doc.fonts.add(await face.load());
  applyFlagFont(doc);
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = { FLAG_FONT_NAME, flagFontFamily, applyFlagFont };
} else {
  // Starts only for a Pelando account (see access.js).
  pelandoWhenAllowed(function () {
    loadFlagFont(document).catch(function () {
      // Without the font the page just keeps showing the letters.
    });
  });
}
