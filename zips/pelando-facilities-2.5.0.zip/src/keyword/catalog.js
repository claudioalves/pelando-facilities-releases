(function () {
'use strict';

// Gerado por scripts/catalog-from-xlsx.py a partir de palavras-chave-2026-10-12.xlsx — não editar à mão.
// Exemplos de referência embutidos na extensão; os cadastrados pelo moderador
// têm prioridade sobre eles.

const CATALOG_EXAMPLES = [
  {
    "id": "catalogo-1",
    "categoria": "smartphone",
    "marca": "Apple",
    "titulo": "iPhone Duo 512GB",
    "keywords": [
      "iPhone Duo"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-2",
    "categoria": "smartphone",
    "marca": "Apple",
    "titulo": "iPhone Duo 1TB",
    "keywords": [
      "iPhone Duo"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-3",
    "categoria": "smartphone",
    "marca": "Apple",
    "titulo": "iPhone 18 Pro Max 256GB",
    "keywords": [
      "iPhone 18 Pro Max"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-4",
    "categoria": "smartphone",
    "marca": "Apple",
    "titulo": "iPhone 18 Pro Max 512GB",
    "keywords": [
      "iPhone 18 Pro Max"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-5",
    "categoria": "smartphone",
    "marca": "Apple",
    "titulo": "iPhone 18 Pro Max 1TB",
    "keywords": [
      "iPhone 18 Pro Max"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-6",
    "categoria": "smartphone",
    "marca": "Apple",
    "titulo": "iPhone 18 Pro 128GB",
    "keywords": [
      "iPhone 18 Pro"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-7",
    "categoria": "smartphone",
    "marca": "Apple",
    "titulo": "iPhone 18 Pro 256GB",
    "keywords": [
      "iPhone 18 Pro"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-8",
    "categoria": "smartphone",
    "marca": "Apple",
    "titulo": "iPhone 18 Pro 512GB",
    "keywords": [
      "iPhone 18 Pro"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-9",
    "categoria": "smartphone",
    "marca": "Apple",
    "titulo": "iPhone Air 256GB",
    "keywords": [
      "iPhone Air"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-10",
    "categoria": "smartphone",
    "marca": "Apple",
    "titulo": "iPhone Air 512GB",
    "keywords": [
      "iPhone Air"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-11",
    "categoria": "smartphone",
    "marca": "Apple",
    "titulo": "iPhone 17 128GB",
    "keywords": [
      "iPhone 17"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-12",
    "categoria": "smartphone",
    "marca": "Apple",
    "titulo": "iPhone 17 256GB",
    "keywords": [
      "iPhone 17"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-13",
    "categoria": "smartphone",
    "marca": "Apple",
    "titulo": "iPhone 17 512GB",
    "keywords": [
      "iPhone 17"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-14",
    "categoria": "smartphone",
    "marca": "Apple",
    "titulo": "iPhone 17e 128GB",
    "keywords": [
      "iPhone 17e"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-15",
    "categoria": "smartphone",
    "marca": "Apple",
    "titulo": "iPhone 17e 256GB",
    "keywords": [
      "iPhone 17e"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-16",
    "categoria": "smartphone",
    "marca": "Apple",
    "titulo": "iPhone 16 128GB",
    "keywords": [
      "iPhone 16"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-17",
    "categoria": "smartphone",
    "marca": "Apple",
    "titulo": "iPhone 16 256GB",
    "keywords": [
      "iPhone 16"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-18",
    "categoria": "smartphone",
    "marca": "Apple",
    "titulo": "iPhone 16 Plus 128GB",
    "keywords": [
      "iPhone 16 Plus"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-19",
    "categoria": "smartphone",
    "marca": "Apple",
    "titulo": "iPhone 16 Plus 256GB",
    "keywords": [
      "iPhone 16 Plus"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-20",
    "categoria": "smartphone",
    "marca": "Apple",
    "titulo": "iPhone 15 128GB",
    "keywords": [
      "iPhone 15"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-21",
    "categoria": "smartphone",
    "marca": "Apple",
    "titulo": "iPhone 15 256GB",
    "keywords": [
      "iPhone 15"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-22",
    "categoria": "smartphone",
    "marca": "Apple",
    "titulo": "iPhone 15 Plus 128GB",
    "keywords": [
      "iPhone 15 Plus"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-23",
    "categoria": "smartphone",
    "marca": "Apple",
    "titulo": "iPhone 15 Plus 256GB",
    "keywords": [
      "iPhone 15 Plus"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-24",
    "categoria": "smartphone",
    "marca": "Samsung",
    "titulo": "Galaxy Z Fold 7 256GB / 12GB RAM",
    "keywords": [
      "Galaxy Z Fold 7 256"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-25",
    "categoria": "smartphone",
    "marca": "Samsung",
    "titulo": "Galaxy Z Fold 7 512GB / 12GB RAM",
    "keywords": [
      "Galaxy Z Fold 7 512"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-26",
    "categoria": "smartphone",
    "marca": "Samsung",
    "titulo": "Galaxy Z Fold 7 1TB / 16GB RAM",
    "keywords": [
      "Galaxy Z Fold 7"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-27",
    "categoria": "smartphone",
    "marca": "Samsung",
    "titulo": "Galaxy Z Flip 7 256GB / 8GB RAM",
    "keywords": [
      "Galaxy Z Flip 7 256"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-28",
    "categoria": "smartphone",
    "marca": "Samsung",
    "titulo": "Galaxy Z Flip 7 512GB / 12GB RAM",
    "keywords": [
      "Galaxy Z Flip 7 512"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-29",
    "categoria": "smartphone",
    "marca": "Samsung",
    "titulo": "Galaxy Z Fold 6 256GB / 12GB RAM",
    "keywords": [
      "Galaxy Z Fold 6 256"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-30",
    "categoria": "smartphone",
    "marca": "Samsung",
    "titulo": "Galaxy Z Fold 6 512GB / 12GB RAM",
    "keywords": [
      "Galaxy Z Fold 6 512"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-31",
    "categoria": "smartphone",
    "marca": "Samsung",
    "titulo": "Galaxy Z Flip 6 256GB / 8GB RAM",
    "keywords": [
      "Galaxy Z Flip 6 256"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-32",
    "categoria": "smartphone",
    "marca": "Samsung",
    "titulo": "Galaxy S25 Ultra 256GB / 12GB RAM",
    "keywords": [
      "Galaxy S25 Ultra 256"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-33",
    "categoria": "smartphone",
    "marca": "Samsung",
    "titulo": "Galaxy S25 Ultra 512GB / 12GB RAM",
    "keywords": [
      "Galaxy S25 Ultra 512"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-34",
    "categoria": "smartphone",
    "marca": "Samsung",
    "titulo": "Galaxy S25 Ultra 1TB / 16GB RAM",
    "keywords": [
      "Galaxy S25 Ultra"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-35",
    "categoria": "smartphone",
    "marca": "Samsung",
    "titulo": "Galaxy S25 Edge 256GB / 12GB RAM",
    "keywords": [
      "Galaxy S25 Edge 256"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-36",
    "categoria": "smartphone",
    "marca": "Samsung",
    "titulo": "Galaxy S25 Edge 512GB / 12GB RAM",
    "keywords": [
      "Galaxy S25 Edge 512"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-37",
    "categoria": "smartphone",
    "marca": "Samsung",
    "titulo": "Galaxy S25 128GB / 8GB RAM",
    "keywords": [
      "Galaxy S25 128"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-38",
    "categoria": "smartphone",
    "marca": "Samsung",
    "titulo": "Galaxy S25 256GB / 8GB RAM",
    "keywords": [
      "Galaxy S25 256"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-39",
    "categoria": "smartphone",
    "marca": "Samsung",
    "titulo": "Galaxy S25 FE 128GB / 8GB RAM",
    "keywords": [
      "Galaxy S25 FE 128"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-40",
    "categoria": "smartphone",
    "marca": "Samsung",
    "titulo": "Galaxy S25 FE 256GB / 8GB RAM",
    "keywords": [
      "Galaxy S25 FE 256"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-41",
    "categoria": "smartphone",
    "marca": "Samsung",
    "titulo": "Galaxy S24 Ultra 256GB / 12GB RAM",
    "keywords": [
      "Galaxy S24 Ultra 256"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-42",
    "categoria": "smartphone",
    "marca": "Samsung",
    "titulo": "Galaxy S24 Ultra 512GB / 12GB RAM",
    "keywords": [
      "Galaxy S24 Ultra 512"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-43",
    "categoria": "smartphone",
    "marca": "Samsung",
    "titulo": "Galaxy S24+ 256GB / 12GB RAM",
    "keywords": [
      "Galaxy S24+ 256"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-44",
    "categoria": "smartphone",
    "marca": "Samsung",
    "titulo": "Galaxy S24+ 512GB / 12GB RAM",
    "keywords": [
      "Galaxy S24+ 512"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-45",
    "categoria": "smartphone",
    "marca": "Samsung",
    "titulo": "Galaxy S24 128GB / 8GB RAM",
    "keywords": [
      "Galaxy S24 128"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-46",
    "categoria": "smartphone",
    "marca": "Samsung",
    "titulo": "Galaxy S24 256GB / 8GB RAM",
    "keywords": [
      "Galaxy S24 256"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-47",
    "categoria": "smartphone",
    "marca": "Samsung",
    "titulo": "Galaxy S24 FE 128GB / 8GB RAM",
    "keywords": [
      "Galaxy S24 FE 128"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-48",
    "categoria": "smartphone",
    "marca": "Samsung",
    "titulo": "Galaxy S24 FE 256GB / 8GB RAM",
    "keywords": [
      "Galaxy S24 FE 256"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-49",
    "categoria": "smartphone",
    "marca": "Samsung",
    "titulo": "Galaxy S23 Ultra 256GB / 12GB RAM",
    "keywords": [
      "Galaxy S23 Ultra 256"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-50",
    "categoria": "smartphone",
    "marca": "Samsung",
    "titulo": "Galaxy S23 Ultra 512GB / 12GB RAM",
    "keywords": [
      "Galaxy S23 Ultra 512"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-51",
    "categoria": "smartphone",
    "marca": "Samsung",
    "titulo": "Galaxy S23+ 256GB / 8GB RAM",
    "keywords": [
      "Galaxy S23+ 256"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-52",
    "categoria": "smartphone",
    "marca": "Samsung",
    "titulo": "Galaxy S23+ 512GB / 8GB RAM",
    "keywords": [
      "Galaxy S23+ 512"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-53",
    "categoria": "smartphone",
    "marca": "Samsung",
    "titulo": "Galaxy S23 128GB / 8GB RAM",
    "keywords": [
      "Galaxy S23 128"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-54",
    "categoria": "smartphone",
    "marca": "Samsung",
    "titulo": "Galaxy S23 256GB / 8GB RAM",
    "keywords": [
      "Galaxy S23 256"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-55",
    "categoria": "smartphone",
    "marca": "Samsung",
    "titulo": "Galaxy S23 FE 128GB / 8GB RAM",
    "keywords": [
      "Galaxy S23 FE 128"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-56",
    "categoria": "smartphone",
    "marca": "Samsung",
    "titulo": "Galaxy S23 FE 256GB / 8GB RAM",
    "keywords": [
      "Galaxy S23 FE 256"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-57",
    "categoria": "smartphone",
    "marca": "Samsung",
    "titulo": "Galaxy S22 Ultra 256GB / 12GB RAM",
    "keywords": [
      "Galaxy S22 Ultra 256"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-58",
    "categoria": "smartphone",
    "marca": "Samsung",
    "titulo": "Galaxy S22 128GB / 8GB RAM",
    "keywords": [
      "Galaxy S22 128"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-59",
    "categoria": "smartphone",
    "marca": "Samsung",
    "titulo": "Galaxy S22 256GB / 8GB RAM",
    "keywords": [
      "Galaxy S22 256"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-60",
    "categoria": "smartphone",
    "marca": "Samsung",
    "titulo": "Galaxy A56 128GB / 8GB RAM",
    "keywords": [
      "Galaxy A56 128"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-61",
    "categoria": "smartphone",
    "marca": "Samsung",
    "titulo": "Galaxy A56 256GB / 12GB RAM",
    "keywords": [
      "Galaxy A56 256"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-62",
    "categoria": "smartphone",
    "marca": "Samsung",
    "titulo": "Galaxy A55 128GB / 8GB RAM",
    "keywords": [
      "Galaxy A55 128"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-63",
    "categoria": "smartphone",
    "marca": "Samsung",
    "titulo": "Galaxy A55 256GB / 8GB RAM",
    "keywords": [
      "Galaxy A55 256"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-64",
    "categoria": "smartphone",
    "marca": "Samsung",
    "titulo": "Galaxy A55 256GB / 12GB RAM",
    "keywords": [
      "Galaxy A55 256"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-65",
    "categoria": "smartphone",
    "marca": "Samsung",
    "titulo": "Galaxy A36 128GB / 6GB RAM",
    "keywords": [
      "Galaxy A36 128"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-66",
    "categoria": "smartphone",
    "marca": "Samsung",
    "titulo": "Galaxy A36 256GB / 8GB RAM",
    "keywords": [
      "Galaxy A36 256"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-67",
    "categoria": "smartphone",
    "marca": "Samsung",
    "titulo": "Galaxy A35 128GB / 6GB RAM",
    "keywords": [
      "Galaxy A35 128"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-68",
    "categoria": "smartphone",
    "marca": "Samsung",
    "titulo": "Galaxy A35 256GB / 8GB RAM",
    "keywords": [
      "Galaxy A35 256"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-69",
    "categoria": "smartphone",
    "marca": "Samsung",
    "titulo": "Galaxy A26 128GB / 6GB RAM",
    "keywords": [
      "Galaxy A26 128"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-70",
    "categoria": "smartphone",
    "marca": "Samsung",
    "titulo": "Galaxy A26 256GB / 8GB RAM",
    "keywords": [
      "Galaxy A26 256"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-71",
    "categoria": "smartphone",
    "marca": "Samsung",
    "titulo": "Galaxy A25 128GB / 6GB RAM",
    "keywords": [
      "Galaxy A25 128"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-72",
    "categoria": "smartphone",
    "marca": "Samsung",
    "titulo": "Galaxy A25 256GB / 8GB RAM",
    "keywords": [
      "Galaxy A25 256"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-73",
    "categoria": "smartphone",
    "marca": "Samsung",
    "titulo": "Galaxy A17 5G 128GB / 6GB RAM",
    "keywords": [
      "Galaxy A17 5G 128"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-74",
    "categoria": "smartphone",
    "marca": "Samsung",
    "titulo": "Galaxy A17 5G 256GB / 8GB RAM",
    "keywords": [
      "Galaxy A17 5G 256"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-75",
    "categoria": "smartphone",
    "marca": "Samsung",
    "titulo": "Galaxy A16 128GB / 4GB RAM",
    "keywords": [
      "Galaxy A16 128"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-76",
    "categoria": "smartphone",
    "marca": "Samsung",
    "titulo": "Galaxy A16 256GB / 8GB RAM",
    "keywords": [
      "Galaxy A16 256"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-77",
    "categoria": "smartphone",
    "marca": "Samsung",
    "titulo": "Galaxy A15 5G 128GB / 4GB RAM",
    "keywords": [
      "Galaxy A15 5G 128"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-78",
    "categoria": "smartphone",
    "marca": "Samsung",
    "titulo": "Galaxy A15 5G 256GB / 8GB RAM",
    "keywords": [
      "Galaxy A15 5G 256"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-79",
    "categoria": "smartphone",
    "marca": "Samsung",
    "titulo": "Galaxy A15 4G 128GB / 4GB RAM",
    "keywords": [
      "Galaxy A15 4G 128"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-80",
    "categoria": "smartphone",
    "marca": "Samsung",
    "titulo": "Galaxy A15 4G 256GB / 8GB RAM",
    "keywords": [
      "Galaxy A15 4G 256"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-81",
    "categoria": "smartphone",
    "marca": "Samsung",
    "titulo": "Galaxy A07 64GB / 4GB RAM",
    "keywords": [
      "Galaxy A07 64"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-82",
    "categoria": "smartphone",
    "marca": "Samsung",
    "titulo": "Galaxy A07 128GB / 6GB RAM",
    "keywords": [
      "Galaxy A07 128"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-83",
    "categoria": "smartphone",
    "marca": "Samsung",
    "titulo": "Galaxy A06 64GB / 4GB RAM",
    "keywords": [
      "Galaxy A06 64"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-84",
    "categoria": "smartphone",
    "marca": "Samsung",
    "titulo": "Galaxy A06 128GB / 6GB RAM",
    "keywords": [
      "Galaxy A06 128"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-85",
    "categoria": "smartphone",
    "marca": "Samsung",
    "titulo": "Galaxy A05 64GB / 4GB RAM",
    "keywords": [
      "Galaxy A05 64"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-86",
    "categoria": "smartphone",
    "marca": "Samsung",
    "titulo": "Galaxy A05 128GB / 6GB RAM",
    "keywords": [
      "Galaxy A05 128"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-87",
    "categoria": "smartphone",
    "marca": "Samsung",
    "titulo": "Galaxy M55 256GB / 8GB RAM",
    "keywords": [
      "Galaxy M55 256"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-88",
    "categoria": "smartphone",
    "marca": "Samsung",
    "titulo": "Galaxy M35 256GB / 8GB RAM",
    "keywords": [
      "Galaxy M35 256"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-89",
    "categoria": "smartphone",
    "marca": "Samsung",
    "titulo": "Galaxy M34 128GB / 6GB RAM",
    "keywords": [
      "Galaxy M34 128"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-90",
    "categoria": "smartphone",
    "marca": "Samsung",
    "titulo": "Galaxy M15 128GB / 4GB RAM",
    "keywords": [
      "Galaxy M15 128"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-91",
    "categoria": "smartphone",
    "marca": "Samsung",
    "titulo": "Galaxy M15 256GB / 8GB RAM",
    "keywords": [
      "Galaxy M15 256"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-92",
    "categoria": "smartwatch",
    "marca": "Samsung",
    "titulo": "Galaxy Watch 9 Ultra 47mm",
    "keywords": [
      "Galaxy Watch 9 Ultra 47"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-93",
    "categoria": "smartwatch",
    "marca": "Samsung",
    "titulo": "Galaxy Watch 9 44mm",
    "keywords": [
      "Galaxy Watch 9 44"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-94",
    "categoria": "smartwatch",
    "marca": "Samsung",
    "titulo": "Galaxy Watch 9 40mm",
    "keywords": [
      "Galaxy Watch 9 40"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-95",
    "categoria": "smartwatch",
    "marca": "Samsung",
    "titulo": "Galaxy Watch 8 Ultra 47mm",
    "keywords": [
      "Galaxy Watch 8 Ultra 47"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-96",
    "categoria": "smartwatch",
    "marca": "Samsung",
    "titulo": "Galaxy Watch 8 44mm",
    "keywords": [
      "Galaxy Watch 8 44"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-97",
    "categoria": "smartwatch",
    "marca": "Samsung",
    "titulo": "Galaxy Watch 8 40mm",
    "keywords": [
      "Galaxy Watch 8 40"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-98",
    "categoria": "smartwatch",
    "marca": "Samsung",
    "titulo": "Galaxy Watch Ultra 47mm",
    "keywords": [
      "Galaxy Watch Ultra 47"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-99",
    "categoria": "smartwatch",
    "marca": "Samsung",
    "titulo": "Galaxy Watch 7 44mm",
    "keywords": [
      "Galaxy Watch 7 44"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-100",
    "categoria": "smartwatch",
    "marca": "Samsung",
    "titulo": "Galaxy Watch 7 40mm",
    "keywords": [
      "Galaxy Watch 7 40"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-101",
    "categoria": "smartwatch",
    "marca": "Samsung",
    "titulo": "Galaxy Watch FE 40mm",
    "keywords": [
      "Galaxy Watch FE 40"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-102",
    "categoria": "smartwatch",
    "marca": "Samsung",
    "titulo": "Galaxy Watch 6 Classic 47mm",
    "keywords": [
      "Galaxy Watch 6 Classic 47"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-103",
    "categoria": "smartwatch",
    "marca": "Samsung",
    "titulo": "Galaxy Watch 6 Classic 43mm",
    "keywords": [
      "Galaxy Watch 6 Classic 43"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-104",
    "categoria": "smartwatch",
    "marca": "Samsung",
    "titulo": "Galaxy Watch 6 44mm",
    "keywords": [
      "Galaxy Watch 6 44"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-105",
    "categoria": "smartwatch",
    "marca": "Samsung",
    "titulo": "Galaxy Watch 6 40mm",
    "keywords": [
      "Galaxy Watch 6 40"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-106",
    "categoria": "smartwatch",
    "marca": "Samsung",
    "titulo": "Galaxy Watch 5 Pro 45mm",
    "keywords": [
      "Galaxy Watch 5 Pro 45"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-107",
    "categoria": "smartwatch",
    "marca": "Samsung",
    "titulo": "Galaxy Watch 5 44mm",
    "keywords": [
      "Galaxy Watch 5 44"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-108",
    "categoria": "smartwatch",
    "marca": "Samsung",
    "titulo": "Galaxy Watch 5 40mm",
    "keywords": [
      "Galaxy Watch 5 40"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-109",
    "categoria": "games",
    "marca": "Sony",
    "titulo": "PlayStation 5 Pro 2TB (Sem Leitor)",
    "keywords": [
      "PlayStation 5 Pro"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-110",
    "categoria": "games",
    "marca": "Sony",
    "titulo": "PlayStation 5 Slim (Com Leitor de Disco)",
    "keywords": [
      "PlayStation 5"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-111",
    "categoria": "games",
    "marca": "Sony",
    "titulo": "PlayStation 5 Slim (Com Leitor de Disco) + 2 Jogos",
    "keywords": [
      "PlayStation 5"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-112",
    "categoria": "games",
    "marca": "Sony",
    "titulo": "PlayStation 5 Slim Edição Digital",
    "keywords": [
      "PlayStation 5"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-113",
    "categoria": "games",
    "marca": "Sony",
    "titulo": "PlayStation 5 Slim Edição Digital + 2 Jogos",
    "keywords": [
      "PlayStation 5"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-114",
    "categoria": "games",
    "marca": "Sony",
    "titulo": "PlayStation 5 (Com Leitor de Disco) - Modelo Fat",
    "keywords": [
      "PlayStation 5"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-115",
    "categoria": "games",
    "marca": "Sony",
    "titulo": "PlayStation 5 Edição Digital - Modelo Fat",
    "keywords": [
      "PlayStation 5"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-116",
    "categoria": "smartphone",
    "marca": "Motorola",
    "titulo": "Motorola Edge 60 Ultra 512GB",
    "keywords": [
      "Motorola Edge 60 Ultra 512"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-117",
    "categoria": "smartphone",
    "marca": "Motorola",
    "titulo": "Motorola Edge 60 Pro 256GB",
    "keywords": [
      "Motorola Edge 60 Pro 256"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-118",
    "categoria": "smartphone",
    "marca": "Motorola",
    "titulo": "Motorola Edge 60 Fusion 256GB",
    "keywords": [
      "Motorola Edge 60 Fusion 256"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-119",
    "categoria": "smartphone",
    "marca": "Motorola",
    "titulo": "Motorola Razr 60 Ultra 512GB (Dobrável)",
    "keywords": [
      "Motorola Razr 60 Ultra 512"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-120",
    "categoria": "smartphone",
    "marca": "Motorola",
    "titulo": "Moto G86 256GB",
    "keywords": [
      "Moto G86 256"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-121",
    "categoria": "smartphone",
    "marca": "Motorola",
    "titulo": "Moto G56 256GB",
    "keywords": [
      "Moto G56 256"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-122",
    "categoria": "smartphone",
    "marca": "Motorola",
    "titulo": "Moto G36 128GB",
    "keywords": [
      "Moto G36 128"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-123",
    "categoria": "smartphone",
    "marca": "Motorola",
    "titulo": "Moto G26 128GB",
    "keywords": [
      "Moto G26 128"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-124",
    "categoria": "smartphone",
    "marca": "Motorola",
    "titulo": "Moto G06 64GB",
    "keywords": [
      "Moto G06 64"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-125",
    "categoria": "smartwatch",
    "marca": "Apple",
    "titulo": "Apple Watch Ultra 3",
    "keywords": [
      "Apple Watch Ultra 3"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-126",
    "categoria": "smartwatch",
    "marca": "Apple",
    "titulo": "Apple Watch Series 12 45mm",
    "keywords": [
      "Apple Watch Series 12"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-127",
    "categoria": "smartwatch",
    "marca": "Apple",
    "titulo": "Apple Watch Series 12 41mm",
    "keywords": [
      "Apple Watch Series 12"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-128",
    "categoria": "smartwatch",
    "marca": "Apple",
    "titulo": "Apple Watch SE (3ª Geração) 44mm",
    "keywords": [
      "Apple Watch SE 3"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-129",
    "categoria": "smartwatch",
    "marca": "Apple",
    "titulo": "Apple Watch SE (3ª Geração) 40mm",
    "keywords": [
      "Apple Watch SE 3"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-130",
    "categoria": "smartwatch",
    "marca": "Apple",
    "titulo": "Apple Watch Series 10 46mm",
    "keywords": [
      "Apple Watch Series 10"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-131",
    "categoria": "games",
    "marca": "Microsoft",
    "titulo": "Xbox Series X 2TB Edição Digital",
    "keywords": [
      "Xbox Series X"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-132",
    "categoria": "games",
    "marca": "Microsoft",
    "titulo": "Xbox Series X 1TB (Com Leitor)",
    "keywords": [
      "Xbox Series X"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-133",
    "categoria": "games",
    "marca": "Microsoft",
    "titulo": "Xbox Series S 1TB (Preto)",
    "keywords": [
      "Xbox Series S"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-134",
    "categoria": "games",
    "marca": "Microsoft",
    "titulo": "Xbox Series S 512GB (Branco)",
    "keywords": [
      "Xbox Series S"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-135",
    "categoria": "games",
    "marca": "Nintendo",
    "titulo": "Nintendo Switch 2 (Com Leitor de Cartucho)",
    "keywords": [
      "Nintendo Switch 2"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-136",
    "categoria": "games",
    "marca": "Nintendo",
    "titulo": "Nintendo Switch 2 Digital",
    "keywords": [
      "Nintendo Switch 2"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-137",
    "categoria": "games",
    "marca": "Nintendo",
    "titulo": "Nintendo Switch OLED",
    "keywords": [
      "Nintendo Switch OLED"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-138",
    "categoria": "games",
    "marca": "Nintendo",
    "titulo": "Nintendo Switch Padrão",
    "keywords": [
      "Nintendo Switch"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-139",
    "categoria": "games",
    "marca": "Nintendo",
    "titulo": "Nintendo Switch Lite",
    "keywords": [
      "Nintendo Switch Lite"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-140",
    "categoria": "áudio",
    "marca": "Apple",
    "titulo": "AirPods Max 2",
    "keywords": [
      "AirPods Max 2"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-141",
    "categoria": "áudio",
    "marca": "Apple",
    "titulo": "AirPods Pro (3ª Geração)",
    "keywords": [
      "AirPods Pro 3"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-142",
    "categoria": "áudio",
    "marca": "Apple",
    "titulo": "AirPods 4 (Com Cancelamento de Ruído)",
    "keywords": [
      "AirPods 4 cancelamento"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-143",
    "categoria": "áudio",
    "marca": "Apple",
    "titulo": "AirPods 4 (Padrão)",
    "keywords": [
      "AirPods 4"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-144",
    "categoria": "áudio",
    "marca": "Samsung",
    "titulo": "Galaxy Buds 3 Pro",
    "keywords": [
      "Galaxy Buds 3 Pro"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-145",
    "categoria": "áudio",
    "marca": "Samsung",
    "titulo": "Galaxy Buds 3",
    "keywords": [
      "Galaxy Buds 3"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-146",
    "categoria": "áudio",
    "marca": "Samsung",
    "titulo": "Galaxy Buds FE",
    "keywords": [
      "Galaxy Buds FE"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-147",
    "categoria": "áudio",
    "marca": "JBL",
    "titulo": "JBL Boombox 4",
    "keywords": [
      "JBL Boombox 4"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-148",
    "categoria": "áudio",
    "marca": "JBL",
    "titulo": "JBL PartyBox Club 120",
    "keywords": [
      "JBL PartyBox Club 120"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-149",
    "categoria": "áudio",
    "marca": "JBL",
    "titulo": "JBL Charge 6",
    "keywords": [
      "JBL Charge 6"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-150",
    "categoria": "áudio",
    "marca": "JBL",
    "titulo": "JBL Flip 7",
    "keywords": [
      "JBL Flip 7"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-151",
    "categoria": "áudio",
    "marca": "JBL",
    "titulo": "JBL Clip 5",
    "keywords": [
      "JBL Clip 5"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-152",
    "categoria": "áudio",
    "marca": "JBL",
    "titulo": "JBL Go 4",
    "keywords": [
      "JBL Go 4"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-153",
    "categoria": "tv",
    "marca": "Samsung",
    "titulo": "Smart TV Samsung Neo QLED 8K 85\" (QN900F)",
    "keywords": [
      "Samsung Neo QLED 85 QN900F"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-154",
    "categoria": "tv",
    "marca": "Samsung",
    "titulo": "Smart TV Samsung Neo QLED 4K 65\" (QN90F)",
    "keywords": [
      "Samsung Neo QLED 65 QN90F"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-155",
    "categoria": "tv",
    "marca": "Samsung",
    "titulo": "Smart TV Samsung OLED 65\" (S95F)",
    "keywords": [
      "Samsung OLED 65 S95F"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-156",
    "categoria": "tv",
    "marca": "Samsung",
    "titulo": "Smart TV Samsung The Frame 55\"",
    "keywords": [
      "Samsung The Frame 55"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-157",
    "categoria": "tv",
    "marca": "Samsung",
    "titulo": "Smart TV Samsung QLED 4K 55\" (Q60F)",
    "keywords": [
      "Samsung QLED 55 Q60F"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-158",
    "categoria": "tv",
    "marca": "Samsung",
    "titulo": "Smart TV Samsung Crystal UHD 4K 50\" (CU8000/DU8000)",
    "keywords": [
      "Samsung Crystal UHD 50 CU8000"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-159",
    "categoria": "tv",
    "marca": "LG",
    "titulo": "Smart TV LG OLED evo G6 65\"",
    "keywords": [
      "LG OLED evo G6 65"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-160",
    "categoria": "tv",
    "marca": "LG",
    "titulo": "Smart TV LG OLED evo C6 55\"",
    "keywords": [
      "LG OLED evo C6 55"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-161",
    "categoria": "tv",
    "marca": "LG",
    "titulo": "Smart TV LG QNED MiniLED 65\"",
    "keywords": [
      "LG QNED MiniLED 65"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-162",
    "categoria": "tv",
    "marca": "LG",
    "titulo": "Smart TV LG UHD 4K 50\" (UR8750)",
    "keywords": [
      "LG UHD 50 UR8750"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-163",
    "categoria": "tv",
    "marca": "TCL",
    "titulo": "Smart TV TCL QD-Mini LED 4K 75\" (X955)",
    "keywords": [
      "TCL QD-Mini LED 75 X955"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-164",
    "categoria": "tv",
    "marca": "TCL",
    "titulo": "Smart TV TCL QLED 4K 65\" (C655)",
    "keywords": [
      "TCL QLED 65 C655"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-165",
    "categoria": "tv",
    "marca": "TCL",
    "titulo": "Smart TV TCL QLED 4K 55\" (C645)",
    "keywords": [
      "TCL QLED 55 C645"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-166",
    "categoria": "tv",
    "marca": "TCL",
    "titulo": "Smart TV TCL UHD 4K 50\" (P755)",
    "keywords": [
      "TCL UHD 50 P755"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-167",
    "categoria": "tv",
    "marca": "TCL",
    "titulo": "Smart TV TCL S615 43\" FHD (Android/Google TV)",
    "keywords": [
      "TCL S615 43 FHD"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-168",
    "categoria": "tv",
    "marca": "Philips",
    "titulo": "Smart TV Philips OLED+ 65\" (Ambilight)",
    "keywords": [
      "Philips OLED+ 65 Ambilight"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-169",
    "categoria": "tv",
    "marca": "Philips",
    "titulo": "Smart TV Philips The One 4K 55\" (Ambilight)",
    "keywords": [
      "Philips The One 55 Ambilight"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-170",
    "categoria": "tv",
    "marca": "Philips",
    "titulo": "Smart TV Philips MiniLED 65\" (Ambilight)",
    "keywords": [
      "Philips MiniLED 65 Ambilight"
    ],
    "origem": "catalogo"
  },
  {
    "id": "catalogo-171",
    "categoria": "tv",
    "marca": "Philips",
    "titulo": "Smart TV Philips 4K 50\" (Série 7000)",
    "keywords": [
      "Philips 50 Série 7000"
    ],
    "origem": "catalogo"
  }
];

const api = { CATALOG_EXAMPLES };

if (typeof module !== 'undefined' && module.exports) {
  module.exports = api;
} else {
  self.PelandoKW = self.PelandoKW || {};
  Object.assign(self.PelandoKW, api);
}

})();
