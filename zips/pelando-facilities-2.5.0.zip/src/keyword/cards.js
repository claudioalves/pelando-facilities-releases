(function () {
'use strict';

// Injeta os 3 botões (Pelando, Google Shopping, Configurações) em cada card de
// promoção das listas do backoffice e do www.pelando.com.br. Cada botão usa o
// título do próprio card. No Promoninja entram só os botões do ladrão, que
// buscam no site concorrente do país.

const ICONS = {
  pelando: 'chama.png',
  google: 'google-circle.png',
  config: 'adicionar.png',
  competitor: 'ladrao.png',
};

const BUTTONS = [
  { action: 'pelando', label: 'Buscar no Pelando', handler: 'onPelando' },
  { action: 'google', label: 'Buscar no Google Shopping', handler: 'onGoogleShopping' },
  { action: 'config', label: 'Adicionar palavras-chave', handler: 'onConfig' },
];

// Botões com texto (`text`) depois do ícone do ladrão - o emoji 🥷 não existe
// no Windows 10. A busca nos recentes só existe para concorrentes com uma
// página das promoções mais novas.
function competitorButtons(competitor) {
  const buttons = [
    { action: 'competitor', icon: 'competitor', text: 'Busca pelo produto', label: `Buscar o produto no ${competitor.name}`, handler: 'onCompetitor' },
  ];
  if (competitor.recentUrl) {
    buttons.push({ action: 'competitor-recent', icon: 'competitor', text: 'Busca recentes', label: `Buscar nos recentes do ${competitor.name}`, handler: 'onCompetitorRecent' });
  }
  return buttons;
}

const CONTAINER_CLASS = 'pelando-kw-buttons';

function iconUrl(file) {
  // getURL lança "Extension context invalidated" se a extensão foi atualizada com a aba aberta.
  try {
    return chrome.runtime.getURL(`src/keyword/icons/${file}`);
  } catch (error) {
    return `src/keyword/icons/${file}`;
  }
}

// `getDeal` (opcional) dá preço e loja da promoção ao botão do concorrente.
function buildIconButtons(doc, handlers, getTitle, buttons = BUTTONS, getDeal) {
  const container = doc.createElement('div');
  container.className = CONTAINER_CLASS;
  for (const { action, label, handler, text, icon: iconName } of buttons) {
    const button = doc.createElement('button');
    button.type = 'button';
    button.className = 'pelando-kw-button';
    button.dataset.action = action;
    button.title = label;
    button.setAttribute('aria-label', label);
    const icon = doc.createElement('span');
    icon.className = 'pelando-kw-icon';
    const url = iconUrl(ICONS[iconName || action]);
    icon.setAttribute('style', `-webkit-mask-image: url("${url}"); mask-image: url("${url}");`);
    button.appendChild(icon);
    if (text) {
      button.classList.add('pelando-kw-button--text');
      button.append(text);
    }
    // Os cards do Pelando são links: sem isso o clique também abriria a promoção.
    button.addEventListener('click', (event) => {
      event.preventDefault();
      event.stopPropagation();
      handlers[handler](getTitle(), getDeal ? getDeal() : undefined);
    });
    container.appendChild(button);
  }
  return container;
}

function textOf(element) {
  return element ? element.textContent.replace(/\s+/g, ' ').trim() : '';
}

// Junta a imagem do card (só endereços web) ao que o ladrão guarda.
function withImage(deal, img) {
  const src = img ? img.currentSrc || img.getAttribute('src') || '' : '';
  if (/^https?:\/\//i.test(src)) deal.image = src;
  return deal;
}

const ADAPTERS = {
  backoffice: {
    findCards(doc) {
      const cards = [];
      doc.querySelectorAll('[data-slot="card"]').forEach((card) => {
        const title = card.querySelector('[data-slot="card-content"] h3');
        const footer = card.querySelector('[data-slot="card-footer"]');
        if (!title || !footer) return;
        cards.push({
          card,
          getTitle: () => textOf(title),
          // O card do BO mostra o preço num h4 e a loja em "Vendido por <loja>"
          // (o link do botão Loja é um redirecionamento, não serve).
          getDeal: () =>
            withImage(
              {
                price: textOf(card.querySelector('[data-slot="card-content"] h4')),
                store: textOf(card.querySelector('[data-slot="card-content"] .text-muted-foreground > .font-bold')),
              },
              card.querySelector('[data-slot="card-content"] img')
            ),
          mount: (container) => (footer.firstElementChild || footer).appendChild(container),
        });
      });
      return cards;
    },
  },
  pelando: {
    findCards(doc) {
      const cards = [];
      doc.querySelectorAll('h3 > a[data-deal-id]').forEach((link) => {
        const h3 = link.parentElement;
        const card = link.closest('[data-show-author]') || link.closest('li') || h3.parentElement;
        cards.push({
          card,
          getTitle: () => textOf(link),
          getDeal: () =>
            withImage(
              {
                price: textOf(card.querySelector('[class*="deal-card-stamp"]')),
                store: textOf(card.querySelector('[class*="default-deal-card-store"] strong')),
              },
              card.querySelector('img[class*="deal-card-image"]')
            ),
          mount: (container) => {
            const actions = card.querySelector('[class*="default-deal-card-actions"]');
            if (actions) actions.appendChild(container);
            else h3.insertAdjacentElement('afterend', container);
          },
        });
      });
      return cards;
    },
  },
};

function adapterFor(hostname) {
  if (hostname === 'bo.pelando.com.br') return ADAPTERS.backoffice;
  if (hostname === 'www.pelando.com.br' || hostname === 'pelando.com.br') return ADAPTERS.pelando;
  // O Promoninja roda o mesmo backoffice e o mesmo site do Pelando.
  if (/^bo\.promoninja\./.test(hostname || '')) return ADAPTERS.backoffice;
  if (/^(www\.)?promoninja\./.test(hostname || '')) return ADAPTERS.pelando;
  return null;
}

// Retorna quantos cards receberam botões nesta passada.
function injectCardButtons(doc, adapter, handlers, buttons = BUTTONS) {
  let injected = 0;
  for (const { card, getTitle, getDeal, mount } of adapter.findCards(doc)) {
    if (card.querySelector(`.${CONTAINER_CLASS}`)) continue;
    mount(buildIconButtons(doc, handlers, getTitle, buttons, getDeal));
    injected += 1;
  }
  return injected;
}

const OBSERVE_DELAY_MS = 50;

// Roda `run` agora e depois de mutações no body, agrupando rajadas de mutações
// (hidratação, scroll infinito) em no máximo uma passada a cada OBSERVE_DELAY_MS.
function observeBody(doc, run) {
  let scheduled = false;
  const observer = new MutationObserver(() => {
    if (scheduled) return;
    scheduled = true;
    setTimeout(() => {
      scheduled = false;
      run();
    }, OBSERVE_DELAY_MS);
  });
  observer.observe(doc.body, { childList: true, subtree: true });
  run();
  return observer;
}

function startCardObserver(doc, adapter, handlers) {
  return observeBody(doc, () => injectCardButtons(doc, adapter, handlers));
}

const api = { ICONS, iconUrl, competitorButtons, buildIconButtons, injectCardButtons, observeBody, startCardObserver, adapterFor, ADAPTERS };

if (typeof module !== 'undefined' && module.exports) {
  module.exports = api;
} else {
  self.PelandoKW = self.PelandoKW || {};
  Object.assign(self.PelandoKW, api);
}

})();
