(function () {
'use strict';

// Objetivo: reduzir o título ao menor trecho que identifica o produto na busca
// do Pelando (marca + modelo/linha), aprendendo com os exemplos cadastrados.

const ROLE = {
  GENERICO: 'GENERICO',
  TIPO: 'TIPO',
  TAMANHO: 'TAMANHO',
  MEMORIA: 'MEMORIA',
  ORDINAL: 'ORDINAL',
  QUANTIDADE: 'QUANTIDADE',
  COR: 'COR',
  CONECTIVIDADE: 'CONECTIVIDADE',
  DESCRITOR: 'DESCRITOR',
  GENERO: 'GENERO',
  ESPECIFICACAO: 'ESPECIFICACAO',
  TECNOLOGIA: 'TECNOLOGIA',
  ANO: 'ANO',
  PARADA: 'PARADA',
};

// Trechos do título: principal, antes de ":" (franquia), depois de " - ",
// depois de vírgula, depois de "para" (compatibilidade), depois de "com"
// (recursos), depois de " + " (brinde/combo), entre parênteses e o subtítulo
// de uma franquia numerada ("The Elder Scrolls V: Skyrim").
const SEGMENT = {
  PRINCIPAL: 'PRINCIPAL',
  FRANQUIA: 'FRANQUIA',
  TRACO: 'TRACO',
  VIRGULA: 'VIRGULA',
  PARA: 'PARA',
  COMBO: 'COMBO',
  COM: 'COM',
  SUBTITULO: 'SUBTITULO',
  PARENTESES: 'PARENTESES',
};

const PRODUCT_TYPES = [
  'celular', 'smartphone', 'tablet', 'notebook', 'computador', 'monitor', 'tv',
  'televisão', 'televisao', 'televisor',
  'smart', 'console', 'jogo', 'controle', 'processador', 'placa', 'video',
  'caixa', 'som', 'fone', 'ouvido', 'headset', 'mouse', 'teclado',
  'máscara', 'mascara', 'capilar', 'sabonete', 'líquido', 'liquido', 'hidratante',
  'labial', 'deo', 'desodorante', 'colônia', 'colonia', 'perfume', 'shampoo',
  'condicionador', 'tênis', 'tenis', 'óculos', 'oculos', 'sol', 'relógio',
  'relogio', 'smartwatch', 'kit', 'cafeteira', 'fritadeira', 'liquidificador', 'geladeira',
  'aspirador', 'microfone', 'moedor', 'café', 'cafe', 'refrigerador', 'berço', 'berco',
  'brinquedo', 'bebê', 'bebe', 'robô', 'robo', 'pó', 'passa', 'pano', 'sensor',
  'estacionamento', 'câmera', 'camera', 'smart tv',
];

const COLORS = [
  'preto', 'preta', 'branco', 'branca', 'azul', 'vermelho', 'vermelha', 'verde',
  'amarelo', 'amarela', 'rosa', 'roxo', 'roxa', 'cinza', 'prata', 'dourado',
  'dourada', 'grafite', 'bordô', 'bordo', 'violeta', 'marrom', 'bege', 'lilás',
  'lilas', 'laranja', 'titânio', 'titanio', 'prateado', 'prateada',
];

const GENDERS = ['masculino', 'masculina', 'feminino', 'feminina', 'unissex'];
// Em roupa o gênero faz parte do produto ("Calça Feminina", "Bermuda Masculina").
const CLOTHING = [
  'calça', 'calca', 'bermuda', 'camisa', 'camiseta', 'short', 'shorts', 'blusa', 'jaqueta',
  'moletom', 'vestido', 'saia', 'regata', 'cueca', 'meia', 'meias',
];
// Descrevem o produto mas não o identificam na busca ("Portátil", "Pote",
// "Longa Vida", "Adulto Castrado").
const DESCRIPTORS = [
  'portátil', 'portatil', 'recarregável', 'recarregavel', 'concentrado', 'pote', 'refil',
  'sachê', 'sache', 'longa', 'vida', 'adulto', 'adultos', 'filhote', 'filhotes',
  'castrado', 'castrados', 'peças', 'pecas',
  'elétrica', 'elétrico', 'eletrica', 'eletrico', 'inteligente', 'ergonômico', 'ergonômica',
  'ergonomico', 'ergonomica', 'manual', 'inox', 'kids', 'silicone', 'ação', 'acao',
  'estabilizador', 'ajuste', 'bateria', 'baterias',
  // Sabores e aromas.
  'aromáticos', 'aromaticos', 'aromático', 'aromatico', 'morango', 'chocolate', 'baunilha',
  'lavanda', 'amêndoas', 'amendoas',
];
// Tecnologias de tela, áudio e proteção: não identificam o produto na busca
// (o catálogo de TVs ainda pode ensinar a manter "4K").
const TECHNOLOGIES = ['4k', '8k', 'hdr', 'fhd', 'ips', 'ai', 'anc', 'dolby', 'atmos', 'argb', 'dolby vision'];
const TECHNOLOGY_RE = /^(ipx?\d{1,2}|\d+dpi|\d+x\d+|\d+%\S*)$/i;
const YEAR_RE = /^20[2-3]\d$/;
const SPECS = ['ram', 'tela', 'ssd', 'hd'];
const QUANTITY_UNITS = ['und', 'unid', 'un', 'unidades', 'unidade', 'alturas'];
const STOPWORDS = ['de', 'da', 'do', 'das', 'dos', 'com', 'para', 'em', 'e', 'o', 'a', 'os', 'as', 'novo', 'nova', 'original'];

const SIZE_UNIT = '(gb|tb|mb|ml|l|g|kg|mg|w|v|mah|hz|cm|mm|pol|polegadas|dias)';
const SIZE_RE = new RegExp(`^\\d+([.,]\\d+)?${SIZE_UNIT}$`, 'i');
const UNIT_RE = new RegExp(`^${SIZE_UNIT}$`, 'i');
const NUMBER_RE = /^\d+([.,]\d+)?$/;

const DROPPED_BY_DEFAULT = new Set([
  ROLE.TAMANHO, ROLE.MEMORIA, ROLE.QUANTIDADE, ROLE.COR, ROLE.CONECTIVIDADE, ROLE.GENERO,
  ROLE.ESPECIFICACAO, ROLE.PARADA, ROLE.DESCRITOR, ROLE.TECNOLOGIA, ROLE.ANO,
]);

function stripPunctuation(word) {
  return word.replace(/^[#*.,;:!?()[\]{}'"]+|[#*.,;:!?()[\]{}'"]+$/g, '');
}

const CONNECTIVITY = ['wifi', 'wi-fi', 'lte', 'gps', 'nfc', 'bluetooth', 'wireless', 'sem fio'];
// Pares que viram um token só ("Sem Fio", "Dolby Vision", "Smart TV").
const WORD_PAIRS = ['sem fio', 'dolby vision', 'smart tv'];
const PUNCTUATION_ONLY_RE = /^[/|+&–—-]+$/;
const ORDINAL_RE = /^\d+[ªº°]$/;
const PARTIAL_NUMBER_ROLES = new Set([ROLE.TAMANHO, ROLE.MEMORIA, ROLE.ORDINAL]);

function classifyToken(rawText) {
  const text = rawText.toLowerCase();
  if (/^[345]g$/.test(text) || CONNECTIVITY.includes(text)) return ROLE.CONECTIVIDADE;
  if (ORDINAL_RE.test(text)) return ROLE.ORDINAL;
  // "5600G"/"3200G" são modelos de processador; gramas vêm em minúsculo ("900g").
  if (/^\d{3,}G$/.test(rawText)) return ROLE.GENERICO;
  if (TECHNOLOGIES.includes(text) || TECHNOLOGY_RE.test(text)) return ROLE.TECNOLOGIA;
  if (YEAR_RE.test(text)) return ROLE.ANO;
  if (SIZE_RE.test(text)) return ROLE.TAMANHO;
  if (QUANTITY_UNITS.includes(text)) return ROLE.QUANTIDADE;
  // "Azul-céu", "Preto-Fosco": a primeira parte já identifica a cor.
  if (COLORS.includes(text) || COLORS.includes(text.split('-')[0])) return ROLE.COR;
  if (GENDERS.includes(text)) return ROLE.GENERO;
  if (DESCRIPTORS.includes(text)) return ROLE.DESCRITOR;
  if (SPECS.includes(text)) return ROLE.ESPECIFICACAO;
  if (STOPWORDS.includes(text)) return ROLE.PARADA;
  if (PRODUCT_TYPES.includes(text)) return ROLE.TIPO;
  return ROLE.GENERICO;
}

function cleanTitle(title) {
  return String(title || '').replace(/\[[^\]]*\]/g, ' ').replace(/[®™©]/g, '');
}

const NUMBERED_FRANCHISE_RE = /\s(\d+|[IVX]+)$/;

function splitSegments(title) {
  const segments = [];
  let rest = cleanTitle(title);

  const colon = rest.lastIndexOf(':');
  if (colon !== -1 && rest.slice(colon + 1).trim()) {
    const franchise = rest.slice(0, colon);
    // "The Elder Scrolls V: Skyrim": a franquia numerada é o jogo; o
    // subtítulo é a edição. Sem número ("Call of Duty: Black Ops 4"), vale o
    // subtítulo.
    if (NUMBERED_FRANCHISE_RE.test(franchise.trim())) {
      segments.push({ text: franchise, segment: SEGMENT.PRINCIPAL });
      segments.push({ text: rest.slice(colon + 1), segment: SEGMENT.SUBTITULO });
      return segments;
    }
    segments.push({ text: franchise, segment: SEGMENT.FRANQUIA });
    rest = rest.slice(colon + 1);
  }

  let comboPart = '';
  const combo = rest.search(/\s\+\s/);
  if (combo !== -1) {
    comboPart = rest.slice(combo);
    rest = rest.slice(0, combo);
  }

  let paraPart = '';
  const para = rest.search(/\spara\s/i);
  if (para !== -1) {
    paraPart = rest.slice(para);
    rest = rest.slice(0, para);
  }

  // "com Máscara e Enchimento", "com Desvio de Obstáculos por IA, Lava, ...".
  let comPart = '';
  const com = rest.search(/\scom\s/i);
  if (com !== -1) {
    comPart = rest.slice(com);
    rest = rest.slice(0, com);
  }

  // Vírgula decimal ("4,2 L") não separa trechos.
  let [beforeComma, ...afterComma] = rest.split(/(?<!\d),|,(?!\d)/);
  // "Tramontina, Jogo de Facas, ...": marca sozinha antes da vírgula; o produto
  // vem no primeiro trecho depois dela.
  if (beforeComma.trim().split(/\s+/).length === 1 && afterComma.length) {
    beforeComma = `${beforeComma} ${afterComma.shift()}`;
  }
  const [main, ...afterDash] = beforeComma.split(/\s[-–—]\s/);
  segments.push({ text: main, segment: SEGMENT.PRINCIPAL });
  afterDash.forEach((text) => segments.push({ text, segment: SEGMENT.TRACO }));
  afterComma.forEach((text) => segments.push({ text, segment: SEGMENT.VIRGULA }));
  if (paraPart) segments.push({ text: paraPart, segment: SEGMENT.PARA });
  if (comPart) segments.push({ text: comPart, segment: SEGMENT.COM });
  if (comboPart) segments.push({ text: comboPart, segment: SEGMENT.COMBO });
  return segments;
}

function tokenizeSegment(text, segment) {
  const words = [];
  let inParen = false;
  // "CU8000/DU8000", "Android/Google": a barra separa alternativas.
  const raws = text.split(/\s+/).flatMap((word) => word.split(/(?<=[^\s/])\/(?=[^\s/])/));
  for (const raw of raws.filter(Boolean)) {
    if (raw.startsWith('(')) inParen = true;
    const word = stripPunctuation(raw);
    if (word && !PUNCTUATION_ONLY_RE.test(word)) {
      words.push({ word, segment: inParen ? SEGMENT.PARENTESES : segment });
    }
    if (raw.endsWith(')')) inParen = false;
  }

  const tokens = [];
  for (let i = 0; i < words.length; i += 1) {
    const { word, segment: wordSegment } = words[i];
    const next = words[i + 1] && words[i + 1].word;
    if (next && WORD_PAIRS.includes(`${word} ${next}`.toLowerCase())) {
      const text = `${word} ${next}`;
      tokens.push({ text, role: classifyToken(text), segment: wordSegment });
      i += 1;
    } else if (NUMBER_RE.test(word) && next && UNIT_RE.test(next)) {
      tokens.push({ text: `${word} ${next}`, role: ROLE.TAMANHO, segment: wordSegment });
      i += 1;
    } else if (NUMBER_RE.test(word) && next && QUANTITY_UNITS.includes(next.toLowerCase())) {
      tokens.push({ text: word, role: ROLE.QUANTIDADE, segment: wordSegment });
    } else {
      tokens.push({ text: word, role: classifyToken(word), segment: wordSegment });
    }
  }
  // "12GB RAM": o tamanho logo antes de "RAM" é memória, não armazenamento.
  tokens.forEach((token, i) => {
    const next = tokens[i + 1];
    if (token.role === ROLE.TAMANHO && next && next.text.toLowerCase() === 'ram') token.role = ROLE.MEMORIA;
    // "Bluetooth 6.0": o número logo depois da conectividade é a versão.
    const previous = tokens[i - 1];
    if (NUMBER_RE.test(token.text) && previous && previous.role === ROLE.CONECTIVIDADE) token.role = ROLE.ESPECIFICACAO;
  });
  return tokens;
}

function tokenize(title) {
  return splitSegments(String(title || '')).flatMap(({ text, segment }) => tokenizeSegment(text, segment));
}

function tokenKey(token) {
  return token.text.toLowerCase().replace(/\s+/g, '');
}

function jaccardSimilarity(a, b) {
  const setA = new Set(a);
  const setB = new Set(b);
  if (setA.size === 0 && setB.size === 0) return 0;
  let intersection = 0;
  for (const item of setA) if (setB.has(item)) intersection += 1;
  const union = new Set([...setA, ...setB]).size;
  return union === 0 ? 0 : intersection / union;
}

function findBestMatch(tokens, examples, threshold = 0.3) {
  const titleKeys = tokens.map(tokenKey);
  let best = null;
  for (const example of examples) {
    const exampleTokens = tokenize(example.titulo);
    const score = jaccardSimilarity(titleKeys, exampleTokens.map(tokenKey));
    if (score >= threshold && (!best || score > best.score)) {
      best = { example, exampleTokens, score };
    }
  }
  return best;
}

function numericPart(token) {
  const match = token.text.match(/^\d+([.,]\d+)?/);
  return match ? match[0] : null;
}

function normalizeDecimal(text) {
  return String(text).replace(/(\d),(\d)/g, '$1.$2');
}

function keywordWordsOf(example) {
  return new Set(
    (example.keywords || [])
      .flatMap((k) => normalizeDecimal(k).toLowerCase().split(/\s+/))
      .map(stripPunctuation)
      .filter(Boolean)
  );
}

// "2.7kg" mantido como "2,7"/"2.7", ou salvo partido em "2" e "7" pelo
// painel antigo, que cortava as palavras-chave na vírgula decimal.
function keptAsNumber(token, keywordWords) {
  const number = numericPart(token);
  if (!number) return false;
  const normalized = normalizeDecimal(number);
  if (keywordWords.has(normalized)) return true;
  const parts = normalized.split('.');
  return parts.length > 1 && parts.every((part) => keywordWords.has(part));
}

// Para cada palavra do título do exemplo: foi mantida nas palavras-chave?
// Tamanhos, memória e ordinais podem ter sido mantidos só como número
// ("128GB" -> "128", "3ª" -> "3").
function learnDecisions(example) {
  const keywordWords = keywordWordsOf(example);
  const words = new Map();
  const roles = new Map();
  const tokens = [];
  for (const token of tokenize(example.titulo)) {
    const key = tokenKey(token);
    // "Homem-Aranha" no título, "Homem Aranha" nas palavras-chave.
    const partsKept = token.text.toLowerCase().split(/[\s-]+/).every((p) => keywordWords.has(p));
    let decision = { keep: keywordWords.has(key) || partsKept, format: 'completo' };
    if (!decision.keep && PARTIAL_NUMBER_ROLES.has(token.role) && keptAsNumber(token, keywordWords)) {
      decision = { keep: true, format: 'numero' };
    }
    words.set(key, decision);
    tokens.push({ token, decision });
    // Tecnologias valem palavra a palavra: manter "4K" não manda manter "AI".
    if (token.role !== ROLE.GENERICO && token.role !== ROLE.TECNOLOGIA) {
      const previous = roles.get(token.role);
      const consistent = !previous || (previous.keep === decision.keep && previous.format === decision.format);
      roles.set(token.role, consistent ? decision : { conflict: true });
    }
  }
  for (const [role, decision] of roles) if (decision.conflict) roles.delete(role);
  return { words, roles, tokens };
}

const VOCABULARY_SEGMENTS = new Set([SEGMENT.PRINCIPAL, SEGMENT.PARENTESES]);
// Tecnologias contam: o catálogo de TVs mantém "4K", os moderadores tiram.
const VOCABULARY_ROLES = new Set([ROLE.GENERICO, ROLE.TIPO, ROLE.TECNOLOGIA]);

// Contagem de manter/descartar por palavra em todo o repositório. Só conta
// palavras do trecho principal e de parênteses: números soltos e trechos como
// "para iPhone" dependem do contexto e não valem como regra geral.
function learnVocabulary(examples) {
  const vocabulary = new Map();
  const count = (key, kept) => {
    const stats = vocabulary.get(key) || { kept: 0, dropped: 0 };
    if (kept) stats.kept += 1; else stats.dropped += 1;
    vocabulary.set(key, stats);
  };
  for (const example of examples) {
    for (const { token, decision } of learnDecisions(example).tokens) {
      if (!VOCABULARY_SEGMENTS.has(token.segment)) continue;
      if (!VOCABULARY_ROLES.has(token.role)) continue;
      if (NUMBER_RE.test(token.text)) continue;
      count(tokenKey(token), decision.keep);
    }
  }
  return vocabulary;
}

// Linhas de produto buscadas sem a marca: um exemplo "Galaxy S25" da marca
// Samsung ensina que "Samsung Galaxy ..." vira "Galaxy ...", sem afetar
// "Smart TV Samsung ..." nem "Apple Watch ...".
function learnBrandLines(examples) {
  const lines = new Map();
  for (const example of examples) {
    const marca = String(example.marca || '').trim().toLowerCase();
    if (!marca || marca.includes(' ') || keywordWordsOf(example).has(marca)) continue;
    const { tokens } = learnDecisions(example);
    if (tokens.some(({ token }) => tokenKey(token) === marca)) continue;
    const first = tokens.find(({ decision }) => decision.keep);
    if (!first) continue;
    if (!lines.has(marca)) lines.set(marca, new Set());
    lines.get(marca).add(tokenKey(first.token));
  }
  return lines;
}

const DROPPED_SEGMENTS = new Set([
  SEGMENT.FRANQUIA, SEGMENT.VIRGULA, SEGMENT.PARA, SEGMENT.COMBO, SEGMENT.COM, SEGMENT.SUBTITULO,
]);
const HAS_DIGIT_RE = /\d/;

function defaultDecision(token, context) {
  const { inLeadingRun, afterColor } = context;
  if (DROPPED_SEGMENTS.has(token.segment)) return { keep: false };
  if (token.role === ROLE.ORDINAL) return { keep: true, format: 'numero' };
  if (token.role === ROLE.GENERO && CLOTHING.includes(context.previousKey)) return { keep: true, format: 'completo' };
  if (DROPPED_BY_DEFAULT.has(token.role)) return { keep: false };
  if (token.role === ROLE.TIPO && inLeadingRun) return { keep: false };
  // Tipo depois do modelo ("Osmo Pocket 4 Câmera") e "Smart TV" em qualquer
  // posição ("Samsung Smart TV 65\"") só descrevem o produto.
  if (token.role === ROLE.TIPO && (context.afterModel || tokenKey(token) === 'smarttv')) return { keep: false };
  // Parênteses descrevem ("Dobrável", "Com Leitor"); só códigos com número ficam.
  if (token.segment === SEGMENT.PARENTESES && !HAS_DIGIT_RE.test(token.text)) return { keep: false };
  // Palavra desconhecida que fecha o trecho logo depois de uma cor completa a cor
  // ("Laranja Cósmico"); no meio do trecho ela é produto ("Rosa Mosqueta 30ml").
  if (afterColor && context.endsColorPhrase && token.role === ROLE.GENERICO && !HAS_DIGIT_RE.test(token.text)) {
    return { keep: false };
  }
  return { keep: true, format: 'completo' };
}

function decide(token, local, vocabulary, context) {
  const key = tokenKey(token);
  if (local && local.words.has(key)) return local.words.get(key);
  if (local && local.roles.has(token.role)) return local.roles.get(token.role);
  const brandLines = context.brandLines && context.brandLines.get(key);
  if (brandLines && brandLines.has(context.nextKey)) return { keep: false };
  const stats = VOCABULARY_SEGMENTS.has(token.segment) ? vocabulary.get(key) : null;
  if (stats && stats.kept !== stats.dropped) {
    return { keep: stats.kept > stats.dropped, format: 'completo' };
  }
  return defaultDecision(token, context);
}

function render(token, decision) {
  return decision.format === 'numero' ? numericPart(token) || token.text : token.text;
}

// O token fecha o trecho, ou só vem outra cor depois dele ("Cósmico Preto").
function endsColorPhrase(tokens, index) {
  for (let i = index + 1; i < tokens.length && tokens[i].segment === tokens[index].segment; i += 1) {
    if (tokens[i].role !== ROLE.COR) return false;
  }
  return true;
}

function extractKeywords(title, examples = []) {
  const tokens = tokenize(title);
  const match = findBestMatch(tokens, examples);
  const local = match ? learnDecisions(match.example) : null;
  const vocabulary = learnVocabulary(examples);
  const brandLines = learnBrandLines(examples);

  const kept = [];
  let inLeadingRun = true;
  let afterColor = false;
  let previousSegment = null;
  let afterModel = false;
  tokens.forEach((token, i) => {
    if (token.segment !== previousSegment) afterColor = false;
    previousSegment = token.segment;
    const decision = decide(token, local, vocabulary, {
      inLeadingRun: inLeadingRun && token.segment === SEGMENT.PRINCIPAL,
      afterColor,
      brandLines,
      nextKey: tokens[i + 1] ? tokenKey(tokens[i + 1]) : null,
      previousKey: tokens[i - 1] ? tokenKey(tokens[i - 1]) : null,
      afterModel,
      endsColorPhrase: endsColorPhrase(tokens, i),
    });
    if (token.role === ROLE.COR) afterColor = true;
    else if (decision.keep) afterColor = false;
    if (token.segment === SEGMENT.PRINCIPAL && decision.keep) inLeadingRun = false;
    if (token.segment === SEGMENT.PRINCIPAL && decision.keep && HAS_DIGIT_RE.test(token.text)) afterModel = true;
    if (decision.keep) kept.push(render(token, decision));
  });

  if (kept.length === 0) {
    const fallback = tokens.filter((t) => t.role === ROLE.GENERICO || t.role === ROLE.TIPO).map((t) => t.text);
    kept.push(...(fallback.length ? fallback : [cleanTitle(title).trim()]));
  }
  const phrase = kept.join(' ').trim();
  return phrase ? [phrase] : [];
}

const api = { ROLE, SEGMENT, tokenize, classifyToken, jaccardSimilarity, findBestMatch, learnDecisions, extractKeywords };

if (typeof module !== 'undefined' && module.exports) {
  module.exports = api;
} else {
  self.PelandoKW = self.PelandoKW || {};
  Object.assign(self.PelandoKW, api);
}

})();
