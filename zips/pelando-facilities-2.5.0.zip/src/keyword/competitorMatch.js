(function () {
'use strict';

// Promoninja -> concorrente: os botões do ladrão guardam título, preço, loja e
// imagem da nossa promoção e abrem, no concorrente, a busca pelo produto ou a
// página das promoções mais novas; nessa aba, este arquivo destaca o card que
// é a mesma promoção - e nenhum, se não houver certeza.

const STORAGE_KEY = 'pelandoCompetitorMatches';
// Uma busca aberta há mais tempo que isso não é mais destacada.
const MAX_AGE_MS = 30 * 60 * 1000;
const MATCH_CLASS = 'pelando-competitor-match';
const BADGE_CLASS = 'pelando-competitor-match-badge';

// A regra, nesta ordem: a loja tem que ser a mesma; a imagem, pelo menos 60%
// parecida (quando dá para comparar - sem imagem de um dos lados, o card
// passa só com loja e preço); o preço, até 10% para mais ou para menos. Sem
// loja ou preço de um dos lados, nada é destacado. O título só desempata.
const MIN_IMAGE_SIMILARITY = 0.6;
const MAX_PRICE_DIFFERENCE = 0.1;
// A promoção copiada é recente: na busca pelo produto ela está entre os
// primeiros resultados; mais abaixo só há promoções antigas parecidas.
const PRODUCT_SEARCH_RESULTS = 20;
// Quantos cards cada tipo de busca olha (a dos recentes, a página toda).
const RESULT_LIMITS = { product: PRODUCT_SEARCH_RESULTS, recent: Infinity };

// Hotukdeals, dealabs, chollometro e mydealz são da mesma plataforma (Pepper).
// Nos cards expirados o título vira <span> e o preço perde a classe thread-price.
// A imagem só carrega quando o card entra na tela.
const PEPPER = {
  cards: ['article.thread'],
  title: ['.thread-title a', '.thread-link', '.thread-title'],
  price: ['.thread-price', 'span.size--all-xl'],
  store: ['a[data-t="merchantLink"]'],
  image: ['img.thread-image'],
};

// O layout novo (V2) põe a imagem fora do __wrapper, então o card é o bloco
// em volta; o antigo ainda vale onde não houver o novo.
const SLICKDEALS = {
  cards: ['.dealCardListView', '.dealCardListView__wrapper'],
  title: ['.dealCardListViewV2__title', '.dealCardListView__title'],
  price: ['.dealCardListViewV2__finalPrice', '.dealCardListView__finalPrice'],
  store: ['.dealCardListViewV2__store', '.dealCardListView__store'],
  image: ['img.dealCardListViewV2__image', 'img.dealCardListView__image'],
};

const SITES = {
  'hotukdeals.com': PEPPER,
  'dealabs.com': PEPPER,
  'chollometro.com': PEPPER,
  'mydealz.de': PEPPER,
  'slickdeals.net': SLICKDEALS,
};

const FREE_WORDS = /^(free|gratis|gratuit|gratuito|kostenlos|grátis)\b/i;

function normalizeText(text) {
  return String(text || '')
    .normalize('NFD')
    .replace(/[̀-ͯ]/g, '')
    .toLowerCase();
}

// As primeiras `count` palavras do título, sem etiquetas entre colchetes
// ("[Reconditionné]") nem pontuação solta.
function firstWords(title, count) {
  return String(title || '')
    .replace(/\[[^\]]*\]/g, ' ')
    .split(/\s+/)
    .map((word) => word.replace(/^[^\p{L}\p{N}]+|[^\p{L}\p{N}]+$/gu, ''))
    .filter((word) => /[\p{L}\p{N}]/u.test(word))
    .slice(0, count);
}

// "£7.95", "179,99€", "1.299,00 €", "$1,299.99", "R$ 9,84" -> número; "Free" -> 0.
function parsePrice(text) {
  const value = String(text || '').trim();
  if (FREE_WORDS.test(value)) return 0;
  const match = value.match(/\d[\d.,\s]*/);
  if (!match) return null;
  let number = match[0].replace(/\s/g, '').replace(/[.,]$/, '');
  const lastDot = number.lastIndexOf('.');
  const lastComma = number.lastIndexOf(',');
  if (lastDot !== -1 && lastComma !== -1) {
    const decimal = lastDot > lastComma ? '.' : ',';
    const thousands = decimal === '.' ? ',' : '.';
    number = number.split(thousands).join('').replace(decimal, '.');
  } else if (lastDot !== -1 || lastComma !== -1) {
    const separator = lastDot !== -1 ? '.' : ',';
    const parts = number.split(separator);
    // Três dígitos depois do separador (ou vários separadores) = milhar.
    const isThousands = parts.length > 2 || parts[parts.length - 1].length === 3;
    number = isThousands ? parts.join('') : parts.join('.');
  }
  const parsed = Number.parseFloat(number);
  return Number.isFinite(parsed) ? parsed : null;
}

// Nome comparável da loja, a partir do nome ("Media Markt") ou de um link
// ("https://www.amazon.co.uk/..." e "Amazon.es" -> "amazon").
function storeKey(store) {
  let text = String(store || '').trim();
  if (!text) return '';
  if (/^https?:\/\//i.test(text)) {
    try {
      text = new URL(text).hostname;
    } catch (error) {
      return '';
    }
  }
  if (!/\s/.test(text) && text.includes('.')) {
    text = text.replace(/^www\./i, '').split('.')[0];
  }
  return normalizeText(text).replace(/[^a-z0-9]/g, '');
}

function titleTokens(title) {
  return new Set(normalizeText(title).split(/[^a-z0-9]+/).filter(Boolean));
}

// Dice entre as palavras dos dois títulos: 1 = mesmas palavras.
function titleSimilarity(a, b) {
  const left = titleTokens(a);
  const right = titleTokens(b);
  if (left.size === 0 || right.size === 0) return 0;
  let shared = 0;
  left.forEach((token) => {
    if (right.has(token)) shared += 1;
  });
  return (2 * shared) / (left.size + right.size);
}

// Quanto o preço do card se afasta do da promoção, em fração deste (0 = igual).
function priceDifference(cardPrice, dealPrice) {
  if (cardPrice === dealPrice) return 0;
  if (dealPrice === 0) return Infinity;
  return Math.abs(cardPrice - dealPrice) / dealPrice;
}

function siteFor(hostname) {
  return SITES[String(hostname || '').replace(/^www\./, '')] || null;
}

// Liga a busca que abrimos à página em que ela cai (o slickdeals acrescenta parâmetros).
function matchKey(url) {
  try {
    const parsed = new URL(url);
    const query = (parsed.searchParams.get('q') || '').toLowerCase().replace(/\s+/g, ' ').trim();
    return `${parsed.hostname.replace(/^www\./, '')}|${query}`;
  } catch (error) {
    return '';
  }
}

function firstText(card, selectors, read) {
  for (const selector of selectors) {
    for (const element of card.querySelectorAll(selector)) {
      const value = read(element);
      if (value !== null && value !== '') return value;
    }
  }
  return null;
}

function cleanText(element) {
  return element.textContent.replace(/\s+/g, ' ').trim();
}

// Endereço da imagem; as que ainda não carregaram (vazias ou data:) não valem.
function imageUrl(element) {
  const src = element.currentSrc || element.getAttribute('src') || '';
  return /^https?:\/\//i.test(src) ? src : null;
}

// Os cards da primeira forma de card que a página tiver.
function cardElements(doc, site) {
  for (const selector of site.cards) {
    const found = doc.querySelectorAll(selector);
    if (found.length) return [...found];
  }
  return [];
}

function readCards(doc, site) {
  return cardElements(doc, site).map((element) => ({
    element,
    title: firstText(element, site.title, (el) => (el.getAttribute('title') || cleanText(el)).trim()) || '',
    price: firstText(element, site.price, (el) => parsePrice(cleanText(el))),
    store: firstText(element, site.store, cleanText) || '',
    image: firstText(element, site.image, imageUrl) || '',
  }));
}

function dealPrice(deal) {
  const price = typeof deal.price === 'string' ? parsePrice(deal.price) : deal.price;
  return price === undefined ? null : price;
}

// O card passa pela regra? `imageSimilarity` (0..1) vem de rateImages; null
// ou ausente quando a imagem não pôde ser comparada.
function passesRule(card, deal) {
  const price = dealPrice(deal);
  const cardStore = storeKey(card.store);
  if (card.price === null || price === null || !cardStore || cardStore !== storeKey(deal.store)) return false;
  if (priceDifference(card.price, price) > MAX_PRICE_DIFFERENCE) return false;
  const image = card.imageSimilarity;
  return image === null || image === undefined || image >= MIN_IMAGE_SIMILARITY;
}

function imageChecked(card) {
  return card.imageSimilarity !== null && card.imageSimilarity !== undefined;
}

// O card que é a promoção ({ title, price, store }) entre os `limit`
// primeiros, ou null. Um card com a imagem conferida ganha de um sem; entre
// iguais nisso desempata o título, depois o preço mais perto.
function pickBest(cards, deal, limit = Infinity) {
  const valid = cards.slice(0, limit).filter((card) => card.title && passesRule(card, deal));
  const checked = valid.filter(imageChecked);
  const pool = checked.length ? checked : valid;
  const price = dealPrice(deal);
  let best = null;
  for (const card of pool) {
    const entry = {
      card,
      title: titleSimilarity(card.title, deal.title),
      priceDifference: priceDifference(card.price, price),
      imageSimilarity: imageChecked(card) ? card.imageSimilarity : null,
    };
    if (
      !best ||
      entry.title > best.title ||
      (entry.title === best.title && entry.priceDifference < best.priceDifference)
    ) {
      best = entry;
    }
  }
  return best;
}

// Compara a imagem da promoção com a de cada card: `compare(a, b)` devolve
// 0..1 ou null. Guarda o resultado em `card.imageSimilarity`.
async function rateImages(cards, deal, compare) {
  await Promise.all(
    cards.map(async (card) => {
      card.imageSimilarity = deal.image && card.image ? await compare(deal.image, card.image) : null;
    })
  );
  return cards;
}

function badgeText(best) {
  if (best.imageSimilarity === null) return 'Mesma loja e preço (imagem não comparada)';
  return `Mesma loja, preço e imagem (${Math.round(best.imageSimilarity * 100)}%)`;
}

// Marca o card que é a promoção (e só ele). Devolve o card marcado ou null.
// `compare` é o comparador de imagens de rateImages; sem ele, nenhuma imagem
// é comparada.
async function highlightBest(doc, site, deal, limit = Infinity, compare = async () => null) {
  const cards = readCards(doc, site).slice(0, limit);
  await rateImages(cards, deal, compare);
  const best = pickBest(cards, deal);
  if (!best) return null;
  const element = best.card.element;
  const text = badgeText(best);
  const current = element.querySelector(`.${BADGE_CLASS}`);
  if (element.classList.contains(MATCH_CLASS) && current && current.textContent === text) return best.card;
  doc.querySelectorAll(`.${MATCH_CLASS}`).forEach((old) => old.classList.remove(MATCH_CLASS));
  doc.querySelectorAll(`.${BADGE_CLASS}`).forEach((old) => old.remove());
  element.classList.add(MATCH_CLASS);
  const badge = doc.createElement('div');
  badge.className = BADGE_CLASS;
  badge.textContent = text;
  element.insertBefore(badge, element.firstChild);
  return best.card;
}

// `mode`: 'product' (a busca pelo produto) ou 'recent' (as promoções mais novas).
async function saveCompetitorMatch(storage, url, deal, now = Date.now(), mode = 'product') {
  const stored = (await storage.get(STORAGE_KEY))[STORAGE_KEY] || {};
  const kept = {};
  Object.entries(stored).forEach(([key, entry]) => {
    if (entry && now - entry.at <= MAX_AGE_MS) kept[key] = entry;
  });
  kept[matchKey(url)] = {
    at: now,
    mode,
    deal: { title: deal.title || '', price: dealPrice(deal), store: deal.store || '', image: deal.image || '' },
  };
  await storage.set({ [STORAGE_KEY]: kept });
}

// { deal, mode } guardados para a página, ou null.
async function loadCompetitorMatch(storage, url, now = Date.now()) {
  const stored = (await storage.get(STORAGE_KEY))[STORAGE_KEY] || {};
  const entry = stored[matchKey(url)];
  if (!entry || now - entry.at > MAX_AGE_MS) return null;
  return { deal: entry.deal, mode: entry.mode || 'product' };
}

// Usado pelos botões do ladrão (content.js).
function rememberCompetitorSearch(url, deal, mode) {
  return saveCompetitorMatch(chrome.storage.local, url, deal, Date.now(), mode);
}

// Comparador de imagens da página: o service worker baixa as duas e compara
// (a página não lê imagens de outros sites). Uma vez por par.
function serviceWorkerImageCompare() {
  const answers = new Map();
  return (a, b) => {
    const key = JSON.stringify([a, b]);
    if (!answers.has(key)) {
      answers.set(
        key,
        new Promise((resolve) => {
          try {
            chrome.runtime.sendMessage({ type: 'PELANDO_IMAGE_SIMILARITY', a, b }, (response) => {
              if (chrome.runtime.lastError || !response || typeof response.data !== 'number') resolve(null);
              else resolve(response.data);
            });
          } catch (error) {
            resolve(null);
          }
        })
      );
    }
    return answers.get(key);
  };
}

const OBSERVE_DELAY_MS = 200;
// Os cards chegam aos poucos (hidratação, rolagem); depois disso para de observar.
const OBSERVE_FOR_MS = 60 * 1000;

async function bootstrapSearchPage(doc, location) {
  const site = siteFor(location.hostname);
  if (!site) return;
  const match = await loadCompetitorMatch(chrome.storage.local, location.href);
  if (!match) return;
  const limit = RESULT_LIMITS[match.mode] || PRODUCT_SEARCH_RESULTS;
  const compare = serviceWorkerImageCompare();

  // Uma passada por vez; mudanças no meio dela pedem outra no fim.
  let scrolled = false;
  let running = false;
  let again = false;
  const run = async () => {
    if (running) {
      again = true;
      return;
    }
    running = true;
    try {
      const card = await highlightBest(doc, site, match.deal, limit, compare);
      if (card && !scrolled && typeof card.element.scrollIntoView === 'function') {
        scrolled = true;
        card.element.scrollIntoView({ block: 'center', behavior: 'smooth' });
      }
    } catch (error) {
      console.warn('[pelando-keyword-inject] falha ao destacar a promoção no concorrente:', error);
    } finally {
      running = false;
      if (again) {
        again = false;
        run();
      }
    }
  };
  let scheduled = false;
  const observer = new MutationObserver(() => {
    if (scheduled) return;
    scheduled = true;
    setTimeout(() => {
      scheduled = false;
      run();
    }, OBSERVE_DELAY_MS);
  });
  observer.observe(doc.body, { childList: true, subtree: true });
  setTimeout(() => observer.disconnect(), OBSERVE_FOR_MS);
  run();
}

const api = {
  firstWords,
  parsePrice,
  storeKey,
  titleSimilarity,
  matchKey,
  siteFor,
  readCards,
  pickBest,
  rateImages,
  highlightBest,
  saveCompetitorMatch,
  loadCompetitorMatch,
  rememberCompetitorSearch,
  PRODUCT_SEARCH_RESULTS,
};

const isNode = typeof module !== 'undefined' && module.exports;

if (isNode) {
  module.exports = api;
} else {
  self.PelandoKW = self.PelandoKW || {};
  Object.assign(self.PelandoKW, api);
  // Só age nas páginas de busca dos concorrentes, para uma conta Pelando (src/access.js).
  const location = typeof window !== 'undefined' ? window.location : null;
  if (location && siteFor(location.hostname)) {
    self.pelandoWhenAllowed(() => bootstrapSearchPage(document, location));
  }
}

})();
