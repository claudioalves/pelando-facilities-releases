(function () {
'use strict';

const CONFIG_KEY = 'pelandoKeywordConfig';

const DEFAULT_CONFIG = {
  pelandoUrlTemplate: 'https://www.pelando.com.br/busca/{query}',
  googleShoppingUrlTemplate: 'https://www.google.com/search?tbm=shop&q={query}',
  // Painel: 'flutuante' (caixa no canto) ou 'lateral' (encaixado à direita, altura total).
  panelMode: 'flutuante',
  panelWidth: 640,
  panelHeight: 720,
};

function buildQuery(keywords) {
  return keywords
    .flatMap((keyword) => String(keyword).trim().split(/\s+/))
    .filter(Boolean)
    .map((word) => encodeURIComponent(word.toLowerCase()))
    .join('+');
}

function buildSearchUrl(template, keywords) {
  return template.replace('{query}', buildQuery(keywords));
}

// Promoninja: cada país copia as promoções de um site concorrente, e a busca
// vai direto nele. Brasil e Argentina têm equipe própria e ficam de fora.
// `recentUrl`: a página com todas as promoções, da mais nova para a mais
// antiga (no slickdeals, o fórum Hot Deals por data, e não a capa curada).
const COMPETITORS = {
  'promoninja.com': {
    name: 'slickdeals',
    urlTemplate: 'https://slickdeals.net/search?q={query}',
    recentUrl: 'https://slickdeals.net/newsearch.php?searcharea=deals&searchin=first&forumchoice%5B%5D=9&sort=newest',
  },
  'promoninja.co.uk': { name: 'hotukdeals', urlTemplate: 'https://www.hotukdeals.com/search?q={query}', recentUrl: 'https://www.hotukdeals.com/new' },
  'promoninja.fr': { name: 'dealabs', urlTemplate: 'https://www.dealabs.com/search?q={query}', recentUrl: 'https://www.dealabs.com/nouveaux' },
  'promoninja.es': { name: 'chollometro', urlTemplate: 'https://www.chollometro.com/search?q={query}', recentUrl: 'https://www.chollometro.com/nuevos' },
  'promoninja.de': { name: 'mydealz', urlTemplate: 'https://www.mydealz.de/search?q={query}', recentUrl: 'https://www.mydealz.de/new' },
};

function siteDomain(hostname) {
  return String(hostname || '').replace(/^(bo|www)\./, '');
}

function isInternational(hostname) {
  return /^promoninja\./.test(siteDomain(hostname));
}

function competitorFor(hostname) {
  return COMPETITORS[siteDomain(hostname)] || null;
}

async function getConfig() {
  const stored = await chrome.storage.local.get(CONFIG_KEY);
  return { ...DEFAULT_CONFIG, ...(stored[CONFIG_KEY] || {}) };
}

async function setConfig(partial) {
  const current = await getConfig();
  const next = { ...current, ...partial };
  await chrome.storage.local.set({ [CONFIG_KEY]: next });
  return next;
}

const api = { DEFAULT_CONFIG, COMPETITORS, buildQuery, buildSearchUrl, isInternational, competitorFor, getConfig, setConfig };

if (typeof module !== 'undefined' && module.exports) {
  module.exports = api;
} else {
  self.PelandoKW = self.PelandoKW || {};
  Object.assign(self.PelandoKW, api);
}

})();
