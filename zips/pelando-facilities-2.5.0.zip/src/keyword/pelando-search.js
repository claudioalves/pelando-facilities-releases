(function () {
'use strict';

// Roda em www.pelando.com.br/busca/*: o site não preenche a caixa de busca a
// partir da URL, então copiamos o termo buscado para ela.

const SEARCH_INPUT_SELECTOR = 'input[data-headerv2-search-input]';

function queryFromPath(pathname) {
  const match = /^\/busca\/([^/]+)/.exec(pathname || '');
  if (!match) return null;
  try {
    const query = decodeURIComponent(match[1].replace(/\+/g, ' ')).trim();
    return query || null;
  } catch (error) {
    return null;
  }
}

// Usa o setter nativo e dispara "input" para que o framework da página
// reconheça o valor como digitado.
function setInputValue(input, value) {
  const view = input.ownerDocument.defaultView;
  const setter = Object.getOwnPropertyDescriptor(view.HTMLInputElement.prototype, 'value').set;
  setter.call(input, value);
  input.dispatchEvent(new view.Event('input', { bubbles: true }));
}

function fillSearchInputs(doc, query) {
  let filled = 0;
  doc.querySelectorAll(SEARCH_INPUT_SELECTOR).forEach((input) => {
    if (input.value || input === doc.activeElement) return;
    setInputValue(input, query);
    filled += 1;
  });
  return filled;
}

// A caixa pode ser renderizada (ou re-renderizada vazia) depois do carregamento;
// observa a página por um tempo curto e preenche caixas vazias que surgirem.
function startSearchPrefill(doc, location, { timeoutMs = 5000 } = {}) {
  const query = queryFromPath(location.pathname);
  if (!query) return () => {};
  fillSearchInputs(doc, query);
  const observer = new MutationObserver(() => fillSearchInputs(doc, query));
  observer.observe(doc.body, { childList: true, subtree: true });
  const timer = setTimeout(() => observer.disconnect(), timeoutMs);
  return () => {
    clearTimeout(timer);
    observer.disconnect();
  };
}

const api = { queryFromPath, fillSearchInputs, startSearchPrefill };

if (typeof module !== 'undefined' && module.exports) {
  module.exports = api;
} else {
  // Starts only for a Pelando account (see src/access.js).
  self.pelandoWhenAllowed(() => {
    try {
      startSearchPrefill(document, window.location);
    } catch (error) {
      console.error('[pelando-keyword-inject] falha ao preencher a busca do Pelando:', error);
    }
  });
}

})();
