(function () {
'use strict';

function buildExportJson(examples, now = new Date()) {
  return JSON.stringify({
    exportadoEm: now.toISOString(),
    total: examples.length,
    exemplos: examples,
  }, null, 2);
}

function uniqueCategories(examples) {
  const seen = new Map();
  for (const example of examples) {
    const categoria = (example.categoria || '').trim();
    if (categoria && !seen.has(categoria.toLowerCase())) seen.set(categoria.toLowerCase(), categoria);
  }
  return [...seen.values()];
}

// BO marca o modo escuro com html.dark; o Pelando usa html.dark/.light,
// data-theme ou, no tema automático, a preferência do sistema.
function detectTheme(doc) {
  const root = doc.documentElement;
  const dataTheme = root.getAttribute('data-theme');
  if (root.classList.contains('dark') || dataTheme === 'dark') return 'dark';
  if (root.classList.contains('light') || dataTheme === 'light') return 'light';
  const view = doc.defaultView;
  if (view && view.location && view.location.hostname === 'bo.pelando.com.br') return 'light';
  const prefersDark = view && view.matchMedia && view.matchMedia('(prefers-color-scheme: dark)').matches;
  return prefersDark ? 'dark' : 'light';
}

// Tipografia e cinzas do Pelando (DM Sans, Coal/Black/Graphite); destaque em carmesim #dc143c, a cor dos ícones.
const STYLES = `
  :host { all: initial; }
  [hidden] { display: none !important; }
  .pelando-kw-panel {
    --accent: #dc143c; --accent-hover: #e8395a; --on-accent: #ffffff;
    --bg: #ffffff; --surface: #faf8f5; --field: #ffffff; --border: #e9eaed;
    --text: #1a1a1a; --muted: #6b6b6b; --danger: #d93a00; --chip-on: #fde8ec;
    position: fixed; top: 72px; right: 24px; z-index: 999999;
    width: min(var(--panel-width, 640px), calc(100vw - 32px));
    max-height: min(var(--panel-height, 720px), calc(100vh - 96px));
    display: flex; flex-direction: column; box-sizing: border-box;
    font-family: 'DM Sans', Helvetica, Arial, sans-serif; font-size: 14px; line-height: 1.4;
    color: var(--text); background: var(--bg); border: 1px solid var(--border);
    border-radius: 16px; box-shadow: 0 12px 40px rgba(0, 0, 0, .25); overflow: hidden;
  }
  .pelando-kw-panel[data-theme="dark"] {
    --bg: #222222; --surface: #1a1a1a; --field: #1a1a1a; --border: #333333;
    --text: #faf8f5; --muted: #999999; --danger: #ff9574; --chip-on: #3a1018;
  }
  /* Janela ao lado: encaixada na borda direita, altura total da tela. */
  .pelando-kw-panel[data-mode="lateral"] {
    top: 0; right: 0; height: 100vh; max-height: 100vh;
    width: min(var(--panel-width, 640px), 100vw);
    border-width: 0 0 0 1px; border-radius: 0; box-shadow: -8px 0 32px rgba(0, 0, 0, .25);
  }
  * { box-sizing: border-box; font-family: inherit; }
  header { flex: none; display: flex; align-items: center; justify-content: space-between; gap: 12px;
    padding: 16px 20px; border-bottom: 1px solid var(--border); }
  h2 { margin: 0; font-size: 18px; font-weight: 700; }
  h3 { margin: 0; font-size: 14px; font-weight: 700; }
  .body { flex: 1 1 auto; min-height: 0; padding: 16px 20px 20px; overflow-y: auto;
    display: flex; flex-direction: column; gap: 16px; }
  /* Sem encolher: quem rola é o corpo do painel, não a lista de exemplos. */
  .body > * { flex: none; }
  .promo { background: var(--surface); border: 1px solid var(--border); border-radius: 12px; padding: 10px 12px; }
  .promo small, .field label, .hint { color: var(--muted); font-size: 12px; }
  .promo p { margin: 2px 0 0; font-weight: 700; }
  .field { display: grid; gap: 6px; }
  .field label { font-weight: 700; text-transform: uppercase; letter-spacing: .02em; }
  input[type="text"], textarea {
    width: 100%; padding: 10px 12px; font-size: 14px; color: var(--text);
    background: var(--field); border: 1px solid var(--border); border-radius: 8px; outline: none; }
  input[type="text"]:focus, textarea:focus { border-color: var(--accent); box-shadow: 0 0 0 3px rgba(220, 20, 60, .2); }
  textarea { min-height: 60px; resize: vertical; }
  .keywords-input { font-size: 16px; font-weight: 700; }
  button { cursor: pointer; font-size: 14px; font-weight: 700; border-radius: 999px; }
  .primary { align-self: flex-start; padding: 10px 20px; border: 0; color: var(--on-accent); background: var(--accent); }
  .primary:hover { background: var(--accent-hover); }
  .secondary { padding: 6px 14px; color: var(--text); background: transparent; border: 1px solid var(--border); }
  .secondary:hover { border-color: var(--accent); color: var(--accent); }
  .icon-button { display: inline-flex; align-items: center; justify-content: center; flex: none;
    width: 32px; height: 32px; padding: 0; border-radius: 6px; background: transparent;
    border: 1px solid var(--border); }
  .icon-button:hover { border-color: #dc143c; background: color-mix(in srgb, #dc143c 12%, transparent); }
  .icon-button:focus-visible { outline: 2px solid #dc143c; outline-offset: 1px; }
  .icon { display: block; width: 16px; height: 16px; background-color: #dc143c;
    -webkit-mask-size: contain; mask-size: contain; -webkit-mask-repeat: no-repeat; mask-repeat: no-repeat;
    -webkit-mask-position: center; mask-position: center; }
  .header-actions { display: flex; gap: 8px; }
  .title-group { display: flex; align-items: center; gap: 10px; min-width: 0; }
  .grip { display: inline-flex; flex: none; padding: 6px 4px; color: #dc143c; cursor: grab;
    border-radius: 6px; touch-action: none; }
  .grip:hover { background: color-mix(in srgb, #dc143c 12%, transparent); }
  .grip:focus-visible { outline: 2px solid #dc143c; outline-offset: 1px; }
  .pelando-kw-panel.dragging, .pelando-kw-panel.dragging .grip { cursor: grabbing; user-select: none; }
  .pelando-kw-panel[data-mode="lateral"] .grip { display: none; }
  .close { font-size: 20px; font-weight: 400; line-height: 1; color: #dc143c; }
  .definicoes { display: grid; gap: 12px; padding: 12px 16px; background: var(--surface);
    border: 1px solid var(--border); border-radius: 12px; }
  .modes { display: flex; gap: 16px; }
  .modes label { display: inline-flex; align-items: center; gap: 6px; font-size: 14px; font-weight: 400;
    text-transform: none; letter-spacing: 0; color: var(--text); cursor: pointer; }
  .modes input { margin: 0; accent-color: var(--accent); }
  .sizes { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; }
  input[type="number"] { width: 100%; padding: 10px 12px; font-size: 14px; color: var(--text);
    background: var(--field); border: 1px solid var(--border); border-radius: 8px; outline: none; }
  input[type="number"]:focus { border-color: var(--accent); box-shadow: 0 0 0 3px rgba(220, 20, 60, .2); }
  input[type="number"]:disabled { opacity: .5; }
  .definicoes .primary { justify-self: start; }
  .erro { margin: 0; color: var(--danger); font-size: 13px; }
  .status { margin: 0; color: var(--muted); font-size: 13px; }
  .sucesso { margin: 0; padding: 8px 12px; font-size: 13px; font-weight: 700; color: #1f7a3a;
    background: #d6f3df; border-radius: 8px; }
  .pelando-kw-panel[data-theme="dark"] .sucesso { color: #70e291; background: #173322; }
  .primary:disabled { opacity: .6; cursor: progress; }
  .pelando-kw-categorias { display: flex; flex-wrap: wrap; gap: 6px; }
  .pelando-kw-categorias:empty { display: none; }
  .pelando-kw-categorias label { display: inline-flex; align-items: center; padding: 4px 12px;
    font-size: 13px; font-weight: 400; text-transform: none; letter-spacing: 0; color: var(--text);
    border: 1px solid var(--border); border-radius: 999px; cursor: pointer; }
  .pelando-kw-categorias label:has(input:checked) { border-color: var(--accent); background: var(--chip-on); color: var(--accent); font-weight: 700; }
  .pelando-kw-categorias input { position: absolute; opacity: 0; pointer-events: none; }
  .section-head { display: flex; align-items: center; justify-content: space-between; gap: 8px; }
  .actions { display: flex; gap: 8px; }
  .count { margin-left: 6px; padding: 1px 8px; font-size: 12px; color: var(--on-accent); background: var(--accent); border-radius: 999px; }
  ul { list-style: none; margin: 0; padding: 0; max-height: 280px; overflow-y: auto;
    border: 1px solid var(--border); border-radius: 12px; }
  ul:empty { display: none; }
  li { display: flex; align-items: center; gap: 8px; padding: 8px 12px; border-bottom: 1px solid var(--border); }
  li:last-child { border-bottom: 0; }
  li .info { flex: 1; min-width: 0; }
  li strong { display: block; }
  li small { display: block; color: var(--muted); font-size: 12px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
`;

const TEMPLATE = `
  <header>
    <div class="title-group">
      <span class="grip" data-role="grip" role="button" tabindex="0" hidden title="Arrastar para mover"
        aria-label="Arrastar para mover"><svg width="12" height="18" viewBox="0 0 12 18" fill="currentColor"
        aria-hidden="true"><circle cx="3" cy="3" r="1.6"/><circle cx="9" cy="3" r="1.6"/><circle cx="3" cy="9" r="1.6"/><circle cx="9" cy="9" r="1.6"/><circle cx="3" cy="15" r="1.6"/><circle cx="9" cy="15" r="1.6"/></svg></span>
      <h2 data-role="cabecalho">Adicionar palavras-chave</h2>
    </div>
    <div class="header-actions">
      <button type="button" class="icon-button" data-role="abrir-definicoes" aria-label="Definições"
        title="Definições" aria-expanded="false"><span class="icon"></span></button>
      <button type="button" class="icon-button close" data-role="fechar" aria-label="Fechar" title="Fechar">×</button>
    </div>
  </header>
  <div class="body">
    <section class="definicoes" data-role="definicoes" hidden>
      <h3>Definições</h3>
      <div class="field">
        <label>Modo</label>
        <div class="modes">
          <label><input type="radio" name="pelando-kw-modo" value="flutuante" data-role="modo-flutuante"> Flutuante</label>
          <label><input type="radio" name="pelando-kw-modo" value="lateral" data-role="modo-lateral"> Janela ao lado</label>
        </div>
      </div>
      <div class="sizes">
        <div class="field">
          <label for="kw-largura">Largura (px)</label>
          <input type="number" id="kw-largura" data-role="largura-input" step="10">
        </div>
        <div class="field">
          <label for="kw-altura">Altura (px)</label>
          <input type="number" id="kw-altura" data-role="altura-input" step="10">
        </div>
      </div>
      <span class="hint" data-role="limites"></span>
      <div class="field">
        <label for="kw-url-pelando">URL Pelando (use {query} no lugar das palavras-chave)</label>
        <input type="text" id="kw-url-pelando" data-role="pelando-template-input" placeholder="https://www.pelando.com.br/busca/{query}">
      </div>
      <div class="field">
        <label for="kw-url-google">URL Google Shopping</label>
        <input type="text" id="kw-url-google" data-role="google-template-input" placeholder="https://www.google.com/search?tbm=shop&q={query}">
      </div>
      <button type="button" class="primary" data-role="salvar-config">Salvar definições</button>
      <p class="status" data-role="status-config" hidden></p>
      <p class="erro" data-role="erro-config" hidden></p>
    </section>
    <div class="promo">
      <small>Promoção</small>
      <p data-role="titulo"></p>
    </div>
    <div class="field">
      <label for="kw-keywords">Palavras-chave</label>
      <input type="text" id="kw-keywords" class="keywords-input" data-role="keywords-input" placeholder="ex: iPhone 17 256">
      <span class="hint">Escreva como você buscaria no Pelando.</span>
    </div>
    <div class="field">
      <label for="kw-categoria">Categoria</label>
      <div data-role="categorias" class="pelando-kw-categorias"></div>
      <input type="text" id="kw-categoria" data-role="categoria-input" placeholder="Escolha acima ou digite uma nova">
    </div>
    <div class="field">
      <label for="kw-dica">Dica (opcional)</label>
      <textarea id="kw-dica" data-role="dica-input" placeholder="O que ajuda em extrações futuras"></textarea>
    </div>
    <button type="button" class="primary" data-role="salvar">Salvar exemplo</button>
    <p class="erro" data-role="erro" hidden></p>
    <p class="sucesso" data-role="sucesso" role="status" hidden></p>
    <div class="section-head">
      <h3>Exemplos cadastrados<span class="count" data-role="contagem">0</span></h3>
      <div class="actions">
        <button type="button" class="secondary" data-role="importar">Importar JSON</button>
        <button type="button" class="secondary" data-role="exportar">Exportar JSON</button>
        <input type="file" accept="application/json,.json" data-role="importar-arquivo" hidden>
      </div>
    </div>
    <p class="status" data-role="status-export" hidden></p>
    <ul data-role="lista"></ul>
  </div>
`;

// Tamanho do painel em px. A altura só vale no modo flutuante; o CSS ainda
// limita os dois à tela visível.
const PANEL_LIMITS = {
  width: { min: 480, max: 960, default: 640 },
  height: { min: 420, max: 1000, default: 720 },
};

function clampValue(value, { min, max, default: fallback }) {
  const number = Math.round(Number(value));
  if (value === '' || value === null || value === undefined || !Number.isFinite(number)) return fallback;
  return Math.min(max, Math.max(min, number));
}

function clampPanelSize({ width, height }) {
  return {
    width: clampValue(width, PANEL_LIMITS.width),
    height: clampValue(height, PANEL_LIMITS.height),
  };
}

function iconUrl(file) {
  // getURL lança "Extension context invalidated" se a extensão foi atualizada com a aba aberta.
  try {
    return chrome.runtime.getURL(`src/keyword/icons/${file}`);
  } catch (error) {
    return `src/keyword/icons/${file}`;
  }
}

function createPanel(doc, deps) {
  const host = doc.createElement('div');
  host.setAttribute('data-pelando-kw-panel-host', 'true');
  const shadow = host.attachShadow({ mode: 'open' });

  const style = doc.createElement('style');
  style.textContent = STYLES;

  const panel = doc.createElement('div');
  panel.className = 'pelando-kw-panel';
  panel.setAttribute('role', 'dialog');
  panel.setAttribute('aria-label', 'Adicionar palavras-chave');
  panel.hidden = true;
  panel.innerHTML = TEMPLATE;

  shadow.appendChild(style);
  shadow.appendChild(panel);

  const $ = (role) => shadow.querySelector(`[data-role="${role}"]`);

  let currentTitle = '';
  let editingId = null;
  let editingTitulo = null;

  function clearForm() {
    $('keywords-input').value = '';
    $('categoria-input').value = '';
    $('dica-input').value = '';
    syncCategoryRadios();
  }

  const gearIcon = shadow.querySelector('[data-role="abrir-definicoes"] .icon');
  const gearUrl = iconUrl('definicoes.png');
  gearIcon.setAttribute('style', `-webkit-mask-image: url("${gearUrl}"); mask-image: url("${gearUrl}");`);

  for (const [role, limits] of [['largura-input', PANEL_LIMITS.width], ['altura-input', PANEL_LIMITS.height]]) {
    $(role).min = String(limits.min);
    $(role).max = String(limits.max);
  }
  $('limites').textContent = `Largura de ${PANEL_LIMITS.width.min} a ${PANEL_LIMITS.width.max} px; `
    + `altura de ${PANEL_LIMITS.height.min} a ${PANEL_LIMITS.height.max} px (só no modo flutuante).`;

  function selectedMode() {
    return $('modo-lateral').checked ? 'lateral' : 'flutuante';
  }

  // Posição do modo flutuante (px a partir do canto superior esquerdo); null
  // mantém o canto padrão definido no CSS.
  let position = null;
  const HEADER_VISIBLE_PX = 56;
  const NUDGE_PX = 20;

  function clampPosition({ left, top }) {
    const view = doc.defaultView;
    const rect = panel.getBoundingClientRect();
    return {
      left: Math.round(Math.min(Math.max(0, left), Math.max(0, view.innerWidth - rect.width))),
      top: Math.round(Math.min(Math.max(0, top), Math.max(0, view.innerHeight - HEADER_VISIBLE_PX))),
    };
  }

  function applyPosition(mode) {
    if (mode === 'lateral' || !position) {
      panel.style.left = '';
      panel.style.top = '';
      panel.style.right = '';
      return;
    }
    panel.style.left = `${position.left}px`;
    panel.style.top = `${position.top}px`;
    panel.style.right = 'auto';
  }

  function savePosition() {
    Promise.resolve(deps.setConfig({ panelLeft: position.left, panelTop: position.top })).catch((error) => {
      console.error('[pelando-keyword-inject] falha ao salvar a posição do painel:', error);
    });
  }

  let dragOffset = null;

  function onDragMove(event) {
    position = clampPosition({ left: event.clientX - dragOffset.x, top: event.clientY - dragOffset.y });
    applyPosition('flutuante');
  }

  function onDragEnd() {
    doc.removeEventListener('mousemove', onDragMove);
    doc.removeEventListener('mouseup', onDragEnd);
    panel.classList.remove('dragging');
    dragOffset = null;
    if (position) savePosition();
  }

  $('grip').addEventListener('mousedown', (event) => {
    if (event.button !== 0 || !canDrag()) return;
    event.preventDefault();
    const rect = panel.getBoundingClientRect();
    dragOffset = { x: event.clientX - rect.left, y: event.clientY - rect.top };
    panel.classList.add('dragging');
    doc.addEventListener('mousemove', onDragMove);
    doc.addEventListener('mouseup', onDragEnd);
  });

  const NUDGES = { ArrowLeft: [-1, 0], ArrowRight: [1, 0], ArrowUp: [0, -1], ArrowDown: [0, 1] };

  $('grip').addEventListener('keydown', (event) => {
    const nudge = NUDGES[event.key];
    if (!nudge || !canDrag()) return;
    event.preventDefault();
    const rect = panel.getBoundingClientRect();
    const base = position || { left: rect.left, top: rect.top };
    position = clampPosition({ left: base.left + nudge[0] * NUDGE_PX, top: base.top + nudge[1] * NUDGE_PX });
    applyPosition('flutuante');
    savePosition();
  });

  function applyLayout({ mode, width, height }) {
    panel.dataset.mode = mode;
    applyPosition(mode);
    panel.style.setProperty('--panel-width', `${width}px`);
    panel.style.setProperty('--panel-height', `${height}px`);
    $('altura-input').disabled = mode === 'lateral';
  }

  function previewLayout() {
    applyLayout({ mode: selectedMode(), ...clampPanelSize({ width: $('largura-input').value, height: $('altura-input').value }) });
  }

  $('modo-flutuante').addEventListener('change', previewLayout);
  $('modo-lateral').addEventListener('change', previewLayout);
  $('largura-input').addEventListener('change', previewLayout);
  $('altura-input').addEventListener('change', previewLayout);

  // O grip só existe enquanto as definições estão abertas.
  function setSettingsOpen(open) {
    $('definicoes').hidden = !open;
    $('grip').hidden = !open;
    $('abrir-definicoes').setAttribute('aria-expanded', String(open));
  }

  const canDrag = () => !$('definicoes').hidden && panel.dataset.mode !== 'lateral';

  $('abrir-definicoes').addEventListener('click', () => setSettingsOpen($('definicoes').hidden));

  async function refreshConfigFields() {
    const config = await deps.getConfig();
    $('pelando-template-input').value = config.pelandoUrlTemplate;
    $('google-template-input').value = config.googleShoppingUrlTemplate;
    const mode = config.panelMode === 'lateral' ? 'lateral' : 'flutuante';
    const size = clampPanelSize({ width: config.panelWidth, height: config.panelHeight });
    $('modo-lateral').checked = mode === 'lateral';
    $('modo-flutuante').checked = mode === 'flutuante';
    $('largura-input').value = String(size.width);
    $('altura-input').value = String(size.height);
    const saved = { left: Number(config.panelLeft), top: Number(config.panelTop) };
    const hasPosition = config.panelLeft != null && config.panelTop != null
      && Number.isFinite(saved.left) && Number.isFinite(saved.top);
    position = hasPosition ? clampPosition(saved) : null;
    applyLayout({ mode, ...size });
  }

  function adjustmentNote(label, raw, value, limits) {
    const number = Math.round(Number(raw));
    if (raw === '' || !Number.isFinite(number)) return `${label} inválida; usando ${value} px.`;
    if (number > limits.max) return `${label} ajustada para ${value} px (máximo).`;
    if (number < limits.min) return `${label} ajustada para ${value} px (mínimo).`;
    return null;
  }

  function renderCategories(examples) {
    const container = $('categorias');
    const categoriaInput = $('categoria-input');
    container.innerHTML = '';
    // Lista padrão primeiro; depois categorias personalizadas já cadastradas.
    const standard = (deps.extraCategories || []).map((categoria) => ({ categoria }));
    for (const categoria of uniqueCategories([...standard, ...examples])) {
      const label = doc.createElement('label');
      const radio = doc.createElement('input');
      radio.type = 'radio';
      radio.name = 'pelando-kw-categoria';
      radio.value = categoria;
      radio.checked = categoriaInput.value.trim().toLowerCase() === categoria.toLowerCase();
      radio.addEventListener('change', () => {
        if (radio.checked) categoriaInput.value = categoria;
      });
      label.appendChild(radio);
      label.appendChild(doc.createTextNode(categoria));
      container.appendChild(label);
    }
  }

  function syncCategoryRadios() {
    const value = $('categoria-input').value.trim().toLowerCase();
    shadow.querySelectorAll('[data-role="categorias"] input[type="radio"]').forEach((radio) => {
      radio.checked = radio.value.toLowerCase() === value;
    });
  }

  $('categoria-input').addEventListener('input', syncCategoryRadios);

  function iconButton(label, file) {
    const button = doc.createElement('button');
    button.type = 'button';
    button.className = 'icon-button';
    button.title = label;
    button.setAttribute('aria-label', label);
    const icon = doc.createElement('span');
    icon.className = 'icon';
    const url = iconUrl(file);
    icon.setAttribute('style', `-webkit-mask-image: url("${url}"); mask-image: url("${url}");`);
    button.appendChild(icon);
    return button;
  }

  function renderExample(example) {
    const item = doc.createElement('li');
    const info = doc.createElement('div');
    info.className = 'info';
    const keywords = doc.createElement('strong');
    keywords.textContent = (example.keywords || []).join(', ');
    const meta = doc.createElement('small');
    meta.textContent = [example.categoria || 'Sem categoria', example.titulo].filter(Boolean).join(' · ');
    meta.title = meta.textContent;
    info.appendChild(keywords);
    info.appendChild(meta);

    const editButton = iconButton('Editar', 'lapis.png');
    editButton.addEventListener('click', () => {
      editingId = example.id;
      editingTitulo = example.titulo;
      $('titulo').textContent = example.titulo || '';
      $('keywords-input').value = (example.keywords || []).join(', ');
      $('categoria-input').value = example.categoria || '';
      $('dica-input').value = example.dica || '';
      syncCategoryRadios();
    });

    const removeButton = iconButton('Excluir', 'lixeira-xmark.png');
    removeButton.addEventListener('click', async () => {
      const erro = $('erro');
      try {
        await deps.deleteExample(example.id);
        if (editingId === example.id) {
          editingId = null;
          editingTitulo = null;
          $('titulo').textContent = currentTitle;
          clearForm();
        }
        erro.hidden = true;
        await refreshList();
      } catch (error) {
        erro.textContent = `Não foi possível excluir: ${error.message}`;
        erro.hidden = false;
      }
    });

    item.appendChild(info);
    item.appendChild(editButton);
    item.appendChild(removeButton);
    return item;
  }

  async function refreshList() {
    const lista = $('lista');
    let examples;
    try {
      examples = await deps.getExamples();
    } catch (error) {
      const erro = $('erro');
      erro.textContent = `Não foi possível carregar os exemplos: ${error.message}`;
      erro.hidden = false;
      return;
    }
    renderCategories(examples);
    $('contagem').textContent = String(examples.length);
    lista.innerHTML = '';
    for (const example of newestFirst(examples)) lista.appendChild(renderExample(example));
  }

  // Do mais novo para o mais velho; sem data (exemplos antigos) vão para o fim.
  function newestFirst(examples) {
    const time = (example) => Date.parse(example.criadoEm) || 0;
    return [...examples].sort((a, b) => time(b) - time(a));
  }

  function sameTitle(a, b) {
    const key = (text) => String(text || '').trim().replace(/\s+/g, ' ').toLowerCase();
    return key(a) !== '' && key(a) === key(b);
  }

  let saving = false;

  $('salvar').addEventListener('click', async () => {
    // Um segundo clique enquanto o primeiro ainda grava não cria outro exemplo.
    if (saving) return;
    const erro = $('erro');
    const sucesso = $('sucesso');
    erro.hidden = true;
    sucesso.hidden = true;
    // Vírgula decimal ("Whiskas 2,7") não separa palavras-chave.
    const keywords = $('keywords-input').value.split(/(?<!\d),|,(?!\d)/).map((k) => k.trim()).filter(Boolean);
    if (!keywords.length) {
      erro.textContent = 'Palavras-chave são obrigatórias';
      erro.hidden = false;
      return;
    }
    const payload = {
      categoria: $('categoria-input').value.trim(),
      titulo: editingId ? editingTitulo : currentTitle,
      keywords,
      dica: $('dica-input').value.trim(),
    };
    saving = true;
    $('salvar').disabled = true;
    try {
      let message;
      if (editingId) {
        await deps.updateExample(editingId, payload);
        message = 'Exemplo atualizado com sucesso.';
      } else {
        // A mesma promoção já tem exemplo: atualiza em vez de duplicar.
        const existing = (await deps.getExamples()).find((example) => sameTitle(example.titulo, payload.titulo));
        if (existing) {
          await deps.updateExample(existing.id, payload);
          message = 'Esta promoção já tinha um exemplo; ele foi atualizado.';
        } else {
          await deps.addExample(payload);
          message = 'Exemplo cadastrado com sucesso.';
        }
      }
      editingId = null;
      editingTitulo = null;
      $('titulo').textContent = currentTitle;
      clearForm();
      await refreshList();
      sucesso.textContent = message;
      sucesso.hidden = false;
    } catch (error) {
      erro.textContent = `Não foi possível salvar: ${error.message}`;
      erro.hidden = false;
    } finally {
      saving = false;
      $('salvar').disabled = false;
    }
  });

  $('salvar-config').addEventListener('click', async () => {
    const erroConfig = $('erro-config');
    const statusConfig = $('status-config');
    erroConfig.hidden = true;
    statusConfig.hidden = true;
    const pelandoTemplate = $('pelando-template-input').value.trim();
    const googleTemplate = $('google-template-input').value.trim();
    if (!pelandoTemplate.includes('{query}') || !googleTemplate.includes('{query}')) {
      erroConfig.textContent = 'Cada URL precisa conter o marcador {query}.';
      erroConfig.hidden = false;
      return;
    }
    const raw = { width: $('largura-input').value, height: $('altura-input').value };
    const size = clampPanelSize(raw);
    const mode = selectedMode();
    const notes = [
      adjustmentNote('Largura', raw.width, size.width, PANEL_LIMITS.width),
      adjustmentNote('Altura', raw.height, size.height, PANEL_LIMITS.height),
    ].filter(Boolean);
    $('largura-input').value = String(size.width);
    $('altura-input').value = String(size.height);
    try {
      await deps.setConfig({
        pelandoUrlTemplate: pelandoTemplate,
        googleShoppingUrlTemplate: googleTemplate,
        panelMode: mode,
        panelWidth: size.width,
        panelHeight: size.height,
      });
      applyLayout({ mode, ...size });
      statusConfig.textContent = [...notes, 'Definições salvas.'].join(' ');
      statusConfig.hidden = false;
    } catch (error) {
      erroConfig.textContent = `Não foi possível salvar: ${error.message}`;
      erroConfig.hidden = false;
    }
  });

  $('exportar').addEventListener('click', async () => {
    const status = $('status-export');
    try {
      const examples = await deps.getExamples();
      const view = doc.defaultView;
      const blob = new view.Blob([buildExportJson(examples)], { type: 'application/json' });
      const url = view.URL.createObjectURL(blob);
      const link = doc.createElement('a');
      link.href = url;
      link.download = `pelando-exemplos-${new Date().toISOString().slice(0, 10)}.json`;
      doc.body.appendChild(link);
      link.click();
      link.remove();
      view.URL.revokeObjectURL(url);
      status.className = 'status';
      status.textContent = `${examples.length} ${examples.length === 1 ? 'exemplo exportado' : 'exemplos exportados'}.`;
    } catch (error) {
      status.className = 'erro';
      status.textContent = `Não foi possível exportar: ${error.message}`;
    }
    status.hidden = false;
  });

  function readFileText(file) {
    return new Promise((resolve, reject) => {
      const reader = new doc.defaultView.FileReader();
      reader.onload = () => resolve(reader.result);
      reader.onerror = () => reject(reader.error);
      reader.readAsText(file);
    });
  }

  const plural = (n, singular, pluralForm) => `${n} ${n === 1 ? singular : pluralForm}`;

  $('importar').addEventListener('click', () => $('importar-arquivo').click());

  $('importar-arquivo').addEventListener('change', async () => {
    const input = $('importar-arquivo');
    const status = $('status-export');
    const [file] = input.files || [];
    if (!file) return;
    try {
      const data = JSON.parse(await readFileText(file));
      const incoming = Array.isArray(data) ? data : data && data.exemplos;
      if (!Array.isArray(incoming)) throw new Error('O arquivo não é uma exportação de exemplos.');
      const result = await deps.importExamples(incoming);
      status.className = 'status';
      status.textContent = [
        plural(result.atualizados, 'atualizado', 'atualizados'),
        plural(result.adicionados, 'adicionado', 'adicionados'),
        result.ignorados ? plural(result.ignorados, 'ignorado', 'ignorados') : null,
      ].filter(Boolean).join(', ') + '.';
      await refreshList();
    } catch (error) {
      status.className = 'erro';
      status.textContent = error instanceof SyntaxError
        ? 'O arquivo não é uma exportação de exemplos (JSON inválido).'
        : `Não foi possível importar: ${error.message}`;
    }
    status.hidden = false;
    input.value = '';
  });

  // Esc fecha o painel mesmo com o foco fora dele (na página).
  function onEscape(event) {
    if (event.key === 'Escape') closePanel();
  }

  function closePanel() {
    panel.hidden = true;
    doc.removeEventListener('keydown', onEscape, true);
  }

  $('fechar').addEventListener('click', closePanel);

  return {
    root: host,
    async open({ title, keywords }) {
      currentTitle = title;
      editingId = null;
      editingTitulo = null;
      panel.dataset.theme = detectTheme(doc);
      $('titulo').textContent = title || '';
      $('keywords-input').value = keywords.join(', ');
      $('categoria-input').value = '';
      $('dica-input').value = '';
      $('status-export').hidden = true;
      $('sucesso').hidden = true;
      $('erro').hidden = true;
      setSettingsOpen(false);
      panel.hidden = false;
      doc.addEventListener('keydown', onEscape, true);
      await refreshList();
      await refreshConfigFields();
      $('keywords-input').focus();
    },
    close: closePanel,
  };
}

const api = { createPanel, buildExportJson, detectTheme, PANEL_LIMITS, clampPanelSize };

if (typeof module !== 'undefined' && module.exports) {
  module.exports = api;
} else {
  self.PelandoKW = self.PelandoKW || {};
  Object.assign(self.PelandoKW, api);
}

})();
