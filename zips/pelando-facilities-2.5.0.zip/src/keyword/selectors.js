(function () {
'use strict';

function findTitleInput(root = document) {
  return root.querySelector('input[name="title"]');
}

function findPriceInput(root = document) {
  return root.querySelector('input[name="price"]');
}

function findSourceUrlField(root = document) {
  return root.querySelector('textarea[name="sourceUrl"]');
}

// O "Link da imagem" da página da promoção do backoffice.
function findImageInput(root = document) {
  return root.querySelector('input[name="imageUrl"]');
}

const api = { findTitleInput, findPriceInput, findSourceUrlField, findImageInput };

if (typeof module !== 'undefined' && module.exports) {
  module.exports = api;
} else {
  self.PelandoKW = self.PelandoKW || {};
  Object.assign(self.PelandoKW, api);
}

})();
