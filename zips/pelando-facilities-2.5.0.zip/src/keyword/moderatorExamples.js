(function () {
'use strict';

// Exemplos cadastrados pelos moderadores e exportados do painel em 2026-10-02
// (pelando-exemplos-2026-10-02.json), revisados: sem o "Alho 1,01kg" (a busca
// não vinha do título), "Adizero Evo SL" e "Whiskas" no lugar das palavras
// cortadas pelo painel antigo, e sem HDR/IPX7 (especificações não identificam
// o produto). Embutidos para todo moderador aprender com eles; os cadastrados
// no próprio navegador continuam com prioridade. Revisados de novo na planilha
// palavras-chave-2026-10-12.xlsx: buscas em várias partes viraram uma frase só.

const MODERATOR_EXAMPLES = [
  {
    "id": "moderador-1",
    "categoria": "casa e cozinha",
    "titulo": "Sanduicheira Elétrica Cadence Preta 220V",
    "keywords": [
      "Sanduicheira Cadence"
    ],
    "origem": "moderador"
  },
  {
    "id": "moderador-2",
    "categoria": "games",
    "titulo": "Monitor portátil FHD 1920x1080 IPS HDR jogos",
    "keywords": [
      "Monitor portátil"
    ],
    "origem": "moderador"
  },
  {
    "id": "moderador-3",
    "categoria": "smartphone",
    "titulo": "[PRÉ-VENDA] iPhone 18 Pro Max de 256 GB – Bordô",
    "keywords": [
      "iPhone 18 Pro Max"
    ],
    "origem": "moderador"
  },
  {
    "id": "moderador-4",
    "categoria": "saúde e beleza",
    "titulo": "Kit 3 und Hidratante Labial Carmed Coca-Cola 10g",
    "keywords": [
      "Carmed Coca-Cola"
    ],
    "origem": "moderador"
  },
  {
    "id": "moderador-5",
    "categoria": "saúde e beleza",
    "titulo": "Deo Colônia Masculino Natura Homem Cor.agio 100 ml",
    "keywords": [
      "Cor.agio"
    ],
    "origem": "moderador"
  },
  {
    "id": "moderador-6",
    "categoria": "games",
    "titulo": "Call of Duty®: Black Ops 4",
    "keywords": [
      "Black Ops 4"
    ],
    "origem": "moderador"
  },
  {
    "id": "moderador-7",
    "categoria": "casa e cozinha",
    "titulo": "Pipoqueira Brinox Ceramic Life Nevada 4,2 L",
    "keywords": [
      "Pipoqueira Brinox"
    ],
    "origem": "moderador"
  },
  {
    "id": "moderador-8",
    "categoria": "",
    "titulo": "Controle GameSir G8 Plus MFi para iPhone, iPad, Android",
    "keywords": [
      "GameSir G8 Plus MFi"
    ],
    "origem": "moderador"
  },
  {
    "id": "moderador-9",
    "categoria": "saúde e beleza",
    "titulo": "Máscara Capilar Wella Pro Invigo 500ml",
    "keywords": [
      "Wella Pro Invigo"
    ],
    "origem": "moderador"
  },
  {
    "id": "moderador-10",
    "categoria": "moda",
    "titulo": "Tênis adidas Adizero Evo SL Masculino",
    "keywords": [
      "Adizero Evo SL"
    ],
    "origem": "moderador"
  },
  {
    "id": "moderador-11",
    "categoria": "tablet",
    "titulo": "Tablet Samsung Galaxy Tab S10 FE, 128GB, Tela 10.9\"",
    "keywords": [
      "tab S10 128"
    ],
    "origem": "moderador"
  },
  {
    "id": "moderador-12",
    "categoria": "saúde e beleza",
    "titulo": "Sabonete Líquido Needs Amêndoas 200ml",
    "keywords": [
      "Needs 200ml"
    ],
    "origem": "moderador"
  },
  {
    "id": "moderador-13",
    "categoria": "esporte",
    "titulo": "Whey Ultra Protein Concentrado Pote 900g - FTW",
    "keywords": [
      "Whey Ultra Protein ftw"
    ],
    "origem": "moderador"
  },
  {
    "id": "moderador-14",
    "categoria": "Eletronicos",
    "titulo": "Caixa De Som Bluetooth Harman Kardon Onyx 9 Preta",
    "keywords": [
      "Harman Kardon Onyx 9"
    ],
    "origem": "moderador"
  },
  {
    "id": "moderador-15",
    "categoria": "games",
    "titulo": "Processador AMD Ryzen 5 5500, Cinza",
    "keywords": [
      "AMD Ryzen 5 5500"
    ],
    "origem": "moderador"
  },
  {
    "id": "moderador-16",
    "categoria": "smartphone",
    "titulo": "Smartphone Motorola Edge 60 Pro 5G 256GB Violeta",
    "keywords": [
      "Motorola Edge 60 Pro"
    ],
    "origem": "moderador"
  },
  {
    "id": "moderador-17",
    "categoria": "moda",
    "titulo": "Óculos de Sol Ray-Ban Bill One - Marrom",
    "keywords": [
      "Bill One"
    ],
    "origem": "moderador"
  },
  {
    "id": "moderador-18",
    "categoria": "casa e cozinha",
    "titulo": "Tramontina, JOGO de FACAS, INOX, x4 Peças, Preto",
    "keywords": [
      "Tramontina Jogo de facas"
    ],
    "origem": "moderador"
  },
  {
    "id": "moderador-19",
    "categoria": "supermercado",
    "titulo": "Leite Longa Vida Desnatado Molico 1L",
    "keywords": [
      "Leite Desnatado Molico"
    ],
    "origem": "moderador"
  },
  {
    "id": "moderador-20",
    "categoria": "",
    "titulo": "Whiskas Gato Adulto Castrado Carne 2.7kg",
    "keywords": [
      "Whiskas"
    ],
    "origem": "moderador"
  },
  {
    "id": "moderador-21",
    "categoria": "áudio",
    "titulo": "Caixa de Som JBL Flip 7 Bluetooth Portátil",
    "keywords": [
      "JBL Flip 7"
    ],
    "origem": "moderador"
  },
  {
    "id": "moderador-22",
    "categoria": "Ferramentas",
    "titulo": "Furadeira Impacto 1/2\" 18V Bosch + Baterias",
    "keywords": [
      "Furadeira Impacto Bosch"
    ],
    "origem": "moderador"
  },
  {
    "id": "moderador-23",
    "categoria": "",
    "titulo": "Moedor Café Inox Manual Icoffee M6-MAX Ajuste",
    "keywords": [
      "Icoffee M6-MAX"
    ],
    "origem": "moderador"
  },
  {
    "id": "moderador-24",
    "categoria": "games",
    "titulo": "Microfone Lavalier Mini Wireless Maono T1",
    "keywords": [
      "Lavalier Mini Maono T1"
    ],
    "origem": "moderador"
  },
  {
    "id": "moderador-25",
    "categoria": "pet",
    "titulo": "Simparic 10Mg Cães 2.6-5Kg 3 Comprimidos",
    "keywords": [
      "Simparic 10"
    ],
    "origem": "moderador"
  },
  {
    "id": "moderador-26",
    "categoria": "",
    "titulo": "Amaciante Ypê Pro Ultra 7L",
    "keywords": [
      "Amaciante Ypê Pro Ultra 7"
    ],
    "origem": "moderador"
  },
  {
    "id": "moderador-27",
    "categoria": "baby",
    "titulo": "Berço Portátil Cosco Kids Cozzy 2 Alturas",
    "keywords": [
      "Cosco Cozzy"
    ],
    "origem": "moderador"
  },
  {
    "id": "moderador-28",
    "categoria": "Eletronicos",
    "titulo": "Relógio Inteligente Amazfit BIP 6 GPS Bateria 14 Dias",
    "keywords": [
      "Amazfit BIP 6"
    ],
    "origem": "moderador"
  },
  {
    "id": "moderador-29",
    "categoria": "casa e cozinha",
    "titulo": "Refrigerador Panasonic 391l Branco Nr-bt41pd2w",
    "keywords": [
      "Panasonic 391l"
    ],
    "origem": "moderador"
  },
  {
    "id": "moderador-30",
    "categoria": "casa e cozinha",
    "titulo": "Ducha Intense 220V 7.800W Black Fame",
    "keywords": [
      "Ducha Intense Black Fame"
    ],
    "origem": "moderador"
  },
  {
    "id": "moderador-31",
    "categoria": "áudio",
    "titulo": "Caixa Som Mlove E90 Bluetooth IPX7 120W",
    "keywords": [
      "Mlove E90"
    ],
    "origem": "moderador"
  },
  {
    "id": "moderador-32",
    "categoria": "áudio",
    "titulo": "Caixa de Som Tribit StormBox Blast 2 200W IP67",
    "keywords": [
      "Tribit StormBox Blast 2"
    ],
    "origem": "moderador"
  },
  {
    "id": "moderador-33",
    "categoria": "Eletronicos",
    "titulo": "Osmo Pocket 4 Câmera Ação Estabilizador Portátil",
    "keywords": [
      "Osmo Pocket 4"
    ],
    "origem": "moderador"
  },
  {
    "id": "moderador-34",
    "categoria": "casa e cozinha",
    "titulo": "Lava e Seca Brastemp 14Kg Titanium",
    "keywords": [
      "Lava Seca Brastemp Titanium"
    ],
    "origem": "moderador"
  },
  {
    "id": "moderador-35",
    "categoria": "Eletronicos",
    "titulo": "Fone Baseus BP1 Pro ANC Bluetooth 6.0",
    "keywords": [
      "Baseus BP1 Pro"
    ],
    "origem": "moderador"
  },
  {
    "id": "moderador-36",
    "categoria": "casa e cozinha",
    "titulo": "Robô Aspirador e Passa Pano eufy C28 com IA",
    "keywords": [
      "eufy C28 IA"
    ],
    "origem": "moderador"
  },
  {
    "id": "moderador-37",
    "categoria": "Eletronicos",
    "titulo": "Pulseira Silicone Samsung Galaxy Watch Ultra 47mm",
    "keywords": [
      "Pulseira Watch Ultra 47"
    ],
    "origem": "moderador"
  },
  {
    "id": "moderador-38",
    "categoria": "familia e cianças",
    "titulo": "Fantasia Homem-Aranha com Máscara e Enchimento",
    "keywords": [
      "Fantasia Homem Aranha"
    ],
    "origem": "moderador"
  },
  {
    "id": "moderador-39",
    "categoria": "carro e moto",
    "titulo": "Sensor Estacionamento Pósitron PS220 4 Cápsulas",
    "keywords": [
      "Pósitron PS220 4 Cápsulas"
    ],
    "origem": "moderador"
  },
  {
    "id": "moderador-40",
    "categoria": "games",
    "titulo": "Mouse Vertical Ergonômico UGREEN 4000DPI Sem Fio",
    "keywords": [
      "Vertical UGREEN"
    ],
    "origem": "moderador"
  },
  {
    "id": "moderador-41",
    "categoria": "Ferramentas",
    "titulo": "Parafusadeira Furadeira 25V Nakasaki Sem Fio",
    "keywords": [
      "Parafusadeira Nakasaki"
    ],
    "origem": "moderador"
  },
  {
    "id": "moderador-42",
    "categoria": "Eletronicos",
    "titulo": "Samsung Smart TV 65\" Mini LED 4K M75H 2027",
    "keywords": [
      "65 Mini LED M75H"
    ],
    "origem": "moderador"
  },
  {
    "id": "moderador-43",
    "categoria": "moda",
    "titulo": "Bermuda Masculina Columbia Silver Ridge Cinza",
    "keywords": [
      "Bermuda Masculina Columbia"
    ],
    "origem": "moderador"
  },
  {
    "id": "moderador-44",
    "categoria": "games",
    "titulo": "(Steam) The Elder Scrolls V: Skyrim Special Edition",
    "keywords": [
      "The Elder Scrolls V"
    ],
    "origem": "moderador"
  },
  {
    "id": "moderador-45",
    "categoria": "games",
    "titulo": "Placa Vídeo Gigabyte RTX 5070 EAGLE OC 12GB",
    "keywords": [
      "Gigabyte RTX 5070"
    ],
    "origem": "moderador"
  },
  {
    "id": "moderador-46",
    "categoria": "tv",
    "titulo": "Smart TV Hisense 75\" 4K QLED AI Dolby Vision",
    "keywords": [
      "Hisense 75 QLED"
    ],
    "origem": "moderador"
  },
  {
    "id": "moderador-47",
    "categoria": "moda",
    "titulo": "Calça Feminina Venum Move Cacau, Tamanho P",
    "keywords": [
      "Calça Feminina Venum"
    ],
    "origem": "moderador"
  },
  {
    "id": "moderador-48",
    "categoria": "esporte",
    "titulo": "Whey Protein 100%HD Black Skull Morango Refil 900g",
    "keywords": [
      "Whey Protein Black Skull"
    ],
    "origem": "moderador"
  },
  {
    "id": "moderador-49",
    "categoria": "games",
    "titulo": "Placa Vídeo Gigabyte RTX 5060 Eagle OC 8GB",
    "keywords": [
      "Gigabyte RTX 5060"
    ],
    "origem": "moderador"
  },
  {
    "id": "moderador-50",
    "categoria": "saúde e beleza",
    "titulo": "Phebo Aromáticos Eau de Toilette Lavanda 200ml",
    "keywords": [
      "Phebo Eau Toilette 200"
    ],
    "origem": "moderador"
  },
  {
    "id": "moderador-51",
    "categoria": "baby",
    "titulo": "Brinquedo Bebê Fisher-Price Apoiador Zebra",
    "keywords": [
      "Fisher-Price Apoiador Zebra"
    ],
    "origem": "moderador"
  },
  {
    "id": "moderador-52",
    "categoria": "smartphone",
    "titulo": "Apple Iphone 17 Pro Max 512gb prateado.",
    "keywords": [
      "Iphone 17 Pro Max 512"
    ],
    "origem": "moderador"
  },
  {
    "id": "moderador-53",
    "categoria": "games",
    "titulo": "Watercooler Kalkan 360mm Aura Lcd 360 Argb Preto",
    "keywords": [
      "Watercooler Kalkan"
    ],
    "origem": "moderador"
  },
  {
    "id": "moderador-54",
    "categoria": "casa e cozinha",
    "titulo": "Aspirador de Pó Robô Eufy X10 Pro com Desvio de Obstáculos por IA, Lava, Seca, Esvazia e Repõe Água Automaticamente",
    "keywords": [
      "Eufy X10 Pro"
    ],
    "origem": "moderador"
  },
  {
    "id": "moderador-55",
    "categoria": "esporte",
    "titulo": "Camisa Botafogo III 25/26 Goleiro Reebok",
    "keywords": [
      "Camisa Botafogo"
    ],
    "origem": "moderador"
  }
];

const api = { MODERATOR_EXAMPLES };

if (typeof module !== 'undefined' && module.exports) {
  module.exports = api;
} else {
  self.PelandoKW = self.PelandoKW || {};
  Object.assign(self.PelandoKW, api);
}

})();
