(function () {
'use strict';

const EXAMPLES_KEY = 'pelandoKeywordExamples';

// Lista padrão de categorias (mesmos nomes dos temas do catálogo).
const STANDARD_CATEGORIES = [
  'smartphone', 'tablet', 'smartwatch', 'informática', 'games', 'áudio', 'tv',
  'casa e cozinha', 'saúde e beleza', 'moda', 'esporte', 'supermercado', 'pet',
];

// Nomes antigos ou variações -> categoria padrão (chaves sem acento, minúsculas).
const CATEGORY_ALIASES = {
  console: 'games', consoles: 'games', jogos: 'games',
  celular: 'smartphone', celulares: 'smartphone',
  'caixa de som': 'áudio', fone: 'áudio', fones: 'áudio',
  cozinha: 'casa e cozinha', casa: 'casa e cozinha',
  beleza: 'saúde e beleza', saude: 'saúde e beleza',
  tenis: 'moda', roupas: 'moda', calcados: 'moda',
  computador: 'informática', notebook: 'informática',
  televisao: 'tv', mercado: 'supermercado', pets: 'pet',
};

function categoryKey(value) {
  return value.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase();
}

const CATEGORY_LOOKUP = new Map([
  ...STANDARD_CATEGORIES.map((categoria) => [categoryKey(categoria), categoria]),
  ...Object.entries(CATEGORY_ALIASES),
]);

// Categorias fora da lista e sem apelido conhecido ficam como foram digitadas.
function normalizeCategoria(categoria) {
  const value = String(categoria || '').trim();
  return CATEGORY_LOOKUP.get(categoryKey(value)) || value;
}

function normalizeExample(example) {
  return { ...example, categoria: normalizeCategoria(example.categoria) };
}

function generateId() {
  if (typeof crypto !== 'undefined' && crypto.randomUUID) {
    return crypto.randomUUID();
  }
  return `${Date.now()}-${Math.random().toString(16).slice(2)}`;
}

async function getExamples() {
  const stored = await chrome.storage.local.get(EXAMPLES_KEY);
  return (stored[EXAMPLES_KEY] || []).map(normalizeExample);
}

async function saveExamples(examples) {
  await chrome.storage.local.set({ [EXAMPLES_KEY]: examples });
  return examples;
}

async function addExample({ categoria, titulo, keywords, dica }) {
  const examples = await getExamples();
  const example = {
    id: generateId(),
    categoria: normalizeCategoria(categoria),
    titulo,
    keywords,
    dica: dica || '',
    criadoEm: new Date().toISOString(),
  };
  await saveExamples([...examples, example]);
  return example;
}

async function updateExample(id, changes) {
  const examples = await getExamples();
  let updated = null;
  const next = examples.map((example) => {
    if (example.id !== id) return example;
    updated = normalizeExample({ ...example, ...changes, id });
    return updated;
  });
  if (updated) await saveExamples(next);
  return updated;
}

async function deleteExample(id) {
  const examples = await getExamples();
  const next = examples.filter((example) => example.id !== id);
  const deleted = next.length !== examples.length;
  if (deleted) await saveExamples(next);
  return deleted;
}

// Importa uma exportação do painel: atualiza pelo id, adiciona os novos e
// mantém os que não vieram no arquivo.
async function importExamples(incoming) {
  const examples = await getExamples();
  const byId = new Map(examples.map((example) => [example.id, example]));
  const result = { atualizados: 0, adicionados: 0, ignorados: 0 };
  for (const example of incoming) {
    const valid = example && example.titulo && Array.isArray(example.keywords) && example.keywords.length;
    if (!valid) {
      result.ignorados += 1;
      continue;
    }
    const id = example.id || generateId();
    if (byId.has(id)) result.atualizados += 1; else result.adicionados += 1;
    byId.set(id, normalizeExample({ criadoEm: new Date().toISOString(), ...byId.get(id), ...example, id }));
  }
  await saveExamples([...byId.values()]);
  return result;
}

const api = { STANDARD_CATEGORIES, normalizeCategoria, getExamples, addExample, updateExample, deleteExample, importExamples };

if (typeof module !== 'undefined' && module.exports) {
  module.exports = api;
} else {
  self.PelandoKW = self.PelandoKW || {};
  Object.assign(self.PelandoKW, api);
}

})();
