const PELANDO_BO_SAVE_SHORTCUT_CLASS = 'pelando-bo-save-shortcut';
// One copy floats in the bottom right corner; another sits above the "Ações"
// card's Aprovar / Reprovar buttons.
const PELANDO_BO_SAVE_FLOATING_CLASS = PELANDO_BO_SAVE_SHORTCUT_CLASS + '--floating';
const PELANDO_BO_SAVE_ACTIONS_CLASS = PELANDO_BO_SAVE_SHORTCUT_CLASS + '--actions';
// Pelando's backoffice is in Portuguese; Promoninja's in Spanish (Spain and
// Argentina) or English (the others).
const PELANDO_BO_DECISION_BUTTON_TEXTS = ['aprovar', 'reprovar', 'aprobar', 'rechazar', 'approve', 'reject'];
// The deal page's submit button at the bottom of the form reads "Salvar
// alterações" ("Guardar cambios", "Save changes"), and "Salvando..."
// ("Guardando...", "Saving...", disabled) while it saves.
const PELANDO_BO_SAVE_TEXTS = ['salvar alterações', 'salvando...', 'guardar cambios', 'guardando...', 'save changes', 'saving...'];
const PELANDO_BO_SAVING_TEXTS = ['salvando...', 'guardando...', 'saving...'];
// The floating copy sits in a bar in the bottom right corner, with a green
// Aprovar to its right that saves first and approves once saved.
const PELANDO_BO_FLOATING_BAR_CLASS = 'pelando-bo-floating-actions';
const PELANDO_BO_APPROVE_SHORTCUT_CLASS = 'pelando-bo-approve-shortcut';
const PELANDO_BO_SAVE_TOAST_CLASS = 'pelando-bo-save-shortcut-toast';
// The "Ações" card's Aprovar ("Aprovando..." while it approves); "Aprovar e
// revisar" is another button.
const PELANDO_BO_APPROVE_TEXTS = ['aprovar', 'aprovando...', 'aprobar', 'aprobando...', 'approve', 'approving...'];
// How the floating Aprovar waits for the save: checks every `pollMs`; the
// save must start within `startMs` (or a field failed validation) and end
// within `saveMs`.
const PELANDO_BO_SAVE_APPROVE_WAIT = { pollMs: 100, startMs: 3000, saveMs: 30000 };

function saveShortcutText(el) {
  return (el.textContent || '').replace(/\s+/g, ' ').trim().toLowerCase();
}

function isOurShortcut(el) {
  return el.classList.contains(PELANDO_BO_SAVE_SHORTCUT_CLASS) || el.classList.contains(PELANDO_BO_APPROVE_SHORTCUT_CLASS);
}

function findSaveShortcutButtonByText(doc, text) {
  const candidates = doc.querySelectorAll('button, a, [role="button"]');
  for (let i = 0; i < candidates.length; i++) {
    const el = candidates[i];
    if (isOurShortcut(el)) continue;
    if (saveShortcutText(el) === text) return el;
  }
  return null;
}

// The deal's Aprovar sits in the "Ações" card next to at least one of these;
// an Aprovar elsewhere on the page (a comment's) isn't the deal's.
const PELANDO_BO_APPROVE_SIBLING_TEXTS = [
  'reprovar', 'reprovando...', 'rejeitar', 'rejeitando...', 'rechazar', 'rechazando...', 'reject', 'rejecting...',
  'aprovar e revisar', 'aprobar y revisar', 'approve and review',
  'expirar', 'vencer', 'expire',
];

function findApproveButton(doc) {
  const buttons = doc.querySelectorAll('button');
  for (let i = 0; i < buttons.length; i++) {
    const button = buttons[i];
    if (isOurShortcut(button) || !button.parentElement) continue;
    if (!PELANDO_BO_APPROVE_TEXTS.includes(saveShortcutText(button))) continue;
    const besideDecisions = Array.prototype.some.call(button.parentElement.children, function (sibling) {
      return sibling !== button && PELANDO_BO_APPROVE_SIBLING_TEXTS.includes(saveShortcutText(sibling));
    });
    if (besideDecisions) return button;
  }
  return null;
}

function findSaveButton(doc) {
  const buttons = doc.querySelectorAll('button[type="submit"]');
  for (let i = 0; i < buttons.length; i++) {
    const button = buttons[i];
    if (isOurShortcut(button)) continue;
    if (PELANDO_BO_SAVE_TEXTS.includes(saveShortcutText(button))) return button;
  }
  return null;
}

function createSaveShortcut(doc, placementClass) {
  const shortcut = doc.createElement('button');
  shortcut.type = 'button';
  shortcut.dataset.placement = placementClass;
  // Clicking the page's own button keeps its form validation and saving flow.
  shortcut.addEventListener('click', function () {
    const original = findSaveButton(doc);
    if (original && !original.disabled) original.click();
  });
  return shortcut;
}

// Makes the shortcut look exactly like the original: its classes (the page's
// own styles) and content (text, and the spinner while saving). Only our
// classes, which place it, are added. A shortcut busy with its own work
// (`data-busy`) stays disabled.
function copySaveButtonLook(shortcut, original, ourClass) {
  const look = original.className + '|' + original.innerHTML;
  if (shortcut.dataset.look !== look) {
    shortcut.dataset.look = look;
    shortcut.className = [original.className, ourClass || PELANDO_BO_SAVE_SHORTCUT_CLASS, shortcut.dataset.placement]
      .filter(Boolean)
      .join(' ');
    shortcut.replaceChildren.apply(
      shortcut,
      Array.prototype.map.call(original.childNodes, function (node) {
        return node.cloneNode(true);
      })
    );
  }
  shortcut.disabled = original.disabled || shortcut.dataset.busy === 'true';
}

function showSaveShortcutToast(doc, text) {
  const toast = doc.createElement('div');
  toast.className = PELANDO_BO_SAVE_TOAST_CLASS;
  toast.setAttribute('role', 'alert');
  toast.textContent = text;
  doc.body.appendChild(toast);
  setTimeout(function () {
    toast.remove();
  }, 6000);
}

function waitMsForSave(ms) {
  return new Promise(function (resolve) {
    setTimeout(resolve, ms);
  });
}

// The page's own toasts (sonner) of a type, as a set to tell new ones apart.
function pageToasts(doc, type) {
  return new Set(doc.querySelectorAll('[data-sonner-toast][data-type="' + type + '"]'));
}

function hasNewToast(doc, type, before) {
  return Array.prototype.some.call(doc.querySelectorAll('[data-sonner-toast][data-type="' + type + '"]'), function (toast) {
    return !before.has(toast);
  });
}

function isSaving(button) {
  return !!button && (button.disabled || PELANDO_BO_SAVING_TEXTS.includes(saveShortcutText(button)));
}

// Clicks the page's Salvar and waits for it: true once saved, false when the
// form didn't save (a field failed validation) or the backoffice refused it.
async function saveDealForm(doc) {
  const wait = PELANDO_BO_SAVE_APPROVE_WAIT;
  const errorsBefore = pageToasts(doc, 'error');
  const successesBefore = pageToasts(doc, 'success');
  const save = findSaveButton(doc);
  if (!save || save.disabled) return false;
  save.click();
  let started = false;
  for (let waited = 0; waited < wait.startMs && !started; waited += wait.pollMs) {
    await waitMsForSave(wait.pollMs);
    started = isSaving(findSaveButton(doc)) || hasNewToast(doc, 'success', successesBefore) || hasNewToast(doc, 'error', errorsBefore);
  }
  if (!started) return false;
  for (let waited = 0; waited < wait.saveMs && isSaving(findSaveButton(doc)); waited += wait.pollMs) {
    await waitMsForSave(wait.pollMs);
  }
  // A save button gone mid-save (the page changed) is no proof of a save.
  const after = findSaveButton(doc);
  return !!after && !isSaving(after) && !hasNewToast(doc, 'error', errorsBefore);
}

function createApproveShortcut(doc) {
  const shortcut = doc.createElement('button');
  shortcut.type = 'button';
  shortcut.addEventListener('click', async function () {
    if (shortcut.dataset.busy === 'true') return;
    shortcut.dataset.busy = 'true';
    shortcut.disabled = true;
    try {
      if (!(await saveDealForm(doc))) {
        showSaveShortcutToast(doc, 'As alterações não foram salvas, então a promoção não foi aprovada. Confira o formulário.');
        return;
      }
      const approve = findApproveButton(doc);
      if (!approve || approve.disabled) {
        showSaveShortcutToast(doc, 'Salvo, mas o botão Aprovar da página não está disponível: a promoção não foi aprovada.');
        return;
      }
      approve.click();
    } finally {
      shortcut.dataset.busy = 'false';
      const approve = findApproveButton(doc);
      shortcut.disabled = !!approve && approve.disabled;
    }
  });
  return shortcut;
}

function syncApproveShortcut(doc, bar) {
  let shortcut = doc.querySelector('.' + PELANDO_BO_APPROVE_SHORTCUT_CLASS);
  const original = bar ? findApproveButton(doc) : null;
  if (!original) {
    if (shortcut) shortcut.remove();
    return;
  }
  if (!shortcut) shortcut = createApproveShortcut(doc);
  copySaveButtonLook(shortcut, original, PELANDO_BO_APPROVE_SHORTCUT_CLASS);
  if (shortcut.parentElement !== bar || bar.lastElementChild !== shortcut) bar.appendChild(shortcut);
}

// The first Aprovar / Reprovar button of the "Ações" card, or the row holding
// it when the card lays them out side by side, so the copy goes above them.
function findDecisionButtonsAnchor(doc) {
  let button = null;
  for (let i = 0; i < PELANDO_BO_DECISION_BUTTON_TEXTS.length && !button; i++) {
    button = findSaveShortcutButtonByText(doc, PELANDO_BO_DECISION_BUTTON_TEXTS[i]);
  }
  if (!button || !button.parentElement) return null;
  const parent = button.parentElement;
  const style = getComputedStyle(parent);
  const sideBySide = /grid/.test(style.display) || (/flex/.test(style.display) && !/column/.test(style.flexDirection));
  return sideBySide && parent !== doc.body ? parent : button;
}

function syncSaveShortcut(doc, original, placementClass, place) {
  let shortcut = doc.querySelector('.' + placementClass);
  if (!original) {
    if (shortcut) shortcut.remove();
    return;
  }
  if (!shortcut) {
    shortcut = createSaveShortcut(doc, placementClass);
  }
  copySaveButtonLook(shortcut, original);
  if (!place(shortcut)) shortcut.remove();
}

// The corner bar holding the floating copies, or null once there's no save
// button to copy.
function syncFloatingBar(doc, original) {
  let bar = doc.querySelector('.' + PELANDO_BO_FLOATING_BAR_CLASS);
  if (!original) {
    if (bar) bar.remove();
    return null;
  }
  if (!bar) {
    bar = doc.createElement('div');
    bar.className = PELANDO_BO_FLOATING_BAR_CLASS;
  }
  if (bar.parentElement !== doc.body) doc.body.appendChild(bar);
  return bar;
}

// Copies of the page's "Salvar alterações" - one floating in the bottom right
// corner, one above Aprovar / Reprovar - so saving doesn't need scrolling to
// the bottom. They follow the original's look and disabled state, and go
// away with it. The floating one has a green Aprovar to its right.
function syncBackofficeSaveShortcut(doc) {
  const original = findSaveButton(doc);
  const bar = syncFloatingBar(doc, original);
  syncSaveShortcut(doc, original, PELANDO_BO_SAVE_FLOATING_CLASS, function (shortcut) {
    if (shortcut.parentElement !== bar || bar.firstElementChild !== shortcut) bar.insertBefore(shortcut, bar.firstChild);
    return true;
  });
  syncApproveShortcut(doc, bar);
  syncSaveShortcut(doc, original, PELANDO_BO_SAVE_ACTIONS_CLASS, function (shortcut) {
    const anchor = findDecisionButtonsAnchor(doc);
    if (!anchor) return false;
    if (anchor.previousElementSibling !== shortcut) anchor.insertAdjacentElement('beforebegin', shortcut);
    return true;
  });
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = { syncBackofficeSaveShortcut, PELANDO_BO_SAVE_APPROVE_WAIT };
}
