// Next to the nickname at the top of a chat: links to the user's profile on
// Pelando and to their page on the backoffice. The chat only shows the
// nickname, so the backoffice id comes from the backoffice's user search,
// looked up when the conversation opens (a tab opened after waiting on it,
// on click, would be blocked as a pop-up).
const PELANDO_CHAT_USER_LINKS_CLASS = 'pelando-chat-user-links';
const PELANDO_CHAT_USER_SITE_CLASS = 'pelando-chat-user-link-site';
const PELANDO_CHAT_USER_BO_CLASS = 'pelando-chat-user-link-bo';
const PELANDO_CHAT_USER_PROFILE_URL = 'https://www.pelando.com.br/perfil/';
const PELANDO_CHAT_USER_BO_URL = 'https://bo.pelando.com.br/usuario/';
const PELANDO_CHAT_USER_NOT_FOUND = 'Usuário não encontrado no backoffice.';

// The search also matches similar nicknames, so only the exact one counts.
async function findBackofficeUserId(nickname, call) {
  const result = await call('GET', '/users?page=1&size=10&search=' + encodeURIComponent(nickname));
  const users = (result && result.data) || [];
  const wanted = nickname.toLowerCase();
  const user = users.find(function (u) {
    return u && typeof u.nickname === 'string' && u.nickname.toLowerCase() === wanted;
  });
  return user ? String(user.id) : null;
}

function chatUserLink(className, text) {
  const link = document.createElement('a');
  link.className = 'pelando-chat-user-link ' + className;
  link.textContent = text;
  link.target = '_blank';
  link.rel = 'noopener noreferrer';
  return link;
}

// Sets an attribute only when it differs (or removes it for null), so
// running on the chat's own changes settles.
function setChatUserAttribute(element, name, value) {
  if (value === null) {
    if (element.hasAttribute(name)) element.removeAttribute(name);
  } else if (element.getAttribute(name) !== value) {
    element.setAttribute(name, value);
  }
}

// `lookup(nickname)` resolves to the backoffice id, or null when there's none.
function createChatUserLinks(lookup) {
  // nickname -> { status: 'loading' | 'ready' | 'failed', id, message }
  const lookups = new Map();

  function lookupFor(nickname, doc) {
    let state = lookups.get(nickname);
    if (state) return state;
    state = { status: 'loading' };
    lookups.set(nickname, state);
    lookup(nickname).then(
      function (id) {
        if (id) {
          state.status = 'ready';
          state.id = id;
        } else {
          state.status = 'failed';
          state.message = PELANDO_CHAT_USER_NOT_FOUND;
        }
        sync(doc);
      },
      function (err) {
        state.status = 'failed';
        state.message = (err && err.message) || PELANDO_CHAT_USER_NOT_FOUND;
        sync(doc);
      }
    );
    return state;
  }

  function createLinks(doc, nickname) {
    const box = document.createElement('span');
    box.className = PELANDO_CHAT_USER_LINKS_CLASS;
    box.dataset.nickname = nickname;
    const site = chatUserLink(PELANDO_CHAT_USER_SITE_CLASS, 'Pelando');
    site.href = PELANDO_CHAT_USER_PROFILE_URL + encodeURIComponent(nickname);
    site.title = 'Abrir o perfil no Pelando';
    const bo = chatUserLink(PELANDO_CHAT_USER_BO_CLASS, 'Backoffice');
    // Until the id is known there's nowhere to go; a failed lookup is retried.
    bo.addEventListener('click', function (event) {
      const state = lookups.get(nickname);
      if (state && state.status === 'ready') return;
      event.preventDefault();
      if (state && state.status === 'failed') {
        lookups.delete(nickname);
        sync(doc);
      }
    });
    box.append(site, bo);
    // The chat's header takes its own tab to the profile on click; the links
    // only open a new tab, so their clicks stop here.
    ['click', 'auxclick'].forEach(function (type) {
      box.addEventListener(type, function (event) {
        event.stopPropagation();
      });
    });
    return box;
  }

  function sync(doc) {
    const name = doc.querySelector('span.chat-header-name');
    const nickname = name ? name.textContent.trim() : '';
    let box = doc.querySelector('.' + PELANDO_CHAT_USER_LINKS_CLASS);
    if (box && (!nickname || box.dataset.nickname !== nickname || box.previousElementSibling !== name)) {
      box.remove();
      box = null;
    }
    if (!nickname) return;
    if (!box) {
      box = createLinks(doc, nickname);
      name.after(box);
    }

    const state = lookupFor(nickname, doc);
    const bo = box.querySelector('.' + PELANDO_CHAT_USER_BO_CLASS);
    const ready = state.status === 'ready';
    setChatUserAttribute(bo, 'href', ready ? PELANDO_CHAT_USER_BO_URL + encodeURIComponent(state.id) : null);
    setChatUserAttribute(bo, 'aria-disabled', ready ? null : 'true');
    setChatUserAttribute(bo, 'data-status', state.status);
    let title = 'Abrir o usuário no backoffice';
    if (state.status === 'loading') title = 'Buscando o usuário no backoffice…';
    if (state.status === 'failed') title = state.message + ' Clique para tentar de novo.';
    setChatUserAttribute(bo, 'title', title);
  }

  return sync;
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = { findBackofficeUserId, createChatUserLinks };
}
