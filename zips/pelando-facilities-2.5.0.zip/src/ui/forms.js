function createThemeForm(theme, callbacks) {
  const form = document.createElement('div');
  form.className = 'pelando-chat-ext-form';

  const nameInput = document.createElement('input');
  nameInput.type = 'text';
  nameInput.className = 'pelando-chat-ext-form-input';
  nameInput.placeholder = 'Nome do tema';
  nameInput.value = theme ? theme.nome : '';
  form.appendChild(nameInput);

  const keywordsInput = document.createElement('textarea');
  keywordsInput.className = 'pelando-chat-ext-form-textarea';
  keywordsInput.placeholder = 'Palavras-chave, separadas por vírgula';
  keywordsInput.value = theme ? theme.palavrasChave.join(', ') : '';
  form.appendChild(keywordsInput);

  const errorEl = document.createElement('div');
  errorEl.className = 'pelando-chat-ext-form-error';
  form.appendChild(errorEl);

  const saveButton = document.createElement('button');
  saveButton.type = 'button';
  saveButton.className = 'pelando-chat-ext-form-save';
  saveButton.textContent = 'Salvar';
  saveButton.addEventListener('click', () => {
    const nome = nameInput.value.trim();
    if (!nome) {
      errorEl.textContent = 'Nome do tema é obrigatório';
      return;
    }
    const palavrasChave = keywordsInput.value
      .split(',')
      .map((k) => k.trim())
      .filter((k) => k.length > 0);
    Promise.resolve(callbacks.onSave({ nome, palavrasChave })).catch((err) => {
      errorEl.textContent = 'Não deu pra salvar: ' + err.message;
    });
  });
  form.appendChild(saveButton);

  const cancelButton = document.createElement('button');
  cancelButton.type = 'button';
  cancelButton.className = 'pelando-chat-ext-form-cancel';
  cancelButton.textContent = 'Cancelar';
  cancelButton.addEventListener('click', () => callbacks.onCancel());
  form.appendChild(cancelButton);

  return form;
}

function createMessageForm(message, callbacks) {
  const form = document.createElement('div');
  form.className = 'pelando-chat-ext-form';

  const nameInput = document.createElement('input');
  nameInput.type = 'text';
  nameInput.className = 'pelando-chat-ext-form-input';
  nameInput.placeholder = 'Nome da mensagem';
  nameInput.value = message ? message.nome : '';
  form.appendChild(nameInput);

  // The greeting keeps its name; only its text can change (see storage.js).
  const lockedName = !!message && typeof isProtectedMessage === 'function' && isProtectedMessage(message.id);
  if (lockedName) {
    nameInput.disabled = true;
    const hint = document.createElement('div');
    hint.className = 'pelando-chat-ext-form-hint';
    hint.textContent = 'O nome da saudação não pode ser trocado, só o texto dela.';
    form.appendChild(hint);
  }

  const textInput = document.createElement('textarea');
  textInput.className = 'pelando-chat-ext-form-textarea';
  textInput.placeholder = 'Texto da mensagem (use {nome} para o nome do contato)';
  textInput.value = message ? message.texto : '';
  form.appendChild(textInput);

  const errorEl = document.createElement('div');
  errorEl.className = 'pelando-chat-ext-form-error';
  form.appendChild(errorEl);

  const saveButton = document.createElement('button');
  saveButton.type = 'button';
  saveButton.className = 'pelando-chat-ext-form-save';
  saveButton.textContent = 'Salvar';
  saveButton.addEventListener('click', () => {
    const nome = lockedName ? message.nome : nameInput.value.trim();
    const texto = textInput.value.trim();
    if (!nome || !texto) {
      errorEl.textContent = 'Nome e texto são obrigatórios';
      return;
    }
    Promise.resolve(callbacks.onSave({ nome, texto })).catch((err) => {
      errorEl.textContent = 'Não deu pra salvar: ' + err.message;
    });
  });
  form.appendChild(saveButton);

  const cancelButton = document.createElement('button');
  cancelButton.type = 'button';
  cancelButton.className = 'pelando-chat-ext-form-cancel';
  cancelButton.textContent = 'Cancelar';
  cancelButton.addEventListener('click', () => callbacks.onCancel());
  form.appendChild(cancelButton);

  return form;
}

function createQuickAddForm(themes, initialTexto, callbacks) {
  const form = document.createElement('div');
  form.className = 'pelando-chat-ext-form';

  const themeSelect = document.createElement('select');
  themeSelect.className = 'pelando-chat-ext-form-select';
  themes.forEach((theme) => {
    const option = document.createElement('option');
    option.value = theme.id;
    option.textContent = theme.nome;
    themeSelect.appendChild(option);
  });
  const newThemeOption = document.createElement('option');
  newThemeOption.value = '__new__';
  newThemeOption.textContent = '+ Novo tema';
  themeSelect.appendChild(newThemeOption);
  form.appendChild(themeSelect);

  const newThemeInput = document.createElement('input');
  newThemeInput.type = 'text';
  newThemeInput.className = 'pelando-chat-ext-form-input';
  newThemeInput.placeholder = 'Nome do novo tema';
  newThemeInput.style.display = themes.length === 0 ? '' : 'none';
  form.appendChild(newThemeInput);

  themeSelect.addEventListener('change', function () {
    newThemeInput.style.display = themeSelect.value === '__new__' ? '' : 'none';
  });

  const nameInput = document.createElement('input');
  nameInput.type = 'text';
  nameInput.className = 'pelando-chat-ext-form-input';
  nameInput.placeholder = 'Nome da mensagem';
  form.appendChild(nameInput);

  const textInput = document.createElement('textarea');
  textInput.className = 'pelando-chat-ext-form-textarea';
  textInput.placeholder = 'Texto da mensagem (use {nome} para o nome do contato)';
  textInput.value = initialTexto || '';
  form.appendChild(textInput);

  const errorEl = document.createElement('div');
  errorEl.className = 'pelando-chat-ext-form-error';
  form.appendChild(errorEl);

  const saveButton = document.createElement('button');
  saveButton.type = 'button';
  saveButton.className = 'pelando-chat-ext-form-save';
  saveButton.textContent = 'Salvar';
  saveButton.addEventListener('click', function () {
    const nome = nameInput.value.trim();
    const texto = textInput.value.trim();
    const isNewTheme = themeSelect.value === '__new__';
    const novoTemaNome = isNewTheme ? newThemeInput.value.trim() : '';

    if (!nome || !texto) {
      errorEl.textContent = 'Nome e texto são obrigatórios';
      return;
    }
    if (isNewTheme && !novoTemaNome) {
      errorEl.textContent = 'Digite o nome do novo tema';
      return;
    }

    const values = isNewTheme
      ? { temaId: null, novoTemaNome: novoTemaNome, nome: nome, texto: texto }
      : { temaId: themeSelect.value, novoTemaNome: '', nome: nome, texto: texto };

    Promise.resolve(callbacks.onSave(values)).catch(function (err) {
      errorEl.textContent = 'Não deu pra salvar: ' + err.message;
    });
  });
  form.appendChild(saveButton);

  const cancelButton = document.createElement('button');
  cancelButton.type = 'button';
  cancelButton.className = 'pelando-chat-ext-form-cancel';
  cancelButton.textContent = 'Cancelar';
  cancelButton.addEventListener('click', function () {
    callbacks.onCancel();
  });
  form.appendChild(cancelButton);

  return form;
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = { createThemeForm, createMessageForm, createQuickAddForm };
}
