// Content-script CSS resolves url() against the page's own origin, not the
// extension package, so icon images must be pointed at via
// chrome.runtime.getURL() from JS instead of a static background/mask-image
// in styles.css.
function createIconSpan(fileName) {
  const icon = document.createElement('span');
  icon.className = 'pelando-chat-ext-icon';
  const url = chrome.runtime.getURL('icons/' + fileName);
  icon.style.webkitMaskImage = 'url(' + url + ')';
  icon.style.maskImage = 'url(' + url + ')';
  return icon;
}

// Text-transcript IA button is temporarily disabled; only the screenshot one is offered for now.
const PELANDO_CHAT_EXT_AI_TEXT_BUTTON_ENABLED = false;

// `options.movable: false` leaves out the handle that moves the popover
// (the side panel stays put).
function createTabBar(themes, activeThemeId, suggestedThemeId, manageMode, notificationsEnabled, callbacks, options) {
  const movable = !options || options.movable !== false;
  const bar = document.createElement('div');
  bar.className = 'pelando-chat-ext-tab-bar';

  // Moving the popover is part of setting it up, so the handle only shows in
  // manage mode, in the popover's top left corner; the caller wires the
  // dragging.
  if (manageMode && movable) {
    const moveHandle = document.createElement('span');
    moveHandle.className = 'pelando-chat-ext-move-handle';
    moveHandle.textContent = '⠿';
    moveHandle.title = 'Arraste para mudar a janela de lugar';
    moveHandle.setAttribute('aria-label', 'Arrastar para mudar a janela de lugar');
    bar.appendChild(moveHandle);
  }

  themes.forEach((theme) => {
    const tab = document.createElement('button');
    tab.type = 'button';
    tab.className = 'pelando-chat-ext-tab';
    if (theme.id === activeThemeId) {
      tab.classList.add('pelando-chat-ext-tab-active');
    }
    if (theme.id === suggestedThemeId) {
      tab.classList.add('pelando-chat-ext-tab-suggested');
    }
    tab.textContent = theme.nome;
    tab.addEventListener('click', () => callbacks.onSelectTheme(theme.id));
    bar.appendChild(tab);

    // The greeting's theme can't be renamed or deleted (see storage.js).
    const protectedTheme = typeof isProtectedTheme === 'function' && isProtectedTheme(theme.id);
    if (manageMode && theme.id === activeThemeId && !protectedTheme) {
      const renameButton = document.createElement('button');
      renameButton.type = 'button';
      renameButton.className = 'pelando-chat-ext-tab-rename';
      renameButton.textContent = '✎';
      renameButton.addEventListener('click', () => callbacks.onRenameTheme(theme));
      bar.appendChild(renameButton);

      const deleteButton = document.createElement('button');
      deleteButton.type = 'button';
      deleteButton.className = 'pelando-chat-ext-tab-delete';
      deleteButton.textContent = '🗑';
      deleteButton.addEventListener('click', () => callbacks.onDeleteTheme(theme));
      bar.appendChild(deleteButton);
    }
  });

  if (manageMode) {
    const addButton = document.createElement('button');
    addButton.type = 'button';
    addButton.className = 'pelando-chat-ext-tab-add';
    addButton.textContent = '+';
    addButton.addEventListener('click', () => callbacks.onAddTheme());
    bar.appendChild(addButton);
  }

  // The icon buttons stay together on one line at the end of the bar,
  // wrapping below the tabs as a group rather than one by one.
  const actions = document.createElement('div');
  actions.className = 'pelando-chat-ext-tab-actions';


  if (PELANDO_CHAT_EXT_AI_TEXT_BUTTON_ENABLED) {
    const aiButton = document.createElement('button');
    aiButton.type = 'button';
    aiButton.className = 'pelando-chat-ext-ai-button';
    aiButton.setAttribute('aria-label', 'Abrir IA com a conversa em texto');
    aiButton.appendChild(createIconSpan('microchip-ia.png'));
    aiButton.addEventListener('click', () => callbacks.onOpenAiText());
    actions.appendChild(aiButton);
  }

  const aiScreenshotButton = document.createElement('button');
  aiScreenshotButton.type = 'button';
  aiScreenshotButton.className = 'pelando-chat-ext-ai-button-screenshot';
  aiScreenshotButton.setAttribute('aria-label', 'Abrir IA com um print do chat');
  aiScreenshotButton.appendChild(createIconSpan('microchip-ia.png'));
  aiScreenshotButton.addEventListener('click', () => callbacks.onOpenAiScreenshot());
  actions.appendChild(aiScreenshotButton);

  if (callbacks.onOpenReasons) {
    const reasonsButton = document.createElement('button');
    reasonsButton.type = 'button';
    reasonsButton.className = 'pelando-chat-ext-reasons-button';
    reasonsButton.appendChild(createIconSpan('motivos-reprova.png'));
    reasonsButton.title = 'Motivos de reprova';
    reasonsButton.setAttribute('aria-label', 'Editar as mensagens dos motivos de reprova');
    reasonsButton.addEventListener('click', () => callbacks.onOpenReasons());
    actions.appendChild(reasonsButton);
  }

  const notificationsToggle = document.createElement('button');
  notificationsToggle.type = 'button';
  notificationsToggle.className = 'pelando-chat-ext-notifications-toggle';
  notificationsToggle.textContent = notificationsEnabled ? '🔔' : '🔕';
  notificationsToggle.setAttribute(
    'aria-label',
    notificationsEnabled ? 'Desativar notificações sonoras' : 'Ativar notificações sonoras'
  );
  notificationsToggle.addEventListener('click', () => callbacks.onToggleNotifications());
  actions.appendChild(notificationsToggle);

  const manageToggle = document.createElement('button');
  manageToggle.type = 'button';
  manageToggle.className = 'pelando-chat-ext-manage-toggle';
  manageToggle.textContent = '⚙️';
  manageToggle.addEventListener('click', () => callbacks.onToggleManage());
  actions.appendChild(manageToggle);

  bar.appendChild(actions);

  return bar;
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = { createTabBar };
}
