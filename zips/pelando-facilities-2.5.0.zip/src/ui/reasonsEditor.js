// Rejection reasons, most used first; each opens the form to edit the messages
// sent to the user when justifying a rejection.
function createReasonsList(reasons, callbacks) {
  const container = document.createElement('div');
  container.className = 'pelando-chat-ext-reasons';

  const header = document.createElement('div');
  header.className = 'pelando-chat-ext-reasons-header';
  const title = document.createElement('span');
  title.className = 'pelando-chat-ext-reasons-title';
  title.textContent = 'Motivos de reprova';
  const backButton = document.createElement('button');
  backButton.type = 'button';
  backButton.className = 'pelando-chat-ext-form-cancel';
  backButton.textContent = 'Voltar';
  backButton.addEventListener('click', () => callbacks.onBack());
  header.append(title, backButton);
  container.appendChild(header);

  const list = document.createElement('div');
  list.className = 'pelando-chat-ext-message-list';
  reasons.forEach((reason) => {
    const option = document.createElement('button');
    option.type = 'button';
    option.className = 'pelando-chat-ext-message-option pelando-chat-ext-reason-option';
    const name = document.createElement('span');
    name.textContent = reason.title + (reason.edited ? ' ✎' : '');
    const meta = document.createElement('span');
    meta.className = 'pelando-chat-ext-reason-meta';
    meta.textContent = reason.type + ' · ' + reason.uses + ' usos';
    option.append(name, meta);
    option.addEventListener('click', () => callbacks.onEdit(reason));
    list.appendChild(option);
  });
  container.appendChild(list);

  return container;
}


function createReasonForm(reason, callbacks) {
  const form = document.createElement('div');
  form.className = 'pelando-chat-ext-form';

  const title = document.createElement('div');
  title.className = 'pelando-chat-ext-reasons-title';
  title.textContent = reason.title + ' (' + reason.type + ')';
  form.appendChild(title);

  // One field per reply; the moderator can add new ones and remove any but
  // the last one left.
  const replies = reasonReplies(reason).slice();
  const fields = document.createElement('div');
  fields.className = 'pelando-chat-ext-reason-fields';
  form.appendChild(fields);

  function readReplies() {
    return [...fields.querySelectorAll('textarea')].map((t) => t.value);
  }

  function renderFields() {
    fields.replaceChildren();
    replies.forEach((text, index) => {
      const field = document.createElement('div');
      field.className = 'pelando-chat-ext-reason-field';
      const header = document.createElement('div');
      header.className = 'pelando-chat-ext-reason-field-header';
      const label = document.createElement('span');
      label.textContent = replyLabel(index);
      header.appendChild(label);
      if (replies.length > 1) {
        const removeButton = document.createElement('button');
        removeButton.type = 'button';
        removeButton.className = 'pelando-chat-ext-reason-remove';
        removeButton.textContent = 'Remover';
        removeButton.setAttribute('aria-label', 'Remover ' + replyLabel(index));
        removeButton.addEventListener('click', () => {
          replies.splice(0, replies.length, ...readReplies());
          replies.splice(index, 1);
          renderFields();
        });
        header.appendChild(removeButton);
      }
      const textarea = document.createElement('textarea');
      textarea.className = 'pelando-chat-ext-form-textarea';
      textarea.value = text;
      field.append(header, textarea);
      fields.appendChild(field);
    });
  }
  renderFields();

  const addButton = document.createElement('button');
  addButton.type = 'button';
  addButton.className = 'pelando-chat-ext-reason-add';
  addButton.textContent = '+ Adicionar resposta';
  addButton.addEventListener('click', () => {
    replies.splice(0, replies.length, ...readReplies(), '');
    renderFields();
    const textareas = fields.querySelectorAll('textarea');
    textareas[textareas.length - 1].focus();
  });
  form.appendChild(addButton);

  const errorEl = document.createElement('div');
  errorEl.className = 'pelando-chat-ext-form-error';
  form.appendChild(errorEl);

  function run(action) {
    Promise.resolve(action()).catch((err) => {
      errorEl.textContent = 'Não deu pra salvar: ' + err.message;
    });
  }

  const saveButton = document.createElement('button');
  saveButton.type = 'button';
  saveButton.className = 'pelando-chat-ext-form-save';
  saveButton.textContent = 'Salvar';
  saveButton.addEventListener('click', () => {
    const messages = readReplies()
      .map((text) => text.trim())
      .filter(Boolean);
    if (messages.length === 0) {
      errorEl.textContent = 'Escreva pelo menos uma resposta';
      return;
    }
    run(() => callbacks.onSave({ messages }));
  });
  form.appendChild(saveButton);

  if (reason.edited) {
    const resetButton = document.createElement('button');
    resetButton.type = 'button';
    resetButton.className = 'pelando-chat-ext-form-cancel';
    resetButton.textContent = 'Restaurar texto original';
    resetButton.addEventListener('click', () => run(() => callbacks.onReset()));
    form.appendChild(resetButton);
  }

  const cancelButton = document.createElement('button');
  cancelButton.type = 'button';
  cancelButton.className = 'pelando-chat-ext-form-cancel';
  cancelButton.textContent = 'Cancelar';
  cancelButton.addEventListener('click', () => callbacks.onCancel());
  form.appendChild(cancelButton);

  return form;
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = { createReasonsList, createReasonForm };
}
