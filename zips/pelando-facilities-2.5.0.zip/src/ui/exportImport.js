function createExportImportControls(callbacks, importError) {
  const container = document.createElement('div');
  container.className = 'pelando-chat-ext-export-import';

  const exportButton = document.createElement('button');
  exportButton.type = 'button';
  exportButton.className = 'pelando-chat-ext-export';
  exportButton.textContent = 'Exportar';
  exportButton.addEventListener('click', () => callbacks.onExport());
  container.appendChild(exportButton);

  const importLabel = document.createElement('label');
  importLabel.className = 'pelando-chat-ext-import';
  importLabel.textContent = 'Importar';
  const importInput = document.createElement('input');
  importInput.type = 'file';
  importInput.accept = 'application/json';
  importInput.style.display = 'none';
  importInput.addEventListener('change', () => {
    const file = importInput.files && importInput.files[0];
    if (file) {
      callbacks.onImport(file);
    }
    importInput.value = '';
  });
  importLabel.appendChild(importInput);
  container.appendChild(importLabel);

  // The full backup (every kind of data, to carry between Chrome profiles)
  // lives on its own page; these buttons only cover themes and messages.
  if (callbacks.onOpenBackup) {
    const backupButton = document.createElement('button');
    backupButton.type = 'button';
    backupButton.className = 'pelando-chat-ext-backup-link';
    backupButton.textContent = 'Backup entre perfis';
    backupButton.title = 'Exportar e importar todos os dados da extensão';
    backupButton.addEventListener('click', () => callbacks.onOpenBackup());
    container.appendChild(backupButton);
  }

  const errorEl = document.createElement('span');
  errorEl.className = 'pelando-chat-ext-export-import-error';
  errorEl.textContent = importError || '';
  container.appendChild(errorEl);

  return container;
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = { createExportImportControls };
}
