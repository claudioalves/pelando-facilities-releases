function positionTooltip(tooltip, anchor) {
  const anchorRect = anchor.getBoundingClientRect();
  const tooltipRect = tooltip.getBoundingClientRect();
  const left = Math.min(Math.max(8, anchorRect.left), window.innerWidth - tooltipRect.width - 8);
  const top = Math.max(8, anchorRect.top - tooltipRect.height - 6);
  tooltip.style.left = left + 'px';
  tooltip.style.top = top + 'px';
}

function createMessageList(messages, onSelect) {
  const list = document.createElement('div');
  list.className = 'pelando-chat-ext-message-list';

  let tooltip = null;
  function hideTooltip() {
    if (tooltip) {
      tooltip.remove();
      tooltip = null;
    }
  }

  messages.forEach((message) => {
    const option = document.createElement('button');
    option.type = 'button';
    option.className = 'pelando-chat-ext-message-option';
    option.textContent = message.nome;
    option.addEventListener('click', () => {
      hideTooltip();
      onSelect(message);
    });
    option.addEventListener('mouseenter', () => {
      hideTooltip();
      tooltip = document.createElement('div');
      tooltip.className = 'pelando-chat-ext-tooltip';
      tooltip.textContent = message.texto;
      document.body.appendChild(tooltip);
      positionTooltip(tooltip, option);
    });
    option.addEventListener('mouseleave', hideTooltip);
    list.appendChild(option);
  });
  return list;
}

// Search box over every message; `onSearch` runs on each keystroke.
function createMessageSearch(value, onSearch) {
  const search = document.createElement('input');
  search.type = 'search';
  search.className = 'pelando-chat-ext-search';
  search.placeholder = '🔍 Buscar mensagem (mín. 3 letras)';
  search.setAttribute('aria-label', 'Buscar mensagem pelo título ou texto');
  search.value = value || '';
  search.addEventListener('input', () => onSearch(search.value));
  // The chat may react to Enter on the page; the search needs no submit.
  search.addEventListener('keydown', (event) => {
    if (event.key === 'Enter') event.preventDefault();
    event.stopPropagation();
  });
  return search;
}

function createSearchEmptyState(text) {
  const empty = document.createElement('div');
  empty.className = 'pelando-chat-ext-search-empty';
  empty.textContent = text;
  return empty;
}

function createManageMessageList(messages, callbacks) {
  const list = document.createElement('div');
  list.className = 'pelando-chat-ext-message-list';

  let dragIndex = null;

  messages.forEach((message, index) => {
    const row = document.createElement('div');
    row.className = 'pelando-chat-ext-manage-row';

    const dragHandle = document.createElement('span');
    dragHandle.className = 'pelando-chat-ext-manage-drag-handle';
    dragHandle.textContent = '⠿';
    dragHandle.setAttribute('draggable', 'true');
    dragHandle.setAttribute('aria-label', 'Arrastar para reordenar');
    dragHandle.addEventListener('dragstart', (event) => {
      dragIndex = index;
      row.classList.add('pelando-chat-ext-manage-row-dragging');
      if (event.dataTransfer) event.dataTransfer.effectAllowed = 'move';
    });
    dragHandle.addEventListener('dragend', () => {
      dragIndex = null;
      row.classList.remove('pelando-chat-ext-manage-row-dragging');
    });
    row.appendChild(dragHandle);

    row.addEventListener('dragover', (event) => {
      event.preventDefault();
    });
    row.addEventListener('drop', (event) => {
      event.preventDefault();
      if (dragIndex === null || dragIndex === index) return;
      const reordered = messages.slice();
      const [moved] = reordered.splice(dragIndex, 1);
      reordered.splice(index, 0, moved);
      dragIndex = null;
      callbacks.onReorder(reordered);
    });

    const label = document.createElement('span');
    label.className = 'pelando-chat-ext-manage-label';
    label.textContent = message.nome;
    row.appendChild(label);

    const editButton = document.createElement('button');
    editButton.type = 'button';
    editButton.className = 'pelando-chat-ext-manage-edit';
    editButton.textContent = '✎';
    editButton.addEventListener('click', () => callbacks.onEdit(message));
    row.appendChild(editButton);

    // The greeting can't be deleted (see storage.js): only its text edited.
    if (typeof isProtectedMessage === 'function' && isProtectedMessage(message.id)) {
      const locked = document.createElement('span');
      locked.className = 'pelando-chat-ext-manage-locked';
      locked.textContent = '🔒';
      locked.title = 'A saudação não pode ser apagada';
      row.appendChild(locked);
    } else {
      const deleteButton = document.createElement('button');
      deleteButton.type = 'button';
      deleteButton.className = 'pelando-chat-ext-manage-delete';
      deleteButton.textContent = '🗑';
      deleteButton.addEventListener('click', () => callbacks.onDelete(message));
      row.appendChild(deleteButton);
    }

    list.appendChild(row);
  });

  const addButton = document.createElement('button');
  addButton.type = 'button';
  addButton.className = 'pelando-chat-ext-manage-add';
  addButton.textContent = '+ Adicionar mensagem';
  addButton.addEventListener('click', () => callbacks.onAdd());
  list.appendChild(addButton);

  return list;
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = { createMessageList, createManageMessageList, createMessageSearch, createSearchEmptyState };
}
