// Content-script CSS resolves url() against the page's own origin, not the
// extension package, so icon images must be pointed at via
// chrome.runtime.getURL() from JS instead of a static background/mask-image
// in styles.css.
function createIconSpan(fileName) {
  const icon = document.createElement('span');
  icon.className = 'pelando-chat-ext-icon';
  const url = chrome.runtime.getURL('icons/' + fileName);
  icon.style.webkitMaskImage = 'url(' + url + ')';
  icon.style.maskImage = 'url(' + url + ')';
  return icon;
}

function createInjectedButton(onClick) {
  const button = document.createElement('button');
  button.type = 'button';
  button.className = 'chat-input-image-button pelando-chat-ext-button pelando-chat-ext-injected';
  button.setAttribute('aria-label', 'Mensagens prontas');
  button.appendChild(createIconSpan('texto-do-blog.png'));
  button.addEventListener('click', onClick);
  return button;
}

function createQuickAddButton(onClick) {
  const button = document.createElement('button');
  button.type = 'button';
  button.className = 'chat-input-image-button pelando-chat-ext-quickadd-button pelando-chat-ext-injected';
  button.setAttribute('aria-label', 'Cadastrar mensagem rápida');
  button.appendChild(createIconSpan('campo-da-caneta.png'));
  button.addEventListener('click', onClick);
  return button;
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = { createInjectedButton, createQuickAddButton };
}
