const PELANDO_BO_NEXT_COUNTRY_CLASS = 'pelando-bo-next-country';
// "Brasil: 3 itens esperando moderação", "Germany: 4 items waiting for
// moderation": the country's name, then how many are waiting.
const PELANDO_BO_COUNTRY_LABEL = /^\s*([^:]+):\s*(\d+)\b/;

// Each country's backoffice, by the two letters of its flag.
const PELANDO_BO_COUNTRY_HOSTS = {
  BR: 'bo.pelando.com.br',
  US: 'bo.promoninja.com',
  AR: 'bo.promoninja.com.ar',
  GB: 'bo.promoninja.co.uk',
  ES: 'bo.promoninja.es',
  DE: 'bo.promoninja.de',
  FR: 'bo.promoninja.fr',
};
const PELANDO_BO_MODERATION_LIST = /^\/moderar-promocoes\/?$/;

// "🇧🇷" is made of the regional indicator letters B and R.
function flagCountryCode(text) {
  const flag = (text || '').match(/[\u{1F1E6}-\u{1F1FF}]{2}/u);
  if (!flag) return null;
  return Array.from(flag[0])
    .map(function (letter) {
      return String.fromCharCode(letter.codePointAt(0) - 0x1f1e6 + 65);
    })
    .join('');
}

// Where "Próximo" takes to: the country's moderation list.
function moderationListUrl(country) {
  const host = PELANDO_BO_COUNTRY_HOSTS[flagCountryCode(country.button.textContent)];
  return host ? 'https://' + host + '/moderar-promocoes' : null;
}

function countryOfButton(button) {
  const match = (button.getAttribute('aria-label') || '').match(PELANDO_BO_COUNTRY_LABEL);
  return match ? { button: button, name: match[1].trim(), count: Number(match[2]) } : null;
}

// The header's country buttons (Brasil, Estados Unidos, ...), in their order,
// with the one of this backoffice marked as current. Each sits in its own
// span inside the menu.
function findCountryMenu(doc) {
  const triggers = doc.querySelectorAll('button[aria-current="true"][data-slot="tooltip-trigger"]');
  for (let i = 0; i < triggers.length; i++) {
    const current = countryOfButton(triggers[i]);
    const menu = triggers[i].parentElement && triggers[i].parentElement.parentElement;
    if (!current || !menu) continue;
    const countries = Array.prototype.map
      .call(menu.querySelectorAll(':scope > * > button[data-slot="tooltip-trigger"]'), countryOfButton)
      .filter(Boolean);
    if (countries.length > 1) return { menu: menu, countries: countries, currentIndex: countries.findIndex((c) => c.button === triggers[i]) };
  }
  return null;
}

// The first country after the current one, going around the list, with
// something waiting for moderation.
function nextCountry(menu) {
  const total = menu.countries.length;
  for (let step = 1; step < total; step++) {
    const country = menu.countries[(menu.currentIndex + step) % total];
    if (country.count > 0) return country;
  }
  return null;
}

function nextCountryWithPending(doc) {
  const menu = findCountryMenu(doc);
  const country = menu && nextCountry(menu);
  return country ? country.button : null;
}

function createNextCountryButton(doc, reload, navigate) {
  const button = doc.createElement('button');
  button.type = 'button';
  button.textContent = 'Próximo';
  // Filled with the site's own color (the page's classes: Pelando's orange,
  // Promoninja's red), shaped like the country buttons.
  button.className =
    'inline-flex items-center justify-center rounded-xl px-3 text-sm font-semibold cursor-pointer ' +
    'bg-primary text-primary-foreground hover:bg-primary/90 ' +
    PELANDO_BO_NEXT_COUNTRY_CLASS;
  button.style.alignSelf = 'stretch';
  // On the list, clicking the country's own button keeps the page's way of
  // switching; elsewhere that button opens the other backoffice's home page,
  // so the list is opened directly. With nowhere to go, reloading brings
  // fresh counts.
  button.addEventListener('click', function () {
    const menu = findCountryMenu(doc);
    const country = menu && nextCountry(menu);
    if (!country) return reload();
    const url = PELANDO_BO_MODERATION_LIST.test(doc.location.pathname) ? null : moderationListUrl(country);
    if (url) navigate(url);
    else country.button.click();
  });
  return button;
}

// "Próximo", left of the country menu, opens the next country with
// promotions waiting for moderation; when there's none, it reloads the page.
// The counts change while the page is open, so this runs again on every
// update.
// On every backoffice page with the country menu.
function syncNextCountryButton(doc, options) {
  let button = doc.querySelector('.' + PELANDO_BO_NEXT_COUNTRY_CLASS);
  const menu = findCountryMenu(doc);
  if (!menu) {
    if (button) button.remove();
    return;
  }
  if (!button) {
    const reload = (options && options.reload) || function () {
      doc.location.reload();
    };
    const navigate = (options && options.navigate) || function (url) {
      doc.location.assign(url);
    };
    button = createNextCountryButton(doc, reload, navigate);
  }
  if (menu.menu.firstElementChild !== button) menu.menu.prepend(button);
  const country = nextCountry(menu);
  const title = country
    ? 'Ir para ' + country.name + ' (' + country.count + ')'
    : 'Nenhum outro país com promoções esperando moderação. Clique para atualizar a página';
  if (button.title !== title) button.title = title;
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = { nextCountryWithPending, syncNextCountryButton };
}
