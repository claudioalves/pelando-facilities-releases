const PELANDO_DISCUSSION_AI_BUTTON_CLASS = 'pelando-discussion-ai-button';
const PELANDO_DISCUSSION_AI_URL = 'https://gemini.google.com/';
const PELANDO_DISCUSSION_AI_LABEL = 'Gerar título de discussão no Gemini';
const PELANDO_DISCUSSION_AI_ICON_FILE = 'icons/microchip-ia.png';

// Deals and discussions share the backoffice edit page (/t/<slug> redirects
// to /promocao/<id>); only a deal's form has Link original and Preço.
function isDiscussionForm(doc) {
  if (!doc.querySelector('input[name="title"]')) return false;
  return !doc.querySelector('[name="sourceUrl"], [name="price"]');
}

function buildDiscussionPrompt(title, description) {
  return 'Transforme em titulo para discussão em forum:\n' + title + '\n' + description;
}

function discussionFormItemByLabel(doc, labelText) {
  const items = doc.querySelectorAll('[data-slot="form-item"]');
  for (const item of items) {
    const label = item.querySelector('label');
    if (label && label.textContent.replace(/\*/g, '').trim() === labelText) return item;
  }
  return null;
}

// The Quill editor keeps one block per paragraph.
function discussionDescriptionText(doc) {
  const item = discussionFormItemByLabel(doc, 'Descrição');
  const editor = item && item.querySelector('.ql-editor');
  if (!editor) return '';
  const blocks = editor.children.length ? Array.from(editor.children) : [editor];
  return blocks
    .map(function (block) {
      return block.textContent.trim();
    })
    .filter(Boolean)
    .join('\n');
}

// Same icon as the chat's AI button (see ui/tabBar.js).
function discussionAiIconUrl() {
  // getURL throws "Extension context invalidated" once the extension is
  // reloaded with the tab still open.
  try {
    return chrome.runtime.getURL(PELANDO_DISCUSSION_AI_ICON_FILE);
  } catch (err) {
    return PELANDO_DISCUSSION_AI_ICON_FILE;
  }
}

function createDiscussionAiButton(doc, deps) {
  const button = doc.createElement('button');
  button.type = 'button';
  button.className = PELANDO_DISCUSSION_AI_BUTTON_CLASS;
  button.title = PELANDO_DISCUSSION_AI_LABEL;
  button.setAttribute('aria-label', PELANDO_DISCUSSION_AI_LABEL);
  const icon = doc.createElement('span');
  icon.className = 'pelando-discussion-ai-icon';
  const url = 'url(' + discussionAiIconUrl() + ')';
  icon.style.webkitMaskImage = url;
  icon.style.maskImage = url;
  button.appendChild(icon);
  button.addEventListener('click', async function (event) {
    event.preventDefault();
    event.stopPropagation();
    const title = doc.querySelector('input[name="title"]');
    const prompt = buildDiscussionPrompt(title ? title.value.trim() : '', discussionDescriptionText(doc));
    try {
      await deps.copyText(prompt);
    } catch (err) {
      console.error('[pelando-discussion-ai] falha ao copiar o texto:', err);
    }
    deps.openTab(PELANDO_DISCUSSION_AI_URL);
  });
  return button;
}

function syncDiscussionAiButton(doc, deps) {
  const existing = doc.querySelector('.' + PELANDO_DISCUSSION_AI_BUTTON_CLASS);
  if (!isDiscussionForm(doc)) {
    if (existing) existing.remove();
    return;
  }
  if (existing) return;
  const title = doc.querySelector('input[name="title"]');
  const button = createDiscussionAiButton(doc, deps);
  // The form item is a grid: sharing the input's row lays the button over the
  // right end of the box, without moving the page's own input.
  const row = String(Array.prototype.indexOf.call(title.parentElement.children, title) + 1);
  button.style.gridRow = row;
  // The input takes the row from here too (see dealEdit.css): left to
  // auto-placement it would move down a row.
  title.parentElement.style.setProperty('--pelando-discussion-ai-row', row);
  title.after(button);
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = {
    isDiscussionForm,
    buildDiscussionPrompt,
    syncDiscussionAiButton,
  };
}
