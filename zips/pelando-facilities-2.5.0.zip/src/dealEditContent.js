// Starts only for a Pelando account (see access.js).
pelandoWhenAllowed(function () {
  let scheduled = false;

  // Lists load more cards on scroll, so re-scan on DOM changes, batched to
  // one pass per frame.
  function scheduleInjection() {
    if (scheduled) return;
    scheduled = true;
    requestAnimationFrame(function () {
      scheduled = false;
      injectEditButtons(document, window.location.href);
      keepEditorsUntranslated(document);
    });
  }

  const observer = new MutationObserver(scheduleInjection);
  observer.observe(document.body, { childList: true, subtree: true });

  injectEditButtons(document, window.location.href);
  keepEditorsUntranslated(document);
});
