// "Testar Promoção", the service worker's side: opens the deal's store in a
// small window of its own, runs the store's steps there one at a time and tells the
// backoffice how it goes. Each step injects compare.js and the store's file
// (chrome.scripting) and calls pelandoPriceTestStep. Reads and writes nothing
// in chrome.storage.

// Paths from the extension's root, as chrome.scripting wants them.
const PRICE_TEST_STORES = {
  magalu: {
    // The link can lead anywhere (redirects, affiliate pages): the adapter
    // only runs on the store's own sites.
    hosts: /(^|\.)(magazineluiza|magalu|magazinevoce)\.com(\.br)?$/i,
    files: ['src/priceTest/compare.js', 'src/priceTest/stores/magalu.js'],
    steps: [
      { key: 'checkProduct', name: 'produto', label: () => 'Abrindo produto na Magalu…' },
      { key: 'buyNow', name: 'Comprar agora', label: () => 'Indo para o checkout…' },
      { key: 'skipProtection', name: 'garantia estendida', label: () => 'Pulando a garantia estendida…' },
      { key: 'pickAddress', name: 'endereço', label: () => 'Escolhendo o endereço padrão…' },
      { key: 'pickShipping', name: 'frete', label: () => 'Escolhendo frete…' },
      {
        key: 'applyCoupon',
        name: 'cupom',
        label: (request) => 'Aplicando cupom ' + request.coupon + '…',
        when: (request) => !!request.coupon,
      },
      { key: 'selectPix', name: 'PIX', label: () => 'Selecionando PIX…' },
      { key: 'readTotals', name: 'valores', label: () => 'Calculando…' },
    ],
  },
};

function priceTestErrorText(code, detail, step, request, deps) {
  const where = step ? step.name : '';
  switch (code) {
    case 'NOT_MAGALU':
      return 'Por enquanto o teste só funciona com promoções da Magalu';
    case 'NO_URL':
      return 'A promoção não tem link da loja';
    case 'NO_PRICE':
      return 'A promoção não tem preço cadastrado';
    case 'SESSION_EXPIRED':
      return 'Sessão expirada: faça login na Magalu para testar novamente';
    case 'OUT_OF_STOCK':
      return 'Produto indisponível na Magalu';
    case 'COUPON_REJECTED':
      return 'Cupom "' + request.coupon + '" recusado pela Magalu: "' + detail.message + '"';
    case 'NEEDS_HUMAN':
      return 'Ação necessária na Magalu não foi resolvida em ' + Math.round(deps.humanWaitMs / 1000) + ' s: resolva na aba e teste de novo';
    case 'SELECTOR_NOT_FOUND':
      return 'Não encontrei "' + detail.element + '" na etapa "' + where + '" (a Magalu pode ter mudado a página)';
    case 'TIMEOUT':
      return 'A Magalu demorou demais na etapa "' + where + '"';
    case 'WRONG_SITE':
      return 'O link da promoção não abriu a Magalu (' + detail.host + ')';
    case 'CANCELLED':
      return 'Teste cancelado (a aba da Magalu foi fechada)';
    case 'BAD_TOTAL':
      return 'Não consegui ler o total na Magalu ("' + detail.text + '")';
    case 'BAD_SHIPPING':
      return 'Não consegui ler o frete na Magalu ("' + detail.text + '")';
    default:
      if (!step) return 'Erro no teste: ' + ((detail && detail.message) || code);
      return 'Erro na etapa "' + where + '": ' + ((detail && detail.message) || code);
  }
}

// The tab's host when it isn't one of the store's, else null.
async function priceTestForeignHost(tabId, store, deps) {
  const host = await deps.tabHost(tabId);
  return store.hosts.test(host) ? null : host;
}

// One step, within the step's time (and never past the test's deadline). A
// step that fails because the page changed under it (a redirect), or answers
// nothing, runs once more on the new page.
async function priceTestRunStep(tabId, files, step, input, deps, deadline) {
  for (let attempt = 0; ; attempt++) {
    try {
      const limitMs = Math.max(0, Math.min(deps.stepTimeoutMs, deadline - deps.now()));
      const result = await Promise.race([
        deps.runStep(tabId, files, step.key, input),
        deps.timer(limitMs).then(function () {
          return { ok: false, code: 'TIMEOUT' };
        }),
      ]);
      if (!result) throw new Error('sem resposta da página');
      if (result.code === 'TIMEOUT' && !(await deps.isTabOpen(tabId))) return { ok: false, code: 'CANCELLED' };
      return result;
    } catch (err) {
      if (!(await deps.isTabOpen(tabId))) return { ok: false, code: 'CANCELLED' };
      if (attempt > 0) return { ok: false, code: 'STEP_FAILED', detail: { message: err.message } };
      await deps.waitForLoad(tabId, deps.stepTimeoutMs);
    }
  }
}

// A captcha or confirmation: tell the backoffice, and try the step again
// every few seconds while someone solves it in the tab.
async function priceTestWaitForHuman(tabId, files, step, input, deps) {
  deps.notify({ type: 'priceTest:needsHuman', tabId: tabId, message: 'Ação necessária na Magalu: resolva na aba e o teste continua' });
  const until = deps.now() + deps.humanWaitMs;
  while (deps.now() < until) {
    await deps.sleep(deps.humanRetryMs);
    // Bounded by humanWaitMs, not by the test's deadline (which waits).
    const result = await priceTestRunStep(tabId, files, step, input, deps, Infinity);
    if (result.ok || result.code !== 'NEEDS_HUMAN') return result;
  }
  return { ok: false, code: 'NEEDS_HUMAN' };
}

// The store refused the deal's coupon and the test went on without it: say
// so, then the usual result, and how much more it is than the deal's.
function priceTestCouponRejectedLines(compared, coupon, refusal) {
  const lines = ['Cupom "' + coupon + '" não funcionou: "' + refusal + '"'].concat(priceTestResultLines(compared));
  if (compared.status === 'validated' || compared.productCents < compared.advertisedCents) return lines;
  return lines.concat(['Sem o cupom, está ' + priceTestFormat(compared.productCents - compared.advertisedCents) + ' mais caro que a promoção']);
}

// The area (CSS pixels of a page viewportWidth wide) in the picture's pixels,
// kept inside the picture.
function priceTestCropBox(area, imageWidth, imageHeight) {
  const scale = imageWidth / area.viewportWidth;
  const sx = Math.min(imageWidth - 1, Math.max(0, Math.round(area.x * scale)));
  const sy = Math.min(imageHeight - 1, Math.max(0, Math.round(area.y * scale)));
  return {
    sx: sx,
    sy: sy,
    sw: Math.max(1, Math.min(imageWidth - sx, Math.round(area.width * scale))),
    sh: Math.max(1, Math.min(imageHeight - sy, Math.round(area.height * scale))),
  };
}

// "2,1 s": tenths of a second, the Brazilian way.
function priceTestSeconds(ms) {
  return (Math.max(0, ms) / 1000).toFixed(1).replace('.', ',') + ' s';
}

// The result's last line: how long the test took, from the click.
function priceTestDurationLine(ms) {
  const seconds = Math.round(ms / 1000);
  if (seconds < 1) return 'O teste da promoção demorou menos de 1 segundo';
  return 'O teste da promoção demorou ' + seconds + (seconds === 1 ? ' segundo' : ' segundos');
}

async function runPriceTest(request, deps) {
  const started = deps.now();
  let tabId = null;
  let failedStep = null;
  // How long each step took, from its start to the next one's (the first
  // counts the tab opening): where a slow or failed test spent its time.
  const timings = [];
  let stepStarted = started;
  function stepDone(name, note) {
    const now = deps.now();
    timings.push(name + ' ' + priceTestSeconds(now - stepStarted) + (note || ''));
    stepStarted = now;
  }
  function timingsText() {
    return timings.length ? 'Tempo por etapa: ' + timings.join(' · ') : undefined;
  }

  function fail(code, detail) {
    if (tabId !== null && failedStep) stepDone(failedStep.name, ' (parou aqui)');
    const message = {
      type: 'priceTest:error',
      code: code,
      message: priceTestErrorText(code, detail || {}, failedStep, request, deps),
      tabId: tabId,
    };
    const text = timingsText();
    if (text) message.timings = text;
    deps.notify(message);
    return message;
  }

  const store = Object.prototype.hasOwnProperty.call(PRICE_TEST_STORES, request.store) ? PRICE_TEST_STORES[request.store] : null;
  if (!store) return fail('NOT_MAGALU');
  if (!request.url) return fail('NO_URL');
  const advertisedCents = priceTestCents(request.price);
  if (!advertisedCents) return fail('NO_PRICE');

  try {
    const steps = store.steps.filter(function (step) {
      return !step.when || step.when(request);
    });
    const input = { coupon: request.coupon || null, timeoutMs: deps.stepTimeoutMs - 2000 };
    let deadline = deps.now() + deps.totalTimeoutMs;
    let totals = null;
    let couponRejected = null;

    deps.notify({ type: 'priceTest:progress', step: steps[0].key, label: steps[0].label(request) });
    tabId = await deps.openTab(request.url);
    await deps.waitForLoad(tabId, deps.stepTimeoutMs);

    for (const step of steps) {
      failedStep = step;
      if (deps.now() > deadline) return fail('TIMEOUT');
      const foreign = await priceTestForeignHost(tabId, store, deps);
      if (foreign !== null) return fail('WRONG_SITE', { host: foreign });
      // The first step's progress went out before opening the tab.
      if (step !== steps[0]) deps.notify({ type: 'priceTest:progress', step: step.key, label: step.label(request) });
      let result = await priceTestRunStep(tabId, store.files, step, input, deps, deadline);
      if (!result.ok && result.code === 'NEEDS_HUMAN') {
        // Time spent waiting for a person doesn't count against the test.
        const waitStarted = deps.now();
        result = await priceTestWaitForHuman(tabId, store.files, step, input, deps);
        deadline += deps.now() - waitStarted;
      }
      if (!result.ok) return fail(result.code, result.detail);
      if (result.navigates) await deps.waitForLoad(tabId, deps.stepTimeoutMs);
      if (step.key === 'readTotals') totals = result;
      if (result.couponRejected) couponRejected = result.couponRejected;
      stepDone(step.name);
    }
    failedStep = null;

    const foreign = await priceTestForeignHost(tabId, store, deps);
    if (foreign !== null) return fail('WRONG_SITE', { host: foreign });
    const totalCents = priceTestCents(totals.totalText);
    if (totalCents === null) return fail('BAD_TOTAL', { text: totals.totalText });
    let shippingCents = 0;
    if (totals.shippingText && !/gr[aá]tis/i.test(totals.shippingText)) {
      shippingCents = priceTestCents(totals.shippingText);
      if (shippingCents === null) return fail('BAD_SHIPPING', { text: totals.shippingText });
    }
    const compared = comparePrice({ advertisedCents: advertisedCents, totalCents: totalCents, shippingCents: shippingCents });
    // A picture of the review's values (the total in PIX) for the moderator,
    // taken before the window closes: the page first has to be clear of its
    // loading blur, at most 5 s more. Without it the result still goes out.
    let screenshot = null;
    try {
      const frame = { key: 'frameTotals', name: 'print' };
      const framed = await priceTestRunStep(tabId, store.files, frame, Object.assign({}, input, { timeoutMs: 5000 }), deps, deps.now() + 7000);
      if (framed && framed.ok && deps.capture) screenshot = await deps.capture(tabId, framed.area);
    } catch (err) {
      screenshot = null;
    }
    // A tab that won't close must not discard the result.
    try {
      await deps.closeTab(tabId);
    } catch (err) {
      // Left open: the backoffice still gets the result.
    }
    const lines = (couponRejected ? priceTestCouponRejectedLines(compared, request.coupon, couponRejected) : priceTestResultLines(compared)).concat(
      priceTestDurationLine(deps.now() - started)
    );
    const message = { type: 'priceTest:result', status: compared.status, lines: lines, timings: timingsText() };
    if (screenshot) message.screenshot = screenshot;
    deps.notify(message);
    return message;
  } catch (err) {
    if (tabId !== null && !(await deps.isTabOpen(tabId))) return fail('CANCELLED');
    return fail('STEP_FAILED', { message: err.message });
  }
}

// The test in progress, if any: one at a time in the browser. Backoffice
// tabs that asked for it ("watchers") get every message; one asking while it
// runs gets the latest right away.
let priceTestRunning = null;

function handlePriceTestStart(request, senderTabId, deps) {
  if (priceTestRunning) {
    priceTestRunning.watchers.add(senderTabId);
    if (priceTestRunning.last) deps.send(senderTabId, priceTestRunning.last);
    return { started: false, dealId: priceTestRunning.dealId };
  }
  const running = { watchers: new Set([senderTabId]), last: null, dealId: request.dealId };
  priceTestRunning = running;
  function notify(original) {
    // The backoffice tab shows only the messages of its own deal.
    const message = Object.assign({}, original, { dealId: running.dealId });
    running.last = message;
    running.watchers.forEach(function (tabId) {
      deps.send(tabId, message);
    });
  }
  runPriceTest(request, Object.assign({}, deps, { notify: notify }))
    .catch(function (err) {
      notify({ type: 'priceTest:error', code: 'STEP_FAILED', message: 'Erro no teste: ' + err.message, tabId: null });
    })
    .finally(function () {
      if (priceTestRunning === running) priceTestRunning = null;
    });
  return { started: true };
}

function resetPriceTest() {
  priceTestRunning = null;
}

// True in a web page that is not the one a step just left: the step that
// navigates flags its page (pelandoPriceTestStep), and a new document starts
// without the flag. Needs a body for the step to search.
function priceTestNewPageProbe() {
  return /^https?:$/.test(location.protocol) && !window.pelandoPriceTestLeft && !!document.body;
}

// Resolves once the tab shows a new page, without waiting for it to finish
// loading (images, ads): the next step looks for its button and clicks as
// soon as it shows. A page that changes without a full load (parts of the
// checkout are a single-page app) never starts loading: after a short grace
// the step goes on, and its own waits do the rest.
function priceTestWaitForLoad(tabId, timeoutMs) {
  return new Promise(function (resolve) {
    let loading = false;
    let finished = false;
    let probing = false;
    const started = Date.now();
    function done() {
      if (finished) return;
      finished = true;
      chrome.tabs.onUpdated.removeListener(listener);
      clearInterval(poll);
      clearTimeout(limit);
      resolve();
    }
    function listener(id, info) {
      if (id === tabId && info.status === 'loading') loading = true;
    }
    chrome.tabs.onUpdated.addListener(listener);
    chrome.tabs.get(tabId).then(
      function (tab) {
        if (tab.status === 'loading') loading = true;
      },
      done
    );
    const poll = setInterval(function () {
      if (!loading) {
        if (Date.now() - started >= 2000) done();
        return;
      }
      if (probing) return;
      probing = true;
      chrome.scripting
        .executeScript({ target: { tabId: tabId }, injectImmediately: true, func: priceTestNewPageProbe })
        .then(
          function (injections) {
            if (injections && injections[0] && injections[0].result === true) done();
          },
          function () {
            // The page is being replaced: try again on the next tick.
          }
        )
        .finally(function () {
          probing = false;
        });
    }, 150);
    const limit = setTimeout(done, timeoutMs);
  });
}

function chromePriceTestDeps() {
  return {
    stepTimeoutMs: 20000,
    totalTimeoutMs: 90000,
    humanWaitMs: 60000,
    humanRetryMs: 3000,
    now: function () {
      return Date.now();
    },
    sleep: function (ms) {
      return new Promise(function (resolve) {
        setTimeout(resolve, ms);
      });
    },
    timer: function (ms) {
      return new Promise(function (resolve) {
        setTimeout(resolve, ms);
      });
    },
    // A small window of its own, on top in the corner of the current one: in
    // a background tab Chrome slows timers down, pauses animations and skips
    // the parts of the page out of view (the product page's shipping check,
    // which tells "Produto esgotado!"). Under 768 px wide Magalu shows its
    // phone layout, which the steps don't know.
    openTab: async function (url) {
      const size = { width: 800, height: 640 };
      const options = Object.assign({ url: url, type: 'popup', focused: true }, size);
      try {
        const current = await chrome.windows.getLastFocused();
        options.left = current.left + current.width - size.width - 16;
        options.top = current.top + current.height - size.height - 16;
      } catch (err) {
        // Chrome places it.
      }
      const win = await chrome.windows.create(options);
      return win.tabs[0].id;
    },
    closeTab: function (tabId) {
      return chrome.tabs.remove(tabId).catch(function () {});
    },
    tabHost: async function (tabId) {
      try {
        return new URL((await chrome.tabs.get(tabId)).url).hostname;
      } catch (err) {
        return '';
      }
    },
    isTabOpen: function (tabId) {
      return chrome.tabs.get(tabId).then(
        function () {
          return true;
        },
        function () {
          return false;
        }
      );
    },
    waitForLoad: priceTestWaitForLoad,
    // What the store window shows ("<all_urls>" lets the extension take it),
    // cut down to the area (the review's values).
    capture: async function (tabId, area) {
      const tab = await chrome.tabs.get(tabId);
      const shot = await chrome.tabs.captureVisibleTab(tab.windowId, { format: 'png' });
      const image = await createImageBitmap(await (await fetch(shot)).blob());
      const box = priceTestCropBox(area, image.width, image.height);
      const canvas = new OffscreenCanvas(box.sw, box.sh);
      canvas.getContext('2d').drawImage(image, box.sx, box.sy, box.sw, box.sh, 0, 0, box.sw, box.sh);
      const bytes = new Uint8Array(await (await canvas.convertToBlob({ type: 'image/jpeg', quality: 0.9 })).arrayBuffer());
      let binary = '';
      for (let i = 0; i < bytes.length; i += 0x8000) binary += String.fromCharCode.apply(null, bytes.subarray(i, i + 0x8000));
      return 'data:image/jpeg;base64,' + btoa(binary);
    },
    runStep: async function (tabId, files, step, input) {
      // Right away, not when the page is idle: the step waits for its own elements.
      await chrome.scripting.executeScript({ target: { tabId: tabId }, injectImmediately: true, files: files });
      const injections = await chrome.scripting.executeScript({
        target: { tabId: tabId },
        injectImmediately: true,
        func: function (step, input) {
          return pelandoPriceTestStep(step, input);
        },
        args: [step, input],
      });
      return injections && injections[0] ? injections[0].result : null;
    },
    send: function (tabId, message) {
      chrome.tabs.sendMessage(tabId, message).catch(function () {
        // That backoffice tab was closed or reloaded: nothing to show there.
      });
    },
  };
}

async function focusPriceTestTab(tabId) {
  const tab = await chrome.tabs.update(tabId, { active: true });
  await chrome.windows.update(tab.windowId, { focused: true });
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = { runPriceTest, handlePriceTestStart, resetPriceTest, chromePriceTestDeps, focusPriceTestTab, priceTestWaitForLoad, priceTestCropBox, PRICE_TEST_STORES };
}
