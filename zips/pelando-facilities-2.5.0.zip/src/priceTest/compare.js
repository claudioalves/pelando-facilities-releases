// "Testar Promoção": money as integer cents, and whether the store's PIX
// price matches the deal's. Loaded by the service worker (importScripts) and
// injected into the store's tab with stores/<store>.js, again on every step:
// only function declarations at the top level, since a second const/let
// would throw there.

// Cents from a number of reais (the deal's price) or from the first amount
// written the Brazilian way in a text ("Total R$ 1.299,00 em até 10x").
function priceTestCents(value) {
  if (typeof value === 'number') return Number.isFinite(value) ? Math.round(value * 100) : null;
  const match = String(value || '').match(/(\d{1,3}(?:\.\d{3})+|\d+),(\d{2})(?!\d)/);
  if (!match) return null;
  return Number(match[1].replace(/\./g, '')) * 100 + Number(match[2]);
}

function priceTestFormat(cents) {
  return (cents / 100).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' }).replace(/\s/g, ' ');
}

// The product's price is the PIX total minus shipping: deals are posted
// without shipping. Rounding at the store can be a cent off either way:
// that is the same price ("validated", green). Under 5% of the deal's price
// is a small change ("slightly", yellow); 5% or more, a real one ("diverges",
// red).
function comparePrice(input) {
  const toleranceCents = 1;
  const shippingCents = input.shippingCents || 0;
  const productCents = input.totalCents - shippingCents;
  const gap = Math.abs(productCents - input.advertisedCents);
  let status = 'diverges';
  if (gap <= toleranceCents) status = 'validated';
  else if (gap * 100 < input.advertisedCents * 5) status = 'slightly';
  return {
    status: status,
    advertisedCents: input.advertisedCents,
    productCents: productCents,
    shippingCents: shippingCents,
    shippingCharged: shippingCents > 0,
  };
}

function priceTestVerdict(result) {
  if (result.status === 'validated') return 'Preço validado';
  if (result.status === 'slightly') return 'Preço um pouco alterado';
  return result.productCents > result.advertisedCents ? 'Preço mudou para maior' : 'Preço mudou para menor';
}

// One fact per line: the verdict, the shipping, the deal's price and the
// tested PIX price (always without shipping).
function priceTestResultLines(result) {
  return [
    priceTestVerdict(result),
    'Frete: ' + (result.shippingCharged ? priceTestFormat(result.shippingCents) : 'grátis'),
    'Valor da promoção: ' + priceTestFormat(result.advertisedCents),
    'Valor do teste (sem frete): ' + priceTestFormat(result.productCents),
  ];
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = { priceTestCents, priceTestFormat, comparePrice, priceTestResultLines };
}
