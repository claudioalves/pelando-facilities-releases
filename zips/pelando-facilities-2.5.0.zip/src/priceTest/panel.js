// "Testar Promoção" on the backoffice deal page: asks the service worker to
// check the deal's price at the store's checkout (src/priceTest/runner.js) and
// shows how it goes below the button. Only on deals of a store the test
// knows: Magalu, for now.
const PELANDO_PRICE_TEST_CLASS = 'pelando-price-test';

// The stores in PRICE_TEST_STORES (runner.js, in the service worker).
const PRICE_TEST_SUPPORTED_STORES = ['magalu'];

// What the test needs from the backoffice deal.
function priceTestRequestFromDeal(deal) {
  return {
    dealId: deal.id,
    store: storeBrandFor(deal),
    url: deal.sourceUrl || deal.redirectUrl || null,
    price: typeof deal.price === 'number' ? deal.price : null,
    coupon: deal.couponCode || null,
  };
}

// If the service worker dies mid-test nothing more arrives: after this long
// without a message the panel says so instead of hanging. Longer after a
// request for a person (a captcha is solved at human speed).
const PELANDO_PRICE_TEST_SILENCE_MS = 30000;
const PELANDO_PRICE_TEST_HUMAN_SILENCE_MS = 75000;

function priceTestDisarm(status) {
  if (status.pelandoCancelWatchdog) status.pelandoCancelWatchdog();
  status.pelandoCancelWatchdog = null;
}

function priceTestArm(status, ms, deps) {
  priceTestDisarm(status);
  status.pelandoCancelWatchdog = deps.setTimer(function () {
    status.pelandoCancelWatchdog = null;
    renderPriceTestStatus(status, { type: 'priceTest:error', message: 'O teste parou de responder. Tente de novo.' }, deps);
  }, ms);
}

function renderPriceTestStatus(status, message, deps) {
  const kinds = { 'priceTest:progress': 'running', 'priceTest:needsHuman': 'attention', 'priceTest:error': 'error' };
  const results = { validated: 'ok', slightly: 'slight' };
  const kind = message.type === 'priceTest:result' ? results[message.status] || 'diverges' : kinds[message.type] || 'running';
  status.hidden = false;
  status.className = PELANDO_PRICE_TEST_CLASS + '-status ' + PELANDO_PRICE_TEST_CLASS + '-status--' + kind;
  status.textContent = '';
  (message.lines || [message.label || message.message]).forEach(function (text) {
    const line = status.ownerDocument.createElement('div');
    // In a result, the deal's price and the tested one stand out in the
    // result's color: green kept, yellow under 5% off, red 5% or more.
    const price = message.type === 'priceTest:result' && /^(Valor da promoção|Valor do teste \(sem frete\)): (.+)$/.exec(text);
    if (price) {
      const value = status.ownerDocument.createElement('strong');
      value.className = PELANDO_PRICE_TEST_CLASS + '-price ' + PELANDO_PRICE_TEST_CLASS + '-price--' + kind;
      value.textContent = price[2];
      line.append(price[1] + ': ', value);
    } else {
      line.textContent = text;
    }
    status.appendChild(line);
  });
  // Where the time went, step by step (runner.js).
  if (message.timings) {
    const timings = status.ownerDocument.createElement('div');
    timings.className = PELANDO_PRICE_TEST_CLASS + '-timings';
    timings.textContent = message.timings;
    status.appendChild(timings);
  }
  // The review's values as the test saw them, last and full width; larger
  // on click. Only the image the service worker took (a JPEG data URL).
  if (message.screenshot && /^data:image\/jpeg;base64,/.test(message.screenshot)) {
    const shot = status.ownerDocument.createElement('img');
    shot.className = PELANDO_PRICE_TEST_CLASS + '-screenshot';
    shot.src = message.screenshot;
    shot.alt = 'Revisão do pedido na Magalu, com o total no PIX';
    shot.title = 'Clique para ampliar';
    shot.addEventListener('click', function () {
      shot.classList.toggle(PELANDO_PRICE_TEST_CLASS + '-screenshot--zoomed');
    });
    status.appendChild(shot);
  }
  if (message.tabId && (kind === 'error' || kind === 'attention')) {
    const focus = status.ownerDocument.createElement('button');
    focus.type = 'button';
    focus.className = PELANDO_PRICE_TEST_CLASS + '-focus';
    focus.textContent = 'Ver aba';
    focus.addEventListener('click', function () {
      deps.focusTab(message.tabId);
    });
    status.appendChild(focus);
  }
}

function createPriceTestBox(doc, dealId, deps) {
  const box = doc.createElement('div');
  box.className = PELANDO_PRICE_TEST_CLASS;
  box.dataset.dealId = dealId;
  // Shown once the deal turns out to be from a store the test knows.
  box.hidden = true;
  const button = doc.createElement('button');
  button.type = 'button';
  button.className = PELANDO_PRICE_TEST_CLASS + '-button';
  button.textContent = 'Testar Promoção';
  button.disabled = true;
  const status = doc.createElement('div');
  status.className = PELANDO_PRICE_TEST_CLASS + '-status';
  status.hidden = true;
  box.append(button, status);

  // Only to show the button: the test itself uses the deal as saved at the
  // click (the usual flow is fix the price, save, test). Unreadable deals
  // and other stores keep it hidden.
  deps.fetchDeal(dealId).then(
    function (deal) {
      if (PRICE_TEST_SUPPORTED_STORES.indexOf(priceTestRequestFromDeal(deal).store) === -1) return;
      box.hidden = false;
      button.disabled = false;
    },
    function () {}
  );
  button.addEventListener('click', function () {
    if (button.disabled) return;
    renderPriceTestStatus(status, { type: 'priceTest:progress', label: 'Lendo a promoção…' }, deps);
    priceTestArm(status, PELANDO_PRICE_TEST_SILENCE_MS, deps);
    deps.fetchDeal(dealId)
      .then(function (deal) {
        return deps.start(priceTestRequestFromDeal(deal));
      })
      .then(function (response) {
        if (response && response.started === false && response.dealId !== dealId) {
          priceTestDisarm(status);
          renderPriceTestStatus(
            status,
            { type: 'priceTest:needsHuman', message: 'Outro teste em andamento em outra promoção. Aguarde terminar.' },
            deps
          );
        }
      })
      .catch(function (err) {
        priceTestDisarm(status);
        renderPriceTestStatus(status, { type: 'priceTest:error', message: err.message }, deps);
      });
  });
  return box;
}

// The form field of the deal's title: the form-item holding a label that
// starts with "Título".
function priceTestTitleField(doc) {
  return (
    Array.from(doc.querySelectorAll('[data-slot="form-item"]')).find(function (item) {
      return Array.from(item.querySelectorAll('label')).some(function (label) {
        return /^t[ií]tulo/i.test((label.textContent || '').trim());
      });
    }) || null
  );
}

// Right below the deal's title field; without it, right below "Justificar ao
// usuário" (which syncBackofficeJustifyButton places first, in the same pass),
// floating with it while it floats. The backoffice is a single-page app: keep
// one box, for the deal in the URL.
function syncPriceTestButton(doc, pathname, deps) {
  const dealId = backofficeDealIdFromPath(pathname);
  let box = doc.querySelector('.' + PELANDO_PRICE_TEST_CLASS);
  if (box && box.dataset.dealId !== dealId) {
    box.remove();
    box = null;
  }
  if (!dealId) return;
  // Preferred spot: right below the deal's title field.
  const title = priceTestTitleField(doc);
  if (title) {
    if (!box) box = createPriceTestBox(doc, dealId, deps);
    if (box.classList.contains(PELANDO_PRICE_TEST_CLASS + '--floating')) box.classList.remove(PELANDO_PRICE_TEST_CLASS + '--floating');
    if (box.style.gridColumn) box.style.gridColumn = '';
    if (title.nextElementSibling !== box) title.insertAdjacentElement('afterend', box);
    return;
  }
  // Fallback: right below "Justificar ao usuário", floating with it.
  const justify = doc.querySelector('.' + PELANDO_BO_JUSTIFY_BUTTON_CLASS);
  if (!justify) return;
  if (!box) box = createPriceTestBox(doc, dealId, deps);
  box.classList.toggle(PELANDO_PRICE_TEST_CLASS + '--floating', justify.classList.contains(PELANDO_BO_JUSTIFY_FLOATING_CLASS));
  box.style.gridColumn = justify.style.gridColumn;
  if (justify.nextElementSibling !== box) justify.insertAdjacentElement('afterend', box);
}

function priceTestHandleMessage(doc, message, deps) {
  const box = doc.querySelector('.' + PELANDO_PRICE_TEST_CLASS);
  const status = doc.querySelector('.' + PELANDO_PRICE_TEST_CLASS + '-status');
  // The service worker runs one test for the whole browser: show only this
  // page's deal.
  if (!box || !status || message.dealId !== box.dataset.dealId) return;
  renderPriceTestStatus(status, message, deps);
  if (message.type === 'priceTest:progress') priceTestArm(status, PELANDO_PRICE_TEST_SILENCE_MS, deps);
  else if (message.type === 'priceTest:needsHuman') priceTestArm(status, PELANDO_PRICE_TEST_HUMAN_SILENCE_MS, deps);
  else priceTestDisarm(status);
}

// The service worker reports to the tab that asked (chrome.tabs.sendMessage).
function listenForPriceTestMessages(doc, deps) {
  chrome.runtime.onMessage.addListener(function (message) {
    if (message && typeof message.type === 'string' && message.type.indexOf('priceTest:') === 0) {
      priceTestHandleMessage(doc, message, deps);
    }
  });
}

const pelandoPriceTestDeps = {
  fetchDeal: function (dealId) {
    return fetchDealById(dealId);
  },
  start: function (request) {
    return sendExtensionMessage({ type: 'priceTest:start', request: request });
  },
  setTimer: function (fn, ms) {
    const id = setTimeout(fn, ms);
    return function () {
      clearTimeout(id);
    };
  },
  focusTab: function (tabId) {
    return sendExtensionMessage({ type: 'priceTest:focus', tabId: tabId }).catch(function () {
      // The tab is gone; nothing to show.
    });
  },
};

if (typeof module !== 'undefined' && module.exports) {
  module.exports = { PRICE_TEST_SUPPORTED_STORES, priceTestRequestFromDeal, syncPriceTestButton, priceTestHandleMessage, listenForPriceTestMessages };
}
