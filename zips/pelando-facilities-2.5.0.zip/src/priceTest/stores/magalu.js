// "Testar Promoção": the steps on Magalu's pages. The service worker
// (src/priceTest/runner.js) injects this file and compare.js into the Magalu
// tab and calls pelandoPriceTestStep(step, input), once per step and again
// after every page change: only function declarations at the top level, since
// a second const/let would throw. Each step answers { ok: true, ... } or
// { ok: false, code, detail }. No step finishes the purchase: every click
// goes through priceTestForbidden.
//
// Magalu's markup isn't ours and changes, so elements are found by their
// visible text and role, not by class.

// Text nodes under root, minus the ones no reader sees: script, style,
// noscript and template contents (JSON state, CSS, fallbacks).
function priceTestTextNodes(root) {
  const nodes = [];
  const walker = root.ownerDocument.createTreeWalker(root, NodeFilter.SHOW_TEXT);
  for (let node = walker.nextNode(); node; node = walker.nextNode()) {
    if (node.parentElement && node.parentElement.closest('script, style, noscript, template')) continue;
    nodes.push(node);
  }
  return nodes;
}

// Visible text, with separate text nodes joined by a space: a summary row
// written as <span>Total</span><span>R$ 1,00</span> reads "Total R$ 1,00".
function priceTestText(el) {
  if (!el) return '';
  return priceTestTextNodes(el)
    .map(function (node) {
      return node.nodeValue;
    })
    .join(' ')
    .replace(/\s+/g, ' ')
    .trim();
}

function priceTestIsVisible(el) {
  if (!el || !el.isConnected) return false;
  if (el.closest('[hidden], [aria-hidden="true"]')) return false;
  const view = el.ownerDocument.defaultView;
  for (let node = el; node && node.nodeType === 1; node = node.parentElement) {
    const style = view.getComputedStyle(node);
    if (style.display === 'none' || style.visibility === 'hidden') return false;
  }
  return true;
}

function priceTestLabelOf(el) {
  const own = el.tagName === 'INPUT' ? el.value : priceTestText(el);
  return (own || el.getAttribute('aria-label') || '').replace(/\s+/g, ' ').trim();
}

function priceTestFindClickable(doc, pattern) {
  const candidates = doc.querySelectorAll('button, a, [role="button"], input[type="submit"], input[type="button"]');
  return (
    Array.from(candidates).find(function (el) {
      return !el.disabled && priceTestIsVisible(el) && pattern.test(priceTestLabelOf(el));
    }) || null
  );
}

// Buttons that would place the order. "Pagar com Pix" is a payment option,
// not the order button, so any "Pagar" not followed by "com" is refused.
// Both the visible label and the aria-label are checked: either one naming
// the order is enough.
function priceTestForbidden(el) {
  const forbidden =
    /finalizar|confirmar (o )?(pedido|compra|pagamento)|^confirmar$|concluir (o )?(pedido|compra)|^concluir$|fazer (o )?pedido|realizar (o )?pedido|efetuar (o )?pagamento|^pagar(?! com\b)|gerar (o )?(c[oó]digo )?pix/i;
  const aria = (el.getAttribute('aria-label') || '').replace(/\s+/g, ' ').trim();
  return forbidden.test(priceTestLabelOf(el)) || forbidden.test(aria);
}

function priceTestClick(el) {
  if (priceTestForbidden(el)) throw new Error('Clique recusado: "' + priceTestLabelOf(el) + '"');
  el.click();
}

// The store's tab is a background tab, where Chrome runs timers about once a
// second at most. A message-channel task isn't held back like that.
function priceTestSoon(fn) {
  const channel = new MessageChannel();
  channel.port1.onmessage = function () {
    channel.port1.close();
    fn();
  };
  channel.port2.postMessage(0);
}

// For clicks that leave the page: the step answers before the page goes,
// or the answer is lost with it.
function priceTestClickSoon(el) {
  if (priceTestForbidden(el)) throw new Error('Clique recusado: "' + priceTestLabelOf(el) + '"');
  priceTestSoon(function () {
    el.click();
  });
}

// A check that runs while the page is being swapped (no body yet) finds
// nothing, rather than failing the step.
function priceTestTryFind(find) {
  try {
    return find();
  } catch (err) {
    return null;
  }
}

// Resolves with what find() returns once it's truthy, or null after
// timeoutMs. Pages fill in after their own requests, so steps wait: find()
// runs again on every change to the page, so a button is clicked the moment
// it shows (timers crawl in background tabs). Checked radios and typed
// values change no markup: a slow timer looks too.
function priceTestWaitFor(find, timeoutMs) {
  return new Promise(function (resolve) {
    const first = priceTestTryFind(find);
    if (first || timeoutMs <= 0) {
      resolve(first || null);
      return;
    }
    let finished = false;
    function finish(value) {
      if (finished) return;
      finished = true;
      observer.disconnect();
      clearInterval(fallback);
      clearTimeout(limit);
      resolve(value || null);
    }
    function check() {
      if (finished) return;
      const found = priceTestTryFind(find);
      if (found) finish(found);
    }
    const observer = new MutationObserver(check);
    observer.observe(document.documentElement, { childList: true, subtree: true, attributes: true, characterData: true });
    const fallback = setInterval(check, 250);
    const limit = setTimeout(function () {
      finish(priceTestTryFind(find));
    }, timeoutMs);
  });
}

// What stops any step: a login form or login route (the session expired) or a captcha
// challenge (someone has to solve it). The invisible reCAPTCHA badge is no
// challenge; its challenge frame is "bframe".
function priceTestBlocker(doc) {
  const view = doc.defaultView;
  const href = view && view.location ? String(view.location.href) : '';
  if (/\/cliente\/login|[#/]login\b/i.test(href)) return { ok: false, code: 'SESSION_EXPIRED' };
  const password = Array.from(doc.querySelectorAll('input[type="password"]')).some(priceTestIsVisible);
  if (password) return { ok: false, code: 'SESSION_EXPIRED' };
  const challenges = doc.querySelectorAll(
    'iframe[src*="recaptcha/api2/bframe"], iframe[src*="recaptcha/enterprise/bframe"], iframe[src*="hcaptcha"], iframe[title*="desafio" i], iframe[title*="challenge" i]'
  );
  if (Array.from(challenges).some(priceTestIsVisible)) return { ok: false, code: 'NEEDS_HUMAN' };
  return null;
}

function priceTestMissing(element) {
  return { ok: false, code: 'SELECTOR_NOT_FOUND', detail: { element: element } };
}

// Only text a person can see counts: a hidden or script-embedded phrase is
// not the page saying the product is out of stock.
function magaluOutOfStock(doc) {
  const pattern = /produto indispon[ií]vel|avise-me quando chegar|produto esgotado/i;
  return priceTestTextNodes(doc.body).some(function (node) {
    return pattern.test(node.nodeValue) && priceTestIsVisible(node.parentElement);
  });
}

// Variant pickers (size, color...): each option links to its variant's page.
// Disabled options are sold out.
function magaluVariantGroups(doc) {
  return Array.from(doc.querySelectorAll('[data-testid="attribute-type"]'))
    .map(function (group) {
      return Array.from(group.querySelectorAll('[data-testid="attribute-option"]')).filter(priceTestIsVisible);
    })
    .filter(function (options) {
      return options.length > 0;
    });
}

function magaluOptionOnSale(option) {
  return option.getAttribute('aria-disabled') !== 'true' && !option.hasAttribute('disabled');
}

// The option that links to this very page: the deal's own variant.
function magaluOwnVariant(doc, options) {
  const here = doc.defaultView.location;
  return (
    options.find(function (option) {
      const href = option.getAttribute('href');
      return href && new URL(href, here.href).pathname === here.pathname;
    }) || null
  );
}

// The product page works out shipping to the account's CEP after loading:
// "Enviar para ... Calcular" until then, "... Alterar" with the delivery
// ("Receba entre...") or "Produto esgotado!" after. Only then is the stock
// known: "Comprar agora" starts on even for a product out of stock.
function magaluShippingKnown(doc) {
  if (priceTestFindClickable(doc, /^enviar para\b.*\balterar$/i)) return true;
  return priceTestTextNodes(doc.body).some(function (node) {
    return /^\s*receba\b/i.test(node.nodeValue) && priceTestIsVisible(node.parentElement);
  });
}

async function magaluCheckProduct(doc, input) {
  const blocked = priceTestBlocker(doc);
  if (blocked) return blocked;
  if (magaluOutOfStock(doc)) return { ok: false, code: 'OUT_OF_STOCK' };
  const buy = await priceTestWaitFor(function () {
    return priceTestFindClickable(doc, /comprar agora/i);
  }, input.timeoutMs);
  if (buy) {
    // The store works shipping out only once its box is on screen (a small
    // window, a long page): bring it into view, once.
    let scrolled = false;
    await priceTestWaitFor(function () {
      if (magaluOutOfStock(doc) || magaluShippingKnown(doc)) return true;
      const box = !scrolled && priceTestFindClickable(doc, /^enviar para\b/i);
      if (box && typeof box.scrollIntoView === 'function') {
        scrolled = true;
        box.scrollIntoView({ block: 'center' });
      }
      return false;
    }, Math.min(6000, input.timeoutMs));
    if (magaluOutOfStock(doc)) return { ok: false, code: 'OUT_OF_STOCK' };
    // A link to a product with variants but none of its own (a parent
    // product): go to the first variant on sale.
    const loose = magaluVariantGroups(doc).find(function (options) {
      return !magaluOwnVariant(doc, options);
    });
    const first = loose && loose.find(magaluOptionOnSale);
    if (!first) return { ok: true };
    priceTestClickSoon(first);
    return { ok: true, navigates: true };
  }
  if (magaluOutOfStock(doc)) return { ok: false, code: 'OUT_OF_STOCK' };
  return priceTestBlocker(doc) || priceTestMissing('Comprar agora');
}

async function magaluBuyNow(doc, input) {
  const blocked = priceTestBlocker(doc);
  if (blocked) return blocked;
  const buy = priceTestFindClickable(doc, /comprar agora/i);
  if (!buy) return magaluOutOfStock(doc) ? { ok: false, code: 'OUT_OF_STOCK' } : priceTestMissing('Comprar agora');
  // The page shows the deal's variant but wants it picked ("Selecione o
  // campo tamanho"): click it, which stays on the page.
  magaluVariantGroups(doc).forEach(function (options) {
    const own = magaluOwnVariant(doc, options);
    if (own && magaluOptionOnSale(own)) priceTestClick(own);
  });
  priceTestClickSoon(buy);
  return { ok: true, navigates: true };
}

// Some products offer an extended warranty ("Proteção") between "Comprar
// agora" and the delivery page: always "Agora não". Without the offer the
// delivery page shows up and the step passes untouched.
async function magaluSkipProtection(doc, input) {
  const blocked = priceTestBlocker(doc);
  if (blocked) return blocked;
  const seen = await priceTestWaitFor(function () {
    const decline = priceTestFindClickable(doc, /^agora n[aã]o$/i);
    if (decline) return { decline: decline };
    return magaluAddressOptions(doc).length || magaluShippingOptions(doc).length || magaluAmountRow(doc, /^(frete|entrega)\b/i) ? { decline: null } : null;
  }, input.timeoutMs);
  if (!seen || !seen.decline) return priceTestBlocker(doc) || { ok: true };
  priceTestClickSoon(seen.decline);
  return { ok: true, navigates: true };
}

// The saved addresses (sacola.../#/endereco): radios whose label shows a CEP.
function magaluAddressOptions(doc) {
  return priceTestRadios(doc).filter(function (option) {
    return /\bCEP\b/.test(option.text) && priceTestIsVisible(option.label);
  });
}

// The default address is the one card without "Tornar padrão".
function magaluDefaultAddress(doc) {
  return (
    magaluAddressOptions(doc).find(function (option) {
      const card = option.radio.parentElement || option.label;
      return !Array.from(card.querySelectorAll('button, a, [role="button"]')).some(function (el) {
        return /tornar padr[aã]o/i.test(priceTestLabelOf(el));
      });
    }) || null
  );
}

// Sometimes the checkout asks for the address before the delivery page, with
// none selected: always the account's default, then "Continuar". Only the
// radio and "Continuar" are clicked, never "Tornar padrão", "Editar" or
// "Excluir". When the delivery page comes straight away, the step passes.
async function magaluPickAddress(doc, input) {
  const blocked = priceTestBlocker(doc);
  if (blocked) return blocked;
  const page = await priceTestWaitFor(function () {
    if (magaluAddressOptions(doc).length) return 'addresses';
    return magaluShippingOptions(doc).length || magaluAmountRow(doc, /^(frete|entrega)\b/i) ? 'delivery' : null;
  }, input.timeoutMs);
  if (page !== 'addresses') return priceTestBlocker(doc) || { ok: true };
  const chosen = magaluDefaultAddress(doc);
  if (!chosen) return priceTestMissing('endereço padrão');
  if (!priceTestIsChosen(chosen.radio)) priceTestClick(chosen.radio);
  // "Continuar" turns on once an address is selected.
  const next = await priceTestWaitFor(function () {
    return priceTestFindClickable(doc, /^continuar$/i);
  }, input.timeoutMs);
  if (!next) return priceTestMissing('Continuar');
  priceTestClickSoon(next);
  return { ok: true, navigates: true };
}

// The text describing a radio: a role="radio" element's own text, an input's
// <label> (wrapping or by `for`), or else its parent.
function priceTestRadioLabel(doc, radio) {
  if (radio.tagName !== 'INPUT') return radio;
  const wrapping = radio.closest('label');
  if (wrapping) return wrapping;
  const byFor = radio.id && Array.from(doc.querySelectorAll('label')).find(function (label) {
    return label.htmlFor === radio.id;
  });
  return byFor || radio.parentElement;
}

// A hidden input inside a role="radio" wrapper is the same option: only the
// wrapper counts.
function priceTestRadios(doc) {
  const radios = Array.from(doc.querySelectorAll('input[type="radio"], [role="radio"]')).filter(function (radio) {
    return radio.tagName !== 'INPUT' || !(radio.parentElement && radio.parentElement.closest('[role="radio"]'));
  });
  return radios.map(function (radio) {
    const label = priceTestRadioLabel(doc, radio);
    return { radio: radio, label: label, text: priceTestText(label) };
  });
}

function priceTestIsChosen(radio) {
  return radio.checked === true || radio.getAttribute('aria-checked') === 'true';
}

// The smallest visible element whose text starts with the label and shows
// an amount or "Grátis" - a summary row like "Total R$ 1.299,00". The last
// one on the page when there are several: the summary comes last.
function magaluAmountRow(doc, label) {
  const row = magaluAmountRowElement(doc, label);
  return row ? priceTestText(row) : null;
}

function magaluAmountRowElement(doc, label) {
  const rows = Array.from(doc.body.querySelectorAll('*')).filter(function (el) {
    const text = priceTestText(el);
    return text.length <= 80 && label.test(text) && /R\$\s?[\d.]+,\d{2}|gr[aá]tis/i.test(text) && priceTestIsVisible(el);
  });
  const smallest = rows.filter(function (el) {
    return !rows.some(function (other) {
      return other !== el && el.contains(other);
    });
  });
  return smallest.length ? smallest[smallest.length - 1] : null;
}

// While the review recalculates, Magalu blurs the page behind a spinner.
function magaluPageBlurred(doc) {
  const view = doc.defaultView;
  return Array.from(doc.body.querySelectorAll('*')).some(function (el) {
    const style = view.getComputedStyle(el);
    return /blur\(/.test(style.filter + ' ' + (style.backdropFilter || '')) && priceTestIsVisible(el);
  });
}

// The review's values block: from "Produtos" down to "Total da sacola".
function magaluValuesBlock(doc) {
  const total = magaluAmountRowElement(doc, /^total\b/i);
  for (let box = total; box && box !== doc.body; box = box.parentElement) {
    const text = priceTestText(box);
    if (/produtos/i.test(text) && /frete/i.test(text)) return box;
  }
  return total;
}

// Where the values are on screen, once the page is clear, for the picture
// the service worker crops (runner.js). In CSS pixels, with a small margin.
async function magaluFrameTotals(doc, input) {
  const block = await priceTestWaitFor(function () {
    return magaluPageBlurred(doc) ? null : magaluValuesBlock(doc);
  }, input.timeoutMs);
  if (!block) return priceTestMissing('valores na tela');
  if (typeof block.scrollIntoView === 'function') block.scrollIntoView({ block: 'center' });
  const rect = block.getBoundingClientRect();
  const margin = 8;
  return {
    ok: true,
    area: {
      x: Math.max(0, Math.floor(rect.left - margin)),
      y: Math.max(0, Math.floor(rect.top - margin)),
      width: Math.ceil(rect.width + margin * 2),
      height: Math.ceil(rect.height + margin * 2),
      viewportWidth: doc.defaultView.innerWidth,
    },
  };
}

// Shipping choices: radios whose label shows a price or "Grátis", minus the
// payment ones. Store pickup ("Retire na loja") is marked: the test always
// ships to the account's default address, the one the page already shows.
function magaluShippingOptions(doc) {
  return priceTestRadios(doc)
    .filter(function (option) {
      return /gr[aá]tis|R\$\s?\d/i.test(option.text) && !/\bpix\b|cart[aã]o|boleto/i.test(option.text) && priceTestIsVisible(option.label);
    })
    .map(function (option) {
      option.cents = /gr[aá]tis/i.test(option.text) ? 0 : priceTestCents(option.text);
      option.pickup = /retir(e|ar|ada)\b/i.test(option.text);
      return option;
    });
}

async function magaluPickShipping(doc, input) {
  const blocked = priceTestBlocker(doc);
  if (blocked) return blocked;
  const found = await priceTestWaitFor(function () {
    const all = magaluShippingOptions(doc);
    return all.length || magaluAmountRow(doc, /^(frete|entrega)\b/i) ? all : null;
  }, input.timeoutMs);
  if (!found) return priceTestBlocker(doc) || priceTestMissing('opções de frete');
  const options = found.filter(function (option) {
    return !option.pickup;
  });
  if (found.length && !options.length) return priceTestMissing('entrega no endereço');
  if (options.length) {
    const cheapest = options.reduce(function (best, option) {
      return option.cents !== null && (best.cents === null || option.cents < best.cents) ? option : best;
    });
    if (!priceTestIsChosen(cheapest.radio)) priceTestClick(cheapest.radio);
  }
  const next = priceTestFindClickable(doc, /^(continuar|ir para (o )?pagamento|seguir para (o )?pagamento)$/i);
  if (!next) return { ok: true };
  priceTestClickSoon(next);
  return { ok: true, navigates: true };
}

function magaluCouponField(doc) {
  return (
    Array.from(doc.querySelectorAll('input:not([type]), input[type="text"], input[type="search"]')).find(function (field) {
      const hint = [field.placeholder, field.getAttribute('aria-label'), field.name, field.id].join(' ');
      return /cupom|coupon/i.test(hint) && priceTestIsVisible(field);
    }) || null
  );
}

// Typing that a React page notices: its own value setter, then the events.
function priceTestType(field, value) {
  const setter = Object.getOwnPropertyDescriptor(field.ownerDocument.defaultView.HTMLInputElement.prototype, 'value').set;
  setter.call(field, value);
  field.dispatchEvent(new field.ownerDocument.defaultView.Event('input', { bubbles: true }));
  field.dispatchEvent(new field.ownerDocument.defaultView.Event('change', { bubbles: true }));
}

// A message matching the pattern inside the coupon box (the smallest element
// holding the field and its button), so text elsewhere on the page
// ("Retirada na loja não disponível") doesn't count.
function magaluCouponMessage(field, button, pattern) {
  let box = field.parentElement;
  while (box && !box.contains(button)) box = box.parentElement;
  const scope = box || field.ownerDocument.body;
  const found = Array.from(scope.querySelectorAll('*')).find(function (el) {
    const text = priceTestText(el);
    return el.children.length === 0 && text.length <= 200 && pattern.test(text) && priceTestIsVisible(el);
  });
  return found ? priceTestText(found) : null;
}

// True when the text around the element (its parent or grandparent, a row
// like "Tem um código de cupom? [Inserir]") talks about coupons.
function magaluNearCoupon(el) {
  const near = [el.parentElement, el.parentElement && el.parentElement.parentElement];
  return near.some(function (box) {
    const text = priceTestText(box);
    return text.length <= 200 && /cupom/i.test(text);
  });
}

// The button that opens a collapsed coupon box: "Adicionar cupom", "Tenho um
// cupom"... or a bare "Inserir" in a row that mentions coupons ("Tem um código
// de cupom? Inserir"), but not "Remover cupom", and not a link that leaves the page.
function magaluCouponToggle(doc) {
  const pattern = /^(adicionar|inserir|usar|tenho( um)?|aplicar)? ?cupom( de desconto)?$/i;
  const bare = /^(inserir|adicionar)( cupom)?$/i;
  const candidates = doc.querySelectorAll('button, a, [role="button"]');
  return (
    Array.from(candidates).find(function (el) {
      const href = el.tagName === 'A' ? el.getAttribute('href') : null;
      if (href && href.charAt(0) !== '#' && !/^javascript:/i.test(href)) return false;
      if (el.disabled || !priceTestIsVisible(el)) return false;
      const label = priceTestLabelOf(el);
      return pattern.test(label) || (bare.test(label) && magaluNearCoupon(el));
    }) || null
  );
}

function magaluCouponRefusal() {
  return /inv[aá]lid|inativ|expirad|n[aã]o (é |foi )?(v[aá]lid|aplic|aceit|encontrad|dispon)|n[aã]o est(á|a|ar) (mais )?(ativo|dispon[ií]vel|v[aá]lido)|esgotad/i;
}

// The field the store marked invalid (aria-invalid), with the message it
// points at (aria-describedby): Magalu's own way of refusing a code.
function magaluCouponFlaggedMessage(field) {
  if (field.getAttribute('aria-invalid') !== 'true') return null;
  const ids = (field.getAttribute('aria-describedby') || '').split(/\s+/).filter(Boolean);
  const texts = ids
    .map(function (id) {
      const el = field.ownerDocument.getElementById(id);
      return el && priceTestIsVisible(el) ? priceTestText(el) : '';
    })
    .filter(Boolean);
  return texts.length ? texts.join(' ') : null;
}

async function magaluApplyCoupon(doc, input) {
  const blocked = priceTestBlocker(doc);
  if (blocked) return blocked;
  let field = magaluCouponField(doc);
  if (!field) {
    // The page may not take clicks yet right after loading: while no field
    // shows, click the opener again every couple of seconds, a few times.
    let clicks = 0;
    let lastClick = 0;
    const open = function () {
      const toggle = magaluCouponToggle(doc);
      if (!toggle) return;
      priceTestClick(toggle);
      clicks += 1;
      lastClick = Date.now();
    };
    open();
    field = await priceTestWaitFor(function () {
      const found = magaluCouponField(doc);
      if (!found && clicks < 6 && Date.now() - lastClick >= 2000) open();
      return found;
    }, input.timeoutMs);
  }
  if (!field) return priceTestMissing('campo de cupom');
  priceTestType(field, input.coupon);
  const apply = priceTestFindClickable(doc, /^aplicar( cupom)?$/i);
  if (!apply) return priceTestMissing('Aplicar cupom');
  priceTestClick(apply);
  const outcome = await priceTestWaitFor(function () {
    // The page may re-render the modal: look at the field and button as they
    // are now, not the ones captured before the click.
    const current = magaluCouponField(doc);
    if (current) {
      const flagged = magaluCouponFlaggedMessage(current);
      if (flagged) return { ok: false, code: 'COUPON_REJECTED', detail: { message: flagged } };
      const button = priceTestFindClickable(doc, /^aplicar( cupom)?$/i) || apply;
      const refused = magaluCouponMessage(current, button, magaluCouponRefusal());
      if (refused) return { ok: false, code: 'COUPON_REJECTED', detail: { message: refused } };
      if (magaluCouponMessage(current, button, /cupom aplicado|desconto aplicado|cupom adicionado/i)) return { ok: true };
      return null;
    }
    // No coupon field anywhere: the modal closed. Accepted, unless a refusal
    // shows elsewhere on the page (a toast outside the modal).
    const toast = priceTestTextNodes(doc.body).find(function (node) {
      return magaluCouponRefusal().test(node.nodeValue) && priceTestIsVisible(node.parentElement);
    });
    if (toast) return { ok: false, code: 'COUPON_REJECTED', detail: { message: priceTestText(toast.parentElement) } };
    return { ok: true };
  }, input.timeoutMs);
  return outcome || priceTestMissing('resposta do cupom');
}

// A refused coupon doesn't stop the test: close the coupon dialog ("Fechar")
// and go on to PIX, telling the refusal so the result can show the price
// without the coupon.
async function magaluTryCoupon(doc, input) {
  const result = await magaluApplyCoupon(doc, input);
  if (result.ok || result.code !== 'COUPON_REJECTED') return result;
  const field = magaluCouponField(doc);
  if (field) {
    const dialog = field.closest('[role="dialog"], [aria-modal="true"]') || doc.body;
    const close = Array.from(dialog.querySelectorAll('button, [role="button"]')).find(function (el) {
      const label = (el.getAttribute('aria-label') || priceTestText(el)).trim();
      return /^(fechar|close|×|x)$/i.test(label) && priceTestIsVisible(el);
    });
    if (!close) return priceTestMissing('Fechar cupom');
    priceTestClick(close);
    const closed = await priceTestWaitFor(function () {
      return !magaluCouponField(doc);
    }, input.timeoutMs);
    if (!closed) return priceTestMissing('Fechar cupom');
  }
  return { ok: true, couponRejected: result.detail.message };
}

// The PIX option: a radio, or (on Magalu's payment page) a list item, button
// or option whose visible text starts with "Pix". Other options ("Novo cartão
// de crédito", "Mastercard 0244") never match.
function magaluPixOption(doc) {
  const radio = priceTestRadios(doc).find(function (option) {
    return /^pix\b/i.test(option.text) && option.text.length <= 80 && priceTestIsVisible(option.label);
  });
  if (radio) return { el: radio.radio, radio: true };
  const item = Array.from(doc.querySelectorAll('li, button, label, [role="option"], [role="button"]')).find(function (el) {
    const text = priceTestText(el);
    return /^pix\b/i.test(text) && text.length <= 80 && !el.querySelector('input[type="radio"], [role="radio"]') && !el.disabled && priceTestIsVisible(el);
  });
  return item ? { el: item, radio: false } : null;
}

async function magaluSelectPix(doc, input) {
  const blocked = priceTestBlocker(doc);
  if (blocked) return blocked;
  const pix = await priceTestWaitFor(function () {
    return magaluPixOption(doc);
  }, input.timeoutMs);
  if (!pix) return priceTestBlocker(doc) || priceTestMissing('PIX');
  if (pix.radio) {
    if (!priceTestIsChosen(pix.el)) priceTestClick(pix.el);
    return { ok: true };
  }
  // Clicking the item takes the page to the review in the same document. A
  // click that lands too early is lost: either the page doesn't move (it was
  // re-rendering after the coupon dialog closed), or the review sends it back
  // to the payment page. Either way, find the item again and click once more.
  // The payment page keeps building for a moment after Pix shows (the
  // subtotal changes, then Pix's "Desconto de R$ ..."), and a click before
  // that bounces back from the review. Wait for Pix's discount, or for the
  // page to stop changing.
  await priceTestSettle(
    doc,
    function () {
      const option = magaluPixOption(doc);
      return !!option && /desconto/i.test(priceTestText(option.el));
    },
    1000,
    Math.min(5000, input.timeoutMs)
  );
  const settled = magaluPixOption(doc);
  const view = doc.defaultView;
  const from = view.location.href;
  let item = settled && !settled.radio ? settled.el : pix.el;
  for (let attempt = 0; attempt < 3 && item; attempt++) {
    priceTestClick(item);
    const left = await priceTestWaitFor(function () {
      return view.location.href !== from;
    }, Math.min(1500, input.timeoutMs));
    if (left) {
      const where = await priceTestWaitFor(function () {
        if (magaluReviewReady(doc)) return 'review';
        return view.location.href === from && magaluPixOption(doc) ? 'back' : null;
      }, Math.min(6000, input.timeoutMs));
      if (where === 'review' || (!where && view.location.href !== from)) return { ok: true };
    }
    const again = magaluPixOption(doc);
    item = again && !again.radio ? again.el : null;
  }
  return priceTestBlocker(doc) || priceTestMissing('revisão do pedido');
}

// Resolves once ready() holds, or the page has not changed for quietMs, or
// after maxMs at most.
function priceTestSettle(doc, ready, quietMs, maxMs) {
  return new Promise(function (resolve) {
    if (maxMs <= 0 || priceTestTryFind(ready)) {
      resolve();
      return;
    }
    let finished = false;
    let quiet = setTimeout(done, quietMs);
    const limit = setTimeout(done, maxMs);
    const observer = new MutationObserver(function () {
      if (priceTestTryFind(ready)) {
        done();
        return;
      }
      clearTimeout(quiet);
      quiet = setTimeout(done, quietMs);
    });
    observer.observe(doc.documentElement, { childList: true, subtree: true, attributes: true, characterData: true });
    function done() {
      if (finished) return;
      finished = true;
      observer.disconnect();
      clearTimeout(quiet);
      clearTimeout(limit);
      resolve();
    }
  });
}

// The review page once it has taken the payment: "Alterar pagamento" and
// the payment block's "Valor total".
function magaluReviewReady(doc) {
  return !!priceTestFindClickable(doc, /^alterar pagamento$/i) && !!magaluAmountRow(doc, /^valor total\b/i);
}

async function magaluReadTotals(doc, input) {
  const blocked = priceTestBlocker(doc);
  if (blocked) return blocked;
  const total = await priceTestWaitFor(function () {
    const bag = magaluAmountRow(doc, /^total\b/i);
    if (!bag) return null;
    // On the review page the bag total first shows without the Pix
    // discount: it counts once the payment block ("Valor total") agrees.
    if (!priceTestFindClickable(doc, /^alterar pagamento$/i)) return bag;
    const paid = magaluAmountRow(doc, /^valor total\b/i);
    return paid && priceTestCents(paid) === priceTestCents(bag) ? bag : null;
  }, input.timeoutMs);
  if (!total) return priceTestBlocker(doc) || priceTestMissing('Total');
  return { ok: true, totalText: total, shippingText: magaluAmountRow(doc, /^(frete|entrega)\b/i) || '' };
}

// What the service worker calls after injecting this file.
function pelandoPriceTestStep(step, input) {
  const steps = {
    checkProduct: magaluCheckProduct,
    buyNow: magaluBuyNow,
    skipProtection: magaluSkipProtection,
    pickAddress: magaluPickAddress,
    pickShipping: magaluPickShipping,
    applyCoupon: magaluTryCoupon,
    selectPix: magaluSelectPix,
    readTotals: magaluReadTotals,
    frameTotals: magaluFrameTotals,
  };
  if (!steps[step]) return Promise.resolve({ ok: false, code: 'STEP_FAILED', detail: { message: 'Etapa desconhecida: ' + step } });
  // A step that leaves the page flags it, so the service worker can tell the
  // next page from this one (priceTestNewPageProbe in runner.js).
  window.pelandoPriceTestLeft = false;
  return Promise.resolve()
    .then(function () {
      return steps[step](document, input);
    })
    .then(function (result) {
      if (result && result.navigates) window.pelandoPriceTestLeft = true;
      return result;
    })
    .catch(function (err) {
      return { ok: false, code: 'STEP_FAILED', detail: { message: err.message } };
    });
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = {
    priceTestText,
    priceTestIsVisible,
    priceTestLabelOf,
    priceTestFindClickable,
    priceTestForbidden,
    priceTestClick,
    priceTestClickSoon,
    priceTestWaitFor,
    priceTestBlocker,
    priceTestMissing,
    magaluCheckProduct,
    magaluBuyNow,
    magaluSkipProtection,
    magaluPickAddress,
    magaluPickShipping,
    magaluApplyCoupon,
    magaluTryCoupon,
    magaluSelectPix,
    magaluReadTotals,
    magaluFrameTotals,
    pelandoPriceTestStep,
  };
}
