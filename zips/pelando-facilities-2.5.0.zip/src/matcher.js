function normalizeText(text) {
  return String(text == null ? '' : text)
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase();
}

function detectTheme(themes, text) {
  if (!text) return null;
  const normalizedText = normalizeText(text);
  const matches = themes.filter((theme) =>
    (theme.palavrasChave || []).some((keyword) => normalizedText.includes(normalizeText(keyword)))
  );
  return matches.length === 1 ? matches[0].id : null;
}

// Searches only start from this many typed characters.
const PELANDO_CHAT_EXT_SEARCH_MIN_LENGTH = 3;

// Messages from any theme whose title or text holds every word of `query`,
// ignoring accents and case; title matches come first. Shorter queries find
// nothing, so a couple of letters don't list every message.
function searchMessages(messages, query) {
  const normalizedQuery = normalizeText(query).trim();
  if (normalizedQuery.length < PELANDO_CHAT_EXT_SEARCH_MIN_LENGTH) return [];
  const words = normalizedQuery.split(/\s+/);
  const found = [];
  messages.forEach(function (message) {
    const title = normalizeText(message.nome);
    const content = title + ' ' + normalizeText(message.texto);
    const matches = words.every(function (word) {
      return content.includes(word);
    });
    if (!matches) return;
    const inTitle = words.every(function (word) {
      return title.includes(word);
    });
    found.push({ message: message, inTitle: inTitle });
  });
  return found
    .filter(function (entry) {
      return entry.inTitle;
    })
    .concat(
      found.filter(function (entry) {
        return !entry.inTitle;
      })
    )
    .map(function (entry) {
      return entry.message;
    });
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = { normalizeText, detectTheme, searchMessages, PELANDO_CHAT_EXT_SEARCH_MIN_LENGTH };
}
